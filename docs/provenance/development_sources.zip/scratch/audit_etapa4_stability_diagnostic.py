import pandas as pd
import numpy as np

# Load annual and monthly datasets
df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

main = df_ann[df_ann['main_sample'] == 1].copy()
main['D'] = main['regime'].isin(['AN', 'NA']).astype(int)

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

print("=== ETAPA 4: DIAGNÓSTICO MATEMÁTICO DA ESTABILIDADE TEMPORAL S ===")

# Compute monthly argmax for valid months
valid_mon = df_mon[df_mon['month_valid'] == 1].copy()
valid_mon['monthly_argmax_idx'] = np.argmax(valid_mon[DW_CLASSES].values, axis=1)
valid_mon['monthly_argmax_class'] = [DW_CLASSES[i] for i in valid_mon['monthly_argmax_idx']]

# Group by sample_id to find:
# 1. unique monthly classes
# 2. count of months where monthly argmax == annual class
mon_summary = valid_mon.groupby('sample_id').agg(
    n_valid_calc=('month', 'count'),
    monthly_classes_set=('monthly_argmax_class', lambda s: set(s)),
    monthly_classes_list=('monthly_argmax_class', list)
).reset_index()

merged = pd.merge(main, mon_summary, on='sample_id', how='left')

# Check if annual_class is in monthly_classes_set
merged['annual_in_monthly'] = [
    row['annual_class'] in row['monthly_classes_set']
    for _, row in merged.iterrows()
]
merged['annual_never_monthly'] = ~merged['annual_in_monthly']

print(f"Total pontos main: {len(merged)}")
print(f"Pontos com S == 0.0: {(merged['stability'] == 0.0).sum()} ({(merged['stability'] == 0.0).mean()*100:.2f}%)")
print(f"Pontos onde a classe anual NUNCA foi argmax mensal: {merged['annual_never_monthly'].sum()} ({merged['annual_never_monthly'].mean()*100:.2f}%)")

print("\n--- Distribuição de S == 0 por Regime ---")
reg_s0 = merged.groupby('regime').agg(
    total=('sample_id', 'count'),
    s_zero=('stability', lambda s: (s == 0.0).sum()),
    annual_never_monthly=('annual_never_monthly', 'sum')
)
reg_s0['pct_s_zero'] = reg_s0['s_zero'] / reg_s0['total'] * 100
reg_s0['pct_never_monthly'] = reg_s0['annual_never_monthly'] / reg_s0['total'] * 100
print(reg_s0)

print("\n--- Distribuição de S == 0 por Concordância (D=0 vs D=1) ---")
d_s0 = merged.groupby('D').agg(
    total=('sample_id', 'count'),
    s_zero=('stability', lambda s: (s == 0.0).sum()),
    annual_never_monthly=('annual_never_monthly', 'sum'),
    s_mean=('stability', 'mean'),
    s_median=('stability', 'median'),
    s_q1=('stability', lambda s: np.percentile(s, 25)),
    s_q3=('stability', lambda s: np.percentile(s, 75))
)
d_s0['pct_s_zero'] = d_s0['s_zero'] / d_s0['total'] * 100
d_s0['pct_never_monthly'] = d_s0['annual_never_monthly'] / d_s0['total'] * 100
print(d_s0)

print("\n=== ETAPA 7: ASSIMETRIA DE DISCORDÂNCIAS (AN vs NA) ===")
# Annual DW classes in AN (MapBiomas crop, DW noncrop)
an_pts = merged[merged['regime'] == 'AN']
na_pts = merged[merged['regime'] == 'NA']
print(f"Pontos AN: {len(an_pts)} ({len(an_pts)/len(merged)*100:.2f}% unweighted, {merged[merged['regime']=='AN']['design_weight_main'].astype(float).sum()/merged['design_weight_main'].astype(float).sum()*100:.2f}% weighted)")
print(f"Pontos NA: {len(na_pts)} ({len(na_pts)/len(merged)*100:.2f}% unweighted, {merged[merged['regime']=='NA']['design_weight_main'].astype(float).sum()/merged['design_weight_main'].astype(float).sum()*100:.2f}% weighted)")

print("\nClasses anuais do Dynamic World nos pontos AN (onde MapBiomas diz lavoura):")
an_dw_classes = an_pts['annual_class'].value_counts()
an_dw_classes_weighted = an_pts.groupby('annual_class')['design_weight_main'].apply(lambda w: w.astype(float).sum())
an_dw_classes_weighted_pct = an_dw_classes_weighted / an_dw_classes_weighted.sum() * 100
df_an_classes = pd.DataFrame({
    'n_points': an_dw_classes,
    'pct_unweighted': an_dw_classes / len(an_pts) * 100,
    'pct_weighted': an_dw_classes_weighted_pct
})
print(df_an_classes)

print("\nClasses do MapBiomas nos pontos NA (onde DW diz crops):")
na_mb_classes = na_pts['mapbiomas_class'].value_counts()
na_mb_classes_weighted = na_pts.groupby('mapbiomas_class')['design_weight_main'].apply(lambda w: w.astype(float).sum())
na_mb_classes_weighted_pct = na_mb_classes_weighted / na_mb_classes_weighted.sum() * 100
df_na_classes = pd.DataFrame({
    'n_points': na_mb_classes,
    'pct_unweighted': na_mb_classes / len(na_pts) * 100,
    'pct_weighted': na_mb_classes_weighted_pct
})
print(df_na_classes)

# Save merged with diagnostics for example extraction
merged.to_parquet('scratch/diagnostic_stability_merged.parquet', index=False)
print("\nSalvo scratch/diagnostic_stability_merged.parquet")
