import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import ee
import json
import pandas as pd
import numpy as np

PROJECT_ID = "dynamicworld-x-mapbiomas"
ee.Initialize(project=PROJECT_ID)

from src.gee.dw_annual import (
    DW_PROB_BANDS,
    DW_START,
    DW_END,
    DW_COLLECTION,
    get_mapbiomas_projection,
    get_source_support_domain,
    DATES_CACHE_PATH,
    build_dw_annual_2025
)

mb_proj = get_mapbiomas_projection()
source_domain = get_source_support_domain()

# Load the 33 pilot points
df_pilot = pd.read_csv('scratch/pilot_sample_points.csv')
print(f"Testando {len(df_pilot)} pontos piloto no GEE...")

# Build feature collection
features = [
    ee.Feature(
        ee.Geometry.Point([row['lon'], row['lat']]),
        {'sample_id': row['sample_id'], 'state': row['state'], 'regime': row['regime']}
    )
    for _, row in df_pilot.iterrows()
]
fc = ee.FeatureCollection(features)

# 1. Authoritative Annual Stack
dw_ann = build_dw_annual_2025()
auth_stack = ee.Image.cat([
    dw_ann["normalized_probs"].rename([f"auth_p_{b}" for b in DW_PROB_BANDS]),
    dw_ann["raw_prob_sum"].rename("auth_raw_prob_sum"),
    dw_ann["annual_class_index"].rename("auth_annual_class_index"),
    dw_ann["dw_crop"].rename("auth_dw_crop"),
    dw_ann["n_valid_months"].rename("auth_n_valid_months"),
])

# 2. Build monthly stacks:
# Approach RAW (original in 11_extract) vs Approach BILINEAR (resampled on mb_proj)
with open(DATES_CACHE_PATH, "r", encoding="utf-8") as f:
    dates_dict = json.load(f)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterDate(DW_START, DW_END)
    .filterBounds(source_domain)
)

raw_bands = []
bil_bands = []

for m in range(1, 13):
    start = f"2025-{m:02d}-01"
    end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
    dw_m = dw_col.filterDate(start, end)
    dates_m = ee.List(dates_dict[f"{m:02d}"])

    def make_daily(d):
        d_start = ee.Date(d)
        d_end = d_start.advance(1, "day")
        return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().toFloat().set("date", d)

    daily_col = ee.ImageCollection(dates_m.map(make_daily))
    comp_m = daily_col.mean().select(DW_PROB_BANDS).toFloat()
    n_days = daily_col.select("water").count()
    
    # RAW (unresampled)
    prob_sum_raw = comp_m.reduce(ee.Reducer.sum())
    for b in DW_PROB_BANDS:
        raw_bands.append(comp_m.select(b).unmask(0.0).rename(f"{b}_raw_m{m:02d}"))
    raw_bands.append(prob_sum_raw.unmask(0.0).rename(f"prob_sum_raw_m{m:02d}"))
    raw_bands.append(n_days.unmask(0).rename(f"n_days_raw_m{m:02d}"))

    # BILINEAR on mb_proj
    comp_m_bil = comp_m.resample("bilinear").reproject(crs=mb_proj)
    prob_sum_bil = comp_m_bil.reduce(ee.Reducer.sum())
    for b in DW_PROB_BANDS:
        bil_bands.append(comp_m_bil.select(b).unmask(0.0).rename(f"{b}_bil_m{m:02d}"))
    bil_bands.append(prob_sum_bil.unmask(0.0).rename(f"prob_sum_bil_m{m:02d}"))
    bil_bands.append(n_days.unmask(0).rename(f"n_days_bil_m{m:02d}"))

# Sample all in one combined extraction
combined_img = ee.Image.cat([auth_stack] + raw_bands + bil_bands)
sampled_records = combined_img.sampleRegions(
    collection=fc,
    projection=mb_proj,
    geometries=False
).getInfo()['features']

results = [f['properties'] for f in sampled_records]
print(f"Extração concluída com sucesso para {len(results)} pontos!")

with open('scratch/pilot_extraction_results.json', 'w', encoding='utf-8') as f:
    json.dump(results, f)
print("Salvo em scratch/pilot_extraction_results.json")
