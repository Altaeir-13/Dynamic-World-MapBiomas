import pandas as pd
import numpy as np

# Load annual and monthly datasets
df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

print(f"Total de pontos em samples_annual: {len(df_ann):,}")
print(f"Total de linhas em dw_monthly: {len(df_mon):,}")

# Filter valid months
valid_mon = df_mon[df_mon['month_valid'] == 1].copy()

# Reconstruct annual vector from valid months of dw_monthly
# Order of aggregation in dw_annual.py:
# 1. Monthly normalized probability vectors
# 2. Equal-weight mean across valid months
# 3. Normalized to sum to 1.0
mon_agg = valid_mon.groupby('sample_id').agg(
    n_valid_months_recon=('month', 'count'),
    **{c: (c, 'mean') for c in DW_CLASSES}
).reset_index()

# Normalize reconstructed vector
prob_sum_recon = mon_agg[DW_CLASSES].sum(axis=1)
for c in DW_CLASSES:
    mon_agg[c + '_recon'] = mon_agg[c] / prob_sum_recon

# Merge with authoritative annual dataset
merged = pd.merge(df_ann, mon_agg, on='sample_id', how='inner')
print(f"Pontos unidos com sucesso: {len(merged):,}")

# 1. Compare n_valid_months
diff_n_valid = (merged['n_valid_months'] != merged['n_valid_months_recon']).sum()
print(f"\n1. Comparação de n_valid_months:")
print(f"  Divergências em n_valid_months: {diff_n_valid} / {len(merged)} ({diff_n_valid/len(merged)*100:.2f}%)")

# 2. Probability differences
all_abs_diffs = []
max_diff_per_point = []
diff_per_class = {}

for c in DW_CLASSES:
    p_auth = merged['p_' + c].values
    p_rec = merged[c + '_recon'].values
    d = np.abs(p_auth - p_rec)
    all_abs_diffs.append(d)
    diff_per_class[c] = {
        'mean': np.mean(d),
        'median': np.median(d),
        'p95': np.percentile(d, 95),
        'p99': np.percentile(d, 99),
        'max': np.max(d)
    }

matrix_diffs = np.column_stack(all_abs_diffs)
max_diff_per_point = np.max(matrix_diffs, axis=1)

print(f"\n2. Estatísticas das Diferenças Absolutas de Probabilidade (40.000 pontos x 9 classes = 360.000 comparações):")
flat_diffs = matrix_diffs.flatten()
print(f"  Diferença Absoluta Máxima:       {np.max(flat_diffs):.6f}")
print(f"  Diferença Absoluta Mediana:      {np.median(flat_diffs):.6f}")
print(f"  Diferença Absoluta Média:        {np.mean(flat_diffs):.6f}")
print(f"  Percentil 95 das Diferenças:     {np.percentile(flat_diffs, 95):.6f}")
print(f"  Percentil 99 das Diferenças:     {np.percentile(flat_diffs, 99):.6f}")
print(f"  Diferença Máxima por Ponto (Mediana): {np.median(max_diff_per_point):.6f}")
print(f"  Diferença Máxima por Ponto (P99):     {np.percentile(max_diff_per_point, 99):.6f}")

df_diff_class = pd.DataFrame(diff_per_class).T
print("\nDiferenças por Classe:")
print(df_diff_class.to_string())

# 3. Compare annual argmax
auth_argmax_idx = merged['annual_class_index'].values
rec_argmax_idx = np.argmax(merged[[c + '_recon' for c in DW_CLASSES]].values, axis=1)
rec_argmax_class = [DW_CLASSES[i] for i in rec_argmax_idx]

diff_argmax = (auth_argmax_idx != rec_argmax_idx).sum()
print(f"\n3. Comparação de argmax anual:")
print(f"  Pontos com argmax divergente:    {diff_argmax:,} / {len(merged):,} ({diff_argmax/len(merged)*100:.2f}%)")

# 4. Compare dw_crop (crop is index 4)
auth_dw_crop = merged['dw_crop'].values
rec_dw_crop = (rec_argmax_idx == 4).astype(int)
diff_crop = (auth_dw_crop != rec_dw_crop).sum()
print(f"\n4. Comparação de dw_crop:")
print(f"  Pontos com dw_crop divergente:   {diff_crop:,} / {len(merged):,} ({diff_crop/len(merged)*100:.2f}%)")

# 5. Breakdown by regime
print("\n5. Divergência de dw_crop por Regime:")
merged['crop_divergent'] = (auth_dw_crop != rec_dw_crop)
merged['argmax_divergent'] = (auth_argmax_idx != rec_argmax_idx)
reg_breakdown = merged.groupby('regime').agg(
    total=('sample_id', 'count'),
    argmax_div=('argmax_divergent', 'sum'),
    crop_div=('crop_divergent', 'sum')
)
reg_breakdown['pct_argmax_div'] = reg_breakdown['argmax_div'] / reg_breakdown['total'] * 100
reg_breakdown['pct_crop_div'] = reg_breakdown['crop_div'] / reg_breakdown['total'] * 100
print(reg_breakdown)

# 6. Specific diagnosis of PT_010352
pt = merged[merged['sample_id'] == 'PT_010352'].iloc[0]
print(f"\n6. Diagnóstico do ponto PT_010352:")
print(f"  UF: {pt['state']} | Regime: {pt['regime']} | Slice: {pt['slice_id']}")
print(f"  Lat: {pt['lat']:.6f}, Lon: {pt['lon']:.6f}")
print(f"  n_valid_months (auth): {pt['n_valid_months']} | n_valid_months (recon): {pt['n_valid_months_recon']}")
print(f"  Annual Class (auth):   {pt['annual_class']} (dw_crop={pt['dw_crop']})")
print(f"  Annual Class (recon):  {DW_CLASSES[rec_argmax_idx[merged['sample_id']=='PT_010352'][0]]} (dw_crop={rec_dw_crop[merged['sample_id']=='PT_010352'][0]})")
print("  Probabilidades Comparadas:")
for c in DW_CLASSES:
    p_a = pt['p_' + c]
    p_r = pt[c + '_recon']
    print(f"    {c:20s}: auth={p_a:.4f} | recon={p_r:.4f} | diff={abs(p_a - p_r):.4f}")
