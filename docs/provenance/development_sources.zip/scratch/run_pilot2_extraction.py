import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import ee
import json
import pandas as pd

PROJECT_ID = "dynamicworld-x-mapbiomas"
ee.Initialize(project=PROJECT_ID)

from src.gee.dw_annual import (
    DW_PROB_BANDS,
    DW_START,
    DW_END,
    DW_COLLECTION,
    get_mapbiomas_projection,
    get_source_support_domain,
    DATES_CACHE_PATH,
    build_dw_annual_2025
)

mb_proj = get_mapbiomas_projection()
source_domain = get_source_support_domain()

df_pilot2 = pd.read_csv('scratch/pilot2_sample_points.csv', keep_default_na=False)
print(f"Iniciando extração do Piloto 2 com {len(df_pilot2)} pontos no GEE...")

features = [
    ee.Feature(
        ee.Geometry.Point([float(row['lon']), float(row['lat'])]),
        {'sample_id': str(row['sample_id'])}
    )
    for _, row in df_pilot2.iterrows()
]
fc = ee.FeatureCollection(features)

# 1. Authoritative Annual Stack
print("1. Extraindo Raster Anual Autoritativo...")
dw_ann = build_dw_annual_2025()
auth_stack = ee.Image.cat([
    dw_ann["normalized_probs"].rename([f"auth_p_{b}" for b in DW_PROB_BANDS]),
    dw_ann["raw_prob_sum"].rename("auth_raw_prob_sum"),
    dw_ann["annual_class_index"].rename("auth_annual_class_index"),
    dw_ann["dw_crop"].rename("auth_dw_crop"),
    dw_ann["n_valid_months"].rename("auth_n_valid_months"),
])

s_auth = auth_stack.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features']
recs_by_id = {f['properties']['sample_id']: f['properties'] for f in s_auth}
print(f"Anual extraído para {len(recs_by_id)} pontos.")

# 2. Monthly stacks quarter by quarter
with open(DATES_CACHE_PATH, "r", encoding="utf-8") as f:
    dates_dict = json.load(f)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterDate(DW_START, DW_END)
    .filterBounds(source_domain)
)

quarters = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [10, 11, 12]
]

for q_idx, months in enumerate(quarters, 1):
    print(f"Extraindo Trimestre Q{q_idx} (Meses {months})...")
    q_bands = []
    for m in months:
        start = f"2025-{m:02d}-01"
        end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
        dw_m = dw_col.filterDate(start, end)
        dates_m = ee.List(dates_dict[f"{m:02d}"])

        def make_daily(d):
            d_start = ee.Date(d)
            d_end = d_start.advance(1, "day")
            return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().toFloat().set("date", d)

        daily_col = ee.ImageCollection(dates_m.map(make_daily))
        comp_m = daily_col.mean().select(DW_PROB_BANDS).toFloat()
        n_days = daily_col.select("water").count()
        n_raw = dw_m.select("label").count()

        # Resampled with BILINEAR to mb_proj
        comp_m_bil = comp_m.resample("bilinear").reproject(crs=mb_proj)

        for b in DW_PROB_BANDS:
            q_bands.append(comp_m_bil.select(b).unmask(0.0).rename(f"{b}_bil_m{m:02d}"))
        q_bands.append(n_days.unmask(0).rename(f"n_days_bil_m{m:02d}"))
        q_bands.append(n_raw.unmask(0).rename(f"n_raw_bil_m{m:02d}"))

    q_img = ee.Image.cat(q_bands)
    s_q = q_img.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features']
    for f in s_q:
        sid = f['properties']['sample_id']
        if sid in recs_by_id:
            recs_by_id[sid].update(f['properties'])
    print(f"Trimestre Q{q_idx} concluído.")

out_list = [recs_by_id[row['sample_id']] for _, row in df_pilot2.iterrows() if row['sample_id'] in recs_by_id]
with open('scratch/pilot2_bilinear_monthly_results.json', 'w', encoding='utf-8') as f:
    json.dump(out_list, f)

print(f"Sucesso! Piloto 2 salvo com {len(out_list)} registros em scratch/pilot2_bilinear_monthly_results.json")
