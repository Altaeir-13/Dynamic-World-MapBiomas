import pandas as pd
import numpy as np

merged = pd.read_parquet('scratch/diagnostic_stability_merged.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

# Pick representative examples:
# 1. AA with high stability (classic crop)
aa_high_s = merged[(merged['regime'] == 'AA') & (merged['stability'] >= 0.8)].iloc[0]

# 2. AN with S=0 (MB says crop, DW says trees/shrub, never crops monthly)
an_s0 = merged[(merged['regime'] == 'AN') & (merged['stability'] == 0.0) & (merged['annual_class'] == 'trees')].iloc[0]

# 3. NA with S=0 (DW says crops annual, but never crops in any month!)
na_s0 = merged[(merged['regime'] == 'NA') & (merged['stability'] == 0.0) & (merged['annual_class'] == 'crops')].iloc[0]

# 4. NN with high stability (stable native/noncrop)
nn_high_s = merged[(merged['regime'] == 'NN') & (merged['stability'] >= 0.9)].iloc[0]

examples = [
    ('AA (Acordo Lavoura - Alta Estabilidade)', aa_high_s),
    ('AN (MapBiomas Lavoura, DW Trees, S=0)', an_s0),
    ('NA (DW Crops Anual, mas S=0, Nunca Crops Mensal)', na_s0),
    ('NN (Acordo Não-Lavoura - Alta Estabilidade)', nn_high_s)
]

for label, row in examples:
    sid = row['sample_id']
    print(f"\n=======================================================")
    print(f"EXEMPLO: {label}")
    print(f"Sample ID: {sid} | UF: {row['state']} | Regime: {row['regime']} | MB Class: {row['mapbiomas_class']}")
    print(f"Annual Class DW: {row['annual_class']} | DW Crop: {row['dw_crop']} | MB Crop: {row['mapbiomas_crop']}")
    print(f"Stability S: {row['stability']:.4f} | n_valid_months: {row['n_valid_months']}")
    print(f"Annual Probs Top 3: top1={row['top1_class']} ({row['top1_probability']:.3f}), top2={row['top2_class']} ({row['top2_probability']:.3f}), margin={row['top2_margin']:.3f}")
    print(f"Entropy Annual: {row['entropy_annual']:.4f} | JSD Temporal: {row['jsd_temporal']:.4f}")
    
    # Monthly profile
    mon_pts = df_mon[(df_mon['sample_id'] == sid) & (df_mon['month_valid'] == 1)].sort_values('month')
    print("\nPerfil Mensal:")
    for _, m_row in mon_pts.iterrows():
        m = int(m_row['month'])
        probs = [m_row[c] for c in DW_CLASSES]
        argmax_idx = np.argmax(probs)
        argmax_cls = DW_CLASSES[argmax_idx]
        max_p = probs[argmax_idx]
        crops_p = m_row['crops']
        trees_p = m_row['trees']
        shrub_p = m_row['shrub_and_scrub']
        grass_p = m_row['grass']
        bare_p = m_row['bare']
        print(f"  Mês {m:02d}: Argmax = {argmax_cls:15s} (p={max_p:.3f}) | crops={crops_p:.3f}, trees={trees_p:.3f}, shrub={shrub_p:.3f}, grass={grass_p:.3f}, bare={bare_p:.3f}")
