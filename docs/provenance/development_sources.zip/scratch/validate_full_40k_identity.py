import numpy as np
import pandas as pd

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

print("="*80)
print("VALIDAÇÃO COMPLETA DE IDENTIDADE TEMPORAL NOS 40.000 PONTOS (CORRIGIDO)")
print("="*80)

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

print(f"Carregados {len(df_ann):,} pontos anuais e {len(df_mon):,} registros mensais.")

# Filtrar meses válidos
val_m = df_mon[df_mon['month_valid'] == 1]
print(f"Total de observações mensais válidas: {len(val_m):,}")

# Agregação mensal por ponto
monthly_means = val_m.groupby('sample_id')[DW_CLASSES].mean()
m_sums = monthly_means.sum(axis=1)
monthly_norm = monthly_means.div(m_sums, axis=0)

# Alinhar com df_ann
ann_indexed = df_ann.set_index('sample_id')
auth_probs = ann_indexed[[f'p_{c}' for c in DW_CLASSES]]
auth_probs.columns = DW_CLASSES

aligned_rec = monthly_norm.loc[ann_indexed.index]

auth_argmax = np.argmax(auth_probs.values, axis=1)
rec_argmax = np.argmax(aligned_rec.values, axis=1)

auth_crop = (auth_argmax == 4).astype(int)
rec_crop = (rec_argmax == 4).astype(int)

diffs = np.abs(auth_probs.values - aligned_rec.values)
max_diffs_per_point = np.max(diffs, axis=1)
mean_diffs_per_point = np.mean(diffs, axis=1)

argmax_div = (auth_argmax != rec_argmax).astype(int)
crop_div = (auth_crop != rec_crop).astype(int)

n_total = len(df_ann)
n_arg_div = np.sum(argmax_div)
n_cr_div = np.sum(crop_div)

print("\nRESULTADOS DA AUDITORIA DE IDENTIDADE NOS 40.000 PONTOS:")
print(f"Total de pontos comparados:          {n_total:,}")
print(f"Pontos com argmax divergente:        {n_arg_div:,} ({n_arg_div / n_total * 100:.2f}%)")
print(f"Pontos com crop/noncrop divergente:  {n_cr_div:,} ({n_cr_div / n_total * 100:.2f}%)")
print(f"Diferença máxima de probabilidade:   {np.max(max_diffs_per_point):.6f}")
print(f"Média das diferenças máximas:        {np.mean(max_diffs_per_point):.6f}")
print(f"Diferença média global (todas 9):    {np.mean(mean_diffs_per_point):.6f} ({np.mean(mean_diffs_per_point)*100:.3f} pp)")
print(f"Mediana da diferença máxima:         {np.median(max_diffs_per_point):.6f}")
print(f"Percentil 95 da diferença máxima:    {np.percentile(max_diffs_per_point, 95):.6f}")
print(f"Percentil 99 da diferença máxima:    {np.percentile(max_diffs_per_point, 99):.6f}")

# Diagnóstico de PT_010352
pt_row = ann_indexed.loc['PT_010352']
pt_rec = aligned_rec.loc['PT_010352']
print("\n" + "-"*80)
print("DIAGNÓSTICO ESPECÍFICO DE PT_010352 (CASO EMBLEMÁTICO):")
print(f"  Classe Anual Canônica:        {pt_row['annual_class']} (crop={pt_row['dw_crop']})")
print(f"  Classe Reconstruída:          {DW_CLASSES[np.argmax(pt_rec.values)]} (crop={(np.argmax(pt_rec.values)==4)*1})")
print(f"  Estabilidade S Corrigida:     {pt_row['stability']:.4f}")
print(f"  JSD Temporal Corrigida:       {pt_row['jsd_temporal']:.6f}")
print(f"  Probabilidades Anuais:        {dict(zip(DW_CLASSES, np.round(pt_row[[f'p_{c}' for c in DW_CLASSES]].values.astype(float), 4)))}")
print(f"  Probabilidades Reconstruídas: {dict(zip(DW_CLASSES, np.round(pt_rec.values, 4)))}")

# Desempenho por Regime
ann_indexed['argmax_div'] = argmax_div
ann_indexed['crop_div'] = crop_div
ann_indexed['max_diff'] = max_diffs_per_point
ann_indexed['mean_diff'] = mean_diffs_per_point

print("\n" + "-"*80)
print("DESEMPENHO POR REGIME NOS 40.000 PONTOS:")
print(ann_indexed.groupby('regime')[['argmax_div', 'crop_div', 'max_diff', 'mean_diff', 'stability', 'jsd_temporal']].mean())

# Desempenho por Estado
print("\n" + "-"*80)
print("DESEMPENHO POR ESTADO NOS 40.000 PONTOS:")
print(ann_indexed.groupby('state')[['argmax_div', 'crop_div', 'max_diff', 'mean_diff', 'stability', 'jsd_temporal']].mean())

# Desempenho por Distância de Borda (convenção idêntica ao H3: right=False, incluindo 250m em >=250m)
ann_indexed['dist_bin'] = pd.cut(ann_indexed['distance_edge_min_m'], bins=[0, 10, 30, 60, 100, 250, np.inf], labels=['0–10m', '10–30m', '30–60m', '60–100m', '100–250m', '>=250m'], right=False)
print("\n" + "-"*80)
print("DESEMPENHO POR DISTÂNCIA DE BORDA NOS 40.000 PONTOS:")
print(ann_indexed.groupby('dist_bin')[['argmax_div', 'crop_div', 'max_diff', 'mean_diff', 'stability']].mean())
print("\nCONTAGEM DE CROP DIVERGENTE POR FAIXA DE DISTÂNCIA:")
print(ann_indexed[ann_indexed['crop_div'] == 1]['dist_bin'].value_counts()[['0–10m', '10–30m', '30–60m', '60–100m', '100–250m', '>=250m']])
