import pandas as pd
import numpy as np
from pyproj import Transformer

df = pd.read_parquet('data/processed/samples_annual.parquet')
main = df[df['main_sample'] == 1].reset_index(drop=True).copy()
main['D'] = main['regime'].isin(['AN', 'NA']).astype(int)
main['w'] = main['design_weight_main'].astype(float)

transformer = Transformer.from_crs("EPSG:4326", "EPSG:5880", always_xy=True)
x, y = transformer.transform(main["lon"].values, main["lat"].values)
main['x'] = x
main['y'] = y

block_size_m = 30000.0
bx = np.floor(main["x"].values / block_size_m).astype(int)
by = np.floor(main["y"].values / block_size_m).astype(int)
main['block_id'] = [f"{xi}_{yi}" for xi, yi in zip(bx, by)]

unique_blocks = main['block_id'].unique()
n_blocks = len(unique_blocks)
block_list = [np.where(main['block_id'] == b)[0] for b in unique_blocks]

# 16 strata true population weights
strata = main['stratum_id'].unique()
strata_true_w = {st: main[main['stratum_id'] == st]['w'].sum() for st in strata}

y_h = main["entropy_annual"].values
y_jsd = main["jsd_temporal"].values
y_s = main["stability"].values
d_arr = main["D"].values
w_arr = main["w"].values
dist_arr = main["distance_edge_min_m"].values
stratum_arr = main["stratum_id"].values

bins = [0, 10, 30, 60, 100, 250, np.inf]
labels = ["0–10 m", "10–30 m", "30–60 m", "60–100 m", "100–250 m", ">=250 m"]
bin_codes = np.digitize(dist_arr, bins, right=False) - 1

N_BOOT = 1999
rng = np.random.default_rng(25)

# Storage for uncalibrated (current) vs recalibrated
diff_h_uncal = np.zeros(N_BOOT)
diff_h_recal = np.zeros(N_BOOT)
diff_jsd_uncal = np.zeros(N_BOOT)
diff_jsd_recal = np.zeros(N_BOOT)
diff_s_uncal = np.zeros(N_BOOT)
diff_s_recal = np.zeros(N_BOOT)
p_disc_uncal = np.zeros(N_BOOT)
p_disc_recal = np.zeros(N_BOOT)

dist_uncal = {lab: np.zeros(N_BOOT) for lab in labels}
dist_recal = {lab: np.zeros(N_BOOT) for lab in labels}

print(f"Running {N_BOOT} replications comparing uncalibrated vs stratum-recalibrated bootstrap...")

for r in range(N_BOOT):
    samp_b = rng.choice(n_blocks, n_blocks, replace=True)
    idx_boot = np.concatenate([block_list[b] for b in samp_b])
    
    w_b = w_arr[idx_boot]
    d_b = d_arr[idx_boot]
    h_b = y_h[idx_boot]
    jsd_b = y_jsd[idx_boot]
    s_b = y_s[idx_boot]
    st_b = stratum_arr[idx_boot]
    b_codes = bin_codes[idx_boot]
    
    # 1. Uncalibrated
    w0_u = w_b[d_b == 0]
    w1_u = w_b[d_b == 1]
    sum_w0_u = np.sum(w0_u)
    sum_w1_u = np.sum(w1_u)
    
    p_disc_uncal[r] = (sum_w1_u / (sum_w0_u + sum_w1_u)) * 100.0
    diff_h_uncal[r] = (np.sum(h_b[d_b == 1] * w1_u) / sum_w1_u) - (np.sum(h_b[d_b == 0] * w0_u) / sum_w0_u)
    diff_jsd_uncal[r] = (np.sum(jsd_b[d_b == 1] * w1_u) / sum_w1_u) - (np.sum(jsd_b[d_b == 0] * w0_u) / sum_w0_u)
    diff_s_uncal[r] = (np.sum(s_b[d_b == 1] * w1_u) / sum_w1_u) - (np.sum(s_b[d_b == 0] * w0_u) / sum_w0_u)
    
    for b_idx, lab in enumerate(labels):
        m_bin = (b_codes == b_idx)
        if np.sum(w_b[m_bin]) > 0:
            dist_uncal[lab][r] = (np.sum(w_b[m_bin & (d_b == 1)]) / np.sum(w_b[m_bin])) * 100.0
            
    # 2. Recalibrated (post-stratified to 16 scientific strata margins)
    w_recal = w_b.copy()
    for st in strata:
        mask_st = (st_b == st)
        sum_w_st = np.sum(w_b[mask_st])
        if sum_w_st > 0:
            w_recal[mask_st] = w_b[mask_st] * (strata_true_w[st] / sum_w_st)
            
    w0_r = w_recal[d_b == 0]
    w1_r = w_recal[d_b == 1]
    sum_w0_r = np.sum(w0_r)
    sum_w1_r = np.sum(w1_r)
    
    p_disc_recal[r] = (sum_w1_r / (sum_w0_r + sum_w1_r)) * 100.0
    diff_h_recal[r] = (np.sum(h_b[d_b == 1] * w1_r) / sum_w1_r) - (np.sum(h_b[d_b == 0] * w0_r) / sum_w0_r)
    diff_jsd_recal[r] = (np.sum(jsd_b[d_b == 1] * w1_r) / sum_w1_r) - (np.sum(jsd_b[d_b == 0] * w0_r) / sum_w0_r)
    diff_s_recal[r] = (np.sum(s_b[d_b == 1] * w1_r) / sum_w1_r) - (np.sum(s_b[d_b == 0] * w0_r) / sum_w0_r)
    
    for b_idx, lab in enumerate(labels):
        m_bin = (b_codes == b_idx)
        if np.sum(w_recal[m_bin]) > 0:
            dist_recal[lab][r] = (np.sum(w_recal[m_bin & (d_b == 1)]) / np.sum(w_recal[m_bin])) * 100.0

print("\n=== COMPARAÇÃO DE CONTRASTES H1, H2a, H2b, TAXA DE DISCORDÂNCIA ===")
print("Statistic                  | Uncalibrated 95% CI          | Recalibrated 95% CI")
print(f"H1 Delta_H                 | [{np.percentile(diff_h_uncal, 2.5):.4f}, {np.percentile(diff_h_uncal, 97.5):.4f}] | [{np.percentile(diff_h_recal, 2.5):.4f}, {np.percentile(diff_h_recal, 97.5):.4f}]")
print(f"H2a Delta_JSD              | [{np.percentile(diff_jsd_uncal, 2.5):.4f}, {np.percentile(diff_jsd_uncal, 97.5):.4f}] | [{np.percentile(diff_jsd_recal, 2.5):.4f}, {np.percentile(diff_jsd_recal, 97.5):.4f}]")
print(f"H2b Delta_Stability        | [{np.percentile(diff_s_uncal, 2.5):.4f}, {np.percentile(diff_s_uncal, 97.5):.4f}] | [{np.percentile(diff_s_recal, 2.5):.4f}, {np.percentile(diff_s_recal, 97.5):.4f}]")
print(f"Taxa Geral Discordância    | [{np.percentile(p_disc_uncal, 2.5):.2f}%, {np.percentile(p_disc_uncal, 97.5):.2f}%] | [{np.percentile(p_disc_recal, 2.5):.2f}%, {np.percentile(p_disc_recal, 97.5):.2f}%]")

print("\n=== COMPARAÇÃO FAIXAS DE DISTÂNCIA H3 ===")
for lab in labels:
    u_low, u_high = np.percentile(dist_uncal[lab], 2.5), np.percentile(dist_uncal[lab], 97.5)
    r_low, r_high = np.percentile(dist_recal[lab], 2.5), np.percentile(dist_recal[lab], 97.5)
    print(f"{lab:10s} | Uncal: [{u_low:5.2f}%, {u_high:5.2f}%] | Recal: [{r_low:5.2f}%, {r_high:5.2f}%]")
