import pandas as pd
import numpy as np

# Load datasets
df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

print(f"Total samples_annual: {len(df_ann):,}")
print(f"Total dw_monthly:     {len(df_mon):,}")

# Filter valid months
valid_mon = df_mon[df_mon['month_valid'] == 1].copy()

# Reconstruct annual vector from valid months of dw_monthly
# Aggregation: mean of monthly normalized probabilities, then normalized
mon_agg = valid_mon.groupby('sample_id').agg(
    n_valid_months_recon=('month', 'count'),
    **{c: (c, 'mean') for c in DW_CLASSES}
).reset_index()

# Normalize reconstructed vector
prob_sum_recon = mon_agg[DW_CLASSES].sum(axis=1)
for c in DW_CLASSES:
    mon_agg[c + '_recon'] = mon_agg[c] / prob_sum_recon

# Merge
merged = pd.merge(df_ann, mon_agg, on='sample_id', how='inner')
print(f"Merged points: {len(merged):,}")

# 1. n_valid_months
diff_n_valid = (merged['n_valid_months'] != merged['n_valid_months_recon']).sum()
print("\n--- 1. n_valid_months ---")
print(f"Divergências em n_valid_months: {diff_n_valid} / {len(merged)} ({diff_n_valid/len(merged)*100:.4f}%)")
if diff_n_valid > 0:
    pts_diff_n = merged[merged['n_valid_months'] != merged['n_valid_months_recon']][['sample_id', 'state', 'regime', 'n_valid_months', 'n_valid_months_recon']]
    print(pts_diff_n.to_string())

# 2. Probability differences
all_abs_diffs = []
diff_per_class = {}
for c in DW_CLASSES:
    p_auth = merged['p_' + c].values
    p_rec = merged[c + '_recon'].values
    d = np.abs(p_auth - p_rec)
    all_abs_diffs.append(d)
    diff_per_class[c] = {
        'mean': np.mean(d),
        'median': np.median(d),
        'p95': np.percentile(d, 95),
        'p99': np.percentile(d, 99),
        'max': np.max(d)
    }

matrix_diffs = np.column_stack(all_abs_diffs) # (40000, 9)
flat_diffs = matrix_diffs.flatten()           # (360000,)
max_diff_per_point = np.max(matrix_diffs, axis=1)

print("\n--- 2. Estatísticas das Diferenças Absolutas (360.000 comparações) ---")
print(f"Diferença Absoluta Máxima:       {np.max(flat_diffs):.6f}")
print(f"Diferença Absoluta Mediana:      {np.median(flat_diffs):.6f}")
print(f"Diferença Absoluta Média:        {np.mean(flat_diffs):.6f}")
print(f"Percentil 95 das Diferenças:     {np.percentile(flat_diffs, 95):.6f}")
print(f"Percentil 99 das Diferenças:     {np.percentile(flat_diffs, 99):.6f}")
print(f"Diferença Máxima por Ponto (Mediana): {np.median(max_diff_per_point):.6f}")
print(f"Diferença Máxima por Ponto (P99):     {np.percentile(max_diff_per_point, 99):.6f}")

print("\nDiferenças por Classe:")
print(pd.DataFrame(diff_per_class).T.to_string())

# 3. Argmax and dw_crop
auth_argmax_idx = merged['annual_class_index'].values
rec_argmax_idx = np.argmax(merged[[c + '_recon' for c in DW_CLASSES]].values, axis=1)
rec_argmax_class = [DW_CLASSES[i] for i in rec_argmax_idx]

diff_argmax = (auth_argmax_idx != rec_argmax_idx).sum()
print("\n--- 3. Argmax Anual ---")
print(f"Pontos com argmax divergente: {diff_argmax:,} / {len(merged):,} ({diff_argmax/len(merged)*100:.2f}%)")

auth_dw_crop = merged['dw_crop'].values
rec_dw_crop = (rec_argmax_idx == 4).astype(int)
diff_crop = (auth_dw_crop != rec_dw_crop).sum()
print("\n--- 4. dw_crop ---")
print(f"Pontos com dw_crop divergente: {diff_crop:,} / {len(merged):,} ({diff_crop/len(merged)*100:.2f}%)")

merged['crop_divergent'] = (auth_dw_crop != rec_dw_crop)
merged['argmax_divergent'] = (auth_argmax_idx != rec_argmax_idx)

# By regime
print("\n--- 5. Detalhamento por Regime ---")
reg_table = merged.groupby('regime').agg(
    total=('sample_id', 'count'),
    argmax_div=('argmax_divergent', 'sum'),
    crop_div=('crop_divergent', 'sum'),
    mean_max_diff=('sample_id', lambda s: np.mean(max_diff_per_point[s.index])),
    median_dist_edge=('distance_edge_min_m', 'median')
)
reg_table['pct_argmax_div'] = reg_table['argmax_div'] / reg_table['total'] * 100
reg_table['pct_crop_div'] = reg_table['crop_div'] / reg_table['total'] * 100
print(reg_table.to_string())

# By distance to edge
print("\n--- 6. Detalhamento por Borda (Distância) ---")
merged['dist_bin'] = pd.cut(
    merged['distance_edge_min_m'],
    bins=[-0.1, 10, 30, 60, 100, 250, 1000],
    labels=['0-10m', '10-30m', '30-60m', '60-100m', '100-250m', '>=250m']
)
edge_table = merged.groupby('dist_bin').agg(
    total=('sample_id', 'count'),
    argmax_div=('argmax_divergent', 'sum'),
    crop_div=('crop_divergent', 'sum')
)
edge_table['pct_argmax_div'] = edge_table['argmax_div'] / edge_table['total'] * 100
edge_table['pct_crop_div'] = edge_table['crop_div'] / edge_table['total'] * 100
print(edge_table.to_string())

# Check PT_010352
print("\n--- 7. Diagnóstico PT_010352 ---")
pt = merged[merged['sample_id'] == 'PT_010352'].iloc[0]
print(f"Sample: {pt['sample_id']} | Regime: {pt['regime']} | State: {pt['state']} | Slice: {pt['slice_id']}")
print(f"Coords: lat={pt['lat']:.6f}, lon={pt['lon']:.6f}")
print(f"Edge min dist: {pt['distance_edge_min_m']}m | Edge MB: {pt['distance_edge_mb_m']}m | Edge DW: {pt['distance_edge_dw_m']}m")
print(f"n_valid_months (auth): {pt['n_valid_months']} | n_valid_months (recon): {pt['n_valid_months_recon']}")
print(f"Annual class (auth):   {pt['annual_class']} (index={pt['annual_class_index']}, dw_crop={pt['dw_crop']})")
print(f"Annual class (recon):  {DW_CLASSES[rec_argmax_idx[merged['sample_id']=='PT_010352'][0]]} (index={rec_argmax_idx[merged['sample_id']=='PT_010352'][0]}, dw_crop={rec_dw_crop[merged['sample_id']=='PT_010352'][0]})")
for c in DW_CLASSES:
    pa = pt['p_' + c]
    pr = pt[c + '_recon']
    print(f"  {c:20s}: auth={pa:.4f} | recon={pr:.4f} | diff={abs(pa-pr):.4f}")
