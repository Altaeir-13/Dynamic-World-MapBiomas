import docx
from docx.shared import Mm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
import subprocess, pypdf

def set_section_cols(section, num_cols=2, space_dxa=340):
    sectPr = section._sectPr
    for child in list(sectPr):
        if child.tag.endswith('cols'):
            sectPr.remove(child)
    cols = OxmlElement('w:cols')
    cols.set(qn('w:num'), str(num_cols))
    if num_cols > 1:
        cols.set(qn('w:space'), str(space_dxa))
        cols.set(qn('w:equalWidth'), '1')
    sectPr.append(cols)

doc = docx.Document()
sec0 = doc.sections[0]
sec0.page_width = Mm(210)
sec0.page_height = Mm(297)
sec0.left_margin = Mm(19)
sec0.right_margin = Mm(13)
sec0.top_margin = Mm(25)
sec0.bottom_margin = Mm(43)
set_section_cols(sec0, 1)

# Title: 14 pt, bold, centered, top at 35 mm
p_title = doc.add_paragraph()
p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_title.paragraph_format.space_before = Pt(28)
p_title.paragraph_format.space_after = Pt(4)
p_title.paragraph_format.line_spacing = Pt(16)
r_title = p_title.add_run("ONDE DYNAMIC WORLD E MAPBIOMAS DISCORDAM SOBRE LAVOURAS? DIAGNÓSTICO ESPACIAL E PROBABILÍSTICO NO MATOPIBA")
r_title.font.name = "Times New Roman"
r_title.font.size = Pt(14)
r_title.font.bold = True

p_auth = doc.add_paragraph()
p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_auth.paragraph_format.space_before = Pt(3)
p_auth.paragraph_format.space_after = Pt(2)
r_auth = p_auth.add_run("[Nome do Primeiro Autor]¹*, [Nome do Segundo Autor]², [Nome do Terceiro Autor]³ e [Nome do Último Autor]⁴")
r_auth.font.name = "Times New Roman"
r_auth.font.size = Pt(10)
r_auth.font.bold = True

p_aff = doc.add_paragraph()
p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_aff.paragraph_format.space_before = Pt(0)
p_aff.paragraph_format.space_after = Pt(6)
p_aff.paragraph_format.line_spacing = Pt(10)
r_aff = p_aff.add_run(
    "¹ [Instituição do Autor 1] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor1@instituicao.edu.br]\n"
    "² [Instituição do Autor 2] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor2@instituicao.edu.br]\n"
    "³ [Instituição do Autor 3] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor3@instituicao.edu.br]\n"
    "⁴ [Instituição do Autor 4] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor4@instituicao.edu.br]\n"
    "*Autor correspondente: [email.autor1@instituicao.edu.br]"
)
r_aff.font.name = "Times New Roman"
r_aff.font.size = Pt(8)

s1 = doc.add_section(docx.enum.section.WD_SECTION_START.CONTINUOUS)
s1.page_width = Mm(210)
s1.page_height = Mm(297)
s1.left_margin = Mm(19)
s1.right_margin = Mm(13)
s1.top_margin = Mm(25)
s1.bottom_margin = Mm(43)
set_section_cols(s1, 2)

def add_h1(text, is_abstract=False):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(7)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10)
    r.font.bold = True
    if is_abstract: r.font.italic = True
    return p

def add_h2(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(1.5)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10)
    r.font.bold = True
    return p

def add_p(text, indent=True, italic=False, space_after=1.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = Pt(11.2)
    p.paragraph_format.first_line_indent = Mm(6.3) if indent else Mm(0)
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10)
    r.font.italic = italic
    return p

# Resumo
add_h1("RESUMO")
add_p("Mapeamentos de uso e cobertura da terra em escala decamétrica (10 m) são vitais para o monitoramento territorial. Em fronteiras agrícolas com acentuada sazonalidade como o MATOPIBA, divergências entre produtos de GeoAI permanecem pouco elucidadas. Este estudo apresenta um diagnóstico simétrico da discordância de lavouras entre Dynamic World e MapBiomas (Coleção 4, 10 m) em 2025. Com amostragem probabilística estratificada de 20.000 pontos em 52,34 milhões de hectares elegíveis, avaliou-se a associação da discordância com incerteza probabilística anual, dinâmica temporal e proximidade a bordas temáticas. A discordância censitária atinge 14,2852% por área e 14,3110% por pixels. Sob Spatial Block Bootstrap (blocos de 30 km, 1.999 réplicas), a discordância associa-se a maior entropia anual (ΔH = +0,0162), maior divergência Jensen-Shannon temporal (ΔJSD = +0,0075) e menor estabilidade modal (ΔS = -0,0790). Em bordas (<30 m), a discordância é 3,87 vezes superior à do interior (≥250 m). Na regressão logística, distância à borda (OR = 0,360) e estabilidade temporal (OR = 0,925) associam-se inversamente à discordância. Apenas 4,28% ponderado das discordâncias atendem a critérios operacionais de baixa ambiguidade, alta estabilidade e afastamento de bordas, indicando que divergências concentram-se em transições de borda e instabilidade temporal.", indent=False)
add_p("Palavras-chave – Dynamic World, MapBiomas, MATOPIBA, Discordância Espacial, Incerteza Temporal.", indent=False, italic=True)

# Abstract
add_h1("ABSTRACT", is_abstract=True)
add_p("High-resolution (10 m) land use and land cover maps are vital for territorial monitoring. In highly seasonal agricultural frontiers such as MATOPIBA, discrepancies between Earth Observation and GeoAI products remain poorly understood. This study provides a symmetric analytical diagnosis of cropland disagreement between Dynamic World and MapBiomas (Collection 4, 10 m) for 2025. Using a design-based stratified random sample of 20,000 points across 52.34 million eligible hectares, we evaluate associations with annual probabilistic uncertainty, intra-annual dynamics, and thematic edge proximity. Census cropland disagreement reaches 14.2852% by area and 14.3110% by pixels. Using Spatial Block Bootstrap inference (30 km blocks, 1,999 replicates), disagreement is significantly associated with higher annual entropy (ΔH = +0.0162), higher temporal Jensen-Shannon divergence (ΔJSD = +0.0075), and lower modal stability (ΔS = -0.0790). At thematic edges (<30 m), disagreement is 3.87 times higher than in core areas (≥250 m). In logistic regression, edge distance (OR = 0.360) and temporal stability (OR = 0.925) show inverse associations with disagreement. Only 4.28% of weighted disagreements meet operational criteria of low ambiguity, high stability, and edge avoidance, showing that discrepancies concentrate along boundary transitions and temporal volatility.", indent=False, italic=True)
add_p("Key words – Dynamic World, MapBiomas, MATOPIBA, Spatial Disagreement, Temporal Uncertainty.", indent=False, italic=True)

# Intro
add_h1("1. INTRODUÇÃO")
add_p("A expansão agropecuária no MATOPIBA consolidou o Cerrado como polo agrícola estratégico [1, 2], demandando monitoramento apoiado em produtos de uso e cobertura da terra (LULC) de 10 m, como MapBiomas (Coleção 4) [3, 4] e Dynamic World (DW) [5]. O MapBiomas estrutura classificações anuais integrando séries temporais e filtros espaciais [3], enquanto o Dynamic World gera vetores contínuos de 9 probabilidades a cada cena Sentinel-2 [5].", indent=False)
add_p("Em ecótonos e fronteiras agrícolas tropicais, discrepâncias entre mapeamentos independentes variam entre 10% e 25% [6, 7]. Na ausência de extensos dados de referência de campo (ground truth) [8, 9], este estudo propõe um diagnóstico analítico simétrico: investigar onde e sob quais condições os produtos divergem, tratando a discordância como objeto de análise associado a sinais intrínsecos de incerteza da GeoAI.", indent=True)
add_p("Formulam-se quatro hipóteses operacionais para 2025: (H1, Ambiguidade Anual) pixels discordantes (D = 1) apresentam maior entropia média na distribuição probabilística anual do que concordantes (D = 0); (H2, Instabilidade Temporal) a discordância associa-se a maior heterogeneidade intra-anual (H2a, divergência Jensen-Shannon temporal) e a menor persistência modal (H2b, estabilidade temporal S); (H3, Efeito de Borda) a discordância é maior nas vizinhanças imediatas de bordas temáticas de transição do que no interior; (H4, Discordâncias sob Restrições Conjuntas) sob critérios operacionais estritos de menor ambiguidade anual, menor heterogeneidade temporal, maior estabilidade modal do DW e afastamento de bordas, as discordâncias restringem-se a uma fração reduzida da população discordante.", indent=True)

# Métodos
add_h1("2. MATERIAL E MÉTODOS")
add_h2("2.1. Domínio Geográfico e Critério de Elegibilidade")
add_p("O MATOPIBA abrange 337 municípios e cerca de 73 milhões de hectares. Para mitigar o impacto de nuvens persistentes, o domínio censitário elegível foi delimitado por células de 10 m com no mínimo 8 meses válidos no Dynamic World em 2025 (n_meses ≥ 8) e classes válidas no MapBiomas (excluindo água e áreas não-vegetadas). A população censitária elegível resultante totaliza 52.342.114,75 ha (5.354.669.418 pixels de 10 m).", indent=False)

add_h2("2.2. Produtos Cartográficos e Harmonização de Suporte")
add_p("Utilizou-se o MapBiomas Cobertura 10 m — Coleção 4 — 2025 [4], definindo lavoura pelo crosswalk das classes 19 (Lavoura Temporária) e 36 (Lavoura Perene), distinguindo-se de mosaico (21) e agricultura genérica (18). O produto foi projetado na grade de 10 m em SIRGAS 2000 / Policonica do Brasil (EPSG:5880).", indent=False)
add_p("Para o Dynamic World (v1) [5], o raster anual resultou da média temporal das observações do mesmo dia, média diária para mensal e agregação anual pela média dos vetores de 9 probabilidades, extraindo a classe pelo argmax anual (e não por votação modal), sendo crops (classe 4) lavoura. As séries mensais foram reamostradas para EPSG:5880 via interpolação bilinear. A não-comutatividade entre interpolação espacial e máscara de nuvens impõe resíduo probabilístico médio de 0,004983, implicando alternância de argmax em 8,24% e inversão de lavoura em 2,59% dos pontos amostrados, concentrada em margens inferiores a 0,05.", indent=True)

add_h2("2.3. Indicadores de Incerteza e Estabilidade")
add_p("Para cada ponto, calcularam-se quatro métricas contínuas: (1) Entropia de Shannon Anual Normalizada, HN(p) = -[1/ln(9)] ∑ pk ln(pk + ε) [14]; (2) Divergência Jensen-Shannon Temporal Normalizada, JSDN = HN(p_méd) - (1/M) ∑ HN(p^(m)) [15], contrastando a entropia da média temporal com a média das entropias mensais; (3) Estabilidade Categórica Modal, S = (1/M) ∑ 1(c^(m) = c_anual), fração de meses em que o argmax coincidiu com a classe anual do DW; e (4) Distância Mínima à Borda Temática, d_min = min(d_dw, d_mb), distância euclidiana métrica em raster até a transição mais próxima, truncada em 250 m, restrita ao suporte analítico de pixels sem inferência sobre limites cadastrais de talhões.", indent=False)

add_h2("2.4. Desenho Amostral e Inferência Espacial")
add_p("O espaço amostral foi particionado em 16 estratos analíticos (4 estados × 4 regimes: AA, AN, NA, NN) e operacionalizado em 410 subestratos espaciais independentes (hs). A seleção nos subestratos atribuiu probabilidade de inclusão π_{robust,hs} = n_{robust,hs} / N_{hs} na amostra robusta de 40k e π_{main,k} = 0,5 · π_{robust,hs} na amostra principal de 20k. As estimativas populacionais incorporam pesos de Horvitz-Thompson (w_k = 1 / π_k) [9].", indent=False)
add_p("Para acomodar a dependência espacial nos resíduos [10, 11], o semivariograma exponencial indicou alcance prático de 25,62 km. Conforme Künsch [12] e Roberts et al. [13], implementou-se Spatial Block Bootstrap estruturado em blocos de 30 km e 1.999 réplicas com reposição. Ajustou-se modelo logístico multivariado ponderado, interpretando os odds ratios (OR) escalonados como associações condicionais com intervalos de confiança a 95%.", indent=True)

add_h1("3. RESULTADOS")
add_h2("3.1. Discordância Censitária e Distribuição Geográfica")
add_p("No censo wall-to-wall de 52,34 Mha elegíveis, a discordância entre os produtos atinge 14,2852% por área (7.477.177,23 ha) e 14,3110% por pixels (766.304.630 pixels). A estimativa ponderada na amostra de 20.000 pontos reproduz com precisão o parâmetro censitário: 14,2897% por área (7.479.568,87 ha) e 14,3148% por pixels (766.512.449 pixels). A discordância decorre predominantemente de alocação espacial (9,30 pp) frente à divergência de quantidade de área (4,99 pp) [7]. A Tabela 1 detalha os regimes censitários e por estado (BA: 27,95%; PI: 21,80%; MA: 10,98%; TO: 5,90%), cuja composição é ilustrada na Figura 1.", indent=False)

doc.save("scratch/test_p1_p2.docx")
cmd = [r"C:\Program Files\LibreOffice\program\soffice.com", "--headless", "--convert-to", "pdf", "scratch/test_p1_p2.docx", "--outdir", "scratch"]
subprocess.run(cmd, check=True)

reader = pypdf.PdfReader("scratch/test_p1_p2.pdf")
print(f"Total pages for Section 1: {len(reader.pages)}")
for i, page in enumerate(reader.pages):
    text = page.extract_text()
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    print(f"Page {i+1}: lines={len(lines)}, chars={len(text)}")
    if lines:
        print(f"   First: {lines[0][:60]}")
        print(f"   Last:  {lines[-1][:60]}")
