import json
import numpy as np
import pandas as pd

# Load pilot definition
df_pilot = pd.read_csv('scratch/pilot_sample_points.csv', keep_default_na=False)

# Load old monthly
df_mon_old = pd.read_parquet('data/processed/dw_monthly.parquet')
df_ann_old = pd.read_parquet('data/processed/samples_annual.parquet')

# Load new bilinear pilot extraction
with open('scratch/pilot_bilinear_monthly_results.json', 'r', encoding='utf-8') as f:
    pilot_ext = json.load(f)

ext_by_id = {r['sample_id']: r for r in pilot_ext}

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

pilot_rows = []

for _, pt in df_pilot.iterrows():
    sid = pt['sample_id']
    props = ext_by_id[sid]
    
    # 1. Authoritative annual from GEE extraction
    auth_p = np.array([float(props[f'auth_p_{c}']) for c in DW_CLASSES])
    auth_sum = float(props['auth_raw_prob_sum'])
    auth_class_idx = int(props['auth_annual_class_index'])
    auth_crop = int(props['auth_dw_crop'])
    auth_n_months = int(props['auth_n_valid_months'])

    # 2. Old raw monthly from dw_monthly.parquet
    old_m = df_mon_old[(df_mon_old['sample_id'] == sid) & (df_mon_old['month_valid'] == 1)]
    old_p_mean = old_m[DW_CLASSES].mean().values
    old_p_mean_norm = old_p_mean / np.sum(old_p_mean)
    old_class_idx = int(np.argmax(old_p_mean_norm))
    old_crop = 1 if old_class_idx == 4 else 0
    old_n_months = len(old_m)
    # Old S
    old_s = np.mean([1 if np.argmax(row[DW_CLASSES].values) == auth_class_idx else 0 for _, row in old_m.iterrows()])

    # 3. New bilinear monthly from GEE pilot extraction
    new_m_list = []
    new_norm_list = []
    new_matching = 0
    valid_count_new = 0

    for m in range(1, 13):
        n_days = int(props.get(f'n_days_bil_m{m:02d}', 0))
        p_sum = float(props.get(f'prob_sum_bil_m{m:02d}', 0.0))
        if n_days > 0 and p_sum > 1e-9:
            valid_count_new += 1
            raw_m = np.array([float(props.get(f'{c}_bil_m{m:02d}', 0.0)) for c in DW_CLASSES])
            norm_m = raw_m / p_sum
            new_m_list.append(raw_m)
            new_norm_list.append(norm_m)
            if np.argmax(norm_m) == auth_class_idx:
                new_matching += 1

    new_p_mean = np.mean(new_m_list, axis=0)
    new_p_mean_norm = new_p_mean / np.sum(new_p_mean)
    new_class_idx = int(np.argmax(new_p_mean_norm))
    new_crop = 1 if new_class_idx == 4 else 0
    new_s = new_matching / valid_count_new if valid_count_new > 0 else 0.0

    # Differences vs Auth
    diff_old = np.abs(auth_p - old_p_mean_norm)
    diff_new = np.abs(auth_p - new_p_mean_norm)

    pilot_rows.append({
        'sample_id': sid,
        'state': pt['state'],
        'regime': pt['regime'],
        'dist_edge': pt['distance_edge_min_m'],
        'auth_class': DW_CLASSES[auth_class_idx],
        'auth_crop': auth_crop,
        'auth_n_months': auth_n_months,
        # Old
        'old_class': DW_CLASSES[old_class_idx],
        'old_crop': old_crop,
        'old_argmax_div': 1 if old_class_idx != auth_class_idx else 0,
        'old_crop_div': 1 if old_crop != auth_crop else 0,
        'old_max_diff': np.max(diff_old),
        'old_mean_diff': np.mean(diff_old),
        'old_s': old_s,
        # New
        'new_class': DW_CLASSES[new_class_idx],
        'new_crop': new_crop,
        'new_argmax_div': 1 if new_class_idx != auth_class_idx else 0,
        'new_crop_div': 1 if new_crop != auth_crop else 0,
        'new_max_diff': np.max(diff_new),
        'new_mean_diff': np.mean(diff_new),
        'new_s': new_s,
    })

res_df = pd.DataFrame(pilot_rows)

print("=" * 80)
print("RESULTADOS DO TESTE PILOTO (33 PONTOS)")
print("=" * 80)

print("\n1. RESUMO COMPARATIVO GLOBAL:")
print(f"Argmax divergente com Anual:")
print(f"  ORIGINAL (RAW):     {res_df['old_argmax_div'].sum()} / {len(res_df)} ({res_df['old_argmax_div'].mean()*100:.1f}%)")
print(f"  HARMONIZADO (BIL):  {res_df['new_argmax_div'].sum()} / {len(res_df)} ({res_df['new_argmax_div'].mean()*100:.1f}%)")

print(f"\ndw_crop divergente com Anual:")
print(f"  ORIGINAL (RAW):     {res_df['old_crop_div'].sum()} / {len(res_df)} ({res_df['old_crop_div'].mean()*100:.1f}%)")
print(f"  HARMONIZADO (BIL):  {res_df['new_crop_div'].sum()} / {len(res_df)} ({res_df['new_crop_div'].mean()*100:.1f}%)")

print(f"\nDiferença Absoluta Máxima de Probabilidade:")
print(f"  ORIGINAL (RAW):     {res_df['old_max_diff'].max():.6f} (Média das máx: {res_df['old_max_diff'].mean():.6f})")
print(f"  HARMONIZADO (BIL):  {res_df['new_max_diff'].max():.6f} (Média das máx: {res_df['new_max_diff'].mean():.6f})")

print("\n2. QUEBRA POR REGIME:")
by_reg = res_df.groupby('regime').agg(
    n=('sample_id', 'count'),
    old_argmax_div=('old_argmax_div', 'sum'),
    new_argmax_div=('new_argmax_div', 'sum'),
    old_crop_div=('old_crop_div', 'sum'),
    new_crop_div=('new_crop_div', 'sum'),
    old_mean_diff=('old_mean_diff', 'mean'),
    new_mean_diff=('new_mean_diff', 'mean'),
    old_s=('old_s', 'mean'),
    new_s=('new_s', 'mean')
)
print(by_reg.to_string())

print("\n3. QUEBRA POR ESTADO:")
by_st = res_df.groupby('state').agg(
    n=('sample_id', 'count'),
    old_argmax_div=('old_argmax_div', 'sum'),
    new_argmax_div=('new_argmax_div', 'sum'),
    old_crop_div=('old_crop_div', 'sum'),
    new_crop_div=('new_crop_div', 'sum'),
    old_mean_diff=('old_mean_diff', 'mean'),
    new_mean_diff=('new_mean_diff', 'mean'),
)
print(by_st.to_string())

print("\n4. CASO ESPECÍFICO PT_010352:")
pt_row = res_df[res_df['sample_id'] == 'PT_010352'].iloc[0]
print(f"  Regime: {pt_row['regime']} | Auth Class: {pt_row['auth_class']} (crop={pt_row['auth_crop']})")
print(f"  OLD (RAW):  Class={pt_row['old_class']} (crop={pt_row['old_crop']}), max_diff={pt_row['old_max_diff']:.4f}, S={pt_row['old_s']:.4f}")
print(f"  NEW (BIL):  Class={pt_row['new_class']} (crop={pt_row['new_crop']}), max_diff={pt_row['new_max_diff']:.4f}, S={pt_row['new_s']:.4f}")

res_df.to_csv('scratch/pilot_evaluation_summary.csv', index=False)
