import pandas as pd
import numpy as np

# Load tables
df_main_pts = pd.read_parquet('data/processed/samples_annual.parquet')
df_alloc = pd.read_csv('tables/slice_sampling_allocation_final.csv')
df_quotas = pd.read_csv('tables/sampling_quotas.csv')
df_w2w = pd.read_csv('data/processed/wall_to_wall_summary.csv')
df_frame = pd.read_csv('tables/sampling_frame_10m.csv')

main = df_main_pts[df_main_pts['main_sample'] == 1].copy()
robust = df_main_pts[df_main_pts['robust_sample'] == 1].copy()

# Convert weights
main['w_des'] = main['design_weight_main'].astype(float)
main['w_area'] = main['area_weight_main'].astype(float)
main['pi_main'] = main['selection_probability_main'].astype(float)
robust['w_des'] = robust['design_weight_robust'].astype(float)
robust['w_area'] = robust['area_weight_robust'].astype(float)
robust['pi_rob'] = robust['selection_probability_robust'].astype(float)

print('=== 1. VERIFICAÇÃO DE PROBABILIDADES DE INCLUSÃO E PESOS ===')
print(f'N main points: {len(main)}')
print(f'N robust points: {len(robust)}')
print(f'Min pi_main: {main["pi_main"].min():.10e}, Max pi_main: {main["pi_main"].max():.10e}')
print(f'Any pi_main <= 0? {(main["pi_main"] <= 0).any()}')
print(f'Any pi_main NaN? {main["pi_main"].isna().any()}')

# Verify w_des == 1/pi
diff_w_des = np.abs(main['w_des'] - 1.0 / main['pi_main'])
print(f'Max diff |w_des - 1/pi_main|: {diff_w_des.max():.10e}')

# Verify w_area == pixel_area_m2 / pi
diff_w_area = np.abs(main['w_area'] - main['pixel_area_m2'] / main['pi_main'])
print(f'Max diff |w_area - pixel_area_m2 / pi_main|: {diff_w_area.max():.10e}')

# pixel_area_m2 stats
print(f'pixel_area_m2 stats: min={main["pixel_area_m2"].min():.4f}, mean={main["pixel_area_m2"].mean():.4f}, max={main["pixel_area_m2"].max():.4f}, std={main["pixel_area_m2"].std():.4f}')

print('\n=== 2. FECHAMENTO POPULACIONAL (SOMAS PONDERADAS) ===')
# Total pixels in eligible frame
total_pixels_frame = df_alloc['N_hs_exact'].sum()
sum_w_des_main = main['w_des'].sum()
sum_w_des_rob = robust['w_des'].sum()
print(f'Total pixels no frame:           {total_pixels_frame:,}')
print(f'Soma design weights (main 20k):   {sum_w_des_main:,.2f} (diff: {sum_w_des_main - total_pixels_frame:,.2f})')
print(f'Soma design weights (robust 40k): {sum_w_des_rob:,.2f} (diff: {sum_w_des_rob - total_pixels_frame:,.2f})')

# Total area in eligible frame
total_area_frame_ha = df_alloc['A_hs'].sum()
sum_w_area_main_ha = main['w_area'].sum() / 10000.0
sum_w_area_rob_ha = robust['w_area'].sum() / 10000.0
print(f'Total área no frame (ha):         {total_area_frame_ha:,.2f} ha')
print(f'Soma area weights main (ha):      {sum_w_area_main_ha:,.2f} ha (diff: {sum_w_area_main_ha - total_area_frame_ha:,.2f} ha, {(sum_w_area_main_ha - total_area_frame_ha)/total_area_frame_ha*100:.6f}%)')
print(f'Soma area weights robust (ha):    {sum_w_area_rob_ha:,.2f} ha (diff: {sum_w_area_rob_ha - total_area_frame_ha:,.2f} ha, {(sum_w_area_rob_ha - total_area_frame_ha)/total_area_frame_ha*100:.6f}%)')

print('\n=== 3. COMPARAÇÃO ESTIMATIVAS: DESIGN WEIGHTS VS AREA WEIGHTS ===')
# Regime proportions
p_reg_des = main.groupby('regime')['w_des'].sum() / main['w_des'].sum() * 100
p_reg_area = main.groupby('regime')['w_area'].sum() / main['w_area'].sum() * 100
comp_df = pd.DataFrame({'Pixel_pct_w_des': p_reg_des, 'Area_pct_w_area': p_reg_area})
comp_df['Diff_pp'] = comp_df['Area_pct_w_area'] - comp_df['Pixel_pct_w_des']
print(comp_df)

disc_des = (main[main['regime'].isin(['AN', 'NA'])]['w_des'].sum() / main['w_des'].sum()) * 100
disc_area = (main[main['regime'].isin(['AN', 'NA'])]['w_area'].sum() / main['w_area'].sum()) * 100
print(f'\nTaxa geral de discordancia: Pixel (w_des) = {disc_des:.6f}%, Area (w_area) = {disc_area:.6f}%, Diff = {disc_area - disc_des:+.6f} pp')

# State discordance comparison
st_disc = []
for st in ['MA', 'TO', 'PI', 'BA']:
    m_st = main[main['state'] == st]
    d_des = (m_st[m_st['regime'].isin(['AN', 'NA'])]['w_des'].sum() / m_st['w_des'].sum()) * 100
    d_area = (m_st[m_st['regime'].isin(['AN', 'NA'])]['w_area'].sum() / m_st['w_area'].sum()) * 100
    st_disc.append({'State': st, 'Disc_pixel_w_des': d_des, 'Disc_area_w_area': d_area, 'Diff_pp': d_area - d_des})
print(pd.DataFrame(st_disc))

# Indicators H1, H2a, H2b comparison
main['D'] = main['regime'].isin(['AN', 'NA']).astype(int)
for var, name in [('entropy_annual', 'H_annual'), ('jsd_temporal', 'JSD'), ('stability', 'Stability')]:
    m0_des = (main[main['D'] == 0][var] * main[main['D'] == 0]['w_des']).sum() / main[main['D'] == 0]['w_des'].sum()
    m1_des = (main[main['D'] == 1][var] * main[main['D'] == 1]['w_des']).sum() / main[main['D'] == 1]['w_des'].sum()
    delta_des = m1_des - m0_des
    
    m0_area = (main[main['D'] == 0][var] * main[main['D'] == 0]['w_area']).sum() / main[main['D'] == 0]['w_area'].sum()
    m1_area = (main[main['D'] == 1][var] * main[main['D'] == 1]['w_area']).sum() / main[main['D'] == 1]['w_area'].sum()
    delta_area = m1_area - m0_area
    print(f'{name}: Delta_pixel = {delta_des:.6f}, Delta_area = {delta_area:.6f}, Diff = {delta_area - delta_des:+.8f}')
