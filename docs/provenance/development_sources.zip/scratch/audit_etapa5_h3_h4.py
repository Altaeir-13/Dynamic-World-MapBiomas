import pandas as pd
import numpy as np

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
main = df_ann[df_ann['main_sample'] == 1].copy()
main['D'] = main['regime'].isin(['AN', 'NA']).astype(int)
main['w'] = main['design_weight_main'].astype(float)

# H3: Distance to edges
print("=== ETAPA 5: AUDITORIA H3 (DISTÂNCIA À BORDA TEMÁTICA) ===")
print("Summary of distance_edge_min_m:")
print(main['distance_edge_min_m'].describe())
print(f"Points at exactly 250m: {(main['distance_edge_min_m'] == 250.0).sum()} ({(main['distance_edge_min_m'] == 250.0).mean()*100:.2f}%)")
print(f"Weighted area at exactly 250m: {(main[main['distance_edge_min_m'] == 250.0]['w'].sum() / main['w'].sum())*100:.2f}%")

bins = [0, 10, 30, 60, 100, 250, np.inf]
labels = ["0–10 m", "10–30 m", "30–60 m", "60–100 m", "100–250 m", ">=250 m"]
main['bin'] = pd.cut(main['distance_edge_min_m'], bins=bins, labels=labels, right=False)

h3_tab = []
for lab in labels:
    sub = main[main['bin'] == lab]
    n_pts = len(sub)
    n_d1 = (sub['D'] == 1).sum()
    w_tot = sub['w'].sum()
    w_d1 = sub[sub['D'] == 1]['w'].sum()
    disc_rate = w_d1 / w_tot * 100
    area_share = w_tot / main['w'].sum() * 100
    h3_tab.append({
        'bin': lab, 'n_points': n_pts, 'n_disc': n_d1,
        'area_share_pct': area_share, 'disc_rate_pct': disc_rate
    })
df_h3 = pd.DataFrame(h3_tab)
print("\nTabela H3 por Faixa de Distância:")
print(df_h3.to_string(index=False))

print("\n=== ETAPA 5: AUDITORIA H4 (FILTROS DE DISCORDÂNCIA ROBUSTA) ===")
# Thresholds
q1_h = 0.8090311814372289
q1_jsd = 0.02068182517448025
q3_s = 0.6666666666666666
d_edge_min = 30.0

d1 = main[main['D'] == 1].copy()
n_d1 = len(d1)
w_d1_tot = d1['w'].sum()

d1['f_h'] = d1['entropy_annual'] <= q1_h
d1['f_jsd'] = d1['jsd_temporal'] <= q1_jsd
d1['f_s'] = d1['stability'] >= q3_s
d1['f_d'] = d1['distance_edge_min_m'] >= d_edge_min

print(f"Total pontos discordantes (D=1): {n_d1} (área ponderada: {w_d1_tot:,.2f})")
print("\n1. Filtros Marginais:")
for col, name in [('f_h', 'H <= Q1'), ('f_jsd', 'JSD <= Q1'), ('f_s', 'S >= Q3'), ('f_d', 'd_min >= 30m')]:
    cnt = d1[col].sum()
    w_cnt = d1[d1[col]]['w'].sum()
    print(f"  {name:15s}: {cnt:5d} ({cnt/n_d1*100:6.2f}% unweighted, {w_cnt/w_d1_tot*100:6.2f}% weighted)")

print("\n2. Interseções de 2 Filtros:")
pairs = [
    ('f_h & f_jsd', d1['f_h'] & d1['f_jsd']),
    ('f_h & f_s', d1['f_h'] & d1['f_s']),
    ('f_h & f_d', d1['f_h'] & d1['f_d']),
    ('f_jsd & f_s', d1['f_jsd'] & d1['f_s']),
    ('f_jsd & f_d', d1['f_jsd'] & d1['f_d']),
    ('f_s & f_d', d1['f_s'] & d1['f_d']),
]
for name, mask in pairs:
    print(f"  {name:15s}: {mask.sum():5d} ({mask.sum()/n_d1*100:6.2f}%)")

print("\n3. Interseções de 3 Filtros:")
triples = [
    ('f_h & f_jsd & f_s', d1['f_h'] & d1['f_jsd'] & d1['f_s']),
    ('f_h & f_jsd & f_d', d1['f_h'] & d1['f_jsd'] & d1['f_d']),
    ('f_h & f_s & f_d', d1['f_h'] & d1['f_s'] & d1['f_d']),
    ('f_jsd & f_s & f_d', d1['f_jsd'] & d1['f_s'] & d1['f_d']),
]
for name, mask in triples:
    print(f"  {name:20s}: {mask.sum():5d} ({mask.sum()/n_d1*100:6.2f}%)")

f_all = d1['f_h'] & d1['f_jsd'] & d1['f_s'] & d1['f_d']
print(f"\n4. Interseção Total (4 Filtros): {f_all.sum()} (0.00%)")
print(f"Nota: H <= Q1 AND S >= Q3 é EXATAMENTE ZERO: {(d1['f_h'] & d1['f_s']).sum()} pontos!")
