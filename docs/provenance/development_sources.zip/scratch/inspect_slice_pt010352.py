import json

with open('data/processed/extraction_slices/MA_x06_y04.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

print('Total points in slice:', len(data))
pt = next((p for p in data if p.get('sample_id') == 'PT_010352'), None)
if pt:
    print('Keys in pt:', sorted(pt.keys()))
    print('\nAuth keys:')
    for k in sorted(pt.keys()):
        if 'auth' in k or 'crop' in k:
            print(f'  {k}: {pt[k]}')
    print('\nMonthly prob sum and raw crops/trees:')
    for m in range(1, 13):
        print(f"  m{m:02d}: prob_sum={pt.get(f'prob_sum_m{m:02d}')}, n_days={pt.get(f'n_days_m{m:02d}')}, crops={pt.get(f'crops_m{m:02d}')}, trees={pt.get(f'trees_m{m:02d}')}")
