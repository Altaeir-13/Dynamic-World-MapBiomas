import docx
from docx.shared import Mm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
import os
import subprocess
import pypdf
import pypdfium2 as pdfium

def set_cell_border(cell, **kwargs):
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key, val in edge_data.items():
                element.set(qn('w:{}'.format(key)), str(val))

def set_cell_margins(cell, top=60, bottom=60, left=80, right=80):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def set_section_cols(section, num_cols=2, space_dxa=340):
    sectPr = section._sectPr
    for child in list(sectPr):
        if child.tag.endswith('cols'):
            sectPr.remove(child)
    cols = OxmlElement('w:cols')
    cols.set(qn('w:num'), str(num_cols))
    if num_cols > 1:
        cols.set(qn('w:space'), str(space_dxa))
        cols.set(qn('w:equalWidth'), '1')
    sectPr.append(cols)

def build_v3_1_docx(output_path):
    doc = docx.Document()
    
    # Section 0: Title and Authors (1 column)
    # Printable area: 178 mm width x 229 mm height
    # Margins: Left 19 mm, Right 13 mm, Top 25 mm, Bottom 43 mm
    # Title vertical position: 35 mm from top page edge -> 25 mm top margin + 10 mm space_before (~28.3 pt)
    sec0 = doc.sections[0]
    sec0.page_width = Mm(210)
    sec0.page_height = Mm(297)
    sec0.left_margin = Mm(19)
    sec0.right_margin = Mm(13)
    sec0.top_margin = Mm(25)
    sec0.bottom_margin = Mm(43)
    set_section_cols(sec0, 1)

    # Helper for adding sections
    def add_sec(start_type=WD_SECTION_START.CONTINUOUS, cols=2):
        s = doc.add_section(start_type)
        s.page_width = Mm(210)
        s.page_height = Mm(297)
        s.left_margin = Mm(19)
        s.right_margin = Mm(13)
        s.top_margin = Mm(25)
        s.bottom_margin = Mm(43)
        set_section_cols(s, cols)
        return s

    # Title: 14 pt, Bold, Uppercase, Centered, Times New Roman
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(28) # 25mm + 10mm = 35mm from top edge
    p_title.paragraph_format.space_after = Pt(4)
    p_title.paragraph_format.line_spacing = Pt(16)
    r_title = p_title.add_run("ONDE DYNAMIC WORLD E MAPBIOMAS DISCORDAM SOBRE LAVOURAS? DIAGNÓSTICO ESPACIAL E PROBABILÍSTICO NO MATOPIBA")
    r_title.font.name = 'Times New Roman'
    r_title.font.size = Pt(14)
    r_title.font.bold = True

    # Authors: 10 pt bold
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_before = Pt(3)
    p_auth.paragraph_format.space_after = Pt(2)
    r_auth = p_auth.add_run("[Nome do Primeiro Autor]¹*, [Nome do Segundo Autor]², [Nome do Terceiro Autor]³ e [Nome do Último Autor]⁴")
    r_auth.font.name = 'Times New Roman'
    r_auth.font.size = Pt(10)
    r_auth.font.bold = True

    # Affiliations: 8 pt regular
    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff.paragraph_format.space_before = Pt(0)
    p_aff.paragraph_format.space_after = Pt(6)
    p_aff.paragraph_format.line_spacing = Pt(10.5)
    r_aff = p_aff.add_run(
        "¹ [Instituição do Autor 1] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor1@instituicao.edu.br]\n"
        "² [Instituição do Autor 2] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor2@instituicao.edu.br]\n"
        "³ [Instituição do Autor 3] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor3@instituicao.edu.br]\n"
        "⁴ [Instituição do Autor 4] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor4@instituicao.edu.br]\n"
        "*Autor correspondente: [email.autor1@instituicao.edu.br]"
    )
    r_aff.font.name = 'Times New Roman'
    r_aff.font.size = Pt(8)

    # Paragraph helpers
    def add_h1(text, is_abstract=False):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(8)
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(10)
        r.font.bold = True
        if is_abstract:
            r.font.italic = True
        return p

    def add_h2(text):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.space_before = Pt(5)
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(10)
        r.font.bold = True
        return p

    def add_p(text, indent=True, italic=False, bold=False, align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_after=2):
        p = doc.add_paragraph()
        p.alignment = align
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(space_after)
        p.paragraph_format.line_spacing = Pt(11.5) # single spacing for 10pt
        if indent:
            p.paragraph_format.first_line_indent = Mm(6.3) # 0.63 cm official
        else:
            p.paragraph_format.first_line_indent = Mm(0)
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(10)
        r.font.italic = italic
        r.font.bold = bold
        return p

    def add_caption(text):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(9)
        r.font.bold = True
        return p

    # ==========================================
    # SECTION 1: 2 columns (Resumo to 3.1)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.CONTINUOUS, cols=2)

    add_h1("RESUMO")
    add_p(
        "Mapeamentos de uso e cobertura da terra em escala decamétrica (10 m) são vitais para o monitoramento territorial. "
        "Em fronteiras agrícolas com acentuada sazonalidade como o MATOPIBA, divergências entre produtos de GeoAI permanecem pouco elucidadas. "
        "Este estudo apresenta um diagnóstico simétrico da discordância de lavouras entre Dynamic World e MapBiomas (Coleção 4, 10 m) em 2025. "
        "Com amostragem probabilística estratificada de 20.000 pontos em 52,34 milhões de hectares elegíveis, avaliou-se a associação da "
        "discordância com incerteza probabilística anual, dinâmica temporal e proximidade a bordas temáticas. A discordância censitária "
        "atinge 14,2852% por área e 14,3110% por pixels. Sob Spatial Block Bootstrap (blocos de 30 km, 1.999 réplicas), a discordância "
        "associa-se a maior entropia anual (ΔH = +0,0162), maior divergência Jensen-Shannon temporal (ΔJSD = +0,0075) e menor "
        "estabilidade modal (ΔS = -0,0790). Em bordas (<30 m), a discordância é 3,87 vezes superior à do interior (≥250 m). "
        "Na regressão logística, distância à borda (OR = 0,360) e estabilidade temporal (OR = 0,925) associam-se inversamente à discordância. "
        "Apenas 4,28% ponderado das discordâncias atendem a critérios operacionais de baixa ambiguidade, alta estabilidade e afastamento de bordas, "
        "indicando que divergências concentram-se em transições de borda e instabilidade temporal.",
        indent=False
    )
    add_p("Palavras-chave – Dynamic World, MapBiomas, MATOPIBA, Discordância Espacial, Incerteza Temporal.", indent=False, italic=True)

    add_h1("ABSTRACT", is_abstract=True)
    add_p(
        "High-resolution (10 m) land use and land cover maps are vital for territorial monitoring. In highly seasonal agricultural "
        "frontiers such as MATOPIBA, discrepancies between Earth Observation and GeoAI products remain poorly understood. This study provides "
        "a symmetric analytical diagnosis of cropland disagreement between Dynamic World and MapBiomas (Collection 4, 10 m) for 2025. "
        "Using a design-based stratified random sample of 20,000 points across 52.34 million eligible hectares, we evaluate associations with "
        "annual probabilistic uncertainty, intra-annual dynamics, and thematic edge proximity. Census cropland disagreement reaches 14.2852% by "
        "area and 14.3110% by pixels. Using Spatial Block Bootstrap inference (30 km blocks, 1,999 replicates), disagreement is significantly "
        "associated with higher annual entropy (ΔH = +0.0162), higher temporal Jensen-Shannon divergence (ΔJSD = +0.0075), and lower "
        "modal stability (ΔS = -0.0790). At thematic edges (<30 m), disagreement is 3.87 times higher than in core areas (≥250 m). "
        "In logistic regression, edge distance (OR = 0.360) and temporal stability (OR = 0.925) show inverse associations with disagreement. "
        "Only 4.28% of weighted disagreements meet operational criteria of low ambiguity, high stability, and edge avoidance, showing that "
        "discrepancies concentrate along boundary transitions and temporal volatility.",
        indent=False, italic=True
    )
    add_p("Key words – Dynamic World, MapBiomas, MATOPIBA, Spatial Disagreement, Temporal Uncertainty.", indent=False, italic=True)

    add_h1("1. INTRODUÇÃO")
    add_p(
        "A expansão agropecuária no MATOPIBA (confluência de Maranhão, Tocantins, Piauí e Bahia) consolidou o Cerrado como polo agrícola "
        "estratégico [1, 2]. Essa dinâmica demanda monitoramento sistemático apoiado em produtos de uso e cobertura da terra (LULC) de "
        "alta resolução (10 m), como o MapBiomas (Coleção 4, 10 m) [3, 4] e o Dynamic World (DW) [5]. O MapBiomas estrutura classificações "
        "anuais integrando séries temporais e filtros espaciais [3], enquanto o Dynamic World estima vetores contínuos de probabilidades para "
        "nove classes a cada cena Sentinel-2 [5].",
        indent=False
    )
    add_p(
        "Em ecótonos e fronteiras agrícolas tropicais, discrepâncias entre mapeamentos independentes são frequentes, variando entre 10% e 25% [6, 7]. "
        "Na ausência de extensos dados de referência de campo (ground truth), a validação pontual convencional enfrenta limitações de escala e "
        "custo [8, 9]. Este estudo propõe um diagnóstico analítico simétrico: investigar onde e sob quais condições os produtos divergem, tratando a "
        "discordância como objeto de análise associado a sinais intrínsecos de incerteza da Inteligência Artificial Geoespacial (GeoAI).",
        indent=True
    )
    add_p(
        "Formulam-se quatro hipóteses operacionais para o ano de 2025:\n"
        "• H1 (Ambiguidade Anual): pixels com discordância temática (D = 1) apresentam maior entropia informacional média na distribuição probabilística anual do que concordantes (D = 0);\n"
        "• H2 (Instabilidade Temporal): a discordância associa-se a maior heterogeneidade intra-anual de probabilidades (H2a, divergência Jensen-Shannon temporal) e a menor persistência categórica modal (H2b, estabilidade temporal S);\n"
        "• H3 (Efeito de Borda Temática): a proporção de discordância é maior nas vizinhanças imediatas de bordas temáticas de transição do que no interior de manchas contínuas;\n"
        "• H4 (Discordâncias sob Restrições Conjuntas): sob critérios operacionais estritos de menor ambiguidade probabilística anual, menor heterogeneidade temporal, maior estabilidade modal do Dynamic World e afastamento de bordas temáticas, a ocorrência de discordâncias restringe-se a uma fração reduzida da população discordante.",
        indent=True
    )

    add_h1("2. MATERIAL E MÉTODOS")
    add_h2("2.1. Domínio Geográfico e Critério de Elegibilidade")
    add_p(
        "O MATOPIBA abrange 337 municípios e cerca de 73 milhões de hectares. Para mitigar o impacto de cobertura persistente de nuvens, o "
        "domínio censitário elegível foi delimitado por células de 10 m que apresentaram no mínimo 8 meses válidos no Dynamic World em 2025 "
        "(n_meses ≥ 8) e classes temáticas válidas no MapBiomas (excluindo corpos d'água permanentes e áreas não-vegetadas). A "
        "população censitária elegível resultante totaliza 52.342.114,75 ha (5.354.669.418 pixels de 10 m).",
        indent=False
    )
    add_h2("2.2. Produtos Cartográficos e Harmonização de Suporte")
    add_p(
        "Utilizou-se o MapBiomas Cobertura 10 m — Coleção 4 — 2025 [4], baseado em mosaicos Sentinel-2. A classe de lavoura foi definida "
        "pelo crosswalk principal composto pelas classes 19 (Lavoura Temporária) e 36 (Lavoura Perene), distinguindo-se das classes 21 "
        "(Mosaico de Usos) e 18 (Agricultura, nível superior). O produto nativo foi projetado na grade analítica de 10 m em SIRGAS 2000 / "
        "Policonica do Brasil (EPSG:5880).",
        indent=False
    )
    add_p(
        "Para o Dynamic World (v1) [5], o pipeline composicional gerou o raster anual mediante média temporal das observações do mesmo "
        "dia, média diária para mensal e agregação anual pela média dos vetores de 9 probabilidades, extraindo-se a classe pelo argmax do "
        "vetor anual (e não por votação modal). A classe 4 (crops) definiu lavoura no DW. As séries mensais foram harmonizadas espacialmente "
        "para EPSG:5880 via reamostragem bilinear. Devido à não-comutatividade matemática entre a interpolação espacial e a máscara temporal de "
        "nuvens, persiste uma diferença probabilística média residual de 0,004983, implicando alternância de argmax em 8,24% e inversão de "
        "lavoura em 2,59% dos pontos amostrados, concentrada em margens probabilísticas inferiores a 0,05.",
        indent=True
    )
    add_h2("2.3. Indicadores de Incerteza e Estabilidade")
    add_p(
        "Para cada ponto amostral, computaram-se quatro métricas contínuas:\n"
        "1. Entropia de Shannon Anual Normalizada (HN): normalizada por ln(9) [14]:\n"
        "   HN(p) = - [1 / ln(9)] ∑_{k=1..9} pk ln(pk + ε)\n"
        "2. Divergência Jensen-Shannon Temporal Normalizada (JSDN): contraste direto entre a entropia normalizada da probabilidade média temporal e a média das entropias normalizadas dos M meses válidos [15]:\n"
        "   JSDN = HN(p_méd) - (1/M) ∑_{m=1..M} HN(p^(m))\n"
        "   onde p_méd = (1/M) ∑ p^(m) é o vetor médio mensal. Como as entropias já se encontram normalizadas por ln(9), a expressão dispensa divisão subsequente;\n"
        "3. Estabilidade Categórica Modal (S): proporção dos meses válidos em que a classe dominante (argmax) coincidiu com a classe anual do Dynamic World:\n"
        "   S = (1/M) ∑_{m=1..M} 1(c^(m) = c_anual)\n"
        "4. Distância Mínima à Borda Temática (d_min): distância euclidiana métrica calculada em raster até a borda temática de transição mais próxima de Dynamic World ou MapBiomas (min(d_dw, d_mb)), truncada em 250 m. O suporte analítico refere-se estritamente a pixels de 10 m e manchas contínuas de raster, sem correspondência com limites cadastrais ou geometrias de talhões agrícolas.",
        indent=False
    )
    add_h2("2.4. Desenho Amostral e Inferência Espacial")
    add_p(
        "O espaço amostral foi particionado em 16 estratos científicos de análise (combinação de 4 Unidades Federativas com 4 regimes temáticos: "
        "AA: Acordo Lavoura; AN: MapBiomas Lavoura e DW Não-Lavoura; NA: DW Lavoura e MapBiomas Não-Lavoura; NN: Acordo Não-Lavoura) e operacionalizado "
        "em 410 subestratos espaciais independentes (slices operacionais hs). A seleção amostral ocorreu no nível dos subestratos operacionais, "
        "onde cada célula k pertencente ao subestrato hs possui probabilidade de inclusão π_{robust,hs} = n_{robust,hs} / N_{hs} "
        "na amostra robusta de 40k (n_{robust,hs} ≥ 1 para todo subestrato não-vazio) e probabilidade π_{main,k} = 0,5 · π_{robust,hs} "
        "na amostra principal de 20k. As estimativas populacionais incorporam os pesos de Horvitz-Thompson inversos às probabilidades efetivas de seleção operacional (w_k = 1 / π_k) [9].",
        indent=False
    )
    add_p(
        "Para acomodar a dependência espacial presente nos resíduos [10, 11], ajustou-se semivariograma empírico exponencial sobre o resíduo da "
        "discordância, identificando alcance prático de 25,62 km. Conforme o protocolo e diretrizes de particionamento [12, 13], implementou-se "
        "Spatial Block Bootstrap como aproximação inferencial estruturada em blocos primários regulares de 30 km e 1.999 réplicas com "
        "reposição. Ajustou-se modelo logístico multivariado ponderado, interpretando os odds ratios (OR) escalonados como associações "
        "condicionais ajustadas, acompanhados de intervalos de confiança empíricos a 95%.",
        indent=True
    )

    add_h1("3. RESULTADOS")
    add_h2("3.1. Discordância Censitária e Distribuição Geográfica")
    add_p(
        "No censo wall-to-wall dos 52,34 Mha elegíveis, a discordância temática entre os produtos atinge 14,2852% por área "
        "(7.477.177,23 ha) e 14,3110% por pixels (766.304.630 pixels). A estimativa ponderada na amostra de 20.000 pontos reproduz com "
        "precisão o parâmetro censitário: 14,2897% por área (7.479.568,87 ha) e 14,3148% por contagem de pixels (766.512.449 pixels). "
        "A discordância decorre predominantemente de alocação espacial (9,30 pp) frente à divergência de quantidade de área (4,99 pp) [7].",
        indent=False
    )
    add_p(
        "A Tabela 1 detalha os regimes censitários e por estado. A discordância varia fortemente entre as Unidades Federativas: a Bahia exibe "
        "a maior proporção (27,95%), seguida por Piauí (21,80%), Maranhão (10,98%) e Tocantins (5,90%). A Figura 1 ilustra a composição dos "
        "regimes temáticos e o gradiente estadual observado.",
        indent=True
    )

    # ==========================================
    # SECTION 2: 1 column (NEW PAGE -> PAGE 3 TOP: TABELA 1)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.NEW_PAGE, cols=1)
    add_caption("Tabela 1. Composição censitária e amostral ponderada por regime temático e estado no MATOPIBA (2025). Fontes: tables/sampling_frame_10m.csv e tables/descriptive_regime_proportions.csv.")
    
    t1_data = [
        ["Regime Temático / Estado", "Área Censitária (ha)", "Proporção Censitária (%)", "Censo Pixels (%)", "Amostra 20k Ponderada (%)", "IC 95% Espacial (30 km)"],
        ["AA (Acordo Lavoura)", "1.274.056,40", "2,4341%", "2,4398%", "2,4334%", "[2,01%; 2,98%]"],
        ["AN (MapBiomas Sim, DW Não)", "5.044.314,15", "9,6372%", "9,6557%", "9,6465%", "[8,95%; 10,48%]"],
        ["NA (DW Sim, MapBiomas Não)", "2.432.863,07", "4,6480%", "4,6592%", "4,6432%", "[4,12%; 5,26%]"],
        ["NN (Acordo Não-Lavoura)", "43.590.881,12", "83,2807%", "83,2454%", "83,2769%", "[82,05%; 84,38%]"],
        ["Discordância Total (AN+NA)", "7.477.177,23", "14,2852%", "14,3110%", "14,2897%", "[13,42%; 15,28%]"],
        ["Maranhão (MA)", "1.093.012,65", "10,9757%", "10,9842%", "10,9624%", "[9,25%; 13,01%]"],
        ["Tocantins (TO)", "1.338.415,21", "5,9012%", "5,9104%", "5,8973%", "[4,88%; 7,12%]"],
        ["Piauí (PI)", "1.639.894,85", "21,7956%", "21,8120%", "21,8165%", "[18,44%; 25,62%]"],
        ["Bahia (BA)", "3.405.854,52", "27,9519%", "27,9845%", "27,9752%", "[24,80%; 31,45%]"],
    ]
    col_widths_mm = [42, 28, 26, 24, 28, 30] # sum = 178 mm
    t1 = doc.add_table(rows=len(t1_data), cols=6)
    t1.alignment = WD_TABLE_ALIGNMENT.CENTER
    tblPr = t1._tbl.tblPr
    tblW = parse_xml(r'<w:tblW xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" w:w="10091" w:type="dxa"/>')
    tblPr.append(tblW)

    for r_idx, row in enumerate(t1_data):
        trPr = t1.rows[r_idx]._tr.get_or_add_trPr()
        trPr.append(parse_xml(r'<w:cantSplit xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))
        if r_idx == 0:
            trPr.append(parse_xml(r'<w:tblHeader xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))
            
        for c_idx, val in enumerate(row):
            cell = t1.cell(r_idx, c_idx)
            cell.width = Mm(col_widths_mm[c_idx])
            cell.text = val
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if c_idx == 0 else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.line_spacing = Pt(9)
            set_cell_margins(cell, top=50, bottom=50, left=70, right=70)
            for r in p.runs:
                r.font.name = 'Times New Roman'
                r.font.size = Pt(7.5)
                if r_idx == 0 or r_idx == 5:
                    r.font.bold = True
            if r_idx == 0:
                set_cell_border(cell, top=dict(sz=8, val='single', color='000000'), bottom=dict(sz=8, val='single', color='000000'))
            elif r_idx == len(t1_data) - 1:
                set_cell_border(cell, bottom=dict(sz=8, val='single', color='000000'))

    # ==========================================
    # SECTION 3: 2 columns (CONTINUES ON PAGE 3 BELOW TABELA 1: 3.2, FIGURA 2, 3.3)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.CONTINUOUS, cols=2)

    add_h2("3.2. Testes de Hipótese H1 a H4")
    add_p(
        "A avaliação das quatro hipóteses operacionais revelou padrões consistentes de incerteza informacional e espacial:\n"
        "• H1 (Ambiguidade Anual): A entropia anual média é superior nas células discordantes (ΔH = +0,0162, IC 95%: [+0,0103; +0,0221], Cohen's d = +0,318), evidenciando associação positiva com incerteza probabilística na classificação anual;\n"
        "• H2a e H2b (Dinâmica Temporal): Pixels discordantes exibem maior divergência temporal bivariada (ΔJSD = +0,007492, IC 95%: [+0,0047; +0,0102], d = +0,335) e menor persistência categórica modal (ΔS = -0,078959, IC 95%: [-0,0974; -0,0599], d = -0,426);\n"
        "• H3 (Efeito de Borda Temática): A taxa de discordância atinge 45,91% na borda imediata (<30 m) e cai para 11,87% no interior (≥250 m), gerando razão de contraste de 3,87 vezes. Entre faixas contíguas, observa-se quebra local de monotonicidade estrita (30–60 m com 45,77% vs. 10–30 m com 44,59%), caracterizando forte gradiente inverso global sem monotonicidade perfeita;\n"
        "• H4 (Discordâncias sob Restrições Conjuntas): Sob critérios operacionais simultâneos de menor ambiguidade probabilística anual (H ≤ Q1), menor heterogeneidade temporal (JSD ≤ Q1), maior estabilidade modal do Dynamic World (S ≥ Q3) e afastamento de bordas temáticas (d_min ≥ 30 m), apenas 207 pontos atendem aos requisitos na amostra de 20k (4,2773% ponderado dos pixels discordantes), confirmados em 404 pontos na amostra de 40k (4,1687% ponderado).",
        indent=False
    )

    # Figura 2 (fits inside 1 column, 84 mm width)
    if os.path.exists('figures/fig5_disagreement_by_distance_bin.png'):
        p_f2 = doc.add_paragraph()
        p_f2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_f2.paragraph_format.space_before = Pt(3)
        p_f2.paragraph_format.space_after = Pt(2)
        p_f2.add_run().add_picture('figures/fig5_disagreement_by_distance_bin.png', width=Mm(84))
        add_caption("Figura 2. Taxa de discordância temática por faixas métricas de distância às bordas com IC 95% empírico derivado de Spatial Block Bootstrap (30 km).")

    add_h2("3.3. Associações Marginais versus Condicionais")
    add_p(
        "A comparação entre as estimativas bivariadas e o modelo logístico multivariado revela distinções metodológicas importantes:\n"
        "1. Atenuação da Divergência Temporal (JSD): Enquanto a JSD exibe forte associação positiva marginal em H2a, seu efeito condicional na regressão dissipa-se (OR = 0,987, IC: [0,914; 1,059]). Quando a persistência categórica S e o afastamento de bordas são controlados conjuntamente, a variação contínua da JSD não agrega poder explicativo condicional adicional. Essa atenuação decorre da correlação empírica entre os regressores, não constituindo demonstração causal de mediação;\n"
        "2. Impacto do Ajuste Espacial no Contraste Estadual: Sob premissa assintótica clássica i.i.d., o contraste Piauí versus Bahia sugeriria significância (p < 0,001, IC analítico: [0,709; 0,900]). O Spatial Block Bootstrap de 30 km acomoda a dependência espacial e expande o intervalo para [0,507; 1,212], cobrindo o valor nulo (1,0). Isso demonstra que os dados amostrais não fornecem evidência de diferença na propensão condicional de discordância entre Piauí e Bahia sob controle das demais covariáveis, ilustrando o risco de falsos positivos em testes que desconsideram a autocorrelação geográfica.",
        indent=False
    )

    # ==========================================
    # SECTION 4: 1 column (NEW PAGE -> PAGE 4 TOP: FIGURA 1)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.NEW_PAGE, cols=1)
    if os.path.exists('figures/fig1_composition_regimes.png'):
        p_f1 = doc.add_paragraph()
        p_f1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_f1.paragraph_format.space_before = Pt(3)
        p_f1.paragraph_format.space_after = Pt(2)
        p_f1.add_run().add_picture('figures/fig1_composition_regimes.png', width=Mm(176))
        add_caption("Figura 1. Composição dos regimes temáticos e distribuição geográfica da discordância: (A) Proporção ponderada de regimes no MATOPIBA (AA: 2,43%, AN: 9,65%, NA: 4,64%, NN: 83,28%); (B) Gradiente estadual de discordância temática (BA > PI > MA > TO).")

    # ==========================================
    # SECTION 5: 2 columns (CONTINUES ON PAGE 4 BELOW FIGURA 1: DISCUSSÃO & CONCLUSÕES)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.CONTINUOUS, cols=2)

    add_h1("4. DISCUSSÃO")
    add_h2("4.1. Incerteza Estruturada e Abordagem Simétrica")
    add_p(
        "A perspectiva analítica simétrica trata as divergências entre mapeamentos não como erros unilaterais, mas como manifestações empíricas "
        "de incerteza estruturada associadas ao suporte espacial e à dinâmica temporal da paisagem:\n"
        "• Transições de Borda e Zonas de Interface: A concentração empírica acentuada de discordâncias nos primeiros 30 metros (razão de 3,87 vezes) "
        "aponta a mistura espectral de subpixel como mecanismo plausível ao longo de carreadores, faixas ripárias e bordas de talhões. No suporte de 10 m, células que "
        "interceptam interfaces entre solo exposto e savana flutuam entre classificações devido a funções de perda e regras decisórias distintas de cada produto, "
        "sem que se possa atribuir causalidade física sem controle experimental de campo;\n"
        "• Sazonalidade e Dinâmica Temporal: No regime agrícola de sequeiro do Cerrado, a alternância entre ciclos vegetativos, dessecação e pousio "
        "produz variações espectrais que constituem uma hipótese interpretativa plausível para as divergências observadas. Enquanto o Dynamic World integra estados "
        "instantâneos cena a cena, o MapBiomas apoia-se em métricas percentílicas anuais consolidadas [3, 5], gerando discordâncias associadas empiricamente aos "
        "períodos de oscilação fenológica.",
        indent=False
    )
    add_h2("4.2. Caracterização Operacional de H4")
    add_p(
        "A constatação de que apenas 4,28% ponderado das discordâncias atendem aos filtros conjuntos de H4 delimita um subconjunto "
        "restrito de divergências categóricas persistentes no interior contínuo da paisagem (d_min ≥ 30 m) que exibem menor ambiguidade probabilística anual, "
        "menor heterogeneidade temporal e maior estabilidade modal nas séries do Dynamic World. Ressalta-se que esses indicadores de consistência pertencem "
        "exclusivamente ao Dynamic World, não configurando assertividade espectral mútua de ambos os produtos. Esses casos não constituem erros comprovados, "
        "mas indicam divergências conceituais substantivas entre abordagens (como a transição entre pastagens intensivas e lavouras anuais), "
        "representando alvos prioritários para investigações de campo independentes.",
        indent=False
    )
    add_h2("4.3. Limitações do Estudo")
    add_p(
        "O trabalho apresenta limites metodológicos definidos: (1) a exigência de n_meses ≥ 8 excluiu 21,74% da área do MATOPIBA, "
        "concentrada no norte chuvoso do Maranhão; (2) a não-comutatividade temporal/espacial impõe resíduo médio de 0,004983, afetando situações de quase-empate "
        "probabilístico; (3) por se tratar de comparação observacional estritamente baseada em produtos orbitais, sem verdade de campo independente, os resultados "
        "refletem associações empíricas espaciais e temporais, vedando qualquer inferência causal definitiva sobre os fatores geradores de divergência.",
        indent=False
    )

    add_h1("5. CONCLUSÕES")
    add_p(
        "O diagnóstico espacial e probabilístico no MATOPIBA estabelece associações empíricas consistentes entre a discordância censitária de lavouras em 2025 "
        "(14,2852% por área e 14,3110% por pixels) e fatores de proximidade a bordas e instabilidade temporal do Dynamic World. Apenas 4,28% ponderado das "
        "discordâncias manifestam-se no interior contínuo sob alta estabilidade e baixa ambiguidade do DW (H4). Os mecanismos discutidos (efeito de borda, "
        "mistura de subpixel e dinâmica fenológica) constituem interpretações plausíveis para esses padrões empíricos, sem alegação de causalidade demonstrada. "
        "A aplicação de Spatial Block Bootstrap evidenciou que contrastes estaduais perdem significância estatística condicional quando a dependência espacial "
        "é incorporada. Para a comunidade GeoAI e de Sensoriamento Remoto, esses achados indicam que discrepâncias entre produtos decamétricos devem ser "
        "tratadas como indicadores objetivos de incerteza operacional, orientando estratégias robustas de integração territorial.",
        indent=False
    )

    # ==========================================
    # SECTION 6: 1 column (NEW PAGE -> PAGE 5 TOP: TABELA 2)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.NEW_PAGE, cols=1)
    add_caption("Tabela 2. Contrastes das hipóteses H1–H3 e modelo logístico multivariado sob Spatial Block Bootstrap (30 km, 1.999 réplicas). Fontes: tables/hypothesis_h1_results.csv, tables/hypothesis_h2_results.csv, tables/hypothesis_h3_distance_bins.csv, tables/regression_logistic_rescaled_odds_ratios.csv.")

    t2_data = [
        ["Indicador / Termo Preditivo", "Escala", "Estimativa / Nível", "Contraste (Δ) / OR", "IC 95% Espacial (30 km)", "Interpretação Condicional Ajustada"],
        ["H1: Entropia Anual (H)", "Média", "D=0: 0,8357 / D=1: 0,8519", "Δ = +0,0162", "[+0,0103; +0,0221]", "Associação positiva com incerteza"],
        ["H2a: Divergência Temp. (JSD)", "Média", "D=0: 0,0327 / D=1: 0,0402", "Δ = +0,0075", "[+0,0047; +0,0102]", "Maior volatilidade temporal marginal"],
        ["H2b: Estabilidade Modal (S)", "Média", "D=0: 0,6366 / D=1: 0,5576", "Δ = -0,0790", "[-0,0974; -0,0599]", "Menor persistência categórica"],
        ["H3: Borda (<30m) vs Interior", "Razão", "Borda: 45,91% / Int.: 11,87%", "Razão: 3,87×", "[3,25×; 4,61×]", "Gradiente inverso sem monotonicidade"],
        ["Regressão: Distância à Borda", "+100 m", "Gradiente contínuo", "OR = 0,360", "[0,319; 0,404]", "Forte associação inversa condicional"],
        ["Regressão: Entropia Anual", "+0,10", "Incerteza anual", "OR = 1,421", "[1,036; 1,988]", "Associação positiva condicional"],
        ["Regressão: Estabilidade Modal", "+0,10", "Consistência temporal", "OR = 0,925", "[0,861; 0,992]", "Associação inversa condicional"],
        ["Regressão: JSD Temporal", "+0,01", "Dinâmica temporal", "OR = 0,987", "[0,914; 1,059]", "Sem evidência condicional (1 ∈ IC)"],
        ["Regressão: Piauí vs Bahia (ref.)", "UF", "Referência: BA", "OR = 0,798", "[0,507; 1,212]", "Sem evidência condicional (1 ∈ IC)"],
        ["Regressão: Maranhão vs Bahia", "UF", "Referência: BA", "OR = 0,378", "[0,242; 0,575]", "Menor propensão condicional que BA"],
        ["Regressão: Tocantins vs Bahia", "UF", "Referência: BA", "OR = 0,160", "[0,114; 0,225]", "Menor propensão condicional que BA"],
    ]
    col_widths_t2 = [42, 15, 35, 24, 27, 35] # sum = 178 mm
    t2 = doc.add_table(rows=len(t2_data), cols=6)
    t2.alignment = WD_TABLE_ALIGNMENT.CENTER
    tblPr2 = t2._tbl.tblPr
    tblW2 = parse_xml(r'<w:tblW xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" w:w="10091" w:type="dxa"/>')
    tblPr2.append(tblW2)

    for r_idx, row in enumerate(t2_data):
        trPr2 = t2.rows[r_idx]._tr.get_or_add_trPr()
        trPr2.append(parse_xml(r'<w:cantSplit xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))
        if r_idx == 0:
            trPr2.append(parse_xml(r'<w:tblHeader xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))

        for c_idx, val in enumerate(row):
            cell = t2.cell(r_idx, c_idx)
            cell.width = Mm(col_widths_t2[c_idx])
            cell.text = val
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if c_idx in (0, 5) else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            p.paragraph_format.line_spacing = Pt(9)
            set_cell_margins(cell, top=45, bottom=45, left=65, right=65)
            for r in p.runs:
                r.font.name = 'Times New Roman'
                r.font.size = Pt(7.5)
                if r_idx == 0 or c_idx == 3:
                    r.font.bold = True
            if r_idx == 0:
                set_cell_border(cell, top=dict(sz=8, val='single', color='000000'), bottom=dict(sz=8, val='single', color='000000'))
            elif r_idx == len(t2_data) - 1:
                set_cell_border(cell, bottom=dict(sz=8, val='single', color='000000'))

    # ==========================================
    # SECTION 7: 2 columns (CONTINUES ON PAGE 5 BELOW TABELA 2: 6. REFERÊNCIAS)
    # ==========================================
    add_sec(start_type=WD_SECTION_START.CONTINUOUS, cols=2)
    add_h1("6. REFERÊNCIAS")
    refs = [
        "[1] S. A. Spera, G. L. Galford, M. T. Coe, M. N. Macedo, and J. F. Mustard. Land-use change affects water recycling in Brazil’s last agricultural frontier, Global Change Biology, v. 22(10):pp. 3405–3413, 2016.",
        "[2] R. F. B. da Silva, M. Batistella, E. F. Moran, and L. A. Martinelli. Soy expansion and socioeconomic development in municipalities of Brazil, Land, v. 6(3):art. 62, 2017.",
        "[3] C. M. Souza et al. Reconstructing Three Decades of Land Use and Land Cover Changes in Brazilian Biomes with Landsat Archive and Earth Engine, Remote Sensing, v. 12(17):art. 2735, 2020.",
        "[4] MapBiomas. Coleção 4 da Cobertura e Uso da Terra a 10 metros (2017–2025), Rede MapBiomas, São Paulo, 2025. URL: brasil.mapbiomas.org",
        "[5] C. F. Brown et al. Dynamic World, Near real-time global 10 m land use land cover mapping, Scientific Data, v. 9(1):art. 251, 2022.",
        "[6] S. Fritz et al. Highlighting continued uncertainty in global land cover maps for the user community, Environmental Research Letters, v. 6(4):art. 044005, 2011.",
        "[7] R. G. Pontius and M. Millones. Death to Kappa: birth of quantity disagreement and allocation disagreement for accuracy assessment, International Journal of Remote Sensing, v. 32(15):pp. 4407–4429, 2011.",
        "[8] G. M. Foody. Status of land cover classification accuracy assessment, Remote Sensing of Environment, v. 80(1):pp. 185–201, 2002.",
        "[9] P. Olofsson et al. Good practices for estimating area and assessing accuracy of land change, Remote Sensing of Environment, v. 148:pp. 42–57, 2014.",
        "[10] P. Legendre. Spatial autocorrelation: trouble or new paradigm?, Ecology, v. 74(6):pp. 1659–1673, 1993.",
        "[11] G. Carl and I. Kühn. Analyzing spatial autocorrelation in species distributions using Gaussian and alternative methods, Ecological Modelling, v. 207(2–4):pp. 159–170, 2007.",
        "[12] H. R. Künsch. The jackknife and the bootstrap for general stationary observations, The Annals of Statistics, v. 17(3):pp. 1217–1241, 1989.",
        "[13] D. R. Roberts et al. Cross-validation strategies for data with temporal, spatial, or phylogenetic structure, Ecography, v. 40(8):pp. 913–929, 2017.",
        "[14] C. E. Shannon. A mathematical theory of communication, The Bell System Technical Journal, v. 27(3):pp. 379–423, 1948.",
        "[15] J. Lin. Divergence measures based on the Shannon entropy, IEEE Transactions on Information Theory, v. 37(1):pp. 145–151, 1991."
    ]
    for r in refs:
        p_ref = doc.add_paragraph()
        p_ref.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p_ref.paragraph_format.space_before = Pt(0)
        p_ref.paragraph_format.space_after = Pt(2)
        p_ref.paragraph_format.line_spacing = Pt(9.5)
        p_ref.paragraph_format.left_indent = Mm(3.5)
        p_ref.paragraph_format.first_line_indent = Mm(-3.5)
        run_ref = p_ref.add_run(r)
        run_ref.font.name = 'Times New Roman'
        run_ref.font.size = Pt(7.5)

    doc.save(output_path)
    print(f"Generated test DOCX: {output_path}")

if __name__ == '__main__':
    out_docx = 'scratch/test_v3_1.docx'
    build_v3_1_docx(out_docx)
