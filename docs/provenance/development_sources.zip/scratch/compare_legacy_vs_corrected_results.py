import pandas as pd
import numpy as np

def compare_results():
    print("="*80)
    print("COMPARAÇÃO DETALHADA: RESULTADOS LEGADOS (RAW) VS RESULTADOS CORRIGIDOS (BIL)")
    print("="*80)

    # 1. H1 Results
    print("\n1. HIPÓTESE H1 (ENTROPIA ANUAL H):")
    h1_old = pd.read_csv('tables_legacy_raw/hypothesis_h1_results.csv')
    h1_new = pd.read_csv('tables/hypothesis_h1_results.csv')
    print("  OLD:")
    print(h1_old.to_string(index=False))
    print("  NEW:")
    print(h1_new.to_string(index=False))

    # 2. H2 Results
    print("\n2. HIPÓTESE H2 (H2a: JSD TEMPORAL | H2b: ESTABILIDADE S):")
    h2_old = pd.read_csv('tables_legacy_raw/hypothesis_h2_results.csv')
    h2_new = pd.read_csv('tables/hypothesis_h2_results.csv')
    print("  OLD:")
    print(h2_old.to_string(index=False))
    print("  NEW:")
    print(h2_new.to_string(index=False))

    # 3. H3 Results
    print("\n3. HIPÓTESE H3 (EFEITO DE BORDA):")
    h3_old = pd.read_csv('tables_legacy_raw/hypothesis_h3_distance_bins.csv')
    h3_new = pd.read_csv('tables/hypothesis_h3_distance_bins.csv')
    print("  Diferença máxima de área ou taxa de discordância em H3:", np.max(np.abs(h3_old['disagreement_pct'].values - h3_new['disagreement_pct'].values)))

    # 4. H4 Results
    print("\n4. HIPÓTESE H4 (DISCORDÂNCIAS ROBUSTAS INTERNAMENTE):")
    h4_old = pd.read_csv('tables_legacy_raw/hypothesis_h4_robust_disagreement.csv')
    h4_new = pd.read_csv('tables/hypothesis_h4_robust_disagreement.csv')
    print("  OLD:")
    print(h4_old.to_string(index=False))
    print("  NEW:")
    print(h4_new.to_string(index=False))

    # 5. Continuous Indicators
    print("\n5. INDICADORES CONTÍNUOS (MÉDIAS E QUARTIS PONDERADOS):")
    ind_old = pd.read_csv('tables_legacy_raw/descriptive_continuous_indicators.csv').set_index(['variable', 'subset'])
    ind_new = pd.read_csv('tables/descriptive_continuous_indicators.csv').set_index(['variable', 'subset'])
    for ind in ['stability', 'jsd_temporal', 'entropy_annual']:
        print(f"\n  Indicador: {ind} (População Total):")
        sub_o = ind_old.loc[(ind, 'População Geral')] if (ind, 'População Geral') in ind_old.index else ind_old.iloc[0]
        sub_n = ind_new.loc[(ind, 'População Geral')] if (ind, 'População Geral') in ind_new.index else ind_new.iloc[0]
        print(f"    Média:       OLD = {sub_o['mean']:.4f}  -->  NEW = {sub_n['mean']:.4f}")
        print(f"    Mediana:     OLD = {sub_o['median']:.4f}  -->  NEW = {sub_n['median']:.4f}")
        print(f"    Q1 (P25):    OLD = {sub_o['q1']:.4f}  -->  NEW = {sub_n['q1']:.4f}")
        print(f"    Q3 (P75):    OLD = {sub_o['q3']:.4f}  -->  NEW = {sub_n['q3']:.4f}")

    # 6. Regressão Logística
    print("\n6. MODELO DE REGRESSÃO LOGÍSTICA MULTIVARIADA (OR RESCALONADOS):")
    reg_old = pd.read_csv('tables_legacy_raw/regression_logistic_rescaled_odds_ratios.csv')
    reg_new = pd.read_csv('tables/regression_logistic_rescaled_odds_ratios.csv')
    print("  OLD:")
    print(reg_old.to_string(index=False))
    print("  NEW:")
    print(reg_new.to_string(index=False))

    # 7. Spatial Bootstrap Contrasts
    print("\n7. CONTRASTES COM INTERVALOS DE CONFIANÇA DO SPATIAL BLOCK BOOTSTRAP:")
    sp_old = pd.read_csv('tables_legacy_raw/spatial_bootstrap_contrasts.csv')
    sp_new = pd.read_csv('tables/spatial_bootstrap_contrasts.csv')
    print("  OLD:")
    print(sp_old.to_string(index=False))
    print("  NEW:")
    print(sp_new.to_string(index=False))

    # 8. Robustness Summary
    print("\n8. RESUMO COMPREENSIVO DE ROBUSTEZ:")
    rob_old = pd.read_csv('tables_legacy_raw/robustness_comprehensive_summary.csv')
    rob_new = pd.read_csv('tables/robustness_comprehensive_summary.csv')
    print("  OLD:")
    print(rob_old.to_string(index=False))
    print("  NEW:")
    print(rob_new.to_string(index=False))

if __name__ == '__main__':
    compare_results()
