import pandas as pd
import numpy as np
from pyproj import Transformer

df = pd.read_parquet('data/processed/samples_annual.parquet')
main = df[df['main_sample'] == 1].copy()
main['D'] = main['regime'].isin(['AN', 'NA']).astype(int)
main['w'] = main['design_weight_main'].astype(float)

transformer = Transformer.from_crs("EPSG:4326", "EPSG:5880", always_xy=True)
x, y = transformer.transform(main["lon"].values, main["lat"].values)
main['x'] = x
main['y'] = y

block_size_m = 30000.0
bx = np.floor(main["x"].values / block_size_m).astype(int)
by = np.floor(main["y"].values / block_size_m).astype(int)
main['block_id'] = [f"{xi}_{yi}" for xi, yi in zip(bx, by)]

unique_blocks = main['block_id'].unique()
n_blocks = len(unique_blocks)
print(f'Total de blocos de 30 km: {n_blocks}')

# Block size distribution
pts_per_block = main['block_id'].value_counts()
print(f'Pontos por bloco: min={pts_per_block.min()}, median={pts_per_block.median()}, mean={pts_per_block.mean():.2f}, max={pts_per_block.max()}')

# Do blocks cross states?
states_per_block = main.groupby('block_id')['state'].nunique()
multi_state_blocks = (states_per_block > 1).sum()
print(f'Blocos que cruzam fronteiras estaduais: {multi_state_blocks} de {n_blocks} ({multi_state_blocks/n_blocks*100:.2f}%)')

# Do blocks contain both D=0 and D=1?
regimes_per_block = main.groupby('block_id')['D'].nunique()
pure_blocks = (regimes_per_block == 1).sum()
print(f'Blocos puros (apenas D=0 ou apenas D=1): {pure_blocks} de {n_blocks} ({pure_blocks/n_blocks*100:.2f}%)')

# Check what happens during bootstrap resampling:
rng = np.random.default_rng(25)
block_list = [main[main['block_id'] == b].index.values for b in unique_blocks]

# Run a test of 500 resamples checking stratum composition
strata = main['stratum_id'].unique()
prop_records = []
for r in range(500):
    samp_b = rng.choice(n_blocks, n_blocks, replace=True)
    idx_boot = np.concatenate([block_list[b] for b in samp_b])
    sub_boot = main.loc[idx_boot]
    w_tot = sub_boot['w'].sum()
    props = {st: (sub_boot[sub_boot['stratum_id'] == st]['w'].sum() / w_tot) * 100 for st in strata}
    prop_records.append(props)

df_props_boot = pd.DataFrame(prop_records)
print('\nVariabilidade da proporção dos estratos científicos no bootstrap NÃO-estratificado:')
for st in sorted(strata):
    true_prop = (main[main['stratum_id'] == st]['w'].sum() / main['w'].sum()) * 100
    b_mean = df_props_boot[st].mean()
    b_p025 = df_props_boot[st].quantile(0.025)
    b_p975 = df_props_boot[st].quantile(0.975)
    print(f'Estrato {st:8s}: Fixo={true_prop:6.3f}%, Boot Mean={b_mean:6.3f}%, 95% CI=[{b_p025:6.3f}%, {b_p975:6.3f}%]')
