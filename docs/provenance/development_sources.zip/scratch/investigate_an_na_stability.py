import pandas as pd
import numpy as np

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

valid_mon = df_mon[df_mon['month_valid'] == 1].copy()
mon_mean = valid_mon.groupby('sample_id')[DW_CLASSES].mean().reset_index()

main = df_ann[df_ann['main_sample'] == 1].copy()
merged = pd.merge(main, mon_mean, on='sample_id', suffixes=('_ann', '_mon'))

merged['auth_class'] = merged['annual_class']
merged['mon_mean_class'] = [DW_CLASSES[i] for i in np.argmax(merged[[c for c in DW_CLASSES]].values, axis=1)]
merged['class_matches'] = (merged['auth_class'] == merged['mon_mean_class'])

print("=== DISTRIBUIÇÃO DE MATCH ENTRE AUTH ANNUAL CLASS E MON MEAN CLASS ===")
print(pd.crosstab(merged['regime'], merged['class_matches'], margins=True, normalize='index') * 100)

print("\n=== MATRIZ DE CONFUSÃO: AUTH ANNUAL CLASS VS MON MEAN CLASS EM AN ===")
an_df = merged[merged['regime'] == 'AN']
print(pd.crosstab(an_df['auth_class'], an_df['mon_mean_class']))

print("\n=== MATRIZ DE CONFUSÃO: AUTH ANNUAL CLASS VS MON MEAN CLASS EM NA ===")
na_df = merged[merged['regime'] == 'NA']
print(pd.crosstab(na_df['auth_class'], na_df['mon_mean_class']))

print("\n=== MATRIZ DE CONFUSÃO: AUTH ANNUAL CLASS VS MON MEAN CLASS EM AA ===")
aa_df = merged[merged['regime'] == 'AA']
print(pd.crosstab(aa_df['auth_class'], aa_df['mon_mean_class']))

print("\n=== MATRIZ DE CONFUSÃO: AUTH ANNUAL CLASS VS MON MEAN CLASS EM NN ===")
nn_df = merged[merged['regime'] == 'NN']
print(pd.crosstab(nn_df['auth_class'], nn_df['mon_mean_class']))
