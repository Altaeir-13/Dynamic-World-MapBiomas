import pandas as pd
import numpy as np

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

# Compute reconstructed monthly vector
valid_mon = df_mon[df_mon['month_valid'] == 1].copy()
mon_agg = valid_mon.groupby('sample_id')[DW_CLASSES].mean().reset_index()
prob_sum_rec = mon_agg[DW_CLASSES].sum(axis=1)
for c in DW_CLASSES:
    mon_agg[c + '_rec'] = mon_agg[c] / prob_sum_rec

merged = pd.merge(df_ann, mon_agg, on='sample_id')
auth_vec = merged[['p_' + c for c in DW_CLASSES]].values
rec_vec = merged[[c + '_rec' for c in DW_CLASSES]].values
merged['max_prob_diff'] = np.max(np.abs(auth_vec - rec_vec), axis=1)
merged['argmax_div'] = (merged['annual_class_index'] != np.argmax(rec_vec, axis=1)).astype(int)

pilot_ids = ['PT_010352']

# For each of the 4 states, pick representative points across the 4 regimes
for state in ['MA', 'TO', 'PI', 'BA']:
    for regime in ['AA', 'AN', 'NA', 'NN']:
        sub = merged[(merged['state'] == state) & (merged['regime'] == regime)]
        # Pick one edge point if available
        edge = sub[sub['distance_edge_min_m'] < 30]
        if len(edge) > 0:
            p = edge.sort_values('max_prob_diff', ascending=False).iloc[0]['sample_id']
            if p not in pilot_ids:
                pilot_ids.append(p)
        # Pick one interior point if available
        interior = sub[sub['distance_edge_min_m'] >= 250]
        if len(interior) > 0:
            p = interior.sort_values('max_prob_diff', ascending=True).iloc[0]['sample_id']
            if p not in pilot_ids:
                pilot_ids.append(p)

pilot_df = merged[merged['sample_id'].isin(pilot_ids)].copy()
print(f"Total pontos selecionados no piloto: {len(pilot_df)}")
print(pilot_df.groupby(['state', 'regime']).size())

pilot_df.to_csv('scratch/pilot_sample_points.csv', index=False)
