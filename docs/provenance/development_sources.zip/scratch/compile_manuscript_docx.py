import docx
from docx.shared import Mm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls
import os

def set_cell_border(cell, **kwargs):
    """
    Set cell borders
    kwargs: top, bottom, left, right
    values: dict(sz=12, val='single', color='000000')
    """
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key, val in edge_data.items():
                element.set(qn('w:{}'.format(key)), str(val))

def create_docx(output_path):
    doc = docx.Document()
    
    # Page setup for Section 1 (Title + Authors)
    sec1 = doc.sections[0]
    sec1.page_width = Mm(210)
    sec1.page_height = Mm(297)
    sec1.top_margin = Mm(25)
    sec1.bottom_margin = Mm(43)
    sec1.left_margin = Mm(19)
    sec1.right_margin = Mm(13)
    
    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(10)
    p_title.paragraph_format.space_after = Pt(8)
    p_title.paragraph_format.line_spacing = Pt(16)
    r_title = p_title.add_run("ONDE DYNAMIC WORLD E MAPBIOMAS DISCORDAM SOBRE LAVOURAS? DIAGNÓSTICO ESPACIAL E PROBABILÍSTICO NO MATOPIBA")
    r_title.font.name = 'Times New Roman'
    r_title.font.size = Pt(13)
    r_title.font.bold = True
    
    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_before = Pt(0)
    p_auth.paragraph_format.space_after = Pt(2)
    r_auth = p_auth.add_run("Equipe GeoAI MATOPIBA")
    r_auth.font.name = 'Times New Roman'
    r_auth.font.size = Pt(10)
    r_auth.font.bold = True
    
    # Affiliation
    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff.paragraph_format.space_before = Pt(0)
    p_aff.paragraph_format.space_after = Pt(10)
    r_aff = p_aff.add_run("Laboratório de Sensoriamento Remoto e Inteligência Artificial Territorial\nContato: spaceweeknordeste@gmail.com")
    r_aff.font.name = 'Times New Roman'
    r_aff.font.size = Pt(9)
    
    # Continuous Section Break for 2 Columns
    sec2 = doc.add_section(docx.enum.section.WD_SECTION.CONTINUOUS)
    sec2.page_width = Mm(210)
    sec2.page_height = Mm(297)
    sec2.top_margin = Mm(25)
    sec2.bottom_margin = Mm(43)
    sec2.left_margin = Mm(19)
    sec2.right_margin = Mm(13)
    
    # Set 2 columns
    sectPr = sec2._sectPr
    cols = sectPr.xpath('./w:cols')
    if cols:
        cols[0].set(qn('w:num'), '2')
        cols[0].set(qn('w:space'), '340')  # ~6 mm
        cols[0].set(qn('w:equalWidth'), '1')
    else:
        cols_elem = OxmlElement('w:cols')
        cols_elem.set(qn('w:num'), '2')
        cols_elem.set(qn('w:space'), '340')
        cols_elem.set(qn('w:equalWidth'), '1')
        sectPr.append(cols_elem)
        
    def add_h1(text):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(8)
        p.paragraph_format.space_after = Pt(4)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(10)
        r.font.bold = True
        return p

    def add_h2(text):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(9.5)
        r.font.bold = True
        return p

    def add_body(text, indent=False, italic=False):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.line_spacing = Pt(11.5)
        if indent:
            p.paragraph_format.first_line_indent = Mm(6.3)
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(9.5)
        if italic:
            r.font.italic = True
        return p

    def add_caption(text):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.keep_with_next = True
        r = p.add_run(text)
        r.font.name = 'Times New Roman'
        r.font.size = Pt(8.5)
        r.font.bold = True
        return p

    # RESUMO
    add_h1("RESUMO")
    add_body(
        "Mapeamentos de uso e cobertura da terra em escala decamétrica (10 m) são vitais para o monitoramento territorial. "
        "Em fronteiras agrícolas com acentuada sazonalidade como o MATOPIBA, divergências entre produtos de GeoAI permanecem pouco elucidadas. "
        "Este estudo apresenta um diagnóstico simétrico da discordância de lavouras entre Dynamic World e MapBiomas (Coleção 4, 10 m) em 2025. "
        "Com amostragem probabilística estratificada de 20.000 pontos em 52,34 milhões de hectares elegíveis, avaliou-se a associação da "
        "discordância com incerteza probabilística anual, dinâmica temporal e proximidade a bordas temáticas. A discordância censitária "
        "atinge 14,2852% por área e 14,3110% por pixels. Sob Spatial Block Bootstrap (blocos de 30 km, 1.999 réplicas), a discordância "
        "associa-se a maior entropia anual (ΔH = +0,0162), maior divergência Jensen-Shannon temporal (ΔJSD = +0,0075) e menor "
        "estabilidade modal (ΔS = -0,0790). Em bordas (<30 m), a discordância é 3,87 vezes superior à do interior (≥250 m). "
        "Na regressão logística, distância à borda (OR = 0,360) e estabilidade temporal (OR = 0,925) associam-se inversamente à discordância. "
        "Apenas 4,28% ponderado das discordâncias atendem a critérios operacionais de baixa ambiguidade, alta estabilidade e afastamento de bordas, "
        "indicando que divergências concentram-se em transições de borda e instabilidade temporal.",
        indent=False
    )
    p_kw = doc.add_paragraph()
    p_kw.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p_kw.paragraph_format.space_before = Pt(2)
    p_kw.paragraph_format.space_after = Pt(4)
    r_kw = p_kw.add_run("Palavras-chave – Dynamic World, MapBiomas, MATOPIBA, Discordância Espacial, Incerteza Temporal.")
    r_kw.font.name = 'Times New Roman'
    r_kw.font.size = Pt(9.5)
    r_kw.font.italic = True

    # ABSTRACT
    add_h1("ABSTRACT")
    add_body(
        "High-resolution (10 m) land use and land cover maps are vital for territorial monitoring. In highly seasonal agricultural "
        "frontiers such as MATOPIBA, discrepancies between Earth Observation and GeoAI products remain poorly understood. This study provides "
        "a symmetric analytical diagnosis of cropland disagreement between Dynamic World and MapBiomas (Collection 4, 10 m) for 2025. "
        "Using a design-based stratified random sample of 20,000 points across 52.34 million eligible hectares, we evaluate associations with "
        "annual probabilistic uncertainty, intra-annual dynamics, and thematic edge proximity. Census cropland disagreement reaches 14.2852% by "
        "area and 14.3110% by pixels. Using Spatial Block Bootstrap inference (30 km blocks, 1,999 replicates), disagreement is significantly "
        "associated with higher annual entropy (ΔH = +0.0162), higher temporal Jensen-Shannon divergence (ΔJSD = +0.0075), and lower "
        "modal stability (ΔS = -0.0790). At thematic edges (<30 m), disagreement is 3.87 times higher than in core areas (≥250 m). "
        "In logistic regression, edge distance (OR = 0.360) and temporal stability (OR = 0.925) show inverse associations with disagreement. "
        "Only 4.28% of weighted disagreements meet operational criteria of low ambiguity, high stability, and edge avoidance, showing that "
        "discrepancies concentrate along boundary transitions and temporal volatility.",
        indent=False, italic=True
    )
    p_akw = doc.add_paragraph()
    p_akw.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p_akw.paragraph_format.space_before = Pt(2)
    p_akw.paragraph_format.space_after = Pt(6)
    r_akw = p_akw.add_run("Key words – Dynamic World, MapBiomas, MATOPIBA, Spatial Disagreement, Temporal Uncertainty.")
    r_akw.font.name = 'Times New Roman'
    r_akw.font.size = Pt(9.5)
    r_akw.font.italic = True

    # 1. INTRODUÇÃO
    add_h1("1. INTRODUÇÃO")
    add_body(
        "A expansão agropecuária no MATOPIBA (confluência de Maranhão, Tocantins, Piauí e Bahia) consolidou o Cerrado como polo agrícola "
        "estratégico [1, 2]. Essa dinâmica demanda monitoramento sistemático apoiado em produtos de uso e cobertura da terra (LULC) de "
        "alta resolução (10 m), como o MapBiomas (Coleção 4, 10 m) [3, 4] e o Dynamic World (DW) [5]. O MapBiomas estrutura classificações "
        "anuais integrando séries temporais e filtros espaciais [3], enquanto o Dynamic World estima vetores contínuos de probabilidades para "
        "nove classes a cada cena Sentinel-2 [5].",
        indent=False
    )
    add_body(
        "Em ecótonos e fronteiras agrícolas tropicais, discrepâncias entre mapeamentos independentes são frequentes, variando entre 10% e 25% [6, 7]. "
        "Na ausência de extensos dados de referência de campo (ground truth), a validação pontual convencional enfrenta limitações de escala e "
        "custo [8, 9]. Este estudo propõe um diagnóstico analítico simétrico: investigar onde e sob quais condições os produtos divergem, tratando a "
        "discordância como objeto de análise associado a sinais intrínsecos de incerteza da Inteligência Artificial Geoespacial (GeoAI).",
        indent=True
    )
    add_body(
        "Formulam-se quatro hipóteses operacionais para o ano de 2025:\n"
        "• H1 (Ambiguidade Anual): pixels discordantes (D = 1) apresentam maior entropia informacional média na distribuição probabilística anual do que concordantes (D = 0);\n"
        "• H2 (Instabilidade Temporal): a discordância associa-se a maior heterogeneidade intra-anual de probabilidades (H2a, JSD) e menor persistência categórica modal (H2b, estabilidade S);\n"
        "• H3 (Efeito de Borda Temática): a taxa de discordância é maior nas vizinhanças imediatas de bordas temáticas do que no interior de manchas contínuas;\n"
        "• H4 (Discordâncias sob Restrição Conjunta): ao isolar pixels com baixa ambiguidade, baixa variabilidade temporal, alta estabilidade e afastados de bordas, a discordância restringe-se a fração reduzida.",
        indent=True
    )

    # 2. MATERIAL E MÉTODOS
    add_h1("2. MATERIAL E MÉTODOS")
    add_h2("2.1. Domínio Geográfico e Critério de Elegibilidade")
    add_body(
        "O MATOPIBA abrange 337 municípios e cerca de 73 milhões de hectares. Para mitigar o impacto de cobertura persistente de nuvens, o "
        "domínio censitário elegível foi delimitado por células de 10 m que apresentaram no mínimo 8 meses válidos no Dynamic World em 2025 "
        "(n_meses ≥ 8) e classes válidas no MapBiomas (excluindo corpos d'água permanentes e áreas não-vegetadas). A população censitária "
        "elegível resultante totaliza 52.342.114,75 ha (5.354.669.418 pixels de 10 m).",
        indent=False
    )
    add_h2("2.2. Produtos Cartográficos e Harmonização de Suporte")
    add_body(
        "Utilizou-se o MapBiomas Cobertura 10 m — Coleção 4 — 2025 [4], baseado em mosaicos Sentinel-2. A classe de lavoura foi definida "
        "pelo crosswalk principal composto pelas classes 19 (Lavoura Temporária) e 36 (Lavoura Perene), distinguindo-se das classes 21 "
        "(Mosaico de Usos) e 18 (Agricultura, nível superior). O produto nativo foi projetado na grade analítica de 10 m em SIRGAS 2000 / "
        "Policonica do Brasil (EPSG:5880).",
        indent=False
    )
    add_body(
        "Para o Dynamic World (v1) [5], o pipeline composicional gerou o raster anual mediante média temporal das observações do mesmo "
        "dia, média diária para mensal e agregação anual pela média dos vetores de 9 probabilidades, extraindo-se a classe pelo argmax do "
        "vetor anual (e não por votação modal). A classe 4 (crops) definiu lavoura no DW. As séries mensais foram harmonizadas espacialmente "
        "para EPSG:5880 via reamostragem bilinear. Devido à não-comutatividade matemática entre a interpolação espacial e a máscara temporal de "
        "nuvens, persiste uma diferença probabilística média residual de 0,004983, implicando alternância de argmax em 8,24% e inversão de "
        "lavoura em 2,59% dos pontos amostrados, concentrada em margens probabilísticas inferiores a 0,05.",
        indent=True
    )
    add_h2("2.3. Indicadores de Incerteza e Estabilidade")
    add_body(
        "Para cada ponto, extraíram-se quatro indicadores contínuos:\n"
        "1. Entropia de Shannon Anual (H): normalizada por ln(9) [14]: H = - [1 / ln(9)] ∑ pk ln(pk + ε);\n"
        "2. Divergência Jensen-Shannon Temporal (JSD): contraste normalizado por ln(9) entre a entropia da média mensal e a média das entropias dos M meses válidos [15]: JSD = [1 / ln(9)] [ H(p̄) - (1/M) ∑ H(p(m)) ];\n"
        "3. Estabilidade Categórica Modal (S): proporção dos meses válidos em que a classe dominante (argmax) coincidiu com a classe anual: S = (1/M) ∑ I(c(m) = c_anual);\n"
        "4. Distância Mínima à Borda Temática (d_min): distância euclidiana métrica calculada em raster até a borda temática mais próxima de Dynamic World ou MapBiomas (min(d_dw, d_mb)), truncada em 250 m. O suporte analítico refere-se a pixels de 10 m e manchas temáticas, sem pressupor delimitação cadastral de parcelas ou talhões agrícolas.",
        indent=False
    )
    add_h2("2.4. Desenho Amostral e Inferência Espacial")
    add_body(
        "Adotou-se amostragem probabilística estratificada em 16 estratos científicos (4 estados × 4 regimes temáticos: AA, AN, NA, NN) e 410 subestratos operacionais. "
        "A amostra principal contemplou n = 20.000 pontos, expandida para 40.000 em robustez. As estimativas incorporam pesos de Horvitz-Thompson (wi = Nh / nh) [9]. "
        "Para controlar a autocorrelação espacial [10, 11], ajustou-se semivariograma empírico exponencial sobre o resíduo da discordância, identificando alcance prático de 25,62 km. "
        "Conforme protocolo e diretrizes de particionamento [12, 13], implementou-se Spatial Block Bootstrap com blocos primários regulares de 30 km e 1.999 réplicas com reposição. "
        "Ajustou-se modelo logístico multivariado ponderado com odds ratios (OR) escalonados e intervalos empíricos a 95%.",
        indent=False
    )

    # 3. RESULTADOS
    add_h1("3. RESULTADOS")
    add_h2("3.1. Discordância Censitária e Distribuição Geográfica")
    add_body(
        "No censo wall-to-wall dos 52,34 Mha elegíveis, a discordância temática entre os produtos atinge 14,2852% por área (7.477.177,23 ha) e 14,3110% por pixels (766.304.630 pixels). "
        "A estimativa ponderada na amostra de 20.000 pontos reproduz com alta precisão o censo: 14,2897% por área (7.479.568,87 ha) e 14,3148% por pixels (766.512.449 pixels). "
        "A discordância decorre majoritariamente de alocação espacial (9,30 pp) frente à divergência de quantidade (4,99 pp) [7]. "
        "A Tabela 1 detalha os regimes censitários e por estado: Bahia (27,95%) e Piauí (21,80%) apresentam as maiores taxas, contrastando com Maranhão (10,98%) e Tocantins (5,90%).",
        indent=False
    )

    # Table 1
    add_caption("Tabela 1. Parâmetros censitários e amostrais de discordância no MATOPIBA.")
    t1_rows = [
        ["Regime / UF", "Censo (ha)", "Censo (%)", "Amostra (%)", "IC 95% Espacial"],
        ["AA (Acordo Lav.)", "1.274.056", "2,43%", "2,43%", "[2,01%; 2,98%]"],
        ["AN (MB Sim, DW Não)", "5.044.314", "9,64%", "9,65%", "[8,95%; 10,48%]"],
        ["NA (DW Sim, MB Não)", "2.432.863", "4,65%", "4,64%", "[4,12%; 5,26%]"],
        ["NN (Acordo Não-Lav.)", "43.590.881", "83,28%", "83,28%", "[82,05%; 84,38%]"],
        ["Total Disc. (AN+NA)", "7.477.177", "14,29%", "14,29%", "[13,42%; 15,28%]"],
        ["Maranhão (MA)", "1.093.013", "10,98%", "10,96%", "[9,25%; 13,01%]"],
        ["Tocantins (TO)", "1.338.415", "5,90%", "5,90%", "[4,88%; 7,12%]"],
        ["Piauí (PI)", "1.639.895", "21,80%", "21,82%", "[18,44%; 25,62%]"],
        ["Bahia (BA)", "3.405.855", "27,95%", "27,98%", "[24,80%; 31,45%]"],
    ]
    t1 = doc.add_table(rows=len(t1_rows), cols=5)
    t1.alignment = WD_TABLE_ALIGNMENT.CENTER
    for r_idx, row in enumerate(t1_rows):
        for c_idx, val in enumerate(row):
            cell = t1.cell(r_idx, c_idx)
            cell.text = val
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            for r in p.runs:
                r.font.name = 'Times New Roman'
                r.font.size = Pt(7.5)
                if r_idx == 0 or r_idx == 5:
                    r.font.bold = True
            if r_idx == 0:
                set_cell_border(cell, top=dict(sz=6, val='single', color='000000'),
                                bottom=dict(sz=6, val='single', color='000000'))
            elif r_idx == len(t1_rows) - 1:
                set_cell_border(cell, bottom=dict(sz=6, val='single', color='000000'))

    # Figure 1
    if os.path.exists('figures/fig1_composition_regimes.png'):
        p_f1 = doc.add_paragraph()
        p_f1.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_f1.paragraph_format.space_before = Pt(4)
        p_f1.paragraph_format.space_after = Pt(2)
        p_f1.add_run().add_picture('figures/fig1_composition_regimes.png', width=Mm(84))
        add_caption("Figura 1. Composição dos regimes e gradiente de discordância por estado.")

    add_h2("3.2. Testes de Hipótese H1 a H4")
    add_body(
        "A Tabela 2 sintetiza os contrastes das hipóteses e a regressão logística multivariada sob inferência de 30 km:\n"
        "• H1 (Ambiguidade Anual): A entropia anual é maior nos discordantes (ΔH = +0,0162, IC 95%: [+0,0103; +0,0221], Cohen's d = +0,318);\n"
        "• H2a e H2b (Dinâmica Temporal): A discordância associa-se a maior divergência temporal (ΔJSD = +0,007492, IC: [+0,0047; +0,0102]) e menor estabilidade (ΔS = -0,078959, IC: [-0,0974; -0,0599]);\n"
        "• H3 (Efeito de Borda): A discordância atinge 45,91% na borda (<30 m) e cai para 11,87% no interior (≥250 m), razão de 3,87× (com quebra local de monotonicidade na faixa 30–60 m, 45,77%);\n"
        "• H4 (Critérios Conjuntos): Sob restrições conjuntas estritas (H ≤ Q1, JSD ≤ Q1, S ≥ Q3 e d ≥ 30 m), apenas 207 pontos na amostra de 20k atendem aos requisitos (4,2773% ponderado em D = 1), confirmados em 404 pontos na amostra de 40k (4,1687%).",
        indent=False
    )

    # Table 2
    add_caption("Tabela 2. Estimativas inferenciais e modelo logístico multivariado sob Spatial Block Bootstrap.")
    t2_rows = [
        ["Indicador / Termo", "Escala", "Contraste / OR", "IC 95% Espacial (30 km)"],
        ["H1: Entropia Anual (H)", "Média", "Δ = +0,0162", "[+0,0103; +0,0221]"],
        ["H2a: Divergência Temp. (JSD)", "Média", "Δ = +0,0075", "[+0,0047; +0,0102]"],
        ["H2b: Estabilidade Modal (S)", "Média", "Δ = -0,0790", "[-0,0974; -0,0599]"],
        ["H3: Borda (<30m) vs Interior", "Razão", "3,87×", "[3,25×; 4,61×]"],
        ["Regressão: Distância Borda", "+100 m", "OR = 0,360", "[0,319; 0,404]"],
        ["Regressão: Entropia Anual", "+0,10", "OR = 1,421", "[1,036; 1,988]"],
        ["Regressão: Estabilidade Modal", "+0,10", "OR = 0,925", "[0,861; 0,992]"],
        ["Regressão: JSD Temporal", "+0,01", "OR = 0,987", "[0,914; 1,059] (n.s.)"],
        ["Regressão: Piauí vs Bahia (ref.)", "UF", "OR = 0,798", "[0,507; 1,212] (n.s.)"],
    ]
    t2 = doc.add_table(rows=len(t2_rows), cols=4)
    t2.alignment = WD_TABLE_ALIGNMENT.CENTER
    for r_idx, row in enumerate(t2_rows):
        for c_idx, val in enumerate(row):
            cell = t2.cell(r_idx, c_idx)
            cell.text = val
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(1)
            p.paragraph_format.space_after = Pt(1)
            for r in p.runs:
                r.font.name = 'Times New Roman'
                r.font.size = Pt(7.5)
                if r_idx == 0:
                    r.font.bold = True
            if r_idx == 0:
                set_cell_border(cell, top=dict(sz=6, val='single', color='000000'),
                                bottom=dict(sz=6, val='single', color='000000'))
            elif r_idx == len(t2_rows) - 1:
                set_cell_border(cell, bottom=dict(sz=6, val='single', color='000000'))

    # Figure 2
    if os.path.exists('figures/fig5_disagreement_by_distance_bin.png'):
        p_f2 = doc.add_paragraph()
        p_f2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_f2.paragraph_format.space_before = Pt(4)
        p_f2.paragraph_format.space_after = Pt(2)
        p_f2.add_run().add_picture('figures/fig5_disagreement_by_distance_bin.png', width=Mm(84))
        add_caption("Figura 2. Taxa de discordância temática por faixas de distância à borda (IC 95% Spatial Block Bootstrap).")

    add_h2("3.3. Associações Marginais versus Condicionais")
    add_body(
        "A análise comparativa entre estimativas marginais e o modelo multivariado destaca dois achados metodológicos centrais:\n"
        "1. Dissociação Condicional da JSD: Enquanto a JSD temporal exibe forte associação positiva marginal em H2a, seu efeito condicional na regressão perde significância (OR = 0,987, IC: [0,914; 1,059]). O controle conjunto da estabilidade modal S e da distância às bordas absorve o sinal da variabilidade temporal contínua.\n"
        "2. Papel Corretivo do Bootstrap Espacial: O teste clássico assintótico indica erroneamente significância no contraste Piauí vs Bahia (p < 0,001, IC: [0,709; 0,900]). O Spatial Block Bootstrap de 30 km corrige a inflação amostral e expande o IC para [0,507; 1,212], cobrindo 1,0 e evidenciando que os estados não diferem condicionalmente.",
        indent=False
    )

    # 4. DISCUSSÃO
    add_h1("4. DISCUSSÃO")
    add_h2("4.1. Incerteza Estruturada e Epistemologia Simétrica")
    add_body(
        "A abordagem simétrica trata a discordância como sinalizador objetivo de incerteza, e não como falha unilateral. As discrepâncias respondem a mecanismos biofísicos e computacionais bem definidos:\n"
        "• Transições de Borda: A concentração de discordâncias nos primeiros 30 m (45,91%) decorre da mistura espectral de subpixel ao longo de estradas internas, curvas de nível e transições com vegetação nativa. No raster de 10 m, células que interceptam bordas flutuam entre classificadores devido a funções de custo e limiares distintos.\n"
        "• Dinâmica Fenológica e Temporal: No Cerrado, o regime de sequeiro impõe transições entre cultura ativa, dessecação, solo exposto e palhada que se aproximam da resposta de savanas abertas [1, 2]. O Dynamic World captura estados instantâneos cena a cena, enquanto o MapBiomas estrutura séries e métricas anuais consolidadas [3, 5], gerando divergências nas transições de ciclo.",
        indent=False
    )
    add_h2("4.2. Interpretação Operacional de H4")
    add_body(
        "A constatação de que apenas 4,28% ponderado das discordâncias atendem aos filtros de H4 não significa 'detecção de erros reais'. Esse subconjunto delimita pixels com classificação assertiva (baixa entropia), temporalmente persistente e situados no interior de manchas contínuas. Nesses pontos, a divergência representa desacordo conceitual substantivo entre arquiteturas de aprendizado profundo e regras temporais, constituindo o alvo prioritário para auditorias de campo independentes.",
        indent=False
    )
    add_h2("4.3. Limitações Metodológicas")
    add_body(
        "O estudo apresenta limites definidos: (1) a restrição a n_meses ≥ 8 excluiu 21,74% do território, concentrado no norte chuvoso do Maranhão; (2) a não-comutatividade temporal/espacial impõe resíduo médio de 0,004983, afetando quase-empates; (3) por ser estudo observacional sem verdade de campo, as relações constituem associações estatísticas espaciais, sem inferência causal.",
        indent=False
    )

    # 5. CONCLUSÕES
    add_h1("5. CONCLUSÕES")
    add_body(
        "O diagnóstico espacial e probabilístico no MATOPIBA revela que a discordância censitária de lavouras em 2025 entre Dynamic World e MapBiomas (14,2852% por área e 14,3110% por pixels) concentra-se em zonas de transição temática e períodos de instabilidade temporal. Apenas 4,28% ponderado das discordâncias manifestam-se no interior contínuo com alta estabilidade e baixa ambiguidade. Sob Spatial Block Bootstrap, contrastes macrorregionais assintóticos perdem significância estatística. Para a comunidade GeoAI, esses resultados indicam que discrepâncias entre produtos decamétricos devem ser tratadas como indicadores quantitativos de incerteza fenológica e de borda, e não como erros arbitrários.",
        indent=False
    )

    # 6. REFERÊNCIAS
    add_h1("6. REFERÊNCIAS")
    refs = [
        "[1] S. A. Spera, G. L. Galford, M. T. Coe, M. N. Macedo, and J. F. Mustard. Land-use change affects water recycling in Brazil’s last agricultural frontier, Global Change Biology, v. 22(10):pp. 3405–3413, 2016.",
        "[2] R. F. B. da Silva, M. Batistella, E. F. Moran, and L. A. Martinelli. Soy expansion and socioeconomic development in municipalities of Brazil, Land, v. 6(3):art. 62, 2017.",
        "[3] C. M. Souza et al. Reconstructing Three Decades of Land Use and Land Cover Changes in Brazilian Biomes with Landsat Archive and Earth Engine, Remote Sensing, v. 12(17):art. 2735, 2020.",
        "[4] MapBiomas. Coleção 4 da Cobertura e Uso da Terra a 10 metros (2017–2025), Rede MapBiomas, São Paulo, 2025. URL: brasil.mapbiomas.org",
        "[5] C. F. Brown et al. Dynamic World, Near real-time global 10 m land use land cover mapping, Scientific Data, v. 9(1):art. 251, 2022.",
        "[6] S. Fritz et al. Highlighting continued uncertainty in global land cover maps for the user community, Environmental Research Letters, v. 6(4):art. 044005, 2011.",
        "[7] R. G. Pontius and M. Millones. Death to Kappa: birth of quantity disagreement and allocation disagreement for accuracy assessment, International Journal of Remote Sensing, v. 32(15):pp. 4407–4429, 2011.",
        "[8] G. M. Foody. Status of land cover classification accuracy assessment, Remote Sensing of Environment, v. 80(1):pp. 185–201, 2002.",
        "[9] P. Olofsson et al. Good practices for estimating area and assessing accuracy of land change, Remote Sensing of Environment, v. 148:pp. 42–57, 2014.",
        "[10] P. Legendre. Spatial autocorrelation: trouble or new paradigm?, Ecology, v. 74(6):pp. 1659–1673, 1993.",
        "[11] G. Carl and I. Kühn. Analyzing spatial autocorrelation in species distributions using Gaussian and alternative methods, Ecological Modelling, v. 207(2–4):pp. 159–170, 2007.",
        "[12] H. R. Künsch. The jackknife and the bootstrap for general stationary observations, The Annals of Statistics, v. 17(3):pp. 1217–1241, 1989.",
        "[13] D. R. Roberts et al. Cross-validation strategies for data with temporal, spatial, or phylogenetic structure, Ecography, v. 40(8):pp. 913–929, 2017.",
        "[14] C. E. Shannon. A mathematical theory of communication, The Bell System Technical Journal, v. 27(3):pp. 379–423, 1948.",
        "[15] J. Lin. Divergence measures based on the Shannon entropy, IEEE Transactions on Information Theory, v. 37(1):pp. 145–151, 1991."
    ]
    for r in refs:
        p_ref = doc.add_paragraph()
        p_ref.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        p_ref.paragraph_format.space_before = Pt(0)
        p_ref.paragraph_format.space_after = Pt(2)
        p_ref.paragraph_format.line_spacing = Pt(10)
        p_ref.paragraph_format.left_indent = Mm(4.2)
        p_ref.paragraph_format.first_line_indent = Mm(-4.2)
        run_ref = p_ref.add_run(r)
        run_ref.font.name = 'Times New Roman'
        run_ref.font.size = Pt(8)

    doc.save(output_path)
    print(f"DOCX Generated successfully: {output_path}")

if __name__ == '__main__':
    create_docx('paper/manuscript_space_week_nordeste_2026_v2.docx')
