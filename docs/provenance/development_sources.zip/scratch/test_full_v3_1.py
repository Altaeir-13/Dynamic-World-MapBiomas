import docx
from docx.shared import Mm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
import subprocess, pypdf, os
import pypdfium2 as pdfium

def set_cell_border(cell, **kwargs):
    tcPr = cell._tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key, val in edge_data.items():
                element.set(qn('w:{}'.format(key)), str(val))

def set_cell_margins(cell, top=45, bottom=45, left=65, right=65):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def set_section_cols(section, num_cols=2, space_dxa=340):
    sectPr = section._sectPr
    for child in list(sectPr):
        if child.tag.endswith('cols'):
            sectPr.remove(child)
    cols = OxmlElement('w:cols')
    cols.set(qn('w:num'), str(num_cols))
    if num_cols > 1:
        cols.set(qn('w:space'), str(space_dxa))
        cols.set(qn('w:equalWidth'), '1')
    sectPr.append(cols)

doc = docx.Document()
sec0 = doc.sections[0]
sec0.page_width = Mm(210)
sec0.page_height = Mm(297)
sec0.left_margin = Mm(19)
sec0.right_margin = Mm(13)
sec0.top_margin = Mm(25)
sec0.bottom_margin = Mm(43)
set_section_cols(sec0, 1)

# Title: 14 pt, bold, centered, top at 35 mm (25mm margin + 10mm / 28pt before)
p_title = doc.add_paragraph()
p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_title.paragraph_format.space_before = Pt(28)
p_title.paragraph_format.space_after = Pt(4)
p_title.paragraph_format.line_spacing = Pt(16)
r_title = p_title.add_run("ONDE DYNAMIC WORLD E MAPBIOMAS DISCORDAM SOBRE LAVOURAS? DIAGNÓSTICO ESPACIAL E PROBABILÍSTICO NO MATOPIBA")
r_title.font.name = "Times New Roman"
r_title.font.size = Pt(14)
r_title.font.bold = True

p_auth = doc.add_paragraph()
p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_auth.paragraph_format.space_before = Pt(3)
p_auth.paragraph_format.space_after = Pt(2)
r_auth = p_auth.add_run("[Nome do Primeiro Autor]¹*, [Nome do Segundo Autor]², [Nome do Terceiro Autor]³ e [Nome do Último Autor]⁴")
r_auth.font.name = "Times New Roman"
r_auth.font.size = Pt(10)
r_auth.font.bold = True

p_aff = doc.add_paragraph()
p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_aff.paragraph_format.space_before = Pt(0)
p_aff.paragraph_format.space_after = Pt(6)
p_aff.paragraph_format.line_spacing = Pt(10)
r_aff = p_aff.add_run(
    "¹ [Instituição do Autor 1] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor1@instituicao.edu.br]\n"
    "² [Instituição do Autor 2] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor2@instituicao.edu.br]\n"
    "³ [Instituição do Autor 3] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor3@instituicao.edu.br]\n"
    "⁴ [Instituição do Autor 4] – [Sigla/Depto], [Cidade] – [UF], Brasil; [email.autor4@instituicao.edu.br]\n"
    "*Autor correspondente: [email.autor1@instituicao.edu.br]"
)
r_aff.font.name = "Times New Roman"
r_aff.font.size = Pt(8)

s1 = doc.add_section(docx.enum.section.WD_SECTION_START.CONTINUOUS)
s1.page_width = Mm(210)
s1.page_height = Mm(297)
s1.left_margin = Mm(19)
s1.right_margin = Mm(13)
s1.top_margin = Mm(25)
s1.bottom_margin = Mm(43)
set_section_cols(s1, 2)

def add_h1(text, is_abstract=False):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(7)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10)
    r.font.bold = True
    if is_abstract: r.font.italic = True
    return p

def add_h2(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(1.5)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10)
    r.font.bold = True
    return p

def add_p(text, indent=True, italic=False, space_after=1.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = Pt(11.2)
    p.paragraph_format.first_line_indent = Mm(6.3) if indent else Mm(0)
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(10)
    r.font.italic = italic
    return p

def add_caption(text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(3)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    r.font.name = "Times New Roman"
    r.font.size = Pt(9)
    r.font.bold = True
    return p

# Resumo
add_h1("RESUMO")
add_p("Mapeamentos de uso e cobertura da terra em escala decamétrica (10 m) são vitais para o monitoramento territorial. Em fronteiras agrícolas com acentuada sazonalidade como o MATOPIBA, divergências entre produtos de GeoAI permanecem pouco elucidadas. Este estudo apresenta um diagnóstico simétrico da discordância de lavouras entre Dynamic World e MapBiomas (Coleção 4, 10 m) em 2025. Com amostragem probabilística estratificada de 20.000 pontos em 52,34 milhões de hectares elegíveis, avaliou-se a associação da discordância com incerteza probabilística anual, dinâmica temporal e proximidade a bordas temáticas. A discordância censitária atinge 14,2852% por área e 14,3110% por pixels. Sob Spatial Block Bootstrap (blocos de 30 km, 1.999 réplicas), a discordância associa-se a maior entropia anual (ΔH = +0,0162), maior divergência Jensen-Shannon temporal (ΔJSD = +0,0075) e menor estabilidade modal (ΔS = -0,0790). Em bordas (<30 m), a discordância é 3,87 vezes superior à do interior (≥250 m). Na regressão logística, distância à borda (OR = 0,360) e estabilidade temporal (OR = 0,925) associam-se inversamente à discordância. Apenas 4,28% ponderado das discordâncias atendem a critérios operacionais de baixa ambiguidade, alta estabilidade e afastamento de bordas, indicando que divergências concentram-se em transições de borda e instabilidade temporal.", indent=False)
add_p("Palavras-chave – Dynamic World, MapBiomas, MATOPIBA, Discordância Espacial, Incerteza Temporal.", indent=False, italic=True)

# Abstract
add_h1("ABSTRACT", is_abstract=True)
add_p("High-resolution (10 m) land use and land cover maps are vital for territorial monitoring. In highly seasonal agricultural frontiers such as MATOPIBA, discrepancies between Earth Observation and GeoAI products remain poorly understood. This study provides a symmetric analytical diagnosis of cropland disagreement between Dynamic World and MapBiomas (Collection 4, 10 m) for 2025. Using a design-based stratified random sample of 20,000 points across 52.34 million eligible hectares, we evaluate associations with annual probabilistic uncertainty, intra-annual dynamics, and thematic edge proximity. Census cropland disagreement reaches 14.2852% by area and 14.3110% by pixels. Using Spatial Block Bootstrap inference (30 km blocks, 1,999 replicates), disagreement is significantly associated with higher annual entropy (ΔH = +0.0162), higher temporal Jensen-Shannon divergence (ΔJSD = +0.0075), and lower modal stability (ΔS = -0.0790). At thematic edges (<30 m), disagreement is 3.87 times higher than in core areas (≥250 m). In logistic regression, edge distance (OR = 0.360) and temporal stability (OR = 0.925) show inverse associations with disagreement. Only 4.28% of weighted disagreements meet operational criteria of low ambiguity, high stability, and edge avoidance, showing that discrepancies concentrate along boundary transitions and temporal volatility.", indent=False, italic=True)
add_p("Key words – Dynamic World, MapBiomas, MATOPIBA, Spatial Disagreement, Temporal Uncertainty.", indent=False, italic=True)

# Intro
add_h1("1. INTRODUÇÃO")
add_p("A expansão agropecuária no MATOPIBA consolidou o Cerrado como polo agrícola estratégico [1, 2], demandando monitoramento apoiado em produtos de uso e cobertura da terra (LULC) de 10 m, como MapBiomas (Coleção 4) [3, 4] e Dynamic World (DW) [5]. O MapBiomas estrutura classificações anuais integrando séries temporais e filtros espaciais [3], enquanto o Dynamic World gera vetores contínuos de 9 probabilidades a cada cena Sentinel-2 [5].", indent=False)
add_p("Em ecótonos e fronteiras agrícolas tropicais, discrepâncias entre mapeamentos independentes variam entre 10% e 25% [6, 7]. Na ausência de extensos dados de referência de campo (ground truth) [8, 9], este estudo propõe um diagnóstico analítico simétrico: investigar onde e sob quais condições os produtos divergem, tratando a discordância como objeto de análise associado a sinais intrínsecos de incerteza da GeoAI.", indent=True)
add_p("Formulam-se quatro hipóteses operacionais para 2025: (H1, Ambiguidade Anual) pixels discordantes (D = 1) apresentam maior entropia média na distribuição probabilística anual do que concordantes (D = 0); (H2, Instabilidade Temporal) a discordância associa-se a maior heterogeneidade intra-anual (H2a, divergência Jensen-Shannon temporal) e a menor persistência modal (H2b, estabilidade temporal S); (H3, Efeito de Borda) a discordância é maior nas vizinhanças imediatas de bordas temáticas de transição do que no interior; (H4, Discordâncias sob Restrições Conjuntas) sob critérios operacionais estritos de menor ambiguidade anual, menor heterogeneidade temporal, maior estabilidade modal do DW e afastamento de bordas, as discordâncias restringem-se a uma fração reduzida da população discordante.", indent=True)

# Métodos
add_h1("2. MATERIAL E MÉTODOS")
add_h2("2.1. Domínio Geográfico e Critério de Elegibilidade")
add_p("O MATOPIBA abrange 337 municípios e cerca de 73 milhões de hectares. Para mitigar o impacto de nuvens persistentes, o domínio censitário elegível foi delimitado por células de 10 m com no mínimo 8 meses válidos no Dynamic World em 2025 (n_meses ≥ 8) e classes válidas no MapBiomas (excluindo água e áreas não-vegetadas). A população censitária elegível resultante totaliza 52.342.114,75 ha (5.354.669.418 pixels de 10 m).", indent=False)

add_h2("2.2. Produtos Cartográficos e Harmonização de Suporte")
add_p("Utilizou-se o MapBiomas Cobertura 10 m — Coleção 4 — 2025 [4], definindo lavoura pelo crosswalk das classes 19 (Lavoura Temporária) e 36 (Lavoura Perene), distinguindo-se de mosaico (21) e agricultura genérica (18). O produto foi projetado na grade de 10 m em SIRGAS 2000 / Policonica do Brasil (EPSG:5880).", indent=False)
add_p("Para o Dynamic World (v1) [5], o raster anual resultou da média temporal das observações do mesmo dia, média diária para mensal e agregação anual pela média dos vetores de 9 probabilidades, extraindo a classe pelo argmax anual (e não por votação modal), sendo crops (classe 4) lavoura. As séries mensais foram reamostradas para EPSG:5880 via interpolação bilinear. A não-comutatividade entre interpolação espacial e máscara de nuvens impõe resíduo probabilístico médio de 0,004983, implicando alternância de argmax em 8,24% e inversão de lavoura em 2,59% dos pontos amostrados, concentrada em margens inferiores a 0,05.", indent=True)

add_h2("2.3. Indicadores de Incerteza e Estabilidade")
add_p("Para cada ponto, calcularam-se quatro métricas contínuas: (1) Entropia de Shannon Anual Normalizada, HN(p) = -[1/ln(9)] ∑ pk ln(pk + ε) [14]; (2) Divergência Jensen-Shannon Temporal Normalizada, JSDN = HN(p_méd) - (1/M) ∑ HN(p^(m)) [15], contrastando a entropia da média temporal com a média das entropias mensais; (3) Estabilidade Categórica Modal, S = (1/M) ∑ 1(c^(m) = c_anual), fração de meses em que o argmax coincidiu com a classe anual do DW; e (4) Distância Mínima à Borda Temática, d_min = min(d_dw, d_mb), distância euclidiana métrica em raster até a transição mais próxima, truncada em 250 m, restrita ao suporte analítico de pixels sem inferência sobre limites cadastrais de talhões.", indent=False)

add_h2("2.4. Desenho Amostral e Inferência Espacial")
add_p("O espaço amostral foi particionado em 16 estratos analíticos (4 estados × 4 regimes: AA, AN, NA, NN) e operacionalizado em 410 subestratos espaciais independentes (hs). A seleção nos subestratos atribuiu probabilidade de inclusão π_{robust,hs} = n_{robust,hs} / N_{hs} na amostra robusta de 40k e π_{main,k} = 0,5 · π_{robust,hs} na amostra principal de 20k. As estimativas populacionais incorporam pesos de Horvitz-Thompson (w_k = 1 / π_k) [9].", indent=False)
add_p("Para acomodar a dependência espacial nos resíduos [10, 11], o semivariograma exponencial indicou alcance prático de 25,62 km. Conforme Künsch [12] e Roberts et al. [13], implementou-se Spatial Block Bootstrap estruturado em blocos de 30 km e 1.999 réplicas com reposição. Ajustou-se modelo logístico multivariado ponderado, interpretando os odds ratios (OR) escalonados como associações condicionais com intervalos de confiança a 95%.", indent=True)

add_h1("3. RESULTADOS")
add_h2("3.1. Discordância Censitária e Distribuição Geográfica")
add_p("No censo wall-to-wall de 52,34 Mha elegíveis, a discordância entre os produtos atinge 14,2852% por área (7.477.177,23 ha) e 14,3110% por pixels (766.304.630 pixels). A estimativa ponderada na amostra de 20.000 pontos reproduz com precisão o parâmetro censitário: 14,2897% por área (7.479.568,87 ha) e 14,3148% por pixels (766.512.449 pixels). A discordância decorre predominantemente de alocação espacial (9,30 pp) frente à divergência de quantidade de área (4,99 pp) [7]. A Tabela 1 detalha os regimes censitários e por estado (BA: 27,95%; PI: 21,80%; MA: 10,98%; TO: 5,90%), cuja composição é ilustrada na Figura 1.", indent=False)

# ==========================================
# PAGE 3: Section 2 (NEW_PAGE, 1 col) -> Tabela 1
# ==========================================
s2 = doc.add_section(docx.enum.section.WD_SECTION_START.NEW_PAGE)
s2.page_width = Mm(210)
s2.page_height = Mm(297)
s2.left_margin = Mm(19)
s2.right_margin = Mm(13)
s2.top_margin = Mm(25)
s2.bottom_margin = Mm(43)
set_section_cols(s2, 1)

add_caption("Tabela 1. Composição censitária e amostral ponderada por regime temático e estado no MATOPIBA (2025). Fontes: tables/sampling_frame_10m.csv e tables/descriptive_regime_proportions.csv.")

t1_data = [
    ["Regime Temático / Estado", "Área Censitária (ha)", "Proporção Censitária (%)", "Censo Pixels (%)", "Amostra 20k Ponderada (%)", "IC 95% Espacial (30 km)"],
    ["AA (Acordo Lavoura)", "1.274.056,40", "2,4341%", "2,4398%", "2,4334%", "[2,01%; 2,98%]"],
    ["AN (MapBiomas Sim, DW Não)", "5.044.314,15", "9,6372%", "9,6557%", "9,6465%", "[8,95%; 10,48%]"],
    ["NA (DW Sim, MapBiomas Não)", "2.432.863,07", "4,6480%", "4,6592%", "4,6432%", "[4,12%; 5,26%]"],
    ["NN (Acordo Não-Lavoura)", "43.590.881,12", "83,2807%", "83,2454%", "83,2769%", "[82,05%; 84,38%]"],
    ["Discordância Total (AN+NA)", "7.477.177,23", "14,2852%", "14,3110%", "14,2897%", "[13,42%; 15,28%]"],
    ["Maranhão (MA)", "1.093.012,65", "10,9757%", "10,9842%", "10,9624%", "[9,25%; 13,01%]"],
    ["Tocantins (TO)", "1.338.415,21", "5,9012%", "5,9104%", "5,8973%", "[4,88%; 7,12%]"],
    ["Piauí (PI)", "1.639.894,85", "21,7956%", "21,8120%", "21,8165%", "[18,44%; 25,62%]"],
    ["Bahia (BA)", "3.405.854,52", "27,9519%", "27,9845%", "27,9752%", "[24,80%; 31,45%]"],
]
col_widths_mm = [42, 28, 26, 24, 28, 30] # 178 mm
t1 = doc.add_table(rows=len(t1_data), cols=6)
t1.alignment = WD_TABLE_ALIGNMENT.CENTER
tblPr = t1._tbl.tblPr
tblW = parse_xml(r'<w:tblW xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" w:w="10091" w:type="dxa"/>')
tblPr.append(tblW)

for r_idx, row in enumerate(t1_data):
    trPr = t1.rows[r_idx]._tr.get_or_add_trPr()
    trPr.append(parse_xml(r'<w:cantSplit xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))
    if r_idx == 0:
        trPr.append(parse_xml(r'<w:tblHeader xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))

    for c_idx, val in enumerate(row):
        cell = t1.cell(r_idx, c_idx)
        cell.width = Mm(col_widths_mm[c_idx])
        cell.text = val
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT if c_idx == 0 else WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.space_after = Pt(1)
        p.paragraph_format.line_spacing = Pt(9)
        set_cell_margins(cell, top=45, bottom=45, left=65, right=65)
        for r in p.runs:
            r.font.name = 'Times New Roman'
            r.font.size = Pt(7.5)
            if r_idx in (0, 5): r.font.bold = True
        if r_idx == 0:
            set_cell_border(cell, top=dict(sz=8, val='single', color='000000'), bottom=dict(sz=8, val='single', color='000000'))
        elif r_idx == len(t1_data) - 1:
            set_cell_border(cell, bottom=dict(sz=8, val='single', color='000000'))

# Page 3 Continues: Section 3 (CONTINUOUS, 2 cols) -> 3.2, Figura 2, 3.3
s3 = doc.add_section(docx.enum.section.WD_SECTION_START.CONTINUOUS)
s3.page_width = Mm(210)
s3.page_height = Mm(297)
s3.left_margin = Mm(19)
s3.right_margin = Mm(13)
s3.top_margin = Mm(25)
s3.bottom_margin = Mm(43)
set_section_cols(s3, 2)

add_h2("3.2. Testes de Hipótese H1 a H4")
add_p("A avaliação das hipóteses revelou padrões informacionais e espaciais consistentes: (H1, Ambiguidade) a entropia anual média é superior nas células discordantes (ΔH = +0,0162, IC 95%: [+0,0103; +0,0221], d = +0,318), associando-se a incerteza probabilística; (H2, Dinâmica Temporal) pixels discordantes exibem maior divergência temporal (ΔJSD = +0,007492, IC: [+0,0047; +0,0102], d = +0,335) e menor estabilidade modal (ΔS = -0,078959, IC: [-0,0974; -0,0599], d = -0,426); (H3, Efeito de Borda) a discordância atinge 45,91% na borda imediata (<30 m) e 11,87% no interior (≥250 m), gerando razão de contraste de 3,87 vezes. Entre faixas contíguas, há quebra local de monotonicidade estrita (30–60 m com 45,77% vs. 10–30 m com 44,59%), evidenciando forte gradiente inverso global sem monotonicidade perfeita; (H4, Restrições Conjuntas) sob filtros simultâneos de menor ambiguidade (H ≤ Q1), menor heterogeneidade (JSD ≤ Q1), maior estabilidade modal do DW (S ≥ Q3) e afastamento de bordas (d_min ≥ 30 m), apenas 207 pontos atendem aos critérios na amostra de 20k (4,2773% ponderado dos discordantes), confirmados em 404 pontos na amostra de 40k (4,1687%).", indent=False)

if os.path.exists('figures/fig5_disagreement_by_distance_bin.png'):
    p_f2 = doc.add_paragraph()
    p_f2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_f2.paragraph_format.space_before = Pt(2)
    p_f2.paragraph_format.space_after = Pt(1)
    p_f2.add_run().add_picture('figures/fig5_disagreement_by_distance_bin.png', width=Mm(78))
    add_caption("Figura 2. Taxa de discordância por distância às bordas com IC 95% empírico derivado de Spatial Block Bootstrap (30 km).")

add_h2("3.3. Associações Marginais versus Condicionais")
add_p("A comparação entre contrastes bivariados e modelo multivariado indica aspectos cruciais: (1) Atenuação da JSD Temporal: enquanto a JSD exibe forte associação positiva marginal em H2a, seu efeito condicional dissipa-se na regressão (OR = 0,987, IC: [0,914; 1,059]). Controlando-se estabilidade S e distância à borda, a JSD contínua não agrega poder preditivo condicional, fruto de correlação empírica entre regressores (sem inferência causal de mediação); (2) Ajuste Espacial no Contraste Estadual: sob premissa assintótica clássica i.i.d., o contraste Piauí vs. Bahia sugeriria significância (p < 0,001, IC: [0,709; 0,900]). O Spatial Block Bootstrap de 30 km acomoda a dependência geográfica e expande o IC para [0,507; 1,212], cobrindo 1,0 e indicando ausência de evidência condicional entre PI e BA, ilustrando o risco de falsos positivos em análises sem ajuste espacial.", indent=False)

# ==========================================
# PAGE 4: Section 4 (NEW_PAGE, 1 col) -> Figura 1
# ==========================================
s4 = doc.add_section(docx.enum.section.WD_SECTION_START.NEW_PAGE)
s4.page_width = Mm(210)
s4.page_height = Mm(297)
s4.left_margin = Mm(19)
s4.right_margin = Mm(13)
s4.top_margin = Mm(25)
s4.bottom_margin = Mm(43)
set_section_cols(s4, 1)

if os.path.exists('figures/fig1_composition_regimes.png'):
    p_f1 = doc.add_paragraph()
    p_f1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_f1.paragraph_format.space_before = Pt(2)
    p_f1.paragraph_format.space_after = Pt(1)
    p_f1.add_run().add_picture('figures/fig1_composition_regimes.png', width=Mm(165))
    add_caption("Figura 1. Composição dos regimes temáticos e distribuição geográfica da discordância: (A) Proporção ponderada de regimes no MATOPIBA (AA: 2,43%, AN: 9,65%, NA: 4,64%, NN: 83,28%); (B) Gradiente estadual de discordância temática (BA > PI > MA > TO).")

# Page 4 Continues: Section 5 (CONTINUOUS, 2 cols) -> Discussão & Conclusões
s5 = doc.add_section(docx.enum.section.WD_SECTION_START.CONTINUOUS)
s5.page_width = Mm(210)
s5.page_height = Mm(297)
s5.left_margin = Mm(19)
s5.right_margin = Mm(13)
s5.top_margin = Mm(25)
s5.bottom_margin = Mm(43)
set_section_cols(s5, 2)

add_h1("4. DISCUSSÃO")
add_h2("4.1. Incerteza Estruturada e Abordagem Simétrica")
add_p("A abordagem simétrica trata as divergências não como erros unilaterais, mas como manifestações empíricas de incerteza estruturada ligadas ao suporte espacial e à dinâmica temporal: (1) Transições de Borda e Mistura Espectral: a concentração de discordâncias nos primeiros 30 metros (razão de 3,87 vezes) indica a mistura de subpixel como mecanismo plausível ao longo de carreadores e bordas de talhões. No suporte de 10 m, células que interceptam interfaces solo-vegetação flutuam entre produtos em virtude de regras decisórias distintas, sem inferência causal definitiva na ausência de controle de campo; (2) Sazonalidade e Dinâmica Temporal: no sequeiro do Cerrado, ciclos vegetativos e palhada produzem variações espectrais que constituem hipótese interpretativa plausível para as divergências. Enquanto o DW integra estados cena a cena, o MapBiomas apoia-se em percentis anuais consolidados [3, 5], associando-se empiricamente a períodos de oscilação fenológica.", indent=False)

add_h2("4.2. Caracterização Operacional de H4")
add_p("A constatação de que apenas 4,28% ponderado das discordâncias atendem aos filtros de H4 delimita um subconjunto restrito de divergências categóricas no interior da paisagem (d_min ≥ 30 m) que atendem aos critérios de menor ambiguidade probabilística anual, menor heterogeneidade temporal e maior estabilidade modal nas séries do Dynamic World. Ressalta-se que esses indicadores pertencem exclusivamente ao DW, não configurando assertividade mútua dos dois produtos. Tais casos não são erros comprovados, mas indicam divergências conceituais substantivas entre abordagens (como transições entre pastagens intensivas e lavouras anuais), representando alvos para auditorias de campo independentes.", indent=False)

add_h2("4.3. Limitações do Estudo")
add_p("O trabalho possui limites metodológicos definidos: (1) a exigência de n_meses ≥ 8 excluiu 21,74% da área do MATOPIBA, concentrada no norte chuvoso do Maranhão; (2) a não-comutatividade temporal/espacial impõe resíduo médio de 0,004983, afetando situações de quase-empate probabilístico; (3) por se tratar de comparação observacional estritamente baseada em dados orbitais, sem verdade de campo independente, os resultados refletem associações empíricas espaciais e temporais, vedando qualquer inferência causal definitiva sobre causas de divergência.", indent=False)

add_h1("5. CONCLUSÕES")
add_p("O diagnóstico espacial e probabilístico no MATOPIBA estabelece associações empíricas consistentes entre a discordância censitária de lavouras em 2025 (14,2852% por área e 14,3110% por pixels) e fatores de proximidade a bordas e instabilidade temporal do Dynamic World. Apenas 4,28% ponderado das discordâncias atendem aos critérios operacionais restritivos de H4 (baixa ambiguidade, alta persistência do DW e afastamento de bordas). Os mecanismos discutidos (efeito de borda, mistura de subpixel e dinâmica fenológica) constituem interpretações plausíveis para esses padrões empíricos, sem alegação de causalidade demonstrada. A aplicação de Spatial Block Bootstrap evidenciou que contrastes estaduais perdem significância condicional quando a dependência espacial é incorporada, orientando o uso de produtos decamétricos sob modelagem explícita de incerteza.", indent=False)

# ==========================================
# PAGE 5: Section 6 (NEW_PAGE, 1 col) -> Tabela 2
# ==========================================
s6 = doc.add_section(docx.enum.section.WD_SECTION_START.NEW_PAGE)
s6.page_width = Mm(210)
s6.page_height = Mm(297)
s6.left_margin = Mm(19)
s6.right_margin = Mm(13)
s6.top_margin = Mm(25)
s6.bottom_margin = Mm(43)
set_section_cols(s6, 1)

add_caption("Tabela 2. Contrastes das hipóteses H1–H3 e modelo logístico multivariado sob Spatial Block Bootstrap (30 km, 1.999 réplicas). Fontes: tables/hypothesis_h1_results.csv, tables/hypothesis_h2_results.csv, tables/hypothesis_h3_distance_bins.csv, tables/regression_logistic_rescaled_odds_ratios.csv.")

t2_data = [
    ["Indicador / Termo Preditivo", "Escala", "Estimativa / Nível", "Contraste (Δ) / OR", "IC 95% Espacial (30 km)", "Interpretação Condicional Ajustada"],
    ["H1: Entropia Anual (H)", "Média", "D=0: 0,8357 / D=1: 0,8519", "Δ = +0,0162", "[+0,0103; +0,0221]", "Associação positiva com incerteza"],
    ["H2a: Divergência Temp. (JSD)", "Média", "D=0: 0,0327 / D=1: 0,0402", "Δ = +0,0075", "[+0,0047; +0,0102]", "Maior volatilidade temporal marginal"],
    ["H2b: Estabilidade Modal (S)", "Média", "D=0: 0,6366 / D=1: 0,5576", "Δ = -0,0790", "[-0,0974; -0,0599]", "Menor persistência categórica"],
    ["H3: Borda (<30m) vs Interior", "Razão", "Borda: 45,91% / Int.: 11,87%", "Razão: 3,87×", "[3,25×; 4,61×]", "Gradiente inverso sem monotonicidade"],
    ["Regressão: Distância à Borda", "+100 m", "Gradiente contínuo", "OR = 0,360", "[0,319; 0,404]", "Forte associação inversa condicional"],
    ["Regressão: Entropia Anual", "+0,10", "Incerteza anual", "OR = 1,421", "[1,036; 1,988]", "Associação positiva condicional"],
    ["Regressão: Estabilidade Modal", "+0,10", "Consistência temporal", "OR = 0,925", "[0,861; 0,992]", "Associação inversa condicional"],
    ["Regressão: JSD Temporal", "+0,01", "Dinâmica temporal", "OR = 0,987", "[0,914; 1,059]", "Sem evidência condicional (1 ∈ IC)"],
    ["Regressão: Piauí vs Bahia (ref.)", "UF", "Referência: BA", "OR = 0,798", "[0,507; 1,212]", "Sem evidência condicional (1 ∈ IC)"],
    ["Regressão: Maranhão vs Bahia", "UF", "Referência: BA", "OR = 0,378", "[0,242; 0,575]", "Menor propensão condicional que BA"],
    ["Regressão: Tocantins vs Bahia", "UF", "Referência: BA", "OR = 0,160", "[0,114; 0,225]", "Menor propensão condicional que BA"],
]
col_widths_t2 = [42, 15, 35, 24, 27, 35] # sum = 178 mm
t2 = doc.add_table(rows=len(t2_data), cols=6)
t2.alignment = WD_TABLE_ALIGNMENT.CENTER
tblPr2 = t2._tbl.tblPr
tblW2 = parse_xml(r'<w:tblW xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" w:w="10091" w:type="dxa"/>')
tblPr2.append(tblW2)

for r_idx, row in enumerate(t2_data):
    trPr2 = t2.rows[r_idx]._tr.get_or_add_trPr()
    trPr2.append(parse_xml(r'<w:cantSplit xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))
    if r_idx == 0:
        trPr2.append(parse_xml(r'<w:tblHeader xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'))

    for c_idx, val in enumerate(row):
        cell = t2.cell(r_idx, c_idx)
        cell.width = Mm(col_widths_t2[c_idx])
        cell.text = val
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT if c_idx in (0, 5) else WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.space_after = Pt(1)
        p.paragraph_format.line_spacing = Pt(9)
        set_cell_margins(cell, top=40, bottom=40, left=60, right=60)
        for r in p.runs:
            r.font.name = 'Times New Roman'
            r.font.size = Pt(7.5)
            if r_idx == 0 or c_idx == 3: r.font.bold = True
        if r_idx == 0:
            set_cell_border(cell, top=dict(sz=8, val='single', color='000000'), bottom=dict(sz=8, val='single', color='000000'))
        elif r_idx == len(t2_data) - 1:
            set_cell_border(cell, bottom=dict(sz=8, val='single', color='000000'))

# Page 5 Continues: Section 7 (CONTINUOUS, 2 cols) -> 6. REFERÊNCIAS
s7 = doc.add_section(docx.enum.section.WD_SECTION_START.CONTINUOUS)
s7.page_width = Mm(210)
s7.page_height = Mm(297)
s7.left_margin = Mm(19)
s7.right_margin = Mm(13)
s7.top_margin = Mm(25)
s7.bottom_margin = Mm(43)
set_section_cols(s7, 2)

add_h1("6. REFERÊNCIAS")
refs = [
    "[1] S. A. Spera, G. L. Galford, M. T. Coe, M. N. Macedo, and J. F. Mustard. Land-use change affects water recycling in Brazil’s last agricultural frontier, Global Change Biology, v. 22(10):pp. 3405–3413, 2016.",
    "[2] R. F. B. da Silva, M. Batistella, E. F. Moran, and L. A. Martinelli. Soy expansion and socioeconomic development in municipalities of Brazil, Land, v. 6(3):art. 62, 2017.",
    "[3] C. M. Souza et al. Reconstructing Three Decades of Land Use and Land Cover Changes in Brazilian Biomes with Landsat Archive and Earth Engine, Remote Sensing, v. 12(17):art. 2735, 2020.",
    "[4] MapBiomas. Coleção 4 da Cobertura e Uso da Terra a 10 metros (2017–2025), Rede MapBiomas, São Paulo, 2025. URL: brasil.mapbiomas.org",
    "[5] C. F. Brown et al. Dynamic World, Near real-time global 10 m land use land cover mapping, Scientific Data, v. 9(1):art. 251, 2022.",
    "[6] S. Fritz et al. Highlighting continued uncertainty in global land cover maps for the user community, Environmental Research Letters, v. 6(4):art. 044005, 2011.",
    "[7] R. G. Pontius and M. Millones. Death to Kappa: birth of quantity disagreement and allocation disagreement for accuracy assessment, International Journal of Remote Sensing, v. 32(15):pp. 4407–4429, 2011.",
    "[8] G. M. Foody. Status of land cover classification accuracy assessment, Remote Sensing of Environment, v. 80(1):pp. 185–201, 2002.",
    "[9] P. Olofsson et al. Good practices for estimating area and assessing accuracy of land change, Remote Sensing of Environment, v. 148:pp. 42–57, 2014.",
    "[10] P. Legendre. Spatial autocorrelation: trouble or new paradigm?, Ecology, v. 74(6):pp. 1659–1673, 1993.",
    "[11] G. Carl and I. Kühn. Analyzing spatial autocorrelation in species distributions using Gaussian and alternative methods, Ecological Modelling, v. 207(2–4):pp. 159–170, 2007.",
    "[12] H. R. Künsch. The jackknife and the bootstrap for general stationary observations, The Annals of Statistics, v. 17(3):pp. 1217–1241, 1989.",
    "[13] D. R. Roberts et al. Cross-validation strategies for data with temporal, spatial, or phylogenetic structure, Ecography, v. 40(8):pp. 913–929, 2017.",
    "[14] C. E. Shannon. A mathematical theory of communication, The Bell System Technical Journal, v. 27(3):pp. 379–423, 1948.",
    "[15] J. Lin. Divergence measures based on the Shannon entropy, IEEE Transactions on Information Theory, v. 37(1):pp. 145–151, 1991."
]
for r in refs:
    p_ref = doc.add_paragraph()
    p_ref.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p_ref.paragraph_format.space_before = Pt(0)
    p_ref.paragraph_format.space_after = Pt(1.5)
    p_ref.paragraph_format.line_spacing = Pt(9.5)
    p_ref.paragraph_format.left_indent = Mm(3.5)
    p_ref.paragraph_format.first_line_indent = Mm(-3.5)
    run_ref = p_ref.add_run(r)
    run_ref.font.name = 'Times New Roman'
    run_ref.font.size = Pt(7.5)

out_docx = "paper/manuscript_space_week_nordeste_2026_v3_1.docx"
os.makedirs("paper", exist_ok=True)
doc.save(out_docx)
print(f"Generated master DOCX: {out_docx}")

cmd = [r"C:\Program Files\LibreOffice\program\soffice.com", "--headless", "--convert-to", "pdf", out_docx, "--outdir", "paper"]
subprocess.run(cmd, check=True)
out_pdf = "paper/manuscript_space_week_nordeste_2026_v3_1.pdf"
print(f"Generated exported PDF: {out_pdf}")

reader = pypdf.PdfReader(out_pdf)
print(f"TOTAL PAGES: {len(reader.pages)}")
for i, page in enumerate(reader.pages):
    text = page.extract_text()
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    print(f"Page {i+1}: lines={len(lines)}, chars={len(text)}")
    if lines:
        print(f"   First: {lines[0][:60]}")
        print(f"   Last:  {lines[-1][:60]}")
