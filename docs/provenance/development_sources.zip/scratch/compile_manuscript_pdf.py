import sys
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Table, TableStyle, Image, FrameBreak, NextPageTemplate, PageBreak, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT, TA_RIGHT
import pypdf

def create_pdf(output_pdf_path):
    # A4 is 210 x 297 mm
    # Print area: width = 178 mm, height = 229 mm
    # Left margin = 19 mm -> Right margin = 210 - 19 - 178 = 13 mm
    # Top margin = 25 mm -> Bottom margin = 297 - 25 - 229 = 43 mm
    col_w = 86 * mm
    gutter = 6 * mm
    left = 19 * mm
    bottom = 43 * mm
    full_h = 229 * mm
    
    # Header on first page: Title + Authors
    # Needs around 42 mm height
    header_h = 40 * mm
    cols_p1_h = full_h - header_h
    
    doc = BaseDocTemplate(
        output_pdf_path,
        pagesize=A4,
        leftMargin=left,
        rightMargin=13 * mm,
        topMargin=25 * mm,
        bottomMargin=bottom
    )
    
    # Frames for First Page
    frame_hdr = Frame(left, bottom + cols_p1_h, 178 * mm, header_h, id='hdr',
                      topPadding=0, bottomPadding=0, leftPadding=0, rightPadding=0)
    frame_c1_p1 = Frame(left, bottom, col_w, cols_p1_h, id='c1_p1',
                        topPadding=2*mm, bottomPadding=0, leftPadding=0, rightPadding=0)
    frame_c2_p1 = Frame(left + col_w + gutter, bottom, col_w, cols_p1_h, id='c2_p1',
                        topPadding=2*mm, bottomPadding=0, leftPadding=0, rightPadding=0)
    
    template_p1 = PageTemplate(id='FirstPage', frames=[frame_hdr, frame_c1_p1, frame_c2_p1])
    
    # Frames for Later Pages (Pages 2-5)
    frame_c1 = Frame(left, bottom, col_w, full_h, id='c1',
                     topPadding=0, bottomPadding=0, leftPadding=0, rightPadding=0)
    frame_c2 = Frame(left + col_w + gutter, bottom, col_w, full_h, id='c2',
                     topPadding=0, bottomPadding=0, leftPadding=0, rightPadding=0)
    
    template_later = PageTemplate(id='LaterPages', frames=[frame_c1, frame_c2])
    
    doc.addPageTemplates([template_p1, template_later])
    
    # Styles
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=13,
        leading=15,
        alignment=TA_CENTER,
        textTransform='uppercase',
        spaceAfter=6
    )
    
    authors_style = ParagraphStyle(
        'DocAuthors',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=9.5,
        leading=12,
        alignment=TA_CENTER,
        spaceAfter=2
    )
    
    affil_style = ParagraphStyle(
        'DocAffil',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=8.5,
        leading=11,
        alignment=TA_CENTER,
        spaceAfter=4
    )
    
    h1_style = ParagraphStyle(
        'SecH1',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=10,
        leading=12,
        alignment=TA_CENTER,
        spaceBefore=7,
        spaceAfter=4,
        keepWithNext=True
    )
    
    h2_style = ParagraphStyle(
        'SecH2',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=9.5,
        leading=11.5,
        alignment=TA_LEFT,
        spaceBefore=5,
        spaceAfter=2,
        keepWithNext=True
    )
    
    body_first = ParagraphStyle(
        'BodyFirst',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=9.5,
        leading=11.5,
        alignment=TA_JUSTIFY,
        firstLineIndent=0,
        spaceAfter=2
    )
    
    body_indent = ParagraphStyle(
        'BodyIndent',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=9.5,
        leading=11.5,
        alignment=TA_JUSTIFY,
        firstLineIndent=14,  # ~0.5 cm
        spaceAfter=2
    )
    
    resumo_title = ParagraphStyle(
        'ResumoTitle',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=9.5,
        leading=11.5,
        alignment=TA_CENTER,
        spaceBefore=2,
        spaceAfter=3,
        keepWithNext=True
    )
    
    abstract_title = ParagraphStyle(
        'AbstractTitle',
        parent=styles['Normal'],
        fontName='Times-BoldItalic',
        fontSize=9.5,
        leading=11.5,
        alignment=TA_CENTER,
        spaceBefore=4,
        spaceAfter=3,
        keepWithNext=True
    )
    
    abstract_body = ParagraphStyle(
        'AbstractBody',
        parent=styles['Normal'],
        fontName='Times-Italic',
        fontSize=9,
        leading=11,
        alignment=TA_JUSTIFY,
        firstLineIndent=0,
        spaceAfter=2
    )
    
    caption_style = ParagraphStyle(
        'Caption',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=8,
        leading=10,
        alignment=TA_CENTER,
        spaceBefore=3,
        spaceAfter=3
    )
    
    table_cell = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=7.2,
        leading=8.8,
        alignment=TA_CENTER
    )
    
    table_cell_bold = ParagraphStyle(
        'TableCellBold',
        parent=styles['Normal'],
        fontName='Times-Bold',
        fontSize=7.2,
        leading=8.8,
        alignment=TA_CENTER
    )
    
    ref_style = ParagraphStyle(
        'RefStyle',
        parent=styles['Normal'],
        fontName='Times-Roman',
        fontSize=7.8,
        leading=9.5,
        alignment=TA_JUSTIFY,
        firstLineIndent=-12,
        leftIndent=12,
        spaceAfter=2.5
    )
    
    eq_style = ParagraphStyle(
        'EqStyle',
        parent=styles['Normal'],
        fontName='Times-Italic',
        fontSize=8.5,
        leading=10.5,
        alignment=TA_CENTER,
        spaceBefore=2,
        spaceAfter=2
    )
    
    story = []
    
    # HEADER FRAME (Page 1)
    story.append(Paragraph("ONDE DYNAMIC WORLD E MAPBIOMAS DISCORDAM SOBRE LAVOURAS? DIAGNÓSTICO ESPACIAL E PROBABILÍSTICO NO MATOPIBA", title_style))
    story.append(Paragraph("Equipe GeoAI MATOPIBA", authors_style))
    story.append(Paragraph("Laboratório de Sensoriamento Remoto e Inteligência Artificial Territorial<br/>Contato: spaceweeknordeste@gmail.com", affil_style))
    story.append(FrameBreak())
    story.append(NextPageTemplate('LaterPages'))
    
    # COLUMN 1 (Page 1): RESUMO & ABSTRACT
    story.append(Paragraph("RESUMO", resumo_title))
    story.append(Paragraph(
        "Mapeamentos de uso e cobertura da terra em escala decamétrica (10 m) são vitais para o monitoramento territorial. "
        "Em fronteiras agrícolas com acentuada sazonalidade como o MATOPIBA, divergências entre produtos de GeoAI permanecem pouco elucidadas. "
        "Este estudo apresenta um diagnóstico simétrico da discordância de lavouras entre Dynamic World e MapBiomas (Coleção 4, 10 m) em 2025. "
        "Com amostragem probabilística estratificada de 20.000 pontos em 52,34 milhões de hectares elegíveis, avaliou-se a associação da "
        "discordância com incerteza probabilística anual, dinâmica temporal e proximidade a bordas temáticas. A discordância censitária "
        "atinge 14,2852% por área e 14,3110% por pixels. Sob <i>Spatial Block Bootstrap</i> (blocos de 30 km, 1.999 réplicas), a discordância "
        "associa-se a maior entropia anual (&Delta;H = +0,0162), maior divergência Jensen-Shannon temporal (&Delta;JSD = +0,0075) e menor "
        "estabilidade modal (&Delta;S = -0,0790). Em bordas (&lt;30 m), a discordância é 3,87 vezes superior à do interior (&ge;250 m). "
        "Na regressão logística, distância à borda (OR = 0,360) e estabilidade temporal (OR = 0,925) associam-se inversamente à discordância. "
        "Apenas 4,28% ponderado das discordâncias atendem a critérios operacionais de baixa ambiguidade, alta estabilidade e afastamento de bordas, "
        "indicando que divergências concentram-se em transições de borda e instabilidade temporal.",
        body_first
    ))
    story.append(Spacer(1, 1*mm))
    story.append(Paragraph("<b>Palavras-chave</b> – <i>Dynamic World</i>, <i>MapBiomas</i>, <i>MATOPIBA</i>, <i>Discordância Espacial</i>, <i>Incerteza Temporal</i>.", body_first))
    
    story.append(Spacer(1, 2*mm))
    story.append(Paragraph("ABSTRACT", abstract_title))
    story.append(Paragraph(
        "High-resolution (10 m) land use and land cover maps are vital for territorial monitoring. In highly seasonal agricultural "
        "frontiers such as MATOPIBA, discrepancies between Earth Observation and GeoAI products remain poorly understood. This study provides "
        "a symmetric analytical diagnosis of cropland disagreement between Dynamic World and MapBiomas (Collection 4, 10 m) for 2025. "
        "Using a design-based stratified random sample of 20,000 points across 52.34 million eligible hectares, we evaluate associations with "
        "annual probabilistic uncertainty, intra-annual dynamics, and thematic edge proximity. Census cropland disagreement reaches 14.2852% by "
        "area and 14.3110% by pixels. Using Spatial Block Bootstrap inference (30 km blocks, 1,999 replicates), disagreement is significantly "
        "associated with higher annual entropy (&Delta;H = +0.0162), higher temporal Jensen-Shannon divergence (&Delta;JSD = +0.0075), and lower "
        "modal stability (&Delta;S = -0.0790). At thematic edges (&lt;30 m), disagreement is 3.87 times higher than in core areas (&ge;250 m). "
        "In logistic regression, edge distance (OR = 0.360) and temporal stability (OR = 0.925) show inverse associations with disagreement. "
        "Only 4.28% of weighted disagreements meet operational criteria of low ambiguity, high stability, and edge avoidance, showing that "
        "discrepancies concentrate along boundary transitions and temporal volatility.",
        abstract_body
    ))
    story.append(Spacer(1, 1*mm))
    story.append(Paragraph("<i>Key words – Dynamic World, MapBiomas, MATOPIBA, Spatial Disagreement, Temporal Uncertainty.</i>", abstract_body))
    
    # 1. INTRODUÇÃO
    story.append(Paragraph("1. INTRODUÇÃO", h1_style))
    story.append(Paragraph(
        "A expansão agropecuária no MATOPIBA (confluência de Maranhão, Tocantins, Piauí e Bahia) consolidou o Cerrado como polo agrícola "
        "estratégico [1, 2]. Essa dinâmica demanda monitoramento sistemático apoiado em produtos de uso e cobertura da terra (LULC) de "
        "alta resolução (10 m), como o MapBiomas (Coleção 4, 10 m) [3, 4] e o Dynamic World (DW) [5]. O MapBiomas estrutura classificações "
        "anuais integrando séries temporais e filtros espaciais [3], enquanto o Dynamic World estima vetores contínuos de probabilidades para "
        "nove classes a cada cena Sentinel-2 [5].",
        body_first
    ))
    story.append(Paragraph(
        "Em ecótonos e fronteiras agrícolas tropicais, discrepâncias entre mapeamentos independentes são frequentes, variando entre 10% e 25% [6, 7]. "
        "Na ausência de extensos dados de referência de campo (<i>ground truth</i>), a validação pontual convencional enfrenta limitações de escala e "
        "custo [8, 9]. Este estudo propõe um diagnóstico analítico simétrico: investigar onde e sob quais condições os produtos divergem, tratando a "
        "discordância como objeto de análise associado a sinais intrínsecos de incerteza da Inteligência Artificial Geoespacial (GeoAI).",
        body_indent
    ))
    story.append(Paragraph(
        "Formulam-se quatro hipóteses operacionais para o ano de 2025:<br/>"
        "• <b><i>H</i><sub>1</sub> (Ambiguidade Anual):</b> pixels discordantes (<i>D</i> = 1) apresentam maior entropia informacional média na distribuição probabilística anual do que concordantes (<i>D</i> = 0);<br/>"
        "• <b><i>H</i><sub>2</sub> (Instabilidade Temporal):</b> a discordância associa-se a maior heterogeneidade intra-anual de probabilidades (<i>H</i><sub>2a</sub>, JSD) e menor persistência categórica modal (<i>H</i><sub>2b</sub>, estabilidade <i>S</i>);<br/>"
        "• <b><i>H</i><sub>3</sub> (Efeito de Borda Temática):</b> a taxa de discordância é maior nas vizinhanças imediatas de bordas temáticas do que no interior de manchas contínuas;<br/>"
        "• <b><i>H</i><sub>4</sub> (Discordâncias sob Restrição Conjunta):</b> ao isolar pixels com baixa ambiguidade, baixa variabilidade temporal, alta estabilidade e afastados de bordas, a discordância restringe-se a fração reduzida.",
        body_indent
    ))
    
    # 2. MATERIAL E MÉTODOS
    story.append(Paragraph("2. MATERIAL E MÉTODOS", h1_style))
    story.append(Paragraph("2.1. Domínio Geográfico e Critério de Elegibilidade", h2_style))
    story.append(Paragraph(
        "O MATOPIBA abrange 337 municípios e cerca de 73 milhões de hectares. Para mitigar o impacto de cobertura persistente de nuvens, o "
        "domínio censitário elegível foi delimitado por células de 10 m que apresentaram no mínimo 8 meses válidos no Dynamic World em 2025 "
        "(<i>n</i><sub>meses</sub> &ge; 8) e classes válidas no MapBiomas (excluindo corpos d'água permanentes e áreas não-vegetadas). A "
        "população censitária elegível resultante totaliza 52.342.114,75 ha (5.354.669.418 pixels de 10 m).",
        body_first
    ))
    
    story.append(Paragraph("2.2. Produtos Cartográficos e Harmonização de Suporte", h2_style))
    story.append(Paragraph(
        "Utilizou-se o <b>MapBiomas Cobertura 10 m — Coleção 4 — 2025</b> [4], baseado em mosaicos Sentinel-2. A classe de lavoura foi definida "
        "pelo <i>crosswalk</i> principal composto pelas classes 19 (Lavoura Temporária) e 36 (Lavoura Perene), distinguindo-se das classes 21 "
        "(Mosaico de Usos) e 18 (Agricultura, nível superior). O produto nativo foi projetado na grade analítica de 10 m em SIRGAS 2000 / "
        "Policonica do Brasil (EPSG:5880).",
        body_first
    ))
    story.append(Paragraph(
        "Para o <b>Dynamic World (v1)</b> [5], o pipeline composicional gerou o raster anual mediante média temporal das observações do mesmo "
        "dia, média diária para mensal e agregação anual pela média dos vetores de 9 probabilidades, extraindo-se a classe pelo <i>argmax</i> do "
        "vetor anual (e não por votação modal). A classe 4 (<i>crops</i>) definiu lavoura no DW. As séries mensais foram harmonizadas espacialmente "
        "para EPSG:5880 via reamostragem bilinear. Devido à não-comutatividade matemática entre a interpolação espacial e a máscara temporal de "
        "nuvens, persiste uma diferença probabilística média residual de 0,004983, implicando alternância de <i>argmax</i> em 8,24% e inversão de "
        "lavoura em 2,59% dos pontos amostrados, concentrada em margens probabilísticas inferiores a 0,05.",
        body_indent
    ))
    
    story.append(Paragraph("2.3. Indicadores de Incerteza e Estabilidade", h2_style))
    story.append(Paragraph(
        "Para cada ponto, extraíram-se quatro indicadores contínuos:<br/>"
        "1. <b>Entropia de Shannon Anual (<i>H</i>):</b> normalizada por ln(9) [14]:",
        body_first
    ))
    story.append(Paragraph("<i>H</i> = &minus; [1 / ln(9)] &sum;<sub>k=1..9</sub> <i>p</i><sub>k</sub> ln(<i>p</i><sub>k</sub> + &epsilon;)", eq_style))
    story.append(Paragraph(
        "2. <b>Divergência Jensen-Shannon Temporal (JSD):</b> contraste normalizado por ln(9) entre a entropia da média mensal e a média das entropias dos <i>M</i> meses válidos [15]:",
        body_first
    ))
    story.append(Paragraph("JSD = [1 / ln(9)] [ <i>H</i>(<i>p&#772;</i>) &minus; (1/<i>M</i>) &sum;<sub>m=1..M</sub> <i>H</i>(<i>p</i><sup>(m)</sup>) ]", eq_style))
    story.append(Paragraph(
        "3. <b>Estabilidade Categórica Modal (<i>S</i>):</b> proporção dos meses válidos em que a classe dominante (<i>argmax</i>) coincidiu com a classe anual:<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;<i>S</i> = (1/<i>M</i>) &sum;<sub>m=1..M</sub> &Iopf;(<i>c</i><sup>(m)</sup> = <i>c</i><sub>anual</sub>)<br/>"
        "4. <b>Distância Mínima à Borda Temática (<i>d</i><sub>min</sub>):</b> distância euclidiana métrica calculada em raster até a borda temática "
        "mais próxima de Dynamic World ou MapBiomas (min(<i>d</i><sub>dw</sub>, <i>d</i><sub>mb</sub>)), truncada em 250 m. O suporte analítico "
        "refere-se a pixels de 10 m e manchas temáticas, sem pressupor delimitação cadastral de parcelas ou talhões agrícolas.",
        body_first
    ))
    
    story.append(Paragraph("2.4. Desenho Amostral e Inferência Espacial", h2_style))
    story.append(Paragraph(
        "Adotou-se amostragem probabilística estratificada em 16 estratos científicos (4 estados &times; 4 regimes temáticos: AA: Acordo Lavoura; "
        "AN: MapBiomas Lavoura e DW Não-Lavoura; NA: DW Lavoura e MapBiomas Não-Lavoura; NN: Acordo Não-Lavoura) e 410 subestratos operacionais. "
        "A amostra principal contemplou <i>n</i> = 20.000 pontos, expandida para 40.000 em robustez. As estimativas incorporam pesos de "
        "Horvitz-Thompson (<i>w</i><sub>i</sub> = <i>N</i><sub>h</sub> / <i>n</i><sub>h</sub>) [9].",
        body_first
    ))
    story.append(Paragraph(
        "Para controlar a autocorrelação espacial [10, 11], ajustou-se semivariograma empírico exponencial sobre o resíduo da discordância, "
        "identificando alcance prático de 25,62 km. Conforme protocolo e diretrizes de particionamento [12, 13], implementou-se <i>Spatial Block "
        "Bootstrap</i> com blocos primários regulares de 30 km e 1.999 réplicas com reposição. Ajustou-se modelo logístico multivariado "
        "ponderado com <i>odds ratios</i> (OR) escalonados e intervalos empíricos a 95%.",
        body_indent
    ))
    
    # 3. RESULTADOS
    story.append(Paragraph("3. RESULTADOS", h1_style))
    story.append(Paragraph("3.1. Discordância Censitária e Distribuição Geográfica", h2_style))
    story.append(Paragraph(
        "No censo <i>wall-to-wall</i> dos 52,34 Mha elegíveis, a discordância temática entre os produtos atinge <b>14,2852% por área</b> "
        "(7.477.177,23 ha) e <b>14,3110% por pixels</b> (766.304.630 pixels). A estimativa ponderada na amostra de 20.000 pontos reproduz com "
        "alta precisão o censo: 14,2897% por área (7.479.568,87 ha) e 14,3148% por pixels (766.512.449 pixels). A discordância decorre "
        "majoritariamente de alocação espacial (9,30 pp) frente à divergência de quantidade (4,99 pp) [7].",
        body_first
    ))
    story.append(Paragraph(
        "A Tabela 1 detalha os regimes censitários e por estado. A discordância varia amplamente: Bahia (27,95%) e Piauí (21,80%) apresentam "
        "as maiores taxas, contrastando com Maranhão (10,98%) e Tocantins (5,90%).",
        body_indent
    ))
    
    # TABLE 1
    t1_data = [
        [Paragraph("<b>Regime / UF</b>", table_cell_bold),
         Paragraph("<b>Censo (ha)</b>", table_cell_bold),
         Paragraph("<b>Censo (%)</b>", table_cell_bold),
         Paragraph("<b>Amostra (%)</b>", table_cell_bold),
         Paragraph("<b>IC 95% Espacial</b>", table_cell_bold)],
        [Paragraph("AA (Acordo Lav.)", table_cell), Paragraph("1.274.056", table_cell), Paragraph("2,43%", table_cell), Paragraph("2,43%", table_cell), Paragraph("[2,01%; 2,98%]", table_cell)],
        [Paragraph("AN (MB Sim, DW Não)", table_cell), Paragraph("5.044.314", table_cell), Paragraph("9,64%", table_cell), Paragraph("9,65%", table_cell), Paragraph("[8,95%; 10,48%]", table_cell)],
        [Paragraph("NA (DW Sim, MB Não)", table_cell), Paragraph("2.432.863", table_cell), Paragraph("4,65%", table_cell), Paragraph("4,64%", table_cell), Paragraph("[4,12%; 5,26%]", table_cell)],
        [Paragraph("NN (Acordo Não-Lav.)", table_cell), Paragraph("43.590.881", table_cell), Paragraph("83,28%", table_cell), Paragraph("83,28%", table_cell), Paragraph("[82,05%; 84,38%]", table_cell)],
        [Paragraph("<b>Total Disc. (AN+NA)</b>", table_cell_bold), Paragraph("<b>7.477.177</b>", table_cell_bold), Paragraph("<b>14,29%</b>", table_cell_bold), Paragraph("<b>14,29%</b>", table_cell_bold), Paragraph("<b>[13,42%; 15,28%]</b>", table_cell_bold)],
        [Paragraph("Maranhão (MA)", table_cell), Paragraph("1.093.013", table_cell), Paragraph("10,98%", table_cell), Paragraph("10,96%", table_cell), Paragraph("[9,25%; 13,01%]", table_cell)],
        [Paragraph("Tocantins (TO)", table_cell), Paragraph("1.338.415", table_cell), Paragraph("5,90%", table_cell), Paragraph("5,90%", table_cell), Paragraph("[4,88%; 7,12%]", table_cell)],
        [Paragraph("Piauí (PI)", table_cell), Paragraph("1.639.895", table_cell), Paragraph("21,80%", table_cell), Paragraph("21,82%", table_cell), Paragraph("[18,44%; 25,62%]", table_cell)],
        [Paragraph("Bahia (BA)", table_cell), Paragraph("3.405.855", table_cell), Paragraph("27,95%", table_cell), Paragraph("27,98%", table_cell), Paragraph("[24,80%; 31,45%]", table_cell)],
    ]
    t1 = Table(t1_data, colWidths=[24*mm, 17*mm, 14*mm, 14*mm, 17*mm])
    t1.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F2F2F2')),
        ('LINEBELOW', (0, 0), (-1, 0), 0.8, colors.black),
        ('LINEBELOW', (0, -1), (-1, -1), 0.8, colors.black),
        ('LINEABOVE', (0, 0), (-1, 0), 0.8, colors.black),
        ('LINEBELOW', (0, 5), (-1, 5), 0.5, colors.grey),
        ('TOPPADDING', (0, 0), (-1, -1), 1.1),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 1.1),
    ]))
    
    t1_cap = Paragraph("<b>Tabela 1.</b> Parâmetros censitários e amostrais de discordância no MATOPIBA.", caption_style)
    story.append(KeepTogether([t1_cap, t1, Spacer(1, 2*mm)]))
    
    # FIGURE 1
    fig1_path = 'figures/fig1_composition_regimes.png'
    if os.path.exists(fig1_path):
        f1_img = Image(fig1_path, width=84*mm, height=35*mm)
        f1_cap = Paragraph("<b>Figura 1.</b> Composição dos regimes e gradiente de discordância por estado.", caption_style)
        story.append(KeepTogether([f1_img, f1_cap, Spacer(1, 2*mm)]))
    
    story.append(Paragraph("3.2. Testes de Hipótese H1 a H4", h2_style))
    story.append(Paragraph(
        "A Tabela 2 sintetiza os contrastes das hipóteses e a regressão logística multivariada sob inferência de 30 km:<br/>"
        "• <b><i>H</i><sub>1</sub> (Ambiguidade Anual):</b> A entropia anual é maior nos discordantes (&Delta;<i>H</i> = +0,0162, IC 95%: [+0,0103; +0,0221], Cohen's <i>d</i> = +0,318);<br/>"
        "• <b><i>H</i><sub>2a</sub> e <i>H</i><sub>2b</sub> (Dinâmica Temporal):</b> A discordância associa-se a maior divergência temporal (&Delta;JSD = +0,007492, IC: [+0,0047; +0,0102]) e menor estabilidade (&Delta;<i>S</i> = &minus;0,078959, IC: [&minus;0,0974; &minus;0,0599]);<br/>"
        "• <b><i>H</i><sub>3</sub> (Efeito de Borda):</b> A discordância atinge 45,91% na borda (&lt;30 m) e cai para 11,87% no interior (&ge;250 m), razão de 3,87&times; (com quebra local de monotonicidade na faixa 30–60 m, 45,77%);<br/>"
        "• <b><i>H</i><sub>4</sub> (Critérios Conjuntos):</b> Sob restrições conjuntas estritas (<i>H</i> &le; <i>Q</i><sub>1</sub>, JSD &le; <i>Q</i><sub>1</sub>, <i>S</i> &ge; <i>Q</i><sub>3</sub> e <i>d</i> &ge; 30 m), apenas 207 pontos na amostra de 20k atendem aos requisitos (4,2773% ponderado em <i>D</i> = 1), confirmados em 404 pontos na amostra de 40k (4,1687%).",
        body_first
    ))
    
    # TABLE 2
    t2_data = [
        [Paragraph("<b>Indicador / Termo</b>", table_cell_bold),
         Paragraph("<b>Escala</b>", table_cell_bold),
         Paragraph("<b>Contraste / OR</b>", table_cell_bold),
         Paragraph("<b>IC 95% Espacial (30 km)</b>", table_cell_bold)],
        [Paragraph("<i>H</i><sub>1</sub>: Entropia Anual (<i>H</i>)", table_cell), Paragraph("Média", table_cell), Paragraph("&Delta; = +0,0162", table_cell), Paragraph("[+0,0103; +0,0221]", table_cell)],
        [Paragraph("<i>H</i><sub>2a</sub>: Divergência Temp. (JSD)", table_cell), Paragraph("Média", table_cell), Paragraph("&Delta; = +0,0075", table_cell), Paragraph("[+0,0047; +0,0102]", table_cell)],
        [Paragraph("<i>H</i><sub>2b</sub>: Estabilidade Modal (<i>S</i>)", table_cell), Paragraph("Média", table_cell), Paragraph("&Delta; = &minus;0,0790", table_cell), Paragraph("[&minus;0,0974; &minus;0,0599]", table_cell)],
        [Paragraph("<i>H</i><sub>3</sub>: Borda (&lt;30m) vs Interior", table_cell), Paragraph("Razão", table_cell), Paragraph("3,87&times;", table_cell), Paragraph("[3,25&times;; 4,61&times;]", table_cell)],
        [Paragraph("Regressão: Distância Borda", table_cell), Paragraph("+100 m", table_cell), Paragraph("OR = 0,360", table_cell), Paragraph("[0,319; 0,404]", table_cell)],
        [Paragraph("Regressão: Entropia Anual", table_cell), Paragraph("+0,10", table_cell), Paragraph("OR = 1,421", table_cell), Paragraph("[1,036; 1,988]", table_cell)],
        [Paragraph("Regressão: Estabilidade Modal", table_cell), Paragraph("+0,10", table_cell), Paragraph("OR = 0,925", table_cell), Paragraph("[0,861; 0,992]", table_cell)],
        [Paragraph("Regressão: JSD Temporal", table_cell), Paragraph("+0,01", table_cell), Paragraph("OR = 0,987", table_cell), Paragraph("[0,914; 1,059] (n.s.)", table_cell)],
        [Paragraph("Regressão: Piauí vs Bahia (ref.)", table_cell), Paragraph("UF", table_cell), Paragraph("OR = 0,798", table_cell), Paragraph("[0,507; 1,212] (n.s.)", table_cell)],
    ]
    t2 = Table(t2_data, colWidths=[31*mm, 13*mm, 18*mm, 24*mm])
    t2.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#F2F2F2')),
        ('LINEBELOW', (0, 0), (-1, 0), 0.8, colors.black),
        ('LINEBELOW', (0, -1), (-1, -1), 0.8, colors.black),
        ('LINEABOVE', (0, 0), (-1, 0), 0.8, colors.black),
        ('LINEBELOW', (0, 4), (-1, 4), 0.5, colors.grey),
        ('TOPPADDING', (0, 0), (-1, -1), 1.0),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 1.0),
    ]))
    
    t2_cap = Paragraph("<b>Tabela 2.</b> Estimativas inferenciais e modelo logístico multivariado sob Spatial Block Bootstrap.", caption_style)
    story.append(KeepTogether([t2_cap, t2, Spacer(1, 2*mm)]))
    
    # FIGURE 2
    fig2_path = 'figures/fig5_disagreement_by_distance_bin.png'
    if os.path.exists(fig2_path):
        f2_img = Image(fig2_path, width=84*mm, height=52*mm)
        f2_cap = Paragraph("<b>Figura 2.</b> Taxa de discordância temática por faixas de distância à borda (IC 95% Spatial Block Bootstrap).", caption_style)
        story.append(KeepTogether([f2_img, f2_cap, Spacer(1, 1.5*mm)]))
    
    story.append(Paragraph("3.3. Associações Marginais versus Condicionais", h2_style))
    story.append(Paragraph(
        "A análise comparativa entre estimativas marginais e o modelo multivariado destaca dois achados metodológicos centrais:<br/>"
        "1. <b>Dissociação Condicional da JSD:</b> Enquanto a JSD temporal exibe forte associação positiva marginal em <i>H</i><sub>2a</sub>, "
        "seu efeito condicional na regressão perde significância (OR = 0,987, IC: [0,914; 1,059]). O controle conjunto da estabilidade modal "
        "<i>S</i> e da distância às bordas absorve o sinal da variabilidade temporal contínua.<br/>"
        "2. <b>Papel Corretivo do Bootstrap Espacial:</b> O teste clássico assintótico indica erroneamente significância no contraste Piauí vs "
        "Bahia (<i>p</i> &lt; 0,001, IC: [0,709; 0,900]). O <i>Spatial Block Bootstrap</i> de 30 km corrige a inflação amostral e expande o IC para "
        "[0,507; 1,212], cobrindo 1,0 e evidenciando que os estados não diferem condicionalmente.",
        body_first
    ))
    
    # 4. DISCUSSÃO
    story.append(Paragraph("4. DISCUSSÃO", h1_style))
    story.append(Paragraph("4.1. Incerteza Estruturada e Epistemologia Simétrica", h2_style))
    story.append(Paragraph(
        "A abordagem simétrica trata a discordância como sinalizador objetivo de incerteza, e não como falha unilateral. As discrepâncias respondem "
        "a mecanismos biofísicos e computacionais bem definidos:<br/>"
        "• <b>Transições de Borda:</b> A concentração de discordâncias nos primeiros 30 m (45,91%) decorre da mistura espectral de subpixel ao longo de "
        "estradas internas, curvas de nível e transições com vegetação nativa. No raster de 10 m, células que interceptam bordas flutuam entre "
        "classificadores devido a funções de custo e limiares distintos.<br/>"
        "• <b>Dinâmica Fenológica e Temporal:</b> No Cerrado, o regime de sequeiro impõe transições entre cultura ativa, dessecação, solo exposto e "
        "palhada que se aproximam da resposta de savanas abertas [1, 2]. O Dynamic World captura estados instantâneos cena a cena, enquanto o "
        "MapBiomas estrutura séries e métricas anuais consolidadas [3, 5], gerando divergências nas transições de ciclo.",
        body_first
    ))
    
    story.append(Paragraph("4.2. Interpretação Operacional de H4", h2_style))
    story.append(Paragraph(
        "A constatação de que apenas 4,28% ponderado das discordâncias atendem aos filtros de <i>H</i><sub>4</sub> não significa 'detecção de erros "
        "reais'. Esse subconjunto delimita pixels com classificação assertiva (baixa entropia), temporalmente persistente e situados no interior de "
        "manchas contínuas. Nesses pontos, a divergência representa desacordo conceitual substantivo entre arquiteturas de aprendizado profundo e "
        "regras temporais, constituindo o alvo prioritário para auditorias de campo independentes.",
        body_first
    ))
    
    story.append(Paragraph("4.3. Limitações Metodológicas", h2_style))
    story.append(Paragraph(
        "O estudo apresenta limites definidos: (1) a restrição a <i>n</i><sub>meses</sub> &ge; 8 excluiu 21,74% do território, concentrado no norte "
        "chuvoso do Maranhão; (2) a não-comutatividade temporal/espacial impõe resíduo médio de 0,004983, afetando quase-empates; (3) por ser "
        "estudo observacional sem verdade de campo, as relações constituem associações estatísticas espaciais, sem inferência causal.",
        body_first
    ))
    
    # 5. CONCLUSÕES
    story.append(Paragraph("5. CONCLUSÕES", h1_style))
    story.append(Paragraph(
        "O diagnóstico espacial e probabilístico no MATOPIBA revela que a discordância censitária de lavouras em 2025 entre Dynamic World e "
        "MapBiomas (14,2852% por área e 14,3110% por pixels) concentra-se em zonas de transição temática e períodos de instabilidade temporal. "
        "Apenas 4,28% ponderado das discordâncias manifestam-se no interior contínuo com alta estabilidade e baixa ambiguidade. Sob <i>Spatial "
        "Block Bootstrap</i>, contrastes macrorregionais assintóticos perdem significância estatística. Para a comunidade GeoAI, esses resultados "
        "indicam que discrepâncias entre produtos decamétricos devem ser tratadas como indicadores quantitativos de incerteza fenológica e de "
        "borda, e não como erros arbitrários.",
        body_first
    ))
    
    # 6. REFERÊNCIAS
    story.append(Paragraph("6. REFERÊNCIAS", h1_style))
    refs = [
        "[1] S. A. Spera, G. L. Galford, M. T. Coe, M. N. Macedo, and J. F. Mustard. Land-use change affects water recycling in Brazil’s last agricultural frontier, <i>Global Change Biology</i>, v. 22(10):pp. 3405–3413, 2016.",
        "[2] R. F. B. da Silva, M. Batistella, E. F. Moran, and L. A. Martinelli. Soy expansion and socioeconomic development in municipalities of Brazil, <i>Land</i>, v. 6(3):art. 62, 2017.",
        "[3] C. M. Souza et al. Reconstructing Three Decades of Land Use and Land Cover Changes in Brazilian Biomes with Landsat Archive and Earth Engine, <i>Remote Sensing</i>, v. 12(17):art. 2735, 2020.",
        "[4] MapBiomas. Coleção 4 da Cobertura e Uso da Terra a 10 metros (2017–2025), Rede MapBiomas, São Paulo, 2025. URL: brasil.mapbiomas.org",
        "[5] C. F. Brown et al. Dynamic World, Near real-time global 10 m land use land cover mapping, <i>Scientific Data</i>, v. 9(1):art. 251, 2022.",
        "[6] S. Fritz et al. Highlighting continued uncertainty in global land cover maps for the user community, <i>Environmental Research Letters</i>, v. 6(4):art. 044005, 2011.",
        "[7] R. G. Pontius and M. Millones. Death to Kappa: birth of quantity disagreement and allocation disagreement for accuracy assessment, <i>International Journal of Remote Sensing</i>, v. 32(15):pp. 4407–4429, 2011.",
        "[8] G. M. Foody. Status of land cover classification accuracy assessment, <i>Remote Sensing of Environment</i>, v. 80(1):pp. 185–201, 2002.",
        "[9] P. Olofsson et al. Good practices for estimating area and assessing accuracy of land change, <i>Remote Sensing of Environment</i>, v. 148:pp. 42–57, 2014.",
        "[10] P. Legendre. Spatial autocorrelation: trouble or new paradigm?, <i>Ecology</i>, v. 74(6):pp. 1659–1673, 1993.",
        "[11] G. Carl and I. Kühn. Analyzing spatial autocorrelation in species distributions using Gaussian and alternative methods, <i>Ecological Modelling</i>, v. 207(2–4):pp. 159–170, 2007.",
        "[12] H. R. Künsch. The jackknife and the bootstrap for general stationary observations, <i>The Annals of Statistics</i>, v. 17(3):pp. 1217–1241, 1989.",
        "[13] D. R. Roberts et al. Cross-validation strategies for data with temporal, spatial, or phylogenetic structure, <i>Ecography</i>, v. 40(8):pp. 913–929, 2017.",
        "[14] C. E. Shannon. A mathematical theory of communication, <i>The Bell System Technical Journal</i>, v. 27(3):pp. 379–423, 1948.",
        "[15] J. Lin. Divergence measures based on the Shannon entropy, <i>IEEE Transactions on Information Theory</i>, v. 37(1):pp. 145–151, 1991."
    ]
    for r in refs:
        story.append(Paragraph(r, ref_style))
        
    doc.build(story)
    
    # Check page count
    reader = pypdf.PdfReader(output_pdf_path)
    num_pages = len(reader.pages)
    print(f"PDF Generated: {output_pdf_path}")
    print(f"Total Page Count: {num_pages}")
    return num_pages

if __name__ == '__main__':
    out_pdf = 'paper/manuscript_space_week_nordeste_2026_v2.pdf'
    pages = create_pdf(out_pdf)
    if pages > 5:
        print(f"WARNING: Exceeded 5 pages ({pages} pages). Adjustments needed!")
    elif pages == 5:
        print(f"PERFECT: Exactly 5 pages!")
    else:
        print(f"ACCEPTABLE: Under 5 pages ({pages} pages).")
