import pandas as pd
import numpy as np

df_w2w = pd.read_csv('data/processed/wall_to_wall_summary.csv')

# Columns in wall_to_wall_summary.csv:
# region, total_area_ha, raster_covered_area_ha, eligible_area_ha, excluded_mb_area_ha, insufficient_dw_temporal_area_ha, ...

rows = []
for idx, r in df_w2w.iterrows():
    reg = r['region']
    total_ha = r['total_area_ha']
    elig_ha = r['eligible_area_ha']
    excl_mb_ha = r['excluded_mb_area_ha']
    inelig_dw_ha = r['insufficient_dw_temporal_area_ha']
    
    # Check closure:
    sum_components = elig_ha + excl_mb_ha + inelig_dw_ha
    diff_ha = sum_components - total_ha
    
    pct_elig = elig_ha / total_ha * 100
    pct_excl_mb = excl_mb_ha / total_ha * 100
    pct_inelig_dw = inelig_dw_ha / total_ha * 100
    
    rows.append({
        'Estado/Região': reg,
        'Área Total Operacional (ha)': total_ha,
        'Área Elegível (ha)': elig_ha,
        'Área Inelegível DW (<8m) (ha)': inelig_dw_ha,
        'Área Excluída MB (18/21) (ha)': excl_mb_ha,
        '% Elegível': pct_elig,
        '% Inelegível DW (<8m)': pct_inelig_dw,
        '% Excluída MB (Temática)': pct_excl_mb,
        'Soma Componentes (ha)': sum_components,
        'Diferença Fechamento (ha)': diff_ha
    })

df_closure = pd.DataFrame(rows)
print("=== ETAPA 6: TABELA DE REPRESENTATIVIDADE E FECHAMENTO TERRITORIAL ===")
print(df_closure.to_string(index=False))

# Also check monthly valid coverage distribution across MATOPIBA from tables/dw_valid_months_area.csv
df_vm = pd.read_csv('tables/dw_valid_months_area.csv')
print("\n=== DISTRIBUIÇÃO DE ÁREA POR NÚMERO DE MESES VÁLIDOS (MATOPIBA) ===")
print(df_vm.to_string(index=False))
