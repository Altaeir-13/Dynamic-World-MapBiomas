import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import ee
import json
import numpy as np

PROJECT_ID = "dynamicworld-x-mapbiomas"
ee.Initialize(project=PROJECT_ID)

from src.gee.dw_annual import (
    DW_PROB_BANDS,
    DW_START,
    DW_END,
    DW_COLLECTION,
    get_mapbiomas_projection,
    get_source_support_domain,
    DATES_CACHE_PATH
)

mb_proj = get_mapbiomas_projection()
source_domain = get_source_support_domain()
DW_CLASSES = DW_PROB_BANDS

fc = ee.FeatureCollection([ee.Feature(ee.Geometry.Point([-44.50545869995448, -6.884643421727807]), {'sample_id': 'PT_010352'})])

with open(DATES_CACHE_PATH, "r", encoding="utf-8") as f:
    dates_dict = json.load(f)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterDate(DW_START, DW_END)
    .filterBounds(source_domain)
)

m_comps_raw = []
for m in range(1, 13):
    start = f"2025-{m:02d}-01"
    end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
    dw_m = dw_col.filterDate(start, end)
    dates_m = ee.List(dates_dict[f"{m:02d}"])

    def make_daily(d):
        d_start = ee.Date(d)
        d_end = d_start.advance(1, "day")
        return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().toFloat().set("date", d)

    daily_col = ee.ImageCollection(dates_m.map(make_daily))
    comp_m = daily_col.mean().select(DW_PROB_BANDS).toFloat()
    m_comps_raw.append(comp_m)

annual_raw = ee.ImageCollection(m_comps_raw).mean()
s_ann_raw = annual_raw.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

# Load the local extracted monthly values from slice JSON
with open('data/processed/extraction_slices/MA_x06_y04.json', 'r', encoding='utf-8') as f:
    slice_data = json.load(f)
pt = next(p for p in slice_data if p.get('sample_id') == 'PT_010352')

valid_months = [m for m in range(1, 13) if int(pt.get(f'n_days_m{m:02d}', 0)) > 0 and float(pt.get(f'prob_sum_m{m:02d}', 0)) > 0]
raw_monthly = []
for m in valid_months:
    raw_monthly.append([float(pt.get(f'{c}_m{m:02d}', 0.0)) for c in DW_CLASSES])
raw_mean = np.mean(raw_monthly, axis=0)

print(f"{'Classe':20s} | {'annual_dw_raw (GEE)':20s} | {'raw_mean (JSON)':20s} | {'Diferença':15s}")
print("-" * 80)
for i, c in enumerate(DW_CLASSES):
    v_gee = float(s_ann_raw.get(c, 0.0))
    v_loc = float(raw_mean[i])
    print(f"{c:20s} | {v_gee:20.6f} | {v_loc:20.6f} | {abs(v_gee - v_loc):15.8f}")
