import pandas as pd
import numpy as np

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

main = df_ann[df_ann['main_sample'] == 1].copy()

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

# Calculate mean of normalized monthly vectors for each point
valid_mon = df_mon[df_mon['month_valid'] == 1].copy()

# Group by sample_id and compute mean across valid months
mon_mean = valid_mon.groupby('sample_id')[DW_CLASSES].mean().reset_index()

merged = pd.merge(main, mon_mean, on='sample_id', suffixes=('_ann', '_mon'))

# Compare auth_p vs mon_mean for crops, trees, etc.
diffs = {}
for c in DW_CLASSES:
    p_ann = merged['p_' + c]
    p_mon = merged[c]
    diff = np.abs(p_ann - p_mon)
    diffs[c] = {
        'mean_abs_diff': diff.mean(),
        'max_abs_diff': diff.max(),
        'p95_abs_diff': diff.quantile(0.95),
        'corr': np.corrcoef(p_ann, p_mon)[0, 1]
    }

df_diffs = pd.DataFrame(diffs).T
print("Diferença entre Vetor Anual Autoritativo e Média Mensal:")
print(df_diffs)

# Compare annual class from auth_p vs annual class from mon_mean
auth_class = merged['annual_class']
mon_argmax_idx = np.argmax(merged[[c for c in DW_CLASSES]].values, axis=1)
mon_annual_class = [DW_CLASSES[i] for i in mon_argmax_idx]

class_match = (auth_class == mon_annual_class)
print(f"\nConcordância da classe anual: {class_match.sum()} / {len(class_match)} ({class_match.mean()*100:.2f}%)")

# Check by regime
reg_match = merged.groupby('regime').apply(lambda g: (g['annual_class'] == [DW_CLASSES[i] for i in np.argmax(g[DW_CLASSES].values, axis=1)]).mean() * 100)
print("\nConcordância da classe anual por regime:")
print(reg_match)
