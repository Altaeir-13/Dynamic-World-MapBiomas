import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT

styles = getSampleStyleSheet()

h1_style = ParagraphStyle('SecH1', parent=styles['Normal'], fontName='Times-Bold', fontSize=9.5, leading=11.5, alignment=TA_CENTER, spaceBefore=4, spaceAfter=2, keepWithNext=True)
h2_style = ParagraphStyle('SecH2', parent=styles['Normal'], fontName='Times-Bold', fontSize=9, leading=11, alignment=TA_LEFT, spaceBefore=3, spaceAfter=1.5, keepWithNext=True)
body_first = ParagraphStyle('BodyFirst', parent=styles['Normal'], fontName='Times-Roman', fontSize=9, leading=11, alignment=TA_JUSTIFY, firstLineIndent=0, spaceAfter=2)
body_indent = ParagraphStyle('BodyIndent', parent=styles['Normal'], fontName='Times-Roman', fontSize=9, leading=11, alignment=TA_JUSTIFY, firstLineIndent=12, spaceAfter=2)
ref_style = ParagraphStyle('RefStyle', parent=styles['Normal'], fontName='Times-Roman', fontSize=7.5, leading=9, alignment=TA_JUSTIFY, firstLineIndent=-8, leftIndent=8, spaceAfter=1.5)
eq_style = ParagraphStyle('EqStyle', parent=styles['Normal'], fontName='Times-Italic', fontSize=8, leading=10, alignment=TA_CENTER, spaceBefore=1, spaceAfter=1)
caption_style = ParagraphStyle('Caption', parent=styles['Normal'], fontName='Times-Bold', fontSize=8, leading=9.5, alignment=TA_CENTER, spaceBefore=2, spaceAfter=2)

col_w = 86 * mm

def get_h(flowables, avail_w):
    total = 0
    for f in flowables:
        w, h = f.wrap(avail_w, 1000*mm)
        total += h
    return total / mm

# 1. Introdução
intro_f = [
    Paragraph("1. INTRODUÇÃO", h1_style),
    Paragraph(
        "A expansão agropecuária no MATOPIBA (confluência de Maranhão, Tocantins, Piauí e Bahia) consolidou o Cerrado como polo agrícola "
        "estratégico [1, 2]. Essa dinâmica demanda monitoramento sistemático apoiado em produtos de uso e cobertura da terra (LULC) de "
        "alta resolução (10 m), como o MapBiomas (Coleção 4, 10 m) [3, 4] e o Dynamic World (DW) [5]. O MapBiomas estrutura classificações "
        "anuais integrando séries temporais e filtros espaciais [3], enquanto o Dynamic World estima vetores contínuos de probabilidades para "
        "nove classes a cada cena Sentinel-2 [5].",
        body_first
    ),
    Paragraph(
        "Em ecótonos e fronteiras agrícolas tropicais, discrepâncias entre mapeamentos independentes são frequentes, variando entre 10% e 25% [6, 7]. "
        "Na ausência de extensos dados de referência de campo (<i>ground truth</i>), a validação pontual convencional enfrenta limitações de escala e "
        "custo [8, 9]. Este estudo propõe um diagnóstico analítico simétrico: investigar onde e sob quais condições os produtos divergem, tratando a "
        "discordância como objeto de análise associado a sinais intrínsecos de incerteza da Inteligência Artificial Geoespacial (GeoAI).",
        body_indent
    ),
    Paragraph(
        "Formulam-se quatro hipóteses operacionais para o ano de 2025:<br/>"
        "• <b><i>H</i><sub>1</sub> (Ambiguidade Anual):</b> pixels com discordância temática (<i>D</i> = 1) apresentam maior entropia informacional média na distribuição probabilística anual do que concordantes (<i>D</i> = 0);<br/>"
        "• <b><i>H</i><sub>2</sub> (Instabilidade Temporal):</b> a discordância associa-se a maior heterogeneidade intra-anual de probabilidades (<i>H</i><sub>2a</sub>, divergência Jensen-Shannon temporal) e a menor persistência categórica modal (<i>H</i><sub>2b</sub>, estabilidade temporal <i>S</i>);<br/>"
        "• <b><i>H</i><sub>3</sub> (Efeito de Borda Temática):</b> a proporção de discordância é maior nas vizinhanças imediatas de bordas temáticas de transição do que no interior de manchas contínuas;<br/>"
        "• <b><i>H</i><sub>4</sub> (Discordâncias sob Restrições Conjuntas):</b> sob critérios operacionais estritos de baixa ambiguidade, baixa variabilidade temporal, alta estabilidade e afastamento de bordas, a ocorrência de discordâncias restringe-se a uma fração reduzida da população discordante.",
        body_indent
    )
]
print(f"1. Introdução height: {get_h(intro_f, col_w):.1f} mm")

# 2. Material e Métodos
metodos_f = [
    Paragraph("2. MATERIAL E MÉTODOS", h1_style),
    Paragraph("2.1. Domínio Geográfico e Critério de Elegibilidade", h2_style),
    Paragraph(
        "O MATOPIBA abrange 337 municípios e cerca de 73 milhões de hectares. Para mitigar o impacto de cobertura persistente de nuvens, o "
        "domínio censitário elegível foi delimitado por células de 10 m que apresentaram no mínimo 8 meses válidos no Dynamic World em 2025 "
        "(<i>n</i><sub>meses</sub> &ge; 8) e classes temáticas válidas no MapBiomas (excluindo corpos d'água permanentes e áreas não-vegetadas). A "
        "população censitária elegível resultante totaliza 52.342.114,75 ha (5.354.669.418 pixels de 10 m).",
        body_first
    ),
    Paragraph("2.2. Produtos Cartográficos e Harmonização de Suporte", h2_style),
    Paragraph(
        "Utilizou-se o <b>MapBiomas Cobertura 10 m — Coleção 4 — 2025</b> [4], baseado em mosaicos Sentinel-2. A classe de lavoura foi definida "
        "pelo <i>crosswalk</i> principal composto pelas classes 19 (Lavoura Temporária) e 36 (Lavoura Perene), distinguindo-se das classes 21 "
        "(Mosaico de Usos) e 18 (Agricultura, nível superior). O produto nativo foi projetado na grade analítica de 10 m em SIRGAS 2000 / "
        "Policonica do Brasil (EPSG:5880).",
        body_first
    ),
    Paragraph(
        "Para o <b>Dynamic World (v1)</b> [5], o pipeline composicional gerou o raster anual mediante média temporal das observações do mesmo "
        "dia, média diária para mensal e agregação anual pela média dos vetores de 9 probabilidades, extraindo-se a classe pelo <i>argmax</i> do "
        "vetor anual (e não por votação modal). A classe 4 (<i>crops</i>) definiu lavoura no DW. As séries mensais foram harmonizadas espacialmente "
        "para EPSG:5880 via reamostragem bilinear. Devido à não-comutatividade matemática entre a interpolação espacial e a máscara temporal de "
        "nuvens, persiste uma diferença probabilística média residual de 0,004983, implicando alternância de <i>argmax</i> em 8,24% e inversão de "
        "lavoura em 2,59% dos pontos amostrados, concentrada em margens probabilísticas inferiores a 0,05.",
        body_indent
    ),
    Paragraph("2.3. Indicadores de Incerteza e Estabilidade", h2_style),
    Paragraph(
        "Para cada ponto amostral, computaram-se quatro métricas contínuas:<br/>"
        "1. <b>Entropia de Shannon Anual Normalizada (<i>H</i><sub>N</sub>):</b> normalizada por ln(9) [14]:",
        body_first
    ),
    Paragraph("<i>H</i><sub>N</sub>(<i>p</i>) = &minus; [1 / ln(9)] &sum;<sub>k=1..9</sub> <i>p</i><sub>k</sub> ln(<i>p</i><sub>k</sub> + &epsilon;)", eq_style),
    Paragraph(
        "2. <b>Divergência Jensen-Shannon Temporal Normalizada (JSD<sub>N</sub>):</b> contraste direto entre a entropia normalizada da probabilidade média temporal e a média das entropias normalizadas dos <i>M</i> meses válidos [15]:",
        body_first
    ),
    Paragraph("JSD<sub>N</sub> = <i>H</i><sub>N</sub>(<i>p&#772;</i>) &minus; (1/<i>M</i>) &sum;<sub>m=1..M</sub> <i>H</i><sub>N</sub>(<i>p</i><sup>(m)</sup>)", eq_style),
    Paragraph(
        "onde <i>p&#772;</i> = (1/<i>M</i>)&sum; <i>p</i><sup>(m)</sup> é o vetor médio mensal. Como as entropias já se encontram normalizadas por ln(9), a expressão dispensa divisão subsequente;<br/>"
        "3. <b>Estabilidade Categórica Modal (<i>S</i>):</b> proporção dos meses válidos em que a classe dominante (<i>argmax</i>) coincidiu com a classe anual do Dynamic World:<br/>"
        "&nbsp;&nbsp;&nbsp;&nbsp;<i>S</i> = (1/<i>M</i>) &sum;<sub>m=1..M</sub> &Iopf;(<i>c</i><sup>(m)</sup> = <i>c</i><sub>anual</sub>)<br/>"
        "4. <b>Distância Mínima à Borda Temática (<i>d</i><sub>min</sub>):</b> distância euclidiana métrica calculada em raster até a borda temática "
        "de transição mais próxima de Dynamic World ou MapBiomas (min(<i>d</i><sub>dw</sub>, <i>d</i><sub>mb</sub>)), truncada em 250 m. O suporte analítico "
        "refere-se estritamente a pixels de 10 m e manchas contínuas de raster, sem correspondência com limites cadastrais ou geometrias de talhões agrícolas.",
        body_first
    ),
    Paragraph("2.4. Desenho Amostral e Inferência Espacial", h2_style),
    Paragraph(
        "O espaço amostral foi particionado em 16 estratos científicos de análise (combinação de 4 Unidades Federativas com 4 regimes temáticos: "
        "AA: Acordo Lavoura; AN: MapBiomas Lavoura e DW Não-Lavoura; NA: DW Lavoura e MapBiomas Não-Lavoura; NN: Acordo Não-Lavoura) e operacionalizado "
        "em 410 subestratos espaciais independentes (<i>slices</i> operacionais <i>hs</i>). A seleção amostral ocorreu no nível dos subestratos operacionais, "
        "onde cada célula <i>k</i> pertencente ao subestrato <i>hs</i> possui probabilidade de inclusão &pi;<sub>robust,hs</sub> = <i>n</i><sub>robust,hs</sub> / <i>N</i><sub>hs</sub> "
        "na amostra robusta de 40k (<i>n</i><sub>robust,hs</sub> &ge; 1 para todo subestrato não-vazio) e probabilidade &pi;<sub>main,k</sub> = 0,5 &middot; &pi;<sub>robust,hs</sub> "
        "na amostra principal de 20k. As estimativas populacionais incorporam os pesos de Horvitz-Thompson inversos às probabilidades efetivas de seleção operacional (<i>w</i><sub>k</sub> = 1 / &pi;<sub>k</sub>) [9].",
        body_first
    ),
    Paragraph(
        "Para acomodar a dependência espacial presente nos resíduos [10, 11], ajustou-se semivariograma empírico exponencial sobre o resíduo da "
        "discordância, identificando alcance prático de 25,62 km. Conforme o protocolo e diretrizes de particionamento [12, 13], implementou-se "
        "<i>Spatial Block Bootstrap</i> como aproximação inferencial estruturada em blocos primários regulares de 30 km e 1.999 réplicas com "
        "reposição. Ajustou-se modelo logístico multivariado ponderado, interpretando os <i>odds ratios</i> (OR) escalonados como associações "
        "condicionais ajustadas, acompanhados de intervalos de confiança empíricos a 95%.",
        body_indent
    )
]
print(f"2. Material e Métodos height: {get_h(metodos_f, col_w):.1f} mm")

# 3. Resultados
resultados_f = [
    Paragraph("3. RESULTADOS", h1_style),
    Paragraph("3.1. Discordância Censitária e Distribuição Geográfica", h2_style),
    Paragraph(
        "No censo <i>wall-to-wall</i> dos 52,34 Mha elegíveis, a discordância temática entre os produtos atinge <b>14,2852% por área</b> "
        "(7.477.177,23 ha) e <b>14,3110% por pixels</b> (766.304.630 pixels). A estimativa ponderada na amostra de 20.000 pontos reproduz com "
        "precisão micrométrica o parâmetro censitário: 14,2897% por área (7.479.568,87 ha) e 14,3148% por contagem de pixels (766.512.449 pixels). "
        "A discordância decorre predominantemente de alocação espacial (9,30 pp) frente à divergência de quantidade de área (4,99 pp) [7].",
        body_first
    ),
    Paragraph(
        "A Tabela 1 detalha os regimes censitários e por estado. A discordância varia fortemente entre as Unidades Federativas: a Bahia exibe "
        "a maior proporção (27,95%), seguida por Piauí (21,80%), Maranhão (10,98%) e Tocantins (5,90%). A Figura 1 ilustra a composição dos "
        "regimes temáticos e o gradiente estadual observado.",
        body_indent
    ),
    Paragraph("3.2. Testes de Hipótese H1 a H4", h2_style),
    Paragraph(
        "A avaliação das quatro hipóteses operacionais revelou padrões consistentes de incerteza informacional e espacial:<br/>"
        "• <b><i>H</i><sub>1</sub> (Ambiguidade Anual):</b> A entropia anual média é superior nas células discordantes (&Delta;<i>H</i> = +0,0162, "
        "IC 95%: [+0,0103; +0,0221], Cohen's <i>d</i> = +0,318), evidenciando associação positiva com incerteza probabilística na classificação anual;<br/>"
        "• <b><i>H</i><sub>2a</sub> e <i>H</i><sub>2b</sub> (Dinâmica Temporal):</b> Pixels discordantes exibem maior divergência temporal bivariada "
        "(&Delta;JSD = +0,007492, IC 95%: [+0,0047; +0,0102], <i>d</i> = +0,335) e menor persistência categórica modal (&Delta;<i>S</i> = &minus;0,078959, "
        "IC 95%: [&minus;0,0974; &minus;0,0599], <i>d</i> = &minus;0,426);<br/>"
        "• <b><i>H</i><sub>3</sub> (Efeito de Borda Temática):</b> A taxa de discordância atinge 45,91% na borda imediata (&lt;30 m) e cai para 11,87% no "
        "interior (&ge;250 m), gerando razão de contraste de <b>3,87 vezes</b>. Entre faixas contíguas, observa-se quebra local de monotonicidade estrita "
        "(30–60 m com 45,77% vs. 10–30 m com 44,59%), caracterizando forte gradiente inverso global sem monotonicidade perfeita;",
        body_first
    ),
    Paragraph(
        "• <b><i>H</i><sub>4</sub> (Discordâncias sob Restrições Conjuntas):</b> Sob critérios operacionais simultâneos (<i>H</i> &le; <i>Q</i><sub>1</sub>, "
        "JSD &le; <i>Q</i><sub>1</sub>, <i>S</i> &ge; <i>Q</i><sub>3</sub> e <i>d</i><sub>min</sub> &ge; 30 m), apenas 207 pontos amostrados atendem aos "
        "requisitos na amostra de 20k (<b>4,2773% ponderado</b> dos pixels discordantes), confirmados em 404 pontos na amostra de 40k (<b>4,1687% ponderado</b>).",
        body_indent
    ),
    Paragraph("3.3. Associações Marginais versus Condicionais", h2_style),
    Paragraph(
        "A comparação entre as estimativas bivariadas e o modelo logístico multivariado revela distinções metodológicas importantes:<br/>"
        "1. <b>Atenuação da Divergência Temporal (JSD):</b> Enquanto a JSD exibe forte associação positiva marginal em <i>H</i><sub>2a</sub>, "
        "seu efeito condicional na regressão dissipa-se (OR = 0,987, IC: [0,914; 1,059]). Quando a persistência categórica <i>S</i> e o afastamento "
        "de bordas são controlados conjuntamente, a variação contínua da JSD não agrega poder explicativo condicional adicional. Essa atenuação "
        "decorre da correlação empírica entre os regressores, não constituindo demonstração causal de mediação;<br/>"
        "2. <b>Impacto do Ajuste Espacial no Contraste Estadual:</b> Sob premissa assintótica clássica i.i.d., o contraste Piauí versus Bahia sugeriria "
        "significância (<i>p</i> &lt; 0,001, IC analítico: [0,709; 0,900]). O <i>Spatial Block Bootstrap</i> de 30 km acomoda a dependência espacial "
        "e expande o intervalo para [0,507; 1,212], cobrindo o valor nulo (1,0). Isso demonstra que os dados amostrais não fornecem evidência de diferença "
        "na propensão condicional de discordância entre Piauí e Bahia sob controle das demais covariáveis, ilustrando o risco de falsos positivos em testes "
        "que desconsideram a autocorrelação geográfica.",
        body_first
    )
]
print(f"3. Resultados height: {get_h(resultados_f, col_w):.1f} mm")

# 4. Discussão
disc_f = [
    Paragraph("4. DISCUSSÃO", h1_style),
    Paragraph("4.1. Incerteza Estruturada e Abordagem Simétrica", h2_style),
    Paragraph(
        "A perspectiva analítica simétrica trata as divergências entre mapeamentos não como erros unilaterais, mas como manifestações de incerteza "
        "estruturada inerentes ao processo de classificação:<br/>"
        "• <b>Transições de Borda e Mistura Espectral:</b> A concentração pronunciada de discordâncias nos primeiros 30 metros reflete o efeito de "
        "mistura de subpixel ao longo de carreadores, faixas de vegetação ripária e limites de manchas cultivadas. No suporte raster de 10 m, células que "
        "interceptam interfaces entre solo exposto e savana flutuam entre produtos em função de limiares de decisão e funções de perda distintas;<br/>"
        "• <b>Sazonalidade e Dinâmica Temporal:</b> No regime agrícola de sequeiro do Cerrado, ciclos produtivos intercalam fases vegetativas com "
        "dessecação e palhada que se aproximam da assinatura espectral de savanas abertas [1, 2]. O Dynamic World captura estados instantâneos cena a cena, "
        "enquanto o MapBiomas apoia-se em métricas percentílicas anuais consolidadas [3, 5], gerando divergências associadas às transições fenológicas.",
        body_first
    ),
    Paragraph("4.2. Caracterização Operacional de H4", h2_style),
    Paragraph(
        "A constatação de que apenas 4,28% ponderado das discordâncias atendem aos filtros conjuntos de <i>H</i><sub>4</sub> delimita um subconjunto "
        "restrito de divergências categóricas persistentes no interior contínuo da paisagem, com alta assertividade espectral em ambos os produtos. "
        "Esses casos não constituem 'erros comprovados', mas indicam divergências conceituais substantivas entre abordagens (por exemplo, transição "
        "entre pastagens intensivas e lavouras anuais), representando alvos prioritários para auditorias de campo independentes.",
        body_first
    ),
    Paragraph("4.3. Limitações do Estudo", h2_style),
    Paragraph(
        "O trabalho apresenta limites metodológicos definidos: (1) a exigência de <i>n</i><sub>meses</sub> &ge; 8 excluiu 21,74% da área do MATOPIBA, "
        "concentrada no norte chuvoso do Maranhão; (2) a não-comutatividade temporal/espacial impõe resíduo médio de 0,004983, afetando situações de quase-empate "
        "probabilístico; (3) por se tratar de comparação observacional sem verdade de campo independente, os resultados refletem associações estatísticas "
        "espaciais, sem inferência causal.",
        body_first
    )
]
print(f"4. Discussão height: {get_h(disc_f, col_w):.1f} mm")

# 5. Conclusões
concl_f = [
    Paragraph("5. CONCLUSÕES", h1_style),
    Paragraph(
        "O diagnóstico espacial e probabilístico no MATOPIBA revela que a discordância censitária de lavouras em 2025 entre Dynamic World e MapBiomas "
        "(14,2852% por área e 14,3110% por pixels) concentra-se em zonas de transição temática e períodos de instabilidade temporal. Apenas 4,28% ponderado "
        "das discordâncias manifestam-se no interior contínuo com alta estabilidade e baixa ambiguidade. A aplicação de <i>Spatial Block Bootstrap</i> "
        "evidenciou que contrastes macrorregionais assintóticos perdem significância quando a dependência espacial é incorporada. Para a comunidade "
        "GeoAI e de Sensoriamento Remoto, esses achados indicam que discrepâncias entre produtos decamétricos devem ser tratadas como indicadores objetivos "
        "de incerteza de borda e fenologia, orientando estratégias robustas de integração territorial.",
        body_first
    )
]
print(f"5. Conclusões height: {get_h(concl_f, col_w):.1f} mm")

# 6. Referências
refs = [
    "[1] S. A. Spera, G. L. Galford, M. T. Coe, M. N. Macedo, and J. F. Mustard. Land-use change affects water recycling in Brazil’s last agricultural frontier, <i>Global Change Biology</i>, v. 22(10):pp. 3405–3413, 2016.",
    "[2] R. F. B. da Silva, M. Batistella, E. F. Moran, and L. A. Martinelli. Soy expansion and socioeconomic development in municipalities of Brazil, <i>Land</i>, v. 6(3):art. 62, 2017.",
    "[3] C. M. Souza et al. Reconstructing Three Decades of Land Use and Land Cover Changes in Brazilian Biomes with Landsat Archive and Earth Engine, <i>Remote Sensing</i>, v. 12(17):art. 2735, 2020.",
    "[4] MapBiomas. Coleção 4 da Cobertura e Uso da Terra a 10 metros (2017–2025), Rede MapBiomas, São Paulo, 2025. URL: brasil.mapbiomas.org",
    "[5] C. F. Brown et al. Dynamic World, Near real-time global 10 m land use land cover mapping, <i>Scientific Data</i>, v. 9(1):art. 251, 2022.",
    "[6] S. Fritz et al. Highlighting continued uncertainty in global land cover maps for the user community, <i>Environmental Research Letters</i>, v. 6(4):art. 044005, 2011.",
    "[7] R. G. Pontius and M. Millones. Death to Kappa: birth of quantity disagreement and allocation disagreement for accuracy assessment, <i>International Journal of Remote Sensing</i>, v. 32(15):pp. 4407–4429, 2011.",
    "[8] G. M. Foody. Status of land cover classification accuracy assessment, <i>Remote Sensing of Environment</i>, v. 80(1):pp. 185–201, 2002.",
    "[9] P. Olofsson et al. Good practices for estimating area and assessing accuracy of land change, <i>Remote Sensing of Environment</i>, v. 148:pp. 42–57, 2014.",
    "[10] P. Legendre. Spatial autocorrelation: trouble or new paradigm?, <i>Ecology</i>, v. 74(6):pp. 1659–1673, 1993.",
    "[11] G. Carl and I. Kühn. Analyzing spatial autocorrelation in species distributions using Gaussian and alternative methods, <i>Ecological Modelling</i>, v. 207(2–4):pp. 159–170, 2007.",
    "[12] H. R. Künsch. The jackknife and the bootstrap for general stationary observations, <i>The Annals of Statistics</i>, v. 17(3):pp. 1217–1241, 1989.",
    "[13] D. R. Roberts et al. Cross-validation strategies for data with temporal, spatial, or phylogenetic structure, <i>Ecography</i>, v. 40(8):pp. 913–929, 2017.",
    "[14] C. E. Shannon. A mathematical theory of communication, <i>The Bell System Technical Journal</i>, v. 27(3):pp. 379–423, 1948.",
    "[15] J. Lin. Divergence measures based on the Shannon entropy, <i>IEEE Transactions on Information Theory</i>, v. 37(1):pp. 145–151, 1991."
]
refs_f = [Paragraph("6. REFERÊNCIAS", h1_style)] + [Paragraph(r, ref_style) for r in refs]
print(f"6. Referências height: {get_h(refs_f, col_w):.1f} mm")
