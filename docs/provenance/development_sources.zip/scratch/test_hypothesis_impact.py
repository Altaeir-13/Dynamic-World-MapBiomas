import pandas as pd
import numpy as np

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

valid_mon = df_mon[df_mon['month_valid'] == 1].copy()

# Reconstruct monthly mean vector
mon_agg = valid_mon.groupby('sample_id').agg(
    **{c: (c, 'mean') for c in DW_CLASSES}
).reset_index()

prob_sum_recon = mon_agg[DW_CLASSES].sum(axis=1)
for c in DW_CLASSES:
    mon_agg[c + '_recon'] = mon_agg[c] / prob_sum_recon

merged = pd.merge(df_ann, mon_agg, on='sample_id')

# Compute H from reconstructed vector
LN_9 = np.log(9)
def calc_entropy(p_mat):
    # p_mat shape (N, 9)
    p_mat = np.clip(p_mat, 1e-12, 1.0)
    return -np.sum(p_mat * np.log(p_mat), axis=1) / LN_9

h_auth = merged['entropy_annual'].values
p_recon_mat = merged[[c + '_recon' for c in DW_CLASSES]].values
h_recon = calc_entropy(p_recon_mat)

merged['h_recon'] = h_recon

# Check H1 under auth vs recon
main = merged[merged['main_sample'] == 1].copy()
main['is_discordant'] = main['regime'].isin(['AN', 'NA']).astype(int)

# H1 under auth
w_disc = main[main['is_discordant']==1]['design_weight_main'].astype(float).values
h_disc_auth = main[main['is_discordant']==1]['entropy_annual'].astype(float).values
mean_h_disc_auth = np.average(h_disc_auth, weights=w_disc)

w_conc = main[main['is_discordant']==0]['design_weight_main'].astype(float).values
h_conc_auth = main[main['is_discordant']==0]['entropy_annual'].astype(float).values
mean_h_conc_auth = np.average(h_conc_auth, weights=w_conc)
diff_h1_auth = mean_h_disc_auth - mean_h_conc_auth

# H1 under recon
h_disc_recon = main[main['is_discordant']==1]['h_recon'].astype(float).values
mean_h_disc_recon = np.average(h_disc_recon, weights=w_disc)

h_conc_recon = main[main['is_discordant']==0]['h_recon'].astype(float).values
mean_h_conc_recon = np.average(h_conc_recon, weights=w_conc)
diff_h1_recon = mean_h_disc_recon - mean_h_conc_recon

print("=== IMPACTO EM H1 (Entropia) ===")
print(f"Auth:  H_disc={mean_h_disc_auth:.4f}, H_conc={mean_h_conc_auth:.4f}, Delta={diff_h1_auth:+.4f}")
print(f"Recon: H_disc={mean_h_disc_recon:.4f}, H_conc={mean_h_conc_recon:.4f}, Delta={diff_h1_recon:+.4f}")

# Check H2b (Stability S)
# Notice in samples_annual, stability was: mean(argmax(p_m) == auth_annual_class)
# What if stability is computed relative to recon_annual_class?
rec_argmax_idx = np.argmax(p_recon_mat, axis=1)
merged['rec_argmax_idx'] = rec_argmax_idx

# Compute stability relative to recon argmax
# Get monthly argmax
valid_mon['m_argmax'] = np.argmax(valid_mon[DW_CLASSES].values, axis=1)
mon_with_rec = pd.merge(valid_mon, merged[['sample_id', 'annual_class_index', 'rec_argmax_idx', 'main_sample', 'design_weight_main', 'regime']], on='sample_id')
mon_with_rec['match_auth'] = (mon_with_rec['m_argmax'] == mon_with_rec['annual_class_index'])
mon_with_rec['match_recon'] = (mon_with_rec['m_argmax'] == mon_with_rec['rec_argmax_idx'])

s_pt = mon_with_rec.groupby(['sample_id', 'main_sample', 'design_weight_main', 'regime']).agg(
    s_auth=('match_auth', 'mean'),
    s_recon=('match_recon', 'mean')
).reset_index()

s_main = s_pt[s_pt['main_sample'] == 1].copy()
s_main['is_discordant'] = s_main['regime'].isin(['AN', 'NA']).astype(int)

w_s_disc = s_main[s_main['is_discordant']==1]['design_weight_main'].astype(float).values
mean_s_disc_auth = np.average(s_main[s_main['is_discordant']==1]['s_auth'].astype(float).values, weights=w_s_disc)
w_s_conc = s_main[s_main['is_discordant']==0]['design_weight_main'].astype(float).values
mean_s_conc_auth = np.average(s_main[s_main['is_discordant']==0]['s_auth'].astype(float).values, weights=w_s_conc)

mean_s_disc_recon = np.average(s_main[s_main['is_discordant']==1]['s_recon'].astype(float).values, weights=w_s_disc)
mean_s_conc_recon = np.average(s_main[s_main['is_discordant']==0]['s_recon'].astype(float).values, weights=w_s_conc)

print("\n=== IMPACTO EM H2b (Estabilidade S) ===")
print(f"Auth S:  S_disc={mean_s_disc_auth:.4f}, S_conc={mean_s_conc_auth:.4f}, Delta={mean_s_disc_auth - mean_s_conc_auth:+.4f}")
print(f"Recon S: S_disc={mean_s_disc_recon:.4f}, S_conc={mean_s_conc_recon:.4f}, Delta={mean_s_disc_recon - mean_s_conc_recon:+.4f}")

# Check breakdown by regime of S_auth vs S_recon
print("\nS por regime:")
for reg in ['AA', 'AN', 'NA', 'NN']:
    sub = s_main[s_main['regime'] == reg]
    w_sub = sub['design_weight_main'].astype(float).values
    print(f"  {reg}: S_auth={np.average(sub['s_auth'].astype(float).values, weights=w_sub):.4f} | S_recon={np.average(sub['s_recon'].astype(float).values, weights=w_sub):.4f}")

# Check H4
# Criteria: H < 0.40, JSD < 0.02, S >= 0.75, dist >= 250m
# Under Auth vs Recon
main_h4 = main.copy()
main_h4 = pd.merge(main_h4, s_pt[['sample_id', 's_recon']], on='sample_id')
cand_auth = main_h4[(main_h4['is_discordant']==1) & (main_h4['entropy_annual'] < 0.40) & (main_h4['jsd_temporal'] < 0.02) & (main_h4['stability'] >= 0.75) & (main_h4['distance_edge_min_m'] >= 250)]
cand_recon = main_h4[(main_h4['is_discordant']==1) & (main_h4['h_recon'] < 0.40) & (main_h4['jsd_temporal'] < 0.02) & (main_h4['s_recon'] >= 0.75) & (main_h4['distance_edge_min_m'] >= 250)]

print(f"\n=== IMPACTO EM H4 ===")
print(f"H4 candidatos com definicao Auth:  {len(cand_auth)}")
print(f"H4 candidatos com definicao Recon: {len(cand_recon)}")
