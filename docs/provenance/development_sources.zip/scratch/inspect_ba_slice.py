import pandas as pd
import numpy as np

df_ann = pd.read_parquet('data/processed/samples_annual.parquet')
df_mon = pd.read_parquet('data/processed/dw_monthly.parquet')

DW_CLASSES = ['water', 'trees', 'grass', 'flooded_vegetation', 'crops', 'shrub_and_scrub', 'built', 'bare', 'snow_and_ice']
sub_ann = df_ann[df_ann['slice_id'] == 'BA_x04_y04']
print('BA_x04_y04 points:', len(sub_ann))
print('Regimes in BA_x04_y04:', sub_ann['regime'].value_counts().to_dict())

pt = sub_ann.iloc[0]
sid = pt['sample_id']
reg = pt['regime']
cls_a = pt['annual_class']
n_v = pt['n_valid_months']
print(f'Point {sid}: regime={reg}, annual_class={cls_a}, n_valid={n_v}')
print('Annual probs:')
for c in DW_CLASSES:
    val = pt['p_' + c]
    print(f'  {c:15s}: {val:.4f}')

mon_pt = df_mon[(df_mon['sample_id'] == sid) & (df_mon['month_valid'] == 1)]
print('Monthly probs valid months:', mon_pt['month'].tolist())
for _, m_row in mon_pt.iterrows():
    m = int(m_row['month'])
    probs = [m_row[c] for c in DW_CLASSES]
    top_c = DW_CLASSES[np.argmax(probs)]
    c_p = m_row['crops']
    t_p = m_row['trees']
    s_p = m_row['shrub_and_scrub']
    b_p = m_row['bare']
    print(f'  Month {m:02d}: top={top_c:15s} (p={np.max(probs):.3f}) | crops={c_p:.3f}, trees={t_p:.3f}, shrub={s_p:.3f}, bare={b_p:.3f}')
