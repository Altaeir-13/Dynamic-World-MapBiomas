import json
import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

def run_pilot2_evaluation():
    df_pts = pd.read_csv('scratch/pilot2_sample_points.csv', keep_default_na=False)
    with open('scratch/pilot2_bilinear_monthly_results.json', 'r', encoding='utf-8') as f:
        new_ext = json.load(f)
    ext_by_id = {r['sample_id']: r for r in new_ext}
    
    # Old monthly & annual
    df_mon_old = pd.read_parquet('data/processed/dw_monthly.parquet')
    df_ann_old = pd.read_parquet('data/processed/samples_annual.parquet')
    ann_by_id = df_ann_old.set_index('sample_id').to_dict('index')

    rows = []
    for _, pt in df_pts.iterrows():
        sid = pt['sample_id']
        props = ext_by_id[sid]
        ann = ann_by_id[sid]
        
        # 1. Authoritative annual
        auth_p = np.array([float(props[f'auth_p_{c}']) for c in DW_CLASSES])
        auth_class_idx = int(props['auth_annual_class_index'])
        auth_crop = int(props['auth_dw_crop'])
        auth_n_months = int(props['auth_n_valid_months'])
        top2_margin = float(pt['top2_margin'])
        
        # 2. Old raw monthly
        old_m = df_mon_old[(df_mon_old['sample_id'] == sid) & (df_mon_old['month_valid'] == 1)]
        old_vecs = []
        old_matches = 0
        for _, r in old_m.iterrows():
            v = r[DW_CLASSES].values.astype(float)
            v_sum = np.sum(v)
            if v_sum > 0:
                v_norm = v / v_sum
                old_vecs.append(v_norm)
                if np.argmax(v_norm) == auth_class_idx:
                    old_matches += 1
        
        if len(old_vecs) > 0:
            old_p_mean = np.mean(old_vecs, axis=0)
            old_p_mean_norm = old_p_mean / np.sum(old_p_mean)
            old_class_idx = int(np.argmax(old_p_mean_norm))
            old_crop = 1 if old_class_idx == 4 else 0
            old_s = old_matches / len(old_vecs)
            # Old JSD
            old_jsd_list = [jensenshannon(v, old_p_mean_norm, base=2)**2 for v in old_vecs]
            old_jsd = np.mean(old_jsd_list)
        else:
            old_class_idx = -1
            old_crop = -1
            old_s = 0.0
            old_jsd = 0.0
            old_p_mean_norm = np.zeros(9)
            
        # 3. New bilinear monthly
        new_vecs = []
        new_matches = 0
        for m in range(1, 13):
            n_days = int(props.get(f'n_days_bil_m{m:02d}', 0))
            raw_m = np.array([float(props.get(f'{c}_bil_m{m:02d}', 0.0)) for c in DW_CLASSES])
            raw_sum = np.sum(raw_m)
            if n_days > 0 and raw_sum > 0.01:
                norm_m = raw_m / raw_sum
                new_vecs.append(norm_m)
                if np.argmax(norm_m) == auth_class_idx:
                    new_matches += 1
                    
        new_p_mean = np.mean(new_vecs, axis=0)
        new_p_mean_norm = new_p_mean / np.sum(new_p_mean)
        new_class_idx = int(np.argmax(new_p_mean_norm))
        new_crop = 1 if new_class_idx == 4 else 0
        new_s = new_matches / len(new_vecs)
        new_jsd_list = [jensenshannon(v, new_p_mean_norm, base=2)**2 for v in new_vecs]
        new_jsd = np.mean(new_jsd_list)

        # Differences
        diff_old = np.abs(auth_p - old_p_mean_norm)
        diff_new = np.abs(auth_p - new_p_mean_norm)

        rows.append({
            'sample_id': sid,
            'state': pt['state'],
            'regime': pt['regime'],
            'dist_edge': pt['distance_edge_min_m'],
            'dist_bin': '<30m' if pt['distance_edge_min_m'] < 30 else ('30-100m' if pt['distance_edge_min_m'] < 100 else '>=100m'),
            'top2_margin': top2_margin,
            'margin_bin': '<0.02' if top2_margin < 0.02 else ('0.02-0.05' if top2_margin < 0.05 else ('0.05-0.10' if top2_margin < 0.10 else '>=0.10')),
            'n_valid_months': auth_n_months,
            'auth_class': DW_CLASSES[auth_class_idx],
            'auth_crop': auth_crop,
            # Old
            'old_class': DW_CLASSES[old_class_idx] if old_class_idx >= 0 else 'none',
            'old_crop': old_crop,
            'old_argmax_div': 1 if old_class_idx != auth_class_idx else 0,
            'old_crop_div': 1 if old_crop != auth_crop else 0,
            'old_max_diff': np.max(diff_old),
            'old_mean_diff': np.mean(diff_old),
            'old_s': old_s,
            'old_jsd': old_jsd,
            # New
            'new_class': DW_CLASSES[new_class_idx],
            'new_crop': new_crop,
            'new_argmax_div': 1 if new_class_idx != auth_class_idx else 0,
            'new_crop_div': 1 if new_crop != auth_crop else 0,
            'new_max_diff': np.max(diff_new),
            'new_mean_diff': np.mean(diff_new),
            'new_s': new_s,
            'new_jsd': new_jsd,
        })

    res_df = pd.DataFrame(rows)
    res_df.to_csv('scratch/pilot2_evaluation_summary.csv', index=False)
    res_df.to_csv('tables/pilot2_evaluation_summary.csv', index=False)
    print("Pilot 2 evaluation summary saved to scratch and tables!")

    print("\n" + "="*80)
    print("PILOT 2 EVALUATION SUMMARY (128 POINTS)")
    print("="*80)
    print(f"Total Pontos: {len(res_df)}")
    old_arg = res_df['old_argmax_div'].sum()
    new_arg = res_df['new_argmax_div'].sum()
    print(f"Argmax Divergente:  OLD = {old_arg} ({old_arg/len(res_df)*100:.1f}%)  -->  NEW = {new_arg} ({new_arg/len(res_df)*100:.1f}%) [Redução de {(old_arg-new_arg)/old_arg*100:.1f}%]")
    old_cr = res_df['old_crop_div'].sum()
    new_cr = res_df['new_crop_div'].sum()
    print(f"Crop/Noncrop Div:   OLD = {old_cr} ({old_cr/len(res_df)*100:.1f}%)  -->  NEW = {new_cr} ({new_cr/len(res_df)*100:.1f}%) [Redução de {(old_cr-new_cr)/old_cr*100:.1f}%]")
    print(f"Max Prob Diff:      OLD = {res_df['old_max_diff'].max():.6f}  -->  NEW = {res_df['new_max_diff'].max():.6f}")
    print(f"Mean Max Prob Diff: OLD = {res_df['old_max_diff'].mean():.6f}  -->  NEW = {res_df['new_max_diff'].mean():.6f}")
    print(f"Global Mean Diff:   OLD = {res_df['old_mean_diff'].mean():.6f}  -->  NEW = {res_df['new_mean_diff'].mean():.6f}")
    print(f"Estabilidade S:     OLD = {res_df['old_s'].mean():.4f}  -->  NEW = {res_df['new_s'].mean():.4f}")
    print(f"JSD Temporal:       OLD = {res_df['old_jsd'].mean():.6f}  -->  NEW = {res_df['new_jsd'].mean():.6f}")

    print("\n" + "-"*80)
    print("DESEMPENHO POR REGIME:")
    print(res_df.groupby('regime')[['old_argmax_div', 'new_argmax_div', 'old_crop_div', 'new_crop_div', 'old_max_diff', 'new_max_diff', 'old_s', 'new_s']].mean())

    print("\n" + "-"*80)
    print("DESEMPENHO POR DISTÂNCIA DE BORDA:")
    print(res_df.groupby('dist_bin')[['old_argmax_div', 'new_argmax_div', 'old_crop_div', 'new_crop_div', 'old_max_diff', 'new_max_diff', 'old_s', 'new_s']].mean())

    print("\n" + "-"*80)
    print("DESEMPENHO POR FAIXA DE MARGEM TOP-1 / TOP-2:")
    print(res_df.groupby('margin_bin')[['old_argmax_div', 'new_argmax_div', 'old_crop_div', 'new_crop_div', 'old_max_diff', 'new_max_diff']].mean())

    print("\n" + "-"*80)
    print("DESEMPENHO POR QUANTIDADE DE MESES VÁLIDOS:")
    print(res_df.groupby('n_valid_months')[['old_argmax_div', 'new_argmax_div', 'old_crop_div', 'new_crop_div', 'old_max_diff', 'new_max_diff']].mean())

    print("\n" + "-"*80)
    print(f"DETALHE DOS PONTOS AINDA DIVERGENTES NO NOVO PIPELINE ({new_arg} pontos):")
    div_pts = res_df[res_df['new_argmax_div'] == 1][['sample_id', 'state', 'regime', 'dist_edge', 'top2_margin', 'auth_class', 'new_class', 'new_crop_div', 'new_max_diff']]
    print(div_pts.to_string())

if __name__ == '__main__':
    run_pilot2_evaluation()
