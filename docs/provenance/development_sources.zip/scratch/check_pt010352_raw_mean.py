import json
import numpy as np

with open('data/processed/extraction_slices/MA_x06_y04.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

pt = next(p for p in data if p.get('sample_id') == 'PT_010352')

DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

print("=== PT_010352: AUTORITATIVO vs MÉDIA MENSAL BRUTA vs MÉDIA MENSAL NORMALIZADA ===")
auth_p = np.array([float(pt[f'auth_p_{c}']) for c in DW_CLASSES])
auth_raw_sum = float(pt['auth_raw_prob_sum'])
print(f"Auth raw prob sum: {auth_raw_sum}")
print(f"Auth p crops: {auth_p[4]:.4f}, Auth p trees: {auth_p[1]:.4f}")

# Valid months
valid_months = [m for m in range(1, 13) if int(pt.get(f'n_days_m{m:02d}', 0)) > 0 and float(pt.get(f'prob_sum_m{m:02d}', 0)) > 0]
print(f"Valid months: {valid_months} (count: {len(valid_months)})")

# 1. Raw monthly vectors
raw_monthly = []
norm_monthly = []
for m in valid_months:
    r_vec = np.array([float(pt.get(f'{c}_m{m:02d}', 0.0)) for c in DW_CLASSES])
    s = float(pt.get(f'prob_sum_m{m:02d}', 0.0))
    raw_monthly.append(r_vec)
    norm_monthly.append(r_vec / s)

raw_mean = np.mean(raw_monthly, axis=0)
norm_mean = np.mean(norm_monthly, axis=0)

print(f"\nRaw Monthly Mean sum: {np.sum(raw_mean):.6f}")
print(f"Raw Monthly Mean:  crops={raw_mean[4]:.4f}, trees={raw_mean[1]:.4f}")
print(f"Norm Monthly Mean: crops={norm_mean[4]:.4f}, trees={norm_mean[1]:.4f}")

print("\nComparação Classe a Classe para PT_010352:")
for i, c in enumerate(DW_CLASSES):
    print(f"  {c:20s}: Auth={auth_p[i]:.4f} | RawMean={raw_mean[i]:.4f} | NormMean={norm_mean[i]:.4f}")
