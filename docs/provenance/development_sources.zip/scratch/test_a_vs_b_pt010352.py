import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import ee
import json

PROJECT_ID = "dynamicworld-x-mapbiomas"
ee.Initialize(project=PROJECT_ID)

from src.gee.dw_annual import (
    DW_PROB_BANDS,
    DW_START,
    DW_END,
    DW_COLLECTION,
    get_mapbiomas_projection,
    get_source_support_domain,
    DATES_CACHE_PATH
)

mb_proj = get_mapbiomas_projection()
source_domain = get_source_support_domain()

fc = ee.FeatureCollection([ee.Feature(ee.Geometry.Point([-44.50545869995448, -6.884643421727807]), {'sample_id': 'PT_010352'})])

with open(DATES_CACHE_PATH, "r", encoding="utf-8") as f:
    dates_dict = json.load(f)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterDate(DW_START, DW_END)
    .filterBounds(source_domain)
)

m_comps = []
for m in range(1, 13):
    start = f"2025-{m:02d}-01"
    end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
    dw_m = dw_col.filterDate(start, end)
    dates_m = ee.List(dates_dict[f"{m:02d}"])

    def make_daily(d):
        d_start = ee.Date(d)
        d_end = d_start.advance(1, "day")
        return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().toFloat().set("date", d)

    daily_col = ee.ImageCollection(dates_m.map(make_daily))
    comp_m = daily_col.mean().select(DW_PROB_BANDS).toFloat()
    m_comps.append(comp_m)

# A. dw_annual way:
# annual_dw = mean of m_comps
# annual_10m = annual_dw.resample('bilinear').reproject(crs=mb_proj)
annual_dw = ee.ImageCollection(m_comps).mean()
annual_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
s_A = annual_10m.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

# B. Month-by-month bilinear:
# For each month m, resample('bilinear').reproject(crs=mb_proj)
# Then take mean of valid months
m_comps_bil = [c.resample("bilinear").reproject(crs=mb_proj) for c in m_comps]
annual_from_bil_months = ee.ImageCollection(m_comps_bil).mean()
s_B = annual_from_bil_months.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

print("=== COMPARAÇÃO A vs B PARA PT_010352 ===")
print("A: annual_dw.resample('bilinear').reproject(crs=mb_proj):")
for c in ['trees', 'crops', 'grass', 'shrub_and_scrub', 'bare']:
    print(f"  {c:15s}: {s_A.get(c):.6f}")

print("\nB: ee.ImageCollection([c.resample('bilinear').reproject(crs=mb_proj)]).mean():")
for c in ['trees', 'crops', 'grass', 'shrub_and_scrub', 'bare']:
    print(f"  {c:15s}: {s_B.get(c):.6f}")

# Check monthly values of B
print("\nValores mensais de B (para cada um dos 8 meses válidos):")
b_sampled = []
for m_idx in [3, 4, 5, 6, 7, 8, 9, 10]: # months 4 to 11
    s_m = m_comps_bil[m_idx].sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']
    b_sampled.append(s_m)
    print(f"  Mês {m_idx+1:02d}: crops={s_m.get('crops'):.4f}, trees={s_m.get('trees'):.4f}")

mean_b_crops = sum(s.get('crops') for s in b_sampled) / len(b_sampled)
mean_b_trees = sum(s.get('trees') for s in b_sampled) / len(b_sampled)
print(f"\nMédia calculada em Python dos 8 meses de B:")
print(f"  crops: {mean_b_crops:.6f}, trees: {mean_b_trees:.6f}")
