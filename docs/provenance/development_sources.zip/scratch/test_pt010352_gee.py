import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import ee
import json

PROJECT_ID = "dynamicworld-x-mapbiomas"
ee.Initialize(project=PROJECT_ID)

from src.gee.dw_annual import (
    DW_PROB_BANDS,
    DW_START,
    DW_END,
    DW_COLLECTION,
    get_mapbiomas_projection,
    get_source_support_domain,
    DATES_CACHE_PATH,
    build_dw_annual_2025
)

mb_proj = get_mapbiomas_projection()
source_domain = get_source_support_domain()

# PT_010352 coordinates
fc = ee.FeatureCollection([ee.Feature(ee.Geometry.Point([-44.50545869995448, -6.884643421727807]), {'sample_id': 'PT_010352'})])

# 1. Authoritative annual stack
dw_ann = build_dw_annual_2025()
auth_img = ee.Image.cat([
    dw_ann["normalized_probs"],
    dw_ann["raw_prob_sum"],
    dw_ann["annual_class_index"],
    dw_ann["dw_crop"]
])
s_auth = auth_img.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

print("=== 1. AUTH ANNUAL (from build_dw_annual_2025) ===")
print(f"  annual_class_index: {s_auth.get('annual_class_index')}")
print(f"  dw_crop:            {s_auth.get('dw_crop')}")
print(f"  raw_prob_sum:       {s_auth.get('probability_sum_before_normalization'):.4f}")
print(f"  trees:              {s_auth.get('trees'):.4f}")
print(f"  crops:              {s_auth.get('crops'):.4f}")

# 2. Reconstructing monthly composites
with open(DATES_CACHE_PATH, "r", encoding="utf-8") as f:
    dates_dict = json.load(f)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterDate(DW_START, DW_END)
    .filterBounds(source_domain)
)

m_comps_raw = []
m_comps_bilinear = []

for m in range(1, 13):
    start = f"2025-{m:02d}-01"
    end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
    dw_m = dw_col.filterDate(start, end)
    dates_m = ee.List(dates_dict[f"{m:02d}"])

    def make_daily(d):
        d_start = ee.Date(d)
        d_end = d_start.advance(1, "day")
        return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().toFloat().set("date", d)

    daily_col = ee.ImageCollection(dates_m.map(make_daily))
    comp_m = daily_col.mean().select(DW_PROB_BANDS).toFloat()
    m_comps_raw.append(comp_m)
    m_comps_bilinear.append(comp_m.resample("bilinear").reproject(crs=mb_proj))

# 3. Monthly Month 4: RAW (as in 11_extract) vs BILINEAR
img_m04_raw = m_comps_raw[3].select(['crops', 'trees'])
s_m04_raw = img_m04_raw.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

img_m04_bil = m_comps_bilinear[3].select(['crops', 'trees'])
s_m04_bil = img_m04_bil.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

print("\n=== 2. MÊS 04 PARA PT_010352 ===")
print(f"  RAW (como em 11_extract):      crops={s_m04_raw.get('crops'):.4f}, trees={s_m04_raw.get('trees'):.4f}")
print(f"  BILINEAR (resampled a mb_proj): crops={s_m04_bil.get('crops'):.4f}, trees={s_m04_bil.get('trees'):.4f}")

# 4. Annual mean of bilinear monthly composites vs Annual DW raw (without bilinear)
annual_from_bilinear_months = ee.ImageCollection(m_comps_bilinear).mean()
s_ann_from_bil = annual_from_bilinear_months.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

annual_raw = ee.ImageCollection(m_comps_raw).mean()
s_ann_raw = annual_raw.sampleRegions(collection=fc, projection=mb_proj, geometries=False).getInfo()['features'][0]['properties']

print("\n=== 3. COMPARAÇÃO ANUAL CONSOLIDADA ===")
print(f"  Média anual de meses RAW (sem bilinear):      crops={s_ann_raw.get('crops'):.4f}, trees={s_ann_raw.get('trees'):.4f}")
print(f"  Média anual de meses BILINEAR (com bilinear): crops={s_ann_from_bil.get('crops'):.4f}, trees={s_ann_from_bil.get('trees'):.4f}")
print(f"  Auth Anual não-normalizado:                   crops={s_auth.get('crops')*s_auth.get('probability_sum_before_normalization'):.4f}, trees={s_auth.get('trees')*s_auth.get('probability_sum_before_normalization'):.4f}")
