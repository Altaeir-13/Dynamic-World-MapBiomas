import json
import numpy as np
import pandas as pd

with open('scratch/pilot_bilinear_monthly_results.json', 'r', encoding='utf-8') as f:
    ext = json.load(f)
ext_by_id = {r['sample_id']: r for r in ext}

div_ids = ['PT_009805', 'PT_028047', 'PT_001215', 'PT_006638']
DW_CLASSES = [
    'water', 'trees', 'grass', 'flooded_vegetation', 'crops',
    'shrub_and_scrub', 'built', 'bare', 'snow_and_ice'
]

for sid in div_ids:
    p = ext_by_id[sid]
    auth_p = {c: float(p[f'auth_p_{c}']) for c in DW_CLASSES}
    
    # Bilinear monthly mean
    m_vecs = []
    for m in range(1, 13):
        if int(p.get(f'n_days_bil_m{m:02d}', 0)) > 0 and float(p.get(f'prob_sum_bil_m{m:02d}', 0)) > 0:
            raw = [float(p.get(f'{c}_bil_m{m:02d}', 0)) for c in DW_CLASSES]
            m_vecs.append(raw)
    mean_vec = np.mean(m_vecs, axis=0)
    norm_mean = mean_vec / np.sum(mean_vec)
    rec_p = {c: norm_mean[i] for i, c in enumerate(DW_CLASSES)}
    
    print(f"\n=== PONTO {sid} ===")
    print(f"Auth sum: {float(p['auth_raw_prob_sum']):.4f} | Rec sum: {np.sum(mean_vec):.4f}")
    auth_top2 = sorted(auth_p.items(), key=lambda x: x[1], reverse=True)[:2]
    rec_top2 = sorted(rec_p.items(), key=lambda x: x[1], reverse=True)[:2]
    print(f"Auth Top 2: {auth_top2[0][0]} ({auth_top2[0][1]:.4f}), {auth_top2[1][0]} ({auth_top2[1][1]:.4f}) [margem: {auth_top2[0][1]-auth_top2[1][1]:.4f}]")
    print(f"Rec  Top 2: {rec_top2[0][0]} ({rec_top2[0][1]:.4f}), {rec_top2[1][0]} ({rec_top2[1][1]:.4f}) [margem: {rec_top2[0][1]-rec_top2[1][1]:.4f}]")
    
    max_d = max(abs(auth_p[c] - rec_p[c]) for c in DW_CLASSES)
    print(f"Max diff: {max_d:.4f}")
