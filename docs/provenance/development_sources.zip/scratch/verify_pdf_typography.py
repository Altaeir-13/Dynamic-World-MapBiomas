import pdfplumber

def verify_typography(pdf_path):
    print("=" * 60)
    print("RELATÓRIO TÉCNICO DE VERIFICAÇÃO TIPOGRÁFICA DO PDF")
    print("=" * 60)
    
    with pdfplumber.open(pdf_path) as pdf:
        num_pages = len(pdf.pages)
        print(f"Total de Páginas: {num_pages} (Limite oficial: máximo 5 páginas)")
        
        for idx, page in enumerate(pdf.pages):
            page_w_mm = page.width * 0.352778
            page_h_mm = page.height * 0.352778
            print(f"\n--- PÁGINA {idx + 1} --- (Dimensões: {page_w_mm:.1f} × {page_h_mm:.1f} mm)")
            
            words = page.extract_words(extra_attrs=['size', 'fontname'])
            
            # Font size distribution
            sizes = {}
            for w in words:
                s = round(float(w['size']), 1)
                sizes[s] = sizes.get(s, 0) + 1
            print(f"Distribuição de tamanhos de fonte (tamanho -> contagem de palavras):")
            for s, c in sorted(sizes.items()):
                print(f"   {s} pt: {c} palavras")
                
            # Inspect Title on Page 1
            if idx == 0:
                title_words = [w for w in words if round(float(w['size']), 1) >= 13.5]
                if title_words:
                    print("\n[VERIFICAÇÃO TÍTULO]")
                    print(f"Texto: {' '.join(w['text'] for w in title_words[:12])}...")
                    print(f"Fonte: {title_words[0]['fontname']}")
                    print(f"Tamanho medido: {title_words[0]['size']:.2f} pt (Norma oficial: 14 pt, negrito)")
                    top_mm = title_words[0]['top'] * 0.352778
                    print(f"Posição vertical (topo do caractere até borda superior): {top_mm:.2f} mm (Norma oficial: 35 mm)")
                    
                auth_words = [w for w in words if 9.5 <= round(float(w['size']), 1) <= 10.5 and 'Autor' in w['text']]
                if auth_words:
                    print(f"[VERIFICAÇÃO AUTORES] Tamanho: {auth_words[0]['size']:.2f} pt, Fonte: {auth_words[0]['fontname']}")

                body_words = [w for w in words if round(float(w['size']), 1) == 10.0]
                if body_words:
                    print(f"[VERIFICAÇÃO TEXTO PRINCIPAL] Tamanho: {body_words[0]['size']:.2f} pt, Fonte: {body_words[0]['fontname']}")

            # Inspect Tables & Captions
            captions = [w for w in words if round(float(w['size']), 1) == 9.0]
            if captions:
                print(f"[VERIFICAÇÃO LEGENDAS] Encontradas {len(captions)} palavras com tamanho 9.0 pt (Norma oficial: 9 pt, negrito), Fonte: {captions[0]['fontname']}")

            tables = [w for w in words if round(float(w['size']), 1) == 7.5]
            if tables:
                print(f"[VERIFICAÇÃO TABELAS/REFERÊNCIAS] Encontradas {len(tables)} palavras com tamanho 7.5 pt, Fonte: {tables[0]['fontname']}")

if __name__ == '__main__':
    verify_typography('paper/manuscript_space_week_nordeste_2026_v3_1.pdf')
