import ee
import ee.oauth
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

ee.Initialize(project='dynamicworld-x-mapbiomas')
creds_args = ee.oauth.get_credentials_arguments()
creds = Credentials(
    None,
    refresh_token=creds_args['refresh_token'],
    token_uri=creds_args['token_uri'],
    client_id=creds_args['client_id'],
    client_secret=creds_args['client_secret'],
    scopes=['https://www.googleapis.com/auth/drive'],
)
drive_service = build('drive', 'v3', credentials=creds)
query = "trashed = false and name contains 'canonical_w2w_batch_'"
results = drive_service.files().list(q=query, pageSize=50, fields='files(id, name, createdTime, size)').execute()
files = results.get('files', [])
print(f'Found {len(files)} files on Drive:')
for f in files:
    print(f"  {f['name']:35} | {f.get('size')} bytes | {f.get('createdTime')}")
