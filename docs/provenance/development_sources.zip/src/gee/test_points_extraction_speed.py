import time
import json
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

pi_feat = next(f for f in d["features"] if f["properties"]["state"] == "PI")
pi_geom = ee.Geometry(pi_feat["geometry"])

# 1. Generate 5,000 random points in PI
t0 = time.time()
pts = ee.FeatureCollection.randomPoints(region=pi_geom, points=5000, seed=25)
print(f"randomPoints(5000) generated in {time.time() - t0:.2f}s!")

# 2. Extract MapBiomas at those 5,000 points
MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")

t1 = time.time()
pts_with_mb = mb.reduceRegions(
    collection=pts,
    reducer=ee.Reducer.first(),
    scale=10
)
# evaluate in python
info = pts_with_mb.limit(5).getInfo()
print(f"MapBiomas extracted at 5,000 points in {time.time() - t1:.2f}s!")
print("Sample feature:", info["features"][0])
