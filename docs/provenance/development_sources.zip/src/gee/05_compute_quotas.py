"""
05_compute_quotas.py — Cálculo das Quotas Amostrais para os 16 Estratos
========================================================================
Calcula as quotas para a amostra principal (N = 20.000) e robustez (N = 40.000)
usando o método Hamilton / largest-remainder.

Estratos: {MA, TO, PI, BA} x {AA, AN, NA, NN} = 16 estratos.
Base: n_min = 400 por estrato ativo (16 * 400 = 6.400).
Restante: 20.000 - 6.400 = 13.600 proporcional à área territorial W_h.
Robustez: n_h_robust = 2 * n_h_main (sum = 40.000).

Salva: tables/sampling_quotas.csv
"""

from __future__ import annotations

import math
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"
W2W_CSV = DATA_PROC / "wall_to_wall_summary.csv"
OUT_CSV = TABLES_DIR / "sampling_quotas.csv"


def compute_quotas() -> pd.DataFrame:
    TABLES_DIR.mkdir(parents=True, exist_ok=True)
    df_w2w = pd.read_csv(W2W_CSV)

    # State rows (exclude MATOPIBA)
    df_states = df_w2w[df_w2w["region"] != "MATOPIBA"].copy()

    ordered_states = ["MA", "TO", "PI", "BA"]
    regimes = ["AA", "AN", "NA", "NN"]

    total_eligible_ha = df_w2w[df_w2w["region"] == "MATOPIBA"]["eligible_area_ha"].values[0]
    total_eligible_m2 = total_eligible_ha * 10000.0

    rows = []
    for st in ordered_states:
        st_row = df_states[df_states["region"] == st].iloc[0]
        for reg in regimes:
            area_ha = float(st_row[f"{reg}_area_ha"])
            area_m2 = area_ha * 10000.0
            w_h = area_m2 / total_eligible_m2
            n_cells = area_m2 / 100.0  # 10m x 10m pixels

            rows.append({
                "state": st,
                "regime": reg,
                "stratum_id": f"{st}_{reg}",
                "area_ha": area_ha,
                "area_m2": area_m2,
                "W_h": w_h,
                "N_h": int(round(n_cells)),
            })

    df = pd.DataFrame(rows)

    # Hamilton / largest-remainder allocation
    N_TOTAL = 20000
    N_MIN = 400
    N_STRATA = len(df)
    BASE_POINTS = N_STRATA * N_MIN  # 16 * 400 = 6400
    REMAINDER_POINTS = N_TOTAL - BASE_POINTS  # 13600

    # Quotas base + fractional
    df["raw_remainder"] = df["W_h"] * REMAINDER_POINTS
    df["integer_part"] = df["raw_remainder"].apply(math.floor).astype(int)
    df["fractional_part"] = df["raw_remainder"] - df["integer_part"]

    allocated_remainder = df["integer_part"].sum()
    points_left = REMAINDER_POINTS - allocated_remainder

    # Sort by fractional part descending, with deterministic tie-breaker on stratum_id
    df = df.sort_values(by=["fractional_part", "stratum_id"], ascending=[False, True]).reset_index(drop=True)

    # Distribute the leftover points to top `points_left` strata
    df["extra_point"] = 0
    df.loc[:points_left - 1, "extra_point"] = 1

    df["n_main"] = N_MIN + df["integer_part"] + df["extra_point"]
    df["n_robust"] = 2 * df["n_main"]

    # Re-sort into canonical order: State (MA, TO, PI, BA) then Regime (AA, AN, NA, NN)
    state_cat = pd.Categorical(df["state"], categories=ordered_states, ordered=True)
    reg_cat = pd.Categorical(df["regime"], categories=regimes, ordered=True)
    df["state_order"] = state_cat
    df["reg_order"] = reg_cat
    df = df.sort_values(by=["state_order", "reg_order"]).reset_index(drop=True)

    # Select output columns requested by user: state, regime, area_m2, area_ha, W_h, N_h, n_main, n_robust
    out_cols = ["state", "regime", "area_m2", "area_ha", "W_h", "N_h", "n_main", "n_robust"]
    df_out = df[out_cols].copy()

    # Formatter for W_h
    df_out["W_h"] = df_out["W_h"].round(8)

    df_out.to_csv(OUT_CSV, index=False, encoding="utf-8")
    print(f"Tabela de quotas salva com sucesso em: {OUT_CSV}")

    print("\n" + "=" * 80)
    print("TABELA DE QUOTAS AMOSTRAIS (16 ESTRATOS):")
    print("=" * 80)
    print(df_out.to_string(index=False))
    print("=" * 80)
    print(f"Total n_main: {df_out['n_main'].sum()} (Target: 20000)")
    print(f"Total n_robust: {df_out['n_robust'].sum()} (Target: 40000)")
    print(f"Total W_h: {df_out['W_h'].sum():.6f} (Target: 1.000000)")
    print("=" * 80)

    assert df_out["n_main"].sum() == 20000, f"sum(n_main) != 20000: {df_out['n_main'].sum()}"
    assert df_out["n_robust"].sum() == 40000, f"sum(n_robust) != 40000: {df_out['n_robust'].sum()}"
    assert (df_out["n_main"] >= 400).all(), "Algum estrato tem quota menor que 400!"

    return df_out


if __name__ == "__main__":
    compute_quotas()
