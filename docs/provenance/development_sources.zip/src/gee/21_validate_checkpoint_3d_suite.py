"""
21_validate_checkpoint_3d_suite.py — Validação Integral e Hashing da Suíte Checkpoint 3D
========================================================================================
Valida com rigor científico todos os 10 artefatos da suíte Checkpoint 3D:
  1. data/processed/canonical_wall_to_wall_by_slice.csv
  2. data/processed/wall_to_wall_summary.csv
  3. tables/sampling_frame_10m.csv
  4. tables/sampling_quotas.csv
  5. tables/slice_sampling_allocation_final.csv
  6. data/processed/master_sampling_points.csv
  7. tables/pagination_invariance_audit.csv
  8. data/processed/dw_monthly.parquet
  9. data/processed/samples_annual.parquet
 10. data/processed/samples_annual.csv

Gera hashes SHA-256 em tables/checkpoint_3d_checksums.sha256.
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

import numpy as np
import pandas as pd

DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"

DELIVERABLES = {
    "D1_wall_to_wall_slices": DATA_PROC / "canonical_wall_to_wall_by_slice.csv",
    "D2_wall_to_wall_summary": DATA_PROC / "wall_to_wall_summary.csv",
    "D3_sampling_frame": TABLES_DIR / "sampling_frame_10m.csv",
    "D4_sampling_quotas": TABLES_DIR / "sampling_quotas.csv",
    "D5_sampling_allocation": TABLES_DIR / "slice_sampling_allocation_final.csv",
    "D6_master_points": DATA_PROC / "master_sampling_points.csv",
    "D7_invariance_audit": TABLES_DIR / "pagination_invariance_audit.csv",
    "D8_dw_monthly": DATA_PROC / "dw_monthly.parquet",
    "D9_samples_annual_parquet": DATA_PROC / "samples_annual.parquet",
    "D10_samples_annual_csv": DATA_PROC / "samples_annual.csv",
}

CHECKSUMS_FILE = TABLES_DIR / "checkpoint_3d_checksums.sha256"


def compute_sha256(file_path: Path) -> str:
    sha = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            sha.update(chunk)
    return sha.hexdigest()


def validate_checkpoint_3d():
    print("=" * 80)
    print("VALIDAÇÃO INTEGRAL DA SUÍTE DE ENTREGÁVEIS DO CHECKPOINT 3D")
    print("=" * 80)

    # 1. Existência e Tamanho dos Arquivos
    print("\n1. Verificando existência de todos os 10 entregáveis...")
    missing = []
    for label, path in DELIVERABLES.items():
        if not path.exists():
            missing.append(f"{label}: {path}")
        else:
            sz_mb = path.stat().st_size / (1024 * 1024)
            print(f"  [OK] {label:<25} ({sz_mb:8.2f} MB) -> {path.name}")

    if missing:
        raise FileNotFoundError(f"Entregáveis ausentes:\n" + "\n".join(missing))

    # 2. Validação da Master Sample
    print("\n2. Validando Master Sample (D6)...")
    df_master = pd.read_csv(DELIVERABLES["D6_master_points"], keep_default_na=False)
    assert len(df_master) == 40000, f"D6: Esperado 40.000 pontos, obtido {len(df_master)}"
    assert set(df_master["regime"].unique()) == {"AA", "AN", "NA", "NN"}
    assert df_master["slice_id"].nunique() == 182
    print(f"  [PASS] 40.000 pontos, 182 fatias ativas, 4 regimes consolidados.")

    # 3. Validação do Teste de Invariância de Paginação (D7)
    print("\n3. Validando Auditoria de Invariância de Paginação (D7)...")
    df_inv = pd.read_csv(DELIVERABLES["D7_invariance_audit"])
    assert len(df_inv) == 1000, f"D7: Esperado 1.000 pontos, obtido {len(df_inv)}"
    assert (df_inv["class_mode_a"] == df_inv["class_mode_c"]).all(), "Mismatch em class_mode (A vs C)"
    assert (df_inv["class_mode_b"] == df_inv["class_mode_c"]).all(), "Mismatch em class_mode (B vs C)"
    assert (df_inv["crop_mode_a"] == df_inv["crop_mode_c"]).all(), "Mismatch em crop_mode (A vs C)"
    assert (df_inv["crop_mode_b"] == df_inv["crop_mode_c"]).all(), "Mismatch em crop_mode (B vs C)"
    assert (df_inv["months_mode_a"] == df_inv["months_mode_c"]).all(), "Mismatch em months_mode (A vs C)"
    assert (df_inv["months_mode_b"] == df_inv["months_mode_c"]).all(), "Mismatch em months_mode (B vs C)"
    assert (df_inv["max_prob_diff_ac"] < 1e-6).all(), "Max prob diff AC > 1e-6"
    assert (df_inv["max_prob_diff_bc"] < 1e-6).all(), "Max prob diff BC > 1e-6"
    assert (df_inv["dist_dw_diff_ac"] == 0.0).all(), "Dist DW diff AC != 0"
    assert (df_inv["dist_mb_diff_ac"] == 0.0).all(), "Dist MB diff AC != 0"
    print(f"  [PASS] 1.000 pontos auditados com 100.000% de invariância estrita.")

    # 4. Validação dos Conjuntos Analíticos Anuais (D9, D10)
    print("\n4. Validando Conjunto Analítico Anual (D9, D10)...")
    df_annual_pq = pd.read_parquet(DELIVERABLES["D9_samples_annual_parquet"])
    df_annual_csv = pd.read_csv(DELIVERABLES["D10_samples_annual_csv"], keep_default_na=False)

    assert len(df_annual_pq) == 40000, f"D9: Esperado 40.000 linhas, obtido {len(df_annual_pq)}"
    assert len(df_annual_csv) == 40000, f"D10: Esperado 40.000 linhas, obtido {len(df_annual_csv)}"
    assert len(df_annual_pq.columns) == 51, f"D9: Esperado 51 colunas, obtido {len(df_annual_pq.columns)}"
    assert len(df_annual_csv.columns) == 51, f"D10: Esperado 51 colunas, obtido {len(df_annual_csv.columns)}"

    # Paridade absoluta de coordenadas e IDs
    assert (df_annual_pq["sample_id"] == df_master["sample_id"]).all(), "IDs divergem da Master Sample!"
    assert np.allclose(df_annual_pq["lat"], df_master["lat"], atol=1e-7), "Latitude diverge da Master Sample!"
    assert np.allclose(df_annual_pq["lon"], df_master["lon"], atol=1e-7), "Longitude diverge da Master Sample!"

    # Paridade de regime com a Master Sample
    regime_mismatches = (df_annual_pq["regime"] != df_master["regime"]).sum()
    print(f"  Mismatches de regime (D9 vs Master): {regime_mismatches} / 40.000")
    assert regime_mismatches == 0, f"D9 possui {regime_mismatches} divergências de regime com a Master!"

    # Elegibilidade temporal estrita (n_valid_months >= 8)
    invalid_temporal = (df_annual_pq["n_valid_months"] < 8).sum()
    print(f"  Pontos com n_valid_months < 8: {invalid_temporal} / 40.000")
    assert invalid_temporal == 0, f"D9 possui {invalid_temporal} pontos com menos de 8 meses válidos!"

    # Verificação de ausência de nulos em métricas chave
    null_cols = [
        "entropy_annual", "entropy_temporal_mean", "entropy_monthly_mean",
        "jsd_temporal", "stability", "distance_edge_mb_m", "distance_edge_dw_m",
        "distance_edge_min_m", "top1_probability", "top2_margin"
    ]
    for c in null_cols:
        n_null = df_annual_pq[c].isna().sum()
        assert n_null == 0, f"Coluna {c} possui {n_null} nulos!"

    # Intervalos matemáticos
    assert (df_annual_pq["entropy_annual"] >= 0).all() and (df_annual_pq["entropy_annual"] <= 1.0 + 1e-6).all()
    assert (df_annual_pq["jsd_temporal"] >= 0).all()
    assert (df_annual_pq["stability"] >= 0).all() and (df_annual_pq["stability"] <= 1.0).all()
    assert (df_annual_pq["distance_edge_min_m"] >= 0).all() and (df_annual_pq["distance_edge_min_m"] <= 250.0).all()
    print(f"  [PASS] Conjunto Anual 100% verificado: 40.000 linhas, 51 colunas, zero nulos.")

    # 5. Validação da Série Mensal (D8)
    print("\n5. Validando Série Mensal (D8)...")
    df_monthly = pd.read_parquet(DELIVERABLES["D8_dw_monthly"])
    assert len(df_monthly) == 480000, f"D8: Esperado 480.000 linhas, obtido {len(df_monthly)}"
    assert len(df_monthly.columns) == 15, f"D8: Esperado 15 colunas, obtido {len(df_monthly.columns)}"
    assert df_monthly["sample_id"].nunique() == 40000, "D8: Número de sample_ids único diverge de 40.000"
    assert (df_monthly.groupby("sample_id").size() == 12).all(), "D8: Cada ponto deve possuir exatamente 12 meses"
    print(f"  [PASS] Série Mensal 100% verificada: 480.000 linhas, 15 colunas, 12 meses por ponto.")

    # 6. Cálculo dos Hashes Criptográficos SHA-256
    print("\n6. Gerando Hashes Criptográficos SHA-256...")
    checksum_lines = []
    print("-" * 80)
    print(f"{'Entregável':<30} {'SHA-256 Checksum':<64}")
    print("-" * 80)
    for label, path in DELIVERABLES.items():
        sha = compute_sha256(path)
        print(f"{path.name:<30} {sha}")
        checksum_lines.append(f"{sha}  {path.name}")
    print("-" * 80)

    with open(CHECKSUMS_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(checksum_lines) + "\n")
    print(f"Hashes salvos em: {CHECKSUMS_FILE}")

    print("\n" + "=" * 80)
    print("TODOS OS 10 ENTREGÁVEIS DO CHECKPOINT 3D APROVADOS COM SUCESSO!")
    print("=" * 80)


if __name__ == "__main__":
    validate_checkpoint_3d()
