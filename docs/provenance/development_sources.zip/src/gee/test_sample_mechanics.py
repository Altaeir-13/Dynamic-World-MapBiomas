import time
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

# Let's test sampling 500 points from AA stratum in PI
PI_BBOX = ee.Geometry.BBox(-46.0, -10.0, -44.0, -8.0)

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_crop = mb.remap([19, 36], [1, 1], 0)

# DW single month or small collection
dw = (
    ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
    .filterBounds(PI_BBOX)
    .filterDate("2025-06-01", "2025-07-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
    .mean()
)
dw_crop = dw.select("crops").eq(dw.reduce(ee.Reducer.max()))

# AA stratum
aa = mb_crop.eq(1).And(dw_crop.eq(1))
aa_masked = ee.Image(1).rename("stratum").updateMask(aa)

t0 = time.time()
print("Testing aa_masked.sample(numPixels=500, scale=10, geometries=True)...")
pts = aa_masked.sample(
    region=PI_BBOX,
    scale=10,
    numPixels=500,
    seed=25,
    geometries=True
)
pts_info = pts.limit(5).getInfo()
print(f"Sample completed in {time.time() - t0:.2f}s!")
print(f"Count: {pts.size().getInfo()}, first point: {pts_info['features'][0]['geometry']}")
