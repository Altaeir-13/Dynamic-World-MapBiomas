import hashlib
import json
from pathlib import Path
import pandas as pd
from shapely.geometry import box, shape

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_REF = BASE_DIR / "data" / "reference"
TABLES_DIR = BASE_DIR / "tables"
TABLES_DIR.mkdir(parents=True, exist_ok=True)

MANIFEST_CSV = TABLES_DIR / "canonical_w2w_batch_manifest.csv"

# Load geometric slices
with open(DATA_REF / "matopiba_states.geojson", "r", encoding="utf-8") as f:
    states_data = json.load(f)

step = 0.75
slices = []

for feat in states_data["features"]:
    st = feat["properties"].get("state") or feat["properties"].get("sigla") or feat["properties"].get("name")
    shp = shape(feat["geometry"])
    min_x, min_y, max_x, max_y = shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                s_id = f"{st}_x{ix:02d}_y{iy:02d}"
                # Exclude the 1 geometric slice with 0 eligible population (MA_x01_y08)
                if s_id != "MA_x01_y08":
                    slices.append({
                        "state": st,
                        "slice_id": s_id,
                    })

df_slices = pd.DataFrame(slices)
assert len(df_slices) == 182, f"Expected 182 slices, found {len(df_slices)}"
assert df_slices["slice_id"].nunique() == 182, "Duplicates found!"

# Sort deterministically by state, slice_id
df_slices = df_slices.sort_values(by=["state", "slice_id"]).reset_index(drop=True)
df_slices["slice_order"] = range(1, 183)

# Partition into 10 balanced batches: 2 of 19, 8 of 18 (total 182)
batch_sizes = [19, 19, 18, 18, 18, 18, 18, 18, 18, 18]
assert sum(batch_sizes) == 182
assert len(batch_sizes) == 10

batch_ids = []
n_slices_batch = []
for i, size in enumerate(batch_sizes):
    b_name = f"canonical_w2w_batch_{i:02d}"
    batch_ids.extend([b_name] * size)
    n_slices_batch.extend([size] * size)

df_slices["batch_id"] = batch_ids
df_slices["n_slices_batch"] = n_slices_batch

# Reorder columns as requested: batch_id, state, slice_id, slice_order, n_slices_batch
manifest = df_slices[["batch_id", "state", "slice_id", "slice_order", "n_slices_batch"]]
manifest.to_csv(MANIFEST_CSV, index=False)

# Compute SHA-256
with open(MANIFEST_CSV, "rb") as f:
    sha = hashlib.sha256(f.read()).hexdigest()

print("=" * 80)
print("CANONICAL W2W BATCH MANIFEST CREATED SUCCESSFULLY")
print("=" * 80)
print(f"Path: {MANIFEST_CSV}")
print(f"Total slices: {len(manifest)}")
print(f"Unique slice_id: {manifest['slice_id'].nunique()}")
print(f"Unique batch_id: {manifest['batch_id'].nunique()}")
print(f"SHA-256: {sha}")
print("\nBatch summary:")
print(manifest.groupby(["batch_id", "n_slices_batch"]).size().reset_index(name="count"))
print("\nFirst 10 rows:")
print(manifest.head(10))
print("\nLast 10 rows:")
print(manifest.tail(10))
