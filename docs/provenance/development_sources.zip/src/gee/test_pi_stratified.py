import time
import json
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

pi_feat = next(f for f in d["features"] if f["properties"]["state"] == "PI")
pi_geom = ee.Geometry(pi_feat["geometry"])

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

dw_col = (
    ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
    .filterBounds(pi_geom)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)
m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()
dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
dw_max = dw_10m.reduce(ee.Reducer.max())
dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

eligible_mask = valid_mb_mask.And(dw_crop.mask())

regime_img = (
    ee.Image(0)
    .where(mb_crop.eq(1).And(dw_crop.eq(1)), 1)
    .where(mb_crop.eq(1).And(dw_crop.eq(0)), 2)
    .where(mb_crop.eq(0).And(dw_crop.eq(1)), 3)
    .where(mb_crop.eq(0).And(dw_crop.eq(0)), 4)
    .rename("regime")
    .updateMask(eligible_mask)
)

# PI Quotas: AA=892, AN=1218, NA=1058, NN=3080
quotas = [892, 1218, 1058, 3080]
print(f"Sampling PI with exact quotas: {quotas} (total: {sum(quotas)})...")
t0 = time.time()
pts_strat = regime_img.stratifiedSample(
    numPoints=0,
    classBand="regime",
    region=pi_geom,
    scale=10,
    seed=25,
    classValues=[1, 2, 3, 4],
    classPoints=quotas,
    geometries=True,
    tileScale=8
)

# We can retrieve in chunks or get size
cnt = pts_strat.size().getInfo()
print(f"Sample completed in {time.time() - t0:.2f}s! Total points collected: {cnt}")
