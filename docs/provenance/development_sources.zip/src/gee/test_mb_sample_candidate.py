import time
import json
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

pi_feat = next(f for f in d["features"] if f["properties"]["state"] == "PI")
pi_geom = ee.Geometry(pi_feat["geometry"])

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

# Test: Sample 3,000 candidate points from MB crop == 1
t0 = time.time()
print("Sampling 3,000 points from mb_crop == 1 in PI...")
mb_crop_only = ee.Image(1).rename("mb_crop").updateMask(mb_crop.eq(1))
pts_mb = mb_crop_only.sample(
    region=pi_geom,
    scale=10,
    numPixels=3000,
    seed=25,
    geometries=True
)
pts_list = pts_mb.getInfo()["features"]
print(f"Sampled {len(pts_list)} points from MapBiomas crop in {time.time() - t0:.2f}s!")
