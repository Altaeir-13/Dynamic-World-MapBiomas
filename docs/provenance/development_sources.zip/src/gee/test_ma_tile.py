import ee
import json
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_REF = BASE_DIR / "data" / "reference"
STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
    states_data = json.load(f)

geom = None
for feat in states_data["features"]:
    if feat["properties"]["state"] == "MA":
        geom = ee.Geometry(feat["geometry"])
        break

bounds = geom.bounds().getInfo()["coordinates"][0]
min_x = min(p[0] for p in bounds)
max_x = max(p[0] for p in bounds)
min_y = min(p[1] for p in bounds)
max_y = max(p[1] for p in bounds)

print(f"MA bounds: X=[{min_x:.3f}, {max_x:.3f}], Y=[{min_y:.3f}, {max_y:.3f}]")

# Let's test a quadrant (1/4 of MA)
mid_x = (min_x + max_x) / 2.0
mid_y = (min_y + max_y) / 2.0

quad = ee.Geometry.BBox(min_x, min_y, mid_x, mid_y)

DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"

mb = ee.Image(MB_ASSET).select(MB_BAND)
is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterBounds(quad)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)

m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()

# Test WITHOUT explicit reproject vs WITH explicit reproject
dw_max = annual_dw.reduce(ee.Reducer.max())
dw_crop = annual_dw.select("crops").eq(dw_max).rename("dw_crop")
eligible_mask = valid_mb_mask.And(dw_crop.mask())

pixel_area_ha = ee.Image.pixelArea().divide(10000.0)
area_stack = ee.Image.cat([
    pixel_area_ha.updateMask(eligible_mask).rename("area_eligible_ha"),
    pixel_area_ha.updateMask(is_excluded.updateMask(mb.mask())).rename("area_excluded_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(1).And(dw_crop.eq(1)).updateMask(eligible_mask)).rename("area_AA_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(1).And(dw_crop.eq(0)).updateMask(eligible_mask)).rename("area_AN_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(0).And(dw_crop.eq(1)).updateMask(eligible_mask)).rename("area_NA_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(0).And(dw_crop.eq(0)).updateMask(eligible_mask)).rename("area_NN_ha"),
]).clip(geom)

t0 = time.time()
print("Starting reduceRegion on 1 quadrant of MA at scale=30...")
stats = area_stack.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=quad,
    scale=30,
    maxPixels=1e13,
    tileScale=8,
).getInfo()
print(f"Done in {time.time() - t0:.2f}s: {stats}")
