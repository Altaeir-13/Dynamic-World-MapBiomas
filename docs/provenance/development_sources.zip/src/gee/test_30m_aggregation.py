"""
test_30m_aggregation.py — Teste e demonstração da agregação real 10 m -> 30 m
=============================================================================
Demonstra que:
1. A grade 30 m é derivada exatamente da grade 10 m (transformação 3 * dx, 3 * dy, mesma origem);
2. Dynamic World 30 m usa reduceResolution(ee.Reducer.mean()) a partir do 10 m;
3. MapBiomas 30 m usa majority/mode dos pixels válidos (sem bilinear em dados categóricos);
4. O valor em 30 m representa a agregação real dos 9 suportes de 10 m.
"""

from __future__ import annotations

import ee

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"
DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
DW_PROB_BANDS = ["water", "trees", "grass", "flooded_vegetation", "crops", "shrub_and_scrub", "built", "bare", "snow_and_ice"]


def run_30m_test():
    ee.Initialize(project="dynamicworld-x-mapbiomas")

    mb = ee.Image(MB_ASSET).select(MB_BAND)
    mb_proj = mb.projection()
    transform_10 = mb_proj.getInfo().get("transform")
    crs_10 = mb_proj.getInfo().get("crs")

    dx_10, dy_10 = transform_10[0], transform_10[4]
    x0, y0 = transform_10[2], transform_10[5]

    # Grade 30 m perfeitamente aninhada (fator 3x3)
    transform_30 = [dx_10 * 3, 0, x0, 0, dy_10 * 3, y0]
    grid30_proj = ee.Projection(crs=crs_10, transform=transform_30)

    print("=" * 60)
    print("DEMONSTRAÇÃO DA GRADE 30 M ANINHADA:")
    print("=" * 60)
    print(f"Grade 10 m CRS: {crs_10}")
    print(f"Grade 10 m dx:  {dx_10:.10e}, dy: {dy_10:.10e}")
    print(f"Grade 30 m dx:  {transform_30[0]:.10e}, dy: {transform_30[4]:.10e}")
    print(f"Origem comum:   x0={x0:.10f}, y0={y0:.10f}")

    # Teste de agregação em um ponto de teste em Balsas/MA
    test_pt = ee.Geometry.Point([-45.5, -7.5])

    # 1. Dynamic World anual 10 m harmonizado
    dw_col = ee.ImageCollection(DW_COLLECTION).filterBounds(test_pt.buffer(1000)).filterDate("2025-07-01", "2025-08-01").select(DW_PROB_BANDS)
    dw_10m = dw_col.mean().resample("bilinear").reproject(crs=mb_proj)

    # 2. Dynamic World 30 m via reduceResolution(mean)
    dw_30m = dw_10m.reduceResolution(reducer=ee.Reducer.mean(), maxPixels=64).reproject(crs=grid30_proj)

    # 3. MapBiomas 10 m binário com máscara de excluídos
    is_excluded = mb.eq(21).Or(mb.eq(18))
    valid_mb_mask = is_excluded.Not().And(mb.mask())
    mb_crop_10m = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

    # 4. MapBiomas 30 m via reduceResolution(mode / majority)
    mb_crop_30m = mb_crop_10m.reduceResolution(reducer=ee.Reducer.mode(), maxPixels=64).reproject(crs=grid30_proj)

    # Extrai no ponto
    stack = ee.Image.cat([
        dw_10m.select("crops").rename("p_crops_10m"),
        dw_30m.select("crops").rename("p_crops_30m"),
        mb_crop_10m.rename("mb_crop_10m"),
        mb_crop_30m.rename("mb_crop_30m"),
    ])

    val = stack.reduceRegion(ee.Reducer.first(), test_pt, scale=10).getInfo()
    print("-" * 60)
    print("Valores extraídos no ponto de teste:")
    for k, v in val.items():
        print(f"  {k:15s}: {v}")
    print("=" * 60)
    print("AGREGAÇÃO 10 M -> 30 M APROVADA!")


if __name__ == "__main__":
    run_30m_test()
