import json
import hashlib
from pathlib import Path
import pandas as pd
from shapely.geometry import box, shape

DATA_REF = Path("data/reference")
TABLES_DIR = Path("tables")
TABLES_DIR.mkdir(parents=True, exist_ok=True)

with open(DATA_REF / "matopiba_states.geojson", "r", encoding="utf-8") as f:
    states_data = json.load(f)

step = 0.75
slices = []

# Ordered states: MA, TO, PI, BA or alphabetical? User requested: "state, slice_id"
for feat in states_data["features"]:
    st = feat["properties"].get("state") or feat["properties"].get("sigla") or feat["properties"].get("name")
    shp = shape(feat["geometry"])
    min_x, min_y, max_x, max_y = shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                s_id = f"{st}_x{ix:02d}_y{iy:02d}"
                slices.append({
                    "state": st,
                    "slice_id": s_id,
                })

df_slices = pd.DataFrame(slices)
print(f"Total slices found: {len(df_slices)}")
print(df_slices.groupby("state").count())
