"""
split_batch_08a1.py — Deterministic split of failed batch 08a1 into 08a1a and 08a1b
====================================================================================
Rule 5:
SE FAILED:
leia o error_message completo.
Se o erro for:
Computation timed out.
divida SOMENTE aquele batch ao meio de forma determinística,
mantendo as mesmas slices e o mesmo raster canônico.
"""
from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent.parent
MANIFEST_CSV = BASE_DIR / "tables" / "canonical_w2w_batch_manifest.csv"

def split_manifest():
    manifest = pd.read_csv(MANIFEST_CSV)
    print(f"Original manifest rows: {len(manifest)}")
    print(f"Original unique slice_ids: {manifest['slice_id'].nunique()}")

    target_batch = "canonical_w2w_batch_08a1"
    sub_a = "canonical_w2w_batch_08a1a"
    sub_b = "canonical_w2w_batch_08a1b"

    sub_df = manifest[manifest["batch_id"] == target_batch].copy().sort_values("slice_order")
    assert len(sub_df) == 4, f"Expected 4 slices for {target_batch}, got {len(sub_df)}"

    n = len(sub_df)
    n_half = n // 2  # 2 slices each
    df_a = sub_df.iloc[:n_half].copy()
    df_b = sub_df.iloc[n_half:].copy()

    df_a["batch_id"] = sub_a
    df_a["n_slices_batch"] = len(df_a)
    df_b["batch_id"] = sub_b
    df_b["n_slices_batch"] = len(df_b)

    new_rows = []
    for _, row in manifest.iterrows():
        if row["batch_id"] == target_batch:
            continue
        new_rows.append(row.to_dict())

    for _, r in df_a.iterrows():
        new_rows.append(r.to_dict())
    for _, r in df_b.iterrows():
        new_rows.append(r.to_dict())

    df_new = pd.DataFrame(new_rows).sort_values("slice_order").reset_index(drop=True)
    print(f"New manifest rows: {len(df_new)}")
    print(f"Unique slice_ids: {df_new['slice_id'].nunique()}")

    assert len(df_new) == 182, f"Expected 182 rows, got {len(df_new)}"
    assert df_new["slice_id"].nunique() == 182, f"Expected 182 unique slices, got {df_new['slice_id'].nunique()}"
    assert set(df_new["slice_id"]) == set(manifest["slice_id"]), "Slice set mismatch!"

    df_new.to_csv(MANIFEST_CSV, index=False)
    print("Updated tables/canonical_w2w_batch_manifest.csv successfully.")
    print("\nNew slices in 08a1a and 08a1b:")
    print(df_new[df_new["batch_id"].isin([sub_a, sub_b])][["batch_id", "state", "slice_id", "slice_order", "n_slices_batch"]].to_string())

if __name__ == "__main__":
    split_manifest()
