"""Deterministic split of failed batches (06, 07, 08, 09) into a/b sub-batches."""
import pandas as pd

manifest_path = 'tables/canonical_w2w_batch_manifest.csv'
manifest = pd.read_csv(manifest_path)
print(f"Original manifest rows: {len(manifest)}")

split_map = {
    'canonical_w2w_batch_06': ('canonical_w2w_batch_06a', 'canonical_w2w_batch_06b'),
    'canonical_w2w_batch_07': ('canonical_w2w_batch_07a', 'canonical_w2w_batch_07b'),
    'canonical_w2w_batch_08': ('canonical_w2w_batch_08a', 'canonical_w2w_batch_08b'),
    'canonical_w2w_batch_09': ('canonical_w2w_batch_09a', 'canonical_w2w_batch_09b'),
}

new_rows = []
for _, row in manifest.iterrows():
    b_id = row['batch_id']
    if b_id in split_map:
        continue
    new_rows.append(row.to_dict())

for orig_b, (sub_a, sub_b) in split_map.items():
    sub_df = manifest[manifest['batch_id'] == orig_b].copy().sort_values('slice_order')
    n = len(sub_df)
    n_half = n // 2
    df_a = sub_df.iloc[:n_half].copy()
    df_b = sub_df.iloc[n_half:].copy()
    df_a['batch_id'] = sub_a
    df_a['n_slices_batch'] = len(df_a)
    df_b['batch_id'] = sub_b
    df_b['n_slices_batch'] = len(df_b)
    for _, r in df_a.iterrows():
        new_rows.append(r.to_dict())
    for _, r in df_b.iterrows():
        new_rows.append(r.to_dict())

df_new = pd.DataFrame(new_rows).sort_values('slice_order').reset_index(drop=True)
print(f"New manifest rows: {len(df_new)}")
print(f"Unique slice_ids: {df_new['slice_id'].nunique()}")
print("New batch distribution:")
print(df_new['batch_id'].value_counts())

# Verification:
assert len(df_new) == 182, f"Expected 182 rows, got {len(df_new)}"
assert df_new['slice_id'].nunique() == 182, f"Expected 182 unique slices, got {df_new['slice_id'].nunique()}"
assert set(df_new['slice_id']) == set(manifest['slice_id']), "Slice set mismatch!"

# Overwrite manifest
df_new.to_csv(manifest_path, index=False)
print("Updated tables/canonical_w2w_batch_manifest.csv successfully.")
