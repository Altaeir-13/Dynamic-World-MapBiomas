"""
15_qa_checkpoint_3b.py — Bateria Completa de Validação e QA (Checkpoint 3B)
===========================================================================
Executa todos os 19 testes obrigatórios da Seção J e gera estatísticas completas.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"
CONFIG_DIR = BASE_DIR / "config"

DW_MONTHLY_PARQUET = DATA_PROC / "dw_monthly.parquet"
SAMPLES_ANNUAL_PARQUET = DATA_PROC / "samples_annual.parquet"
SAMPLES_ANNUAL_CSV = DATA_PROC / "samples_annual.csv"
MASTER_POINTS_CSV = DATA_PROC / "master_sampling_points.csv"
ALLOC_FINAL_CSV = TABLES_DIR / "slice_sampling_allocation_final.csv"
FRAME_10M_CSV = TABLES_DIR / "sampling_frame_10m.csv"
QUOTAS_CSV = TABLES_DIR / "sampling_quotas.csv"

DW_PROB_BANDS = [
    "water", "trees", "grass", "flooded_vegetation", "crops",
    "shrub_and_scrub", "built", "bare", "snow_and_ice"
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def main():
    print("=" * 80)
    print("BATERIA DE AUDITORIA E QA FORMAL — CHECKPOINT 3B")
    print("=" * 80)

    # 1. Carregar datasets
    df_pts = pd.read_csv(MASTER_POINTS_CSV, keep_default_na=False)
    df_ann = pd.read_parquet(SAMPLES_ANNUAL_PARQUET)
    df_m = pd.read_parquet(DW_MONTHLY_PARQUET)
    df_alloc = pd.read_csv(ALLOC_FINAL_CSV, keep_default_na=False)
    df_frame = pd.read_csv(FRAME_10M_CSV, keep_default_na=False)
    df_q = pd.read_csv(QUOTAS_CSV, keep_default_na=False)

    print(f"Master points: {len(df_pts):,} linhas")
    print(f"Samples annual: {len(df_ann):,} linhas, {len(df_ann.columns)} colunas")
    print(f"DW monthly:     {len(df_m):,} linhas, {len(df_m.columns)} colunas")

    results = {}

    # Test 1: População completa com pi > 0
    min_pi = df_alloc["pi_robust_hs"].min()
    zero_pi_count = (df_alloc["pi_robust_hs"] <= 0).sum()
    results["1_populacao_completa_pi_gt_0"] = (zero_pi_count == 0 and min_pi > 0)
    print(f"\n[Test 1] População completa com pi > 0: {results['1_populacao_completa_pi_gt_0']} (min_pi = {min_pi:.6e})")

    # Test 2: Soma das áreas representadas = área elegível completa
    frame_area_ha = df_frame["A_hs"].sum()
    alloc_area_ha = df_alloc["A_hs"].sum()
    sample_area_ha = df_pts["area_weight_robust"].sum() / 10000.0
    area_diff_ha = abs(sample_area_ha - frame_area_ha)
    results["2_fechamento_area_elegivel"] = (abs(alloc_area_ha - frame_area_ha) < 1e-6 and area_diff_ha < 100.0)
    print(f"[Test 2] Fechamento de área elegível: {results['2_fechamento_area_elegivel']}")
    print(f"         Frame total: {frame_area_ha:,.2f} ha | Alocação: {alloc_area_ha:,.2f} ha | Ponderada: {sample_area_ha:,.2f} ha (diff: {sample_area_ha - frame_area_ha:+.2f} ha)")

    # Test 3 & 4: Robust = 40.000, Main = 20.000
    n_rob = (df_pts["robust_sample"] == 1).sum()
    n_main = (df_pts["main_sample"] == 1).sum()
    results["3_robust_40k"] = (n_rob == 40000 and len(df_pts) == 40000)
    results["4_main_20k"] = (n_main == 20000)
    print(f"[Test 3] Robust = 40.000: {results['3_robust_40k']} ({n_rob:,})")
    print(f"[Test 4] Main = 20.000:   {results['4_main_20k']} ({n_main:,})")

    # Test 5: Duplicatas = 0
    unique_coords = len(set(zip(df_pts["lon"], df_pts["lat"])))
    unique_ids = df_pts["sample_id"].nunique()
    results["5_duplicatas_zero"] = (unique_coords == 40000 and unique_ids == 40000)
    print(f"[Test 5] Duplicatas = 0:  {results['5_duplicatas_zero']} (coords: {unique_coords:,}, IDs: {unique_ids:,})")

    # Test 6: Integridade do join entre master e samples_annual
    same_ids = (df_pts["sample_id"] == df_ann["sample_id"]).all()
    results["6_integridade_join_sample_id"] = same_ids
    print(f"[Test 6] Integridade sample_id no join: {results['6_integridade_join_sample_id']}")

    # Test 7: Paridade DW Crop vs Regime Master = 100.000%
    expected_dw_crop = df_ann["regime"].map({"AA": 1, "AN": 0, "NA": 1, "NN": 0})
    dw_crop_match = (df_ann["dw_crop"] == expected_dw_crop).mean() * 100.0
    results["7_dw_crop_match_regime_100pct"] = (dw_crop_match == 100.0)
    print(f"[Test 7] dw_crop match regime = 100%: {results['7_dw_crop_match_regime_100pct']} ({dw_crop_match:.5f}%)")

    # Test 8: Paridade Annual Class vs DW Crop = 100.000%
    # annual_class == 'crops' sse dw_crop == 1
    class_crop_match = ((df_ann["annual_class"] == "crops") == (df_ann["dw_crop"] == 1)).mean() * 100.0
    results["8_annual_class_match_dw_crop_100pct"] = (class_crop_match == 100.0)
    print(f"[Test 8] annual_class match dw_crop = 100%: {results['8_annual_class_match_dw_crop_100pct']} ({class_crop_match:.5f}%)")

    # Test 9: Paridade MapBiomas Crop vs Regime Master = 100.000%
    expected_mb_crop = df_ann["regime"].map({"AA": 1, "AN": 1, "NA": 0, "NN": 0})
    mb_crop_match = (df_ann["mapbiomas_crop"] == expected_mb_crop).mean() * 100.0
    results["9_mb_crop_match_regime_100pct"] = (mb_crop_match == 100.0)
    print(f"[Test 9] mapbiomas_crop match regime = 100%: {results['9_mb_crop_match_regime_100pct']} ({mb_crop_match:.5f}%)")

    # Test 10: Classes 18/21 = 0 na amostra 2025
    c18_21 = df_ann["mapbiomas_class"].isin([18, 21]).sum()
    results["10_classes_18_21_zero"] = (c18_21 == 0)
    print(f"[Test 10] MapBiomas 18/21 = 0 pontos: {results['10_classes_18_21_zero']} (encontrado: {c18_21})")

    # Test 11: Auditoria de month_valid
    n_raw_gt_0 = df_m["n_raw_obs"] > 0
    n_days_eq_0 = df_m["n_valid_days"] == 0
    case_raw_gt_days_eq_0 = (n_raw_gt_0 & n_days_eq_0).sum()

    n_days_gt_0 = df_m["n_valid_days"] > 0
    prob_sum_le_0 = df_m["probability_sum_before_normalization"] <= 0
    case_days_gt_prob_le_0 = (n_days_gt_0 & prob_sum_le_0).sum()

    expected_m_valid = ((df_m["n_valid_days"] > 0) & (df_m["probability_sum_before_normalization"] > 0)).astype(int)
    inconsistent_m_valid = (df_m["month_valid"] != expected_m_valid).sum()

    results["11_month_valid_consistente"] = (inconsistent_m_valid == 0)
    print(f"[Test 11] month_valid consistente: {results['11_month_valid_consistente']}")
    print(f"          n_raw > 0 e n_days == 0: {case_raw_gt_days_eq_0}")
    print(f"          n_days > 0 e prob_sum <= 0: {case_days_gt_prob_le_0}")
    print(f"          month_valid inconsistentes: {inconsistent_m_valid}")

    # Test 12: Sum p_year autoritativo = 1.000000
    p_ann_cols = [f"p_{b}" for b in DW_PROB_BANDS]
    sum_p_ann = df_ann[p_ann_cols].sum(axis=1)
    max_p_ann_dev = np.max(np.abs(sum_p_ann - 1.0))
    results["12_sum_p_year_eq_1"] = (max_p_ann_dev < 1e-5)
    print(f"[Test 12] sum(p_year) autoritativo = 1: {results['12_sum_p_year_eq_1']} (desvio max: {max_p_ann_dev:.2e})")

    # Test 13: Sum p_month = 1 para meses válidos
    valid_m = df_m[df_m["month_valid"] == 1]
    sum_p_m = valid_m[DW_PROB_BANDS].sum(axis=1)
    max_p_m_dev = np.max(np.abs(sum_p_m - 1.0))
    results["13_sum_p_month_valid_eq_1"] = (max_p_m_dev < 1e-5)
    print(f"[Test 13] sum(p_month) válidos = 1: {results['13_sum_p_month_valid_eq_1']} (desvio max: {max_p_m_dev:.2e})")

    # Test 14: Entropia anual em [0, 1] e temporal mean em [0, 1]
    h_ann_min, h_ann_max = df_ann["entropy_annual"].min(), df_ann["entropy_annual"].max()
    h_temp_min, h_temp_max = df_ann["entropy_temporal_mean"].min(), df_ann["entropy_temporal_mean"].max()
    results["14_entropias_em_0_1"] = (0.0 <= h_ann_min and h_ann_max <= 1.0 and 0.0 <= h_temp_min and h_temp_max <= 1.0)
    print(f"[Test 14] Entropias em [0,1]: {results['14_entropias_em_0_1']} (H_ann: [{h_ann_min:.4f}, {h_ann_max:.4f}], H_temp: [{h_temp_min:.4f}, {h_temp_max:.4f}])")

    # Test 15: JSD >= -1e-12
    jsd_min = df_ann["jsd_temporal"].min()
    results["15_jsd_temporal_ge_zero"] = (jsd_min >= -1e-12)
    print(f"[Test 15] JSD_temporal >= -1e-12: {results['15_jsd_temporal_ge_zero']} (min: {jsd_min:.6e}, max: {df_ann['jsd_temporal'].max():.4f})")

    # Test 16: Stability em [0, 1]
    s_min, s_max = df_ann["stability"].min(), df_ann["stability"].max()
    results["16_stability_em_0_1"] = (0.0 <= s_min and s_max <= 1.0)
    print(f"[Test 16] Stability em [0,1]: {results['16_stability_em_0_1']} (min: {s_min:.4f}, max: {s_max:.4f})")

    # Test 17: n_valid_months >= 8 em todos os pontos
    min_months = df_ann["n_valid_months"].min()
    results["17_n_valid_months_gte_8"] = (min_months >= 8)
    print(f"[Test 17] n_valid_months >= 8: {results['17_n_valid_months_gte_8']} (min: {min_months}, max: {df_ann['n_valid_months'].max()})")

    # Test 18: Distâncias de borda em [0, 250]
    d_mb_min, d_mb_max = df_ann["distance_edge_mb_m"].min(), df_ann["distance_edge_mb_m"].max()
    d_dw_min, d_dw_max = df_ann["distance_edge_dw_m"].min(), df_ann["distance_edge_dw_m"].max()
    d_min_min, d_min_max = df_ann["distance_edge_min_m"].min(), df_ann["distance_edge_min_m"].max()
    results["18_distancias_em_0_250"] = (
        0.0 <= d_mb_min and d_mb_max <= 250.0 and
        0.0 <= d_dw_min and d_dw_max <= 250.0 and
        0.0 <= d_min_min and d_min_max <= 250.0
    )
    print(f"[Test 18] Distâncias em [0, 250]: {results['18_distancias_em_0_250']}")
    print(f"          d_mb: [{d_mb_min:.1f}, {d_mb_max:.1f}] | d_dw: [{d_dw_min:.1f}, {d_dw_max:.1f}] | d_min: [{d_min_min:.1f}, {d_min_max:.1f}]")

    # Test 19: MapBiomas Estável possui flag de elegibilidade
    has_elig = "mapbiomas_stability_eligible_2017_2025" in df_ann.columns
    has_stable = "mapbiomas_stable_2017_2025" in df_ann.columns
    n_elig = df_ann["mapbiomas_stability_eligible_2017_2025"].sum()
    n_stable = df_ann["mapbiomas_stable_2017_2025"].sum()
    results["19_mapbiomas_stable_audit"] = (has_elig and has_stable and n_stable <= n_elig)
    print(f"[Test 19] MapBiomas Estável auditado: {results['19_mapbiomas_stable_audit']} (elegíveis: {n_elig:,} / 40.000, estáveis: {n_stable:,})")

    # Missingness check
    print("\n" + "=" * 50 + " MISSINGNESS CHECK " + "=" * 50)
    nulls_ann = df_ann.isna().sum()
    expected_null_cols = {"selection_probability_main", "design_weight_main", "area_weight_main"}
    unexpected_nulls = {k: v for k, v in nulls_ann.items() if v > 0 and k not in expected_null_cols}
    print(f"Colunas com valores nulos não esperados em samples_annual: {unexpected_nulls}")
    for col in expected_null_cols:
        print(f"  {col}: {nulls_ann.get(col, 0):,} nulos (esperado exatamente 20.000 para non-main)")

    nulls_m = df_m.isna().sum()
    unexpected_nulls_m = {k: v for k, v in nulls_m.items() if v > 0}
    print(f"Colunas com valores nulos em dw_monthly: {unexpected_nulls_m}")

    # Checkpoint result
    all_passed = all(results.values()) and len(unexpected_nulls) == 0 and len(unexpected_nulls_m) == 0
    print("\n" + "=" * 80)
    print(f"RESULTADO GERAL DOS TESTES: {'PASS' if all_passed else 'BLOCKED'} ({sum(results.values())} / {len(results)} aprovados)")
    print("=" * 80)

    # Hashes dos artefatos
    print("\nHASHES SHA-256 DOS ARTEFATOS CONGELADOS:")
    files_to_hash = [
        BASE_DIR / "data" / "reference" / "matopiba_boundary.geojson",
        BASE_DIR / "data" / "reference" / "matopiba_municipalities.csv",
        BASE_DIR / "config" / "experiment.yaml",
        TABLES_DIR / "sampling_frame_10m.csv",
        TABLES_DIR / "sampling_quotas.csv",
        TABLES_DIR / "slice_sampling_allocation_final.csv",
        TABLES_DIR / "zero_inclusion_substrata_audit.csv",
        TABLES_DIR / "dw_annual_identity_diagnostic.csv",
        DATA_PROC / "master_sampling_points.csv",
        DATA_PROC / "dw_monthly.parquet",
        DATA_PROC / "samples_annual.parquet",
        DATA_PROC / "samples_annual.csv",
    ]
    hashes = {}
    for p in files_to_hash:
        if p.exists():
            h = sha256_file(p)
            hashes[p.name] = h
            print(f"  {h}  {p.relative_to(BASE_DIR)}")

    return all_passed, results, hashes


if __name__ == "__main__":
    main()
