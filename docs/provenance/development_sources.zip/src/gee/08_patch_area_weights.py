"""
08_patch_area_weights.py — Patch A: Area Weights Exatos por Ponto
================================================================
Extrai pixel_area_m2 = ee.Image.pixelArea() para cada uma das 40.000
coordenadas congeladas da Master Sample e recalcula:
  area_weight_robust = pixel_area_m2 / selection_probability_robust
  area_weight_main = pixel_area_m2 / selection_probability_main (se main_sample == 1)
  area_weight_main = NaN (se main_sample == 0)

Preserva estritamente:
  - sample_id, lat, lon, state, stratum_id, regime, slice_id
  - main_sample, robust_sample, rank_within_stratum
  - root_seed, stratum_seed
  - selection_probability_robust, design_weight_robust
  - selection_probability_main, design_weight_main
"""

from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

import ee
import numpy as np
import pandas as pd

PROJECT_ID = "dynamicworld-x-mapbiomas"
PROC_DIR = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"

MASTER_POINTS_CSV = PROC_DIR / "master_sampling_points.csv"
BACKUP_POINTS_CSV = PROC_DIR / "master_sampling_points_BEFORE_AREA_WEIGHT_PATCH.csv"
CHECKPOINT_JSON = PROC_DIR / "pixel_area_m2_checkpoint.json"
DESIGN_AUDIT_CSV = TABLES_DIR / "slice_sampling_design_audit.csv"

BATCH_SIZE = 5000


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def load_checkpoints() -> dict[str, float]:
    if CHECKPOINT_JSON.exists():
        try:
            with open(CHECKPOINT_JSON, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_checkpoints(ckpt: dict[str, float]) -> None:
    with open(CHECKPOINT_JSON, "w", encoding="utf-8") as f:
        json.dump(ckpt, f)


def main():
    log("=== INICIANDO PATCH A: AREA WEIGHTS EXATOS POR PONTO ===")

    # 1. Verificar backup
    if not BACKUP_POINTS_CSV.exists():
        raise FileNotFoundError(f"Backup obrigatório não encontrado: {BACKUP_POINTS_CSV}")
    log(f"Backup validado: {BACKUP_POINTS_CSV}")

    df = pd.read_csv(MASTER_POINTS_CSV, keep_default_na=False)
    log(f"Pontos lidos: {len(df)}")
    assert len(df) == 40000, f"Esperado 40.000 pontos, encontrado {len(df)}"

    # 2. Inicializar GEE
    ee.Initialize(project=PROJECT_ID)
    from src.gee.dw_annual import get_mapbiomas_projection
    mb_proj = get_mapbiomas_projection()
    img_area = ee.Image.pixelArea().reproject(crs=mb_proj).rename("pixel_area_m2")

    # 3. Carregar checkpoints existentes
    ckpt = load_checkpoints()
    log(f"Checkpoints pré-existentes de pixel_area_m2: {len(ckpt)} / 40.000")

    missing_indices = [i for i, row in df.iterrows() if row["sample_id"] not in ckpt]
    log(f"Pontos pendentes para extração de pixel_area_m2: {len(missing_indices)}")

    if missing_indices:
        n_batches = (len(missing_indices) + BATCH_SIZE - 1) // BATCH_SIZE
        for b_idx in range(n_batches):
            b_indices = missing_indices[b_idx * BATCH_SIZE : (b_idx + 1) * BATCH_SIZE]
            b_df = df.iloc[b_indices]

            features = [
                ee.Feature(
                    ee.Geometry.Point([row["lon"], row["lat"]]),
                    {"sample_id": row["sample_id"]}
                )
                for _, row in b_df.iterrows()
            ]
            fc = ee.FeatureCollection(features)

            t0 = time.time()
            sampled = img_area.sampleRegions(
                collection=fc,
                projection=mb_proj,
                geometries=False
            )
            res = sampled.getInfo()
            t1 = time.time()

            for feat in res["features"]:
                sid = feat["properties"]["sample_id"]
                val = feat["properties"]["pixel_area_m2"]
                ckpt[sid] = float(val)

            save_checkpoints(ckpt)
            log(f"Batch {b_idx + 1}/{n_batches} ({len(b_df)} pontos) extraído em {t1 - t0:.2f}s | Total no ckpt: {len(ckpt)}")

    # 4. Mapear pixel_area_m2 de volta ao dataframe
    assert len(ckpt) == 40000, f"Faltam checkpoints: {len(ckpt)} / 40.000"
    df["pixel_area_m2"] = df["sample_id"].map(ckpt)
    assert not df["pixel_area_m2"].isna().any(), "Valores NaN encontrados em pixel_area_m2!"

    log(f"pixel_area_m2 estatísticas: min={df['pixel_area_m2'].min():.4f}, mean={df['pixel_area_m2'].mean():.4f}, max={df['pixel_area_m2'].max():.4f}")

    # 5. Calcular novos area weights
    # Garantir dtypes numéricos (colunas podem ter strings vazias lidas do CSV)
    pi_robust = pd.to_numeric(df["selection_probability_robust"], errors="coerce")
    pi_main = pd.to_numeric(df["selection_probability_main"], errors="coerce")

    # area_weight_robust = pixel_area_m2 / selection_probability_robust
    df["area_weight_robust"] = df["pixel_area_m2"] / pi_robust

    # area_weight_main = pixel_area_m2 / selection_probability_main (se main_sample == 1)
    df["area_weight_main"] = np.where(
        df["main_sample"] == 1,
        df["pixel_area_m2"] / pi_main,
        np.nan
    )

    # 6. Validação por subestrato operacional (slice)
    audit_slice = pd.read_csv(DESIGN_AUDIT_CSV, keep_default_na=False)
    # Filtra apenas fatias ativas (onde n_robust_hs > 0)
    audit_slice = audit_slice[audit_slice["n_robust_hs"] > 0].copy()

    # Soma de area_weight_robust por slice convertida para hectares (/ 10000.0)
    slice_sums = (
        df.groupby(["state", "regime", "slice_id"])["area_weight_robust"]
        .sum()
        .reset_index()
    )
    slice_sums["est_area_ha"] = slice_sums["area_weight_robust"] / 10000.0

    merged_audit = pd.merge(audit_slice, slice_sums, on=["state", "regime", "slice_id"], how="inner")
    merged_audit["diff_ha"] = merged_audit["est_area_ha"] - merged_audit["A_hs"]
    merged_audit["diff_pct"] = np.where(
        merged_audit["A_hs"] > 0,
        100.0 * np.abs(merged_audit["diff_ha"]) / merged_audit["A_hs"],
        0.0
    )

    total_true_ha = merged_audit["A_hs"].sum()
    total_est_ha = merged_audit["est_area_ha"].sum()
    log(f"Validação Wall-to-Wall Elegível:")
    log(f"  Área Física Total A_hs:            {total_true_ha:,.2f} ha")
    log(f"  Área Estimada sum(w_area_robust):   {total_est_ha:,.2f} ha")
    log(f"  Diferença Absoluta:                {abs(total_est_ha - total_true_ha):,.2f} ha ({abs(total_est_ha - total_true_ha)/total_true_ha*100:.4f}%)")
    log(f"  Diff % médio por slice:            {merged_audit['diff_pct'].mean():.4f}% (Max: {merged_audit['diff_pct'].max():.4f}%)")

    # 7. Salvar atualizado no MESMO master_sampling_points.csv
    # Manter a ordem original das colunas exatamente igual
    cols = [
        "sample_id", "lat", "lon", "state", "stratum_id", "regime", "slice_id",
        "main_sample", "robust_sample", "rank_within_stratum",
        "root_seed", "stratum_seed",
        "selection_probability_robust", "design_weight_robust", "area_weight_robust",
        "selection_probability_main", "design_weight_main", "area_weight_main"
    ]
    df[cols].to_csv(MASTER_POINTS_CSV, index=False)
    log(f"Arquivo atualizado com sucesso: {MASTER_POINTS_CSV} ({len(df)} linhas)")
    log("=== PATCH A CONCLUÍDO COM SUCESSO ===")


if __name__ == "__main__":
    main()
