"""
04_wall_to_wall_canonical_interactive.py — Interactive Slice Reduction with Checkpointing
=======================================================================================
Computes the canonical 10m wall-to-wall metrics per slice with continuous JSON checkpointing.
Works in parallel with the GEE batch export (whichever completes all 183 slices first is used).

Uses the CANONICAL RASTER:
  - Fixed support domain (MATOPIBA + 5,000 m)
  - Precomputed monthly dates
  - 16 canonical area (ha) and cell count bands
  - Slices used for computational reduction only

Saves checkpoints to:
  data/processed/canonical_wall_to_wall_slices_checkpoint.json
"""

from __future__ import annotations

import json
import socket
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from concurrent.futures import ThreadPoolExecutor, as_completed

socket.setdefaulttimeout(300)

import ee
import pandas as pd
from shapely.geometry import box, shape

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

from src.gee.dw_annual import (
    PROJECT_ID,
    get_harmonized_crosswalk_layers,
    get_mapbiomas_projection,
)

DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"
CKPT_FILE = DATA_PROC / "canonical_wall_to_wall_slices_checkpoint.json"

STEP_DEG = 0.75
MAX_WORKERS = 2  # Conservative to avoid restricted mode rate-limits
LOCK = threading.Lock()


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def load_checkpoints() -> dict[str, dict[str, Any]]:
    if CKPT_FILE.exists():
        try:
            with open(CKPT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_checkpoint(slice_id: str, stats: dict[str, Any]) -> None:
    with LOCK:
        ckpt = load_checkpoints()
        ckpt[slice_id] = stats
        with open(CKPT_FILE, "w", encoding="utf-8") as f:
            json.dump(ckpt, f, indent=2)


def partition_state(state: str, geom_shp, step: float = STEP_DEG) -> list[tuple[str, any]]:
    min_x, min_y, max_x, max_y = geom_shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    pieces = []
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = geom_shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                pieces.append((f"{state}_x{ix:02d}_y{iy:02d}", sub))
    return pieces


def compute_slice(slice_id: str, state: str, geom_shp, stack: ee.Image, mb_proj: ee.Projection, crs: str, transform: list[float]) -> dict[str, Any]:
    ee_geom = ee.Geometry(geom_shp.__geo_interface__)
    max_retries = 4
    for attempt in range(1, max_retries + 1):
        try:
            t0 = time.time()
            res = stack.reduceRegion(
                reducer=ee.Reducer.sum().unweighted(),
                geometry=ee_geom,
                crs=crs,
                crsTransform=transform,
                maxPixels=1e13,
                tileScale=16,
            ).getInfo()

            clean = {"slice_id": slice_id, "state": state, "poly_area_ha": geom_shp.area * (111319.5 ** 2) / 10000.0}
            for k, v in res.items():
                if v is None:
                    clean[k] = 0.0 if "ha" in k else 0
                elif "count" in k:
                    clean[k] = int(round(v))
                else:
                    clean[k] = float(v)

            save_checkpoint(slice_id, clean)
            log(f"  Slice {slice_id} ({state}) done in {time.time() - t0:.1f}s: total={clean.get('total_covered_ha', 0):,.1f} ha, eligible={clean.get('eligible_ha', 0):,.1f} ha")
            return clean
        except Exception as exc:
            log(f"  [ERROR] Slice {slice_id} attempt {attempt}/{max_retries}: {exc}")
            if attempt == max_retries:
                raise
            time.sleep(10 * attempt)
    return {}


def main():
    log("=" * 80)
    log("STARTING CANONICAL 10M INTERACTIVE WALL-TO-WALL REDUCTION")
    log("=" * 80)

    ee.Initialize(project=PROJECT_ID)
    mb_proj = get_mapbiomas_projection()
    proj_info = mb_proj.getInfo()
    crs = proj_info["crs"]
    transform = proj_info["transform"]

    log("Building canonical raster stack on fixed support domain...")
    layers = get_harmonized_crosswalk_layers()

    pixel_area_ha = ee.Image.pixelArea().divide(10000.0)
    mb = layers["mb"]
    bands = [
        pixel_area_ha.updateMask(mb.mask()).rename("total_covered_ha"),
        pixel_area_ha.updateMask(layers["eligible_mask"]).rename("eligible_ha"),
        pixel_area_ha.updateMask(layers["is_excluded"].updateMask(mb.mask())).rename("excluded_mb_ha"),
        pixel_area_ha.updateMask(layers["insufficient_dw_temporal"]).rename("insufficient_dw_temporal_ha"),
        pixel_area_ha.updateMask(layers["regime_AA"]).rename("AA_ha"),
        pixel_area_ha.updateMask(layers["regime_AN"]).rename("AN_ha"),
        pixel_area_ha.updateMask(layers["regime_NA"]).rename("NA_ha"),
        pixel_area_ha.updateMask(layers["regime_NN"]).rename("NN_ha"),
        ee.Image(1).updateMask(mb.mask()).rename("total_covered_count"),
        ee.Image(1).updateMask(layers["eligible_mask"]).rename("eligible_count"),
        ee.Image(1).updateMask(layers["is_excluded"].updateMask(mb.mask())).rename("excluded_mb_count"),
        ee.Image(1).updateMask(layers["insufficient_dw_temporal"]).rename("insufficient_dw_temporal_count"),
        ee.Image(1).updateMask(layers["regime_AA"]).rename("AA_count"),
        ee.Image(1).updateMask(layers["regime_AN"]).rename("AN_count"),
        ee.Image(1).updateMask(layers["regime_NA"]).rename("NA_count"),
        ee.Image(1).updateMask(layers["regime_NN"]).rename("NN_count"),
    ]
    stack = ee.Image.cat(bands)

    # Load states and partition into slices
    with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
        states_data = json.load(f)

    all_slices = []
    for feat in states_data["features"]:
        st = feat["properties"]["state"]
        shp = shape(feat["geometry"])
        pieces = partition_state(st, shp, STEP_DEG)
        for s_id, s_geom in pieces:
            all_slices.append((s_id, st, s_geom))

    log(f"Total canonical slices: {len(all_slices)}")

    # Check already completed slices
    ckpt = load_checkpoints()
    pending = [s for s in all_slices if s[0] not in ckpt]
    log(f"Already completed in checkpoint: {len(ckpt)} / {len(all_slices)}")
    log(f"Pending slices: {len(pending)}")

    if not pending:
        log("All 183 slices already completed in checkpoint!")
        return

    # Execute with worker pool
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(compute_slice, s_id, st, geom, stack, mb_proj, crs, transform): s_id
            for s_id, st, geom in pending
        }
        for fut in as_completed(futures):
            s_id = futures[fut]
            try:
                fut.result()
            except Exception as e:
                log(f"Failed slice {s_id}: {e}")

    log("Canonical interactive reduction complete!")


if __name__ == "__main__":
    main()
