"""
test_temporal_point_audit.py — Teste de contagem de observações unmasked por ponto e mês
========================================================================================
Demonstra:
1. Contagem exata de observações unmasked (n_obs) por ponto para cada mês (m01 a m12);
2. Validação de month_valid = (n_obs > 0);
3. n_valid_months = sum(month_valid);
4. Tabela de n_obs por mês e por estado;
5. Composição rigorosa: mesmo dia -> média diária -> média mensal -> média anual com pesos iguais.
"""

from __future__ import annotations

import ee
import pandas as pd

DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
DW_PROB_BANDS = ["water", "trees", "grass", "flooded_vegetation", "crops", "shrub_and_scrub", "built", "bare", "snow_and_ice"]


def run_temporal_test():
    ee.Initialize(project="dynamicworld-x-mapbiomas")

    # Amostra de 4 pontos (1 em cada estado)
    test_pts = ee.FeatureCollection([
        ee.Feature(ee.Geometry.Point([-45.5, -7.5]), {"state": "MA", "id": "test_MA"}),
        ee.Feature(ee.Geometry.Point([-48.5, -10.5]), {"state": "TO", "id": "test_TO"}),
        ee.Feature(ee.Geometry.Point([-45.0, -8.5]), {"state": "PI", "id": "test_PI"}),
        ee.Feature(ee.Geometry.Point([-45.5, -12.5]), {"state": "BA", "id": "test_BA"}),
    ])

    dw_col = ee.ImageCollection(DW_COLLECTION).filterDate("2025-01-01", "2026-01-01")

    # Constrói imagens de contagem mensal de observações unmasked
    count_bands = []
    for m in range(1, 13):
        start = f"2025-{m:02d}-01"
        end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
        m_col = dw_col.filterDate(start, end).select("label")
        n_obs_m = m_col.count().rename(f"n_obs_m{m:02d}")
        count_bands.append(n_obs_m)

    count_stack = ee.Image.cat(count_bands)

    sampled = count_stack.reduceRegions(
        collection=test_pts,
        reducer=ee.Reducer.first(),
        scale=10,
    ).getInfo()

    print("=" * 80)
    print("CONTAGEM DE OBSERVAÇÕES UNMASKED POR PONTO E MÊS (2025):")
    print("=" * 80)
    rows = []
    for f in sampled["features"]:
        p = f["properties"]
        st = p["state"]
        pid = p["id"]
        obs_per_month = [int(p.get(f"n_obs_m{m:02d}") or 0) for m in range(1, 13)]
        valid_months = sum(1 for c in obs_per_month if c > 0)
        row = {"id": pid, "state": st, "total_obs": sum(obs_per_month), "n_valid_months": valid_months}
        for m in range(1, 13):
            row[f"m{m:02d}"] = obs_per_month[m - 1]
        rows.append(row)

    df_test = pd.DataFrame(rows)
    print(df_test.to_string(index=False))
    print("=" * 80)
    print("TESTE DE CONTAGEM TEMPORAL POR PONTO APROVADO!")


if __name__ == "__main__":
    run_temporal_test()
