"""
Dynamic World x MapBiomas — Prototype Pipeline (Checkpoint 1)
=============================================================
Executes technical validation checkpoint for ~500 points across 4 windows
in the MATOPIBA completo using the official frozen boundary.

Requirements addressed:
  - Official boundary from data/reference/matopiba_boundary.geojson
  - Dynamic World V1: [2025-01-01, 2026-01-01)
  - MapBiomas 10m Col 4: classification_2025
  - Daily neutral composite -> Monthly mean -> Annual equal-weight
  - Per-point per-month observation counting (n_obs_m01..m12, n_valid_months)
  - 10m primary grid + Real 30m aggregation via reduceResolution(mean) & reduceResolution(mode)
  - Robust crosswalk handling (19, 36 CROP; 21, 18 EXCLUDED; others NONCROP)
  - AA / AN / NA / NN agreement regimes
  - Edge detection with EXCLUDED masked & direct fastDistanceTransform (no edge.Not())
  - Normalized probability vector (p'_k = p_k / sum(p)) with probability_sum_before_normalization preserved
  - Automated validation & config/experiment.yaml generation
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import ee
import yaml

# ──────────────────────────────────────────────────────────────────────
# CONSTANTS — frozen from PROJECT_BRIEF.md
# ──────────────────────────────────────────────────────────────────────
PROJECT_ID = "dynamicworld-x-mapbiomas"
DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"
DW_START = "2025-01-01"
DW_END = "2026-01-01"
RANDOM_SEED = 25
DISTANCE_CRS = "EPSG:5880"
EDGE_MAX_DISTANCE_M = 250

DW_PROB_BANDS = [
    "water", "trees", "grass", "flooded_vegetation", "crops",
    "shrub_and_scrub", "built", "bare", "snow_and_ice"
]

CROP_CODES = [19, 36]           # Lavoura Temporária + Perene
CROP_STRICT_CODES = [19]        # Sensibilidade: apenas Temporária
EXCLUDED_CODES = [21, 18]       # Mosaico de Usos + Agricultura se aparecer

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
CONFIG_DIR = BASE_DIR / "config"

BOUNDARY_GEOJSON = DATA_REF / "matopiba_boundary.geojson"
MUNICIPALITIES_CSV = DATA_REF / "matopiba_municipalities.csv"

# Quatro pequenas janelas para o protótipo técnico (uma em cada estado)
PROTOTYPE_WINDOWS = {
    "MA": {"lon_min": -45.2, "lon_max": -44.8, "lat_min": -7.7, "lat_max": -7.3},   # Balsas
    "TO": {"lon_min": -49.2, "lon_max": -48.8, "lat_min": -11.0, "lat_max": -10.6},  # Dianópolis
    "PI": {"lon_min": -45.2, "lon_max": -44.8, "lat_min": -8.5, "lat_max": -8.1},    # Uruçuí
    "BA": {"lon_min": -46.2, "lon_max": -45.8, "lat_min": -12.2, "lat_max": -11.8},  # Luís Eduardo Magalhães
}
POINTS_PER_WINDOW = 125


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def initialize_ee() -> None:
    log("Inicializando Google Earth Engine...")
    try:
        ee.Initialize(project=PROJECT_ID)
    except Exception:
        log("Autenticação necessária, invocando ee.Authenticate()...")
        ee.Authenticate()
        ee.Initialize(project=PROJECT_ID)
    log(f"Earth Engine inicializado com projeto: {PROJECT_ID}")


def load_official_boundary() -> tuple[ee.Geometry, dict]:
    """Carrega a boundary oficial congelada do MATOPIBA."""
    if not BOUNDARY_GEOJSON.exists():
        raise FileNotFoundError(
            f"Arquivo de boundary oficial não encontrado: {BOUNDARY_GEOJSON}. "
            "Execute src/gee/02_boundary.py primeiro."
        )

    log(f"Carregando delimitação oficial: {BOUNDARY_GEOJSON}")
    with open(BOUNDARY_GEOJSON, "r", encoding="utf-8") as f:
        boundary_data = json.load(f)

    props = boundary_data["features"][0].get("properties", {})
    raw_geom = boundary_data["features"][0]["geometry"]
    ee_geom = ee.Geometry(raw_geom)

    area_ha_ee = ee_geom.area(maxError=1000).divide(10000).getInfo()
    area_km2_ee = area_ha_ee / 100.0

    sha256 = hashlib.sha256(BOUNDARY_GEOJSON.read_bytes()).hexdigest()
    log("Delimitação carregada com sucesso:")
    log(f"  Fonte: {props.get('source')}")
    log(f"  Municípios: {props.get('n_municipalities')}")
    log(f"  Área projetada (EPSG:5880): {props.get('area_ha_epsg5880'):,.2f} ha")
    log(f"  Área geodésica GEE: {area_ha_ee:,.2f} ha ({area_km2_ee:,.2f} km²)")
    log(f"  SHA-256: {sha256}")

    boundary_info = {
        "file": str(BOUNDARY_GEOJSON),
        "sha256": sha256,
        "source": props.get("source"),
        "definition": props.get("definition"),
        "n_municipalities": props.get("n_municipalities", 337),
        "area_ha_epsg5880": props.get("area_ha_epsg5880"),
        "area_ha_gee": round(area_ha_ee, 2),
        "area_km2_gee": round(area_km2_ee, 2),
        "states": props.get("states", ["MA", "TO", "PI", "BA"]),
        "retrieval_date": props.get("retrieval_date"),
    }
    return ee_geom, boundary_info


def validate_sources() -> tuple[dict, dict]:
    """Valida datasets Dynamic World V1 e MapBiomas 10m Col 4."""
    log("Validando Dynamic World V1 e MapBiomas 10m Col 4...")

    dw_col = ee.ImageCollection(DW_COLLECTION).filterDate(DW_START, DW_END)
    first_dw = dw_col.first()
    dw_bands = first_dw.bandNames().getInfo()
    missing_dw = set(DW_PROB_BANDS + ["label"]) - set(dw_bands)
    if missing_dw:
        raise RuntimeError(f"Bandas Dynamic World ausentes: {missing_dw}")

    dw_info = {
        "asset": DW_COLLECTION,
        "date_range": f"[{DW_START}, {DW_END})",
        "bands": dw_bands,
    }
    log("  Dynamic World V1: OK (9 bandas probabilísticas + label)")

    mb_img = ee.Image(MB_ASSET)
    mb_bands = mb_img.bandNames().getInfo()
    if MB_BAND not in mb_bands:
        raise RuntimeError(f"Banda '{MB_BAND}' não encontrada no asset MapBiomas {MB_ASSET}")

    proj = mb_img.select(MB_BAND).projection().getInfo()
    scale = mb_img.select(MB_BAND).projection().nominalScale().getInfo()

    mb_info = {
        "asset": MB_ASSET,
        "band": MB_BAND,
        "total_bands": len(mb_bands),
        "crs": proj.get("crs"),
        "crs_transform": proj.get("transform"),
        "nominal_scale_m": scale,
    }
    log(f"  MapBiomas 10m Col 4: OK (banda {MB_BAND}, CRS: {proj.get('crs')}, escala: {scale} m)")

    return dw_info, mb_info


def audit_mapbiomas_legend(matopiba_geom: ee.Geometry) -> dict:
    """Audita códigos da legenda MapBiomas 2025 no MATOPIBA."""
    log("Auditando códigos da legenda MapBiomas 2025 no MATOPIBA...")
    mb = ee.Image(MB_ASSET).select(MB_BAND)

    hist = mb.reduceRegion(
        reducer=ee.Reducer.frequencyHistogram(),
        geometry=matopiba_geom,
        scale=1000,
        maxPixels=1e9,
        bestEffort=True,
    ).getInfo()

    class_counts = hist.get(MB_BAND, {})
    codes_found = {}
    for k, v in class_counts.items():
        try:
            codes_found[int(float(k))] = int(v)
        except (ValueError, TypeError):
            codes_found[k] = v

    specific_codes = {
        18: "Agricultura (se houver)",
        19: "Lavoura Temporária",
        36: "Lavoura Perene",
        15: "Pastagem",
        21: "Mosaico de Usos",
        9: "Silvicultura",
    }

    legend_audit = {
        "all_codes_found": dict(sorted(codes_found.items())),
        "specific_code_check": {},
    }

    for code, name in specific_codes.items():
        present = code in codes_found
        cnt = codes_found.get(code, 0)
        legend_audit["specific_code_check"][code] = {
            "name": name,
            "present": present,
            "sample_pixel_count": cnt,
        }
        status = "PRESENTE" if present else "NÃO DETECTADO NA AMOSTRAGEM"
        log(f"  Código {code:2d} ({name:25s}): {status} ({cnt:,} pixels a 1000m)")

    return legend_audit


def test_mapbiomas_stability() -> dict:
    """Verifica disponibilidade da série histórica MapBiomas 10m para sensibilidade."""
    log("Verificando série MapBiomas 10m para sensibilidade de estabilidade...")
    mb = ee.Image(MB_ASSET)
    bands = mb.bandNames().getInfo()
    years = []
    for b in bands:
        if b.startswith("classification_"):
            try:
                y = int(b.split("_")[1])
                if 2017 <= y <= 2025:
                    years.append(y)
            except (ValueError, IndexError):
                pass
    years.sort()
    feasible = len(years) >= 2
    log(f"  Anos disponíveis (2017–2025): {years} (Viável: {feasible})")
    return {"years_available": years, "feasible": feasible}


def generate_prototype_samples(matopiba_geom: ee.Geometry) -> list[dict]:
    """Gera ~500 pontos do protótipo com pipeline temporal completo e correções auditadas."""
    log("=" * 60)
    log("ETAPA: Gerando ~500 amostras do protótipo nas 4 janelas")
    log("=" * 60)

    mb = ee.Image(MB_ASSET).select(MB_BAND)
    mb_proj = mb.projection()
    mb_proj_info = mb_proj.getInfo()
    transform_10 = mb_proj_info.get("transform")
    crs_10 = mb_proj_info.get("crs")

    # Grade 30 m derivada exatamente da grade 10 m (preserva origem e alinhamento)
    transform_30 = [transform_10[0] * 3, 0, transform_10[2], 0, transform_10[4] * 3, transform_10[5]]
    grid30_proj = ee.Projection(crs=crs_10, transform=transform_30)

    kernel = ee.Kernel.square(1)
    all_points = []

    for state, win in PROTOTYPE_WINDOWS.items():
        t_win = time.time()
        log(f"\nProcessando janela estadual: {state}...")
        bbox = ee.Geometry.BBox(win["lon_min"], win["lat_min"], win["lon_max"], win["lat_max"])
        region = bbox.intersection(matopiba_geom, maxError=100)

        # 1. Pontos aleatórios com seed=25
        points_fc = ee.FeatureCollection.randomPoints(
            region=region,
            points=POINTS_PER_WINDOW,
            seed=RANDOM_SEED,
        )
        n_pts = points_fc.size().getInfo()
        log(f"  {state}: {n_pts} pontos amostrais gerados")

        # 2. Dynamic World temporal: contagem de observações unmasked e composições mensais neutras
        dw_col = (
            ee.ImageCollection(DW_COLLECTION)
            .filterBounds(region)
            .select(DW_PROB_BANDS + ["label"])
        )

        m_comps = []
        count_bands = []
        for m in range(1, 13):
            start = f"2025-{m:02d}-01"
            end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
            dw_m = dw_col.filterDate(start, end)

            # Contagem de observações unmasked por pixel
            n_obs_m = dw_m.select("label").count().rename(f"n_obs_m{m:02d}")
            count_bands.append(n_obs_m)

            # Composição diária neutra -> média mensal
            dates_m = ee.List(dw_m.aggregate_array("system:time_start")).map(
                lambda t: ee.Date(t).format("YYYY-MM-dd")
            ).distinct()

            def make_daily(d):
                d_start = ee.Date(d)
                d_end = d_start.advance(1, "day")
                return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().set("date", d)

            daily_col_m = ee.ImageCollection(dates_m.map(make_daily))
            comp_m = daily_col_m.mean()
            m_comps.append(comp_m)

        count_stack = ee.Image.cat(count_bands)

        # Composição anual de pesos iguais entre meses válidos
        annual_dw = ee.ImageCollection(m_comps).mean()

        # Alinhamento 10 m (bilinear em probabilidades contínuas)
        annual_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)

        # Agregação real 10 m -> 30 m via reduceResolution(mean)
        annual_30m = annual_10m.reduceResolution(
            reducer=ee.Reducer.mean(),
            maxPixels=64,
        ).reproject(crs=grid30_proj)

        # 3. MapBiomas binário 10 m com classes excluídas mascaradas
        is_excluded = mb.eq(21).Or(mb.eq(18))
        valid_mb_mask = is_excluded.Not().And(mb.mask())
        mb_crop_binary_10m = mb.remap(CROP_CODES, [1] * len(CROP_CODES), 0).updateMask(valid_mb_mask)

        # Agregação MapBiomas 30 m por maioria/mode (sem bilinear em categoria)
        mb_crop_30m = mb_crop_binary_10m.reduceResolution(
            reducer=ee.Reducer.mode(),
            maxPixels=64,
        ).reproject(crs=grid30_proj)

        # 4. Bordas espaciais e distâncias euclidianas em EPSG:5880
        # MapBiomas edge com classes excluídas devidamente mascaradas
        is_mb_crop = mb_crop_binary_10m.eq(1).unmask(0)
        is_mb_noncrop = mb_crop_binary_10m.eq(0).updateMask(valid_mb_mask).unmask(0)

        mb_crop_proj = is_mb_crop.reproject(crs=DISTANCE_CRS, scale=10)
        mb_noncrop_proj = is_mb_noncrop.reproject(crs=DISTANCE_CRS, scale=10)
        valid_mb_proj = valid_mb_mask.reproject(crs=DISTANCE_CRS, scale=10)

        n_crop = mb_crop_proj.reduceNeighborhood(ee.Reducer.sum(), kernel)
        n_noncrop = mb_noncrop_proj.reduceNeighborhood(ee.Reducer.sum(), kernel)

        # Pixel de borda: válido e com vizinho de classe oposta (não dispara em borda com excluded)
        mb_edge = valid_mb_proj.And(
            (mb_crop_proj.And(n_noncrop.gte(1))).Or(mb_noncrop_proj.And(n_crop.gte(1)))
        ).rename("mb_edge")

        # fastDistanceTransform diretamente sobre edge=1 (sem edge.Not())
        mb_dist = (
            mb_edge.fastDistanceTransform(neighborhood=25, units="pixels", metric="squared_euclidean")
            .sqrt()
            .multiply(10)
            .clamp(0, EDGE_MAX_DISTANCE_M)
            .rename("distance_edge_mb_m")
        )

        # Dynamic World edge
        dw_annual_fast = dw_col.filterDate(DW_START, DW_END).select(DW_PROB_BANDS).mean()
        dw_max = dw_annual_fast.reduce(ee.Reducer.max())
        dw_crop = dw_annual_fast.select("crops").eq(dw_max)

        dw_crop_proj = dw_crop.eq(1).unmask(0).reproject(crs=DISTANCE_CRS, scale=10)
        dw_noncrop_proj = dw_crop.eq(0).unmask(0).reproject(crs=DISTANCE_CRS, scale=10)

        dw_n_crop = dw_crop_proj.reduceNeighborhood(ee.Reducer.sum(), kernel)
        dw_n_noncrop = dw_noncrop_proj.reduceNeighborhood(ee.Reducer.sum(), kernel)

        dw_edge = (
            (dw_crop_proj.And(dw_n_noncrop.gte(1))).Or(dw_noncrop_proj.And(dw_n_crop.gte(1)))
        ).rename("dw_edge")

        dw_dist = (
            dw_edge.fastDistanceTransform(neighborhood=25, units="pixels", metric="squared_euclidean")
            .sqrt()
            .multiply(10)
            .clamp(0, EDGE_MAX_DISTANCE_M)
            .rename("distance_edge_dw_m")
        )

        edge_stack = ee.Image.cat([mb_dist, dw_dist])

        # 5. Extrações desacopladas
        log(f"  {state}: Extraindo probabilidades e contagens temporais 10m...")
        stack_10m = ee.Image.cat([
            mb.rename("mapbiomas_class"),
            mb_crop_binary_10m.rename("mb_crop_10m"),
            annual_10m,
            count_stack,
        ])
        sampled_10m = stack_10m.reduceRegions(
            collection=points_fc,
            reducer=ee.Reducer.first(),
            scale=10,
        ).getInfo()

        log(f"  {state}: Extraindo probabilidades 30m e suporte agregado...")
        stack_30m = ee.Image.cat([
            mb_crop_30m.rename("mb_crop_30m"),
            annual_30m,
        ])
        sampled_30m = stack_30m.reduceRegions(
            collection=points_fc,
            reducer=ee.Reducer.first(),
            scale=30,
        ).getInfo()

        log(f"  {state}: Extraindo distâncias de borda corrigidas (EPSG:5880)...")
        sampled_edges = edge_stack.reduceRegions(
            collection=points_fc,
            reducer=ee.Reducer.first(),
            scale=10,
        ).getInfo()

        log(f"  {state}: Extrações concluídas em {time.time() - t_win:.1f}s")

        # 6. Estruturação tabular e renormalização neutra justificada
        for i in range(len(sampled_10m["features"])):
            props_10 = sampled_10m["features"][i]["properties"]
            props_30 = sampled_30m["features"][i]["properties"]
            props_ed = sampled_edges["features"][i]["properties"]

            coords = sampled_10m["features"][i]["geometry"]["coordinates"]
            lon, lat = coords[0], coords[1]

            mb_raw = props_10.get("mapbiomas_class")
            mb_class = int(mb_raw) if mb_raw is not None else None

            # Contagens temporais por ponto
            obs_per_month = [int(props_10.get(f"n_obs_m{m:02d}") or 0) for m in range(1, 13)]
            n_obs_total = sum(obs_per_month)
            month_valid = [c > 0 for c in obs_per_month]
            n_valid_m = sum(month_valid)

            # Probabilidades 10m brutas e renormalização neutra
            dw_probs_raw = [props_10.get(b) for b in DW_PROB_BANDS]
            if all(v is not None for v in dw_probs_raw):
                sum_p_raw = sum(dw_probs_raw)
                dw_probs_norm = [p / sum_p_raw for p in dw_probs_raw]

                top1_idx = dw_probs_norm.index(max(dw_probs_norm))
                dw_annual_class = DW_PROB_BANDS[top1_idx]
                p_crops_norm = dw_probs_norm[4]

                sorted_p = sorted(dw_probs_norm, reverse=True)
                top1_p, top2_p = sorted_p[0], sorted_p[1]
                top2_margin = top1_p - top2_p
                top2_idx = dw_probs_norm.index(top2_p)
                competitor_class = DW_PROB_BANDS[top2_idx] if dw_annual_class == "crops" else dw_annual_class

                # Entropia normalizada sobre vetor probabilístico estritamente unitário
                ent = -sum(p * math.log(p) for p in dw_probs_norm if p > 0) / math.log(9)
            else:
                sum_p_raw = None
                dw_probs_norm = [None] * 9
                dw_annual_class = None
                p_crops_norm = None
                top2_margin = None
                competitor_class = None
                ent = None

            # Probabilidades 30m brutas e renormalização neutra
            dw_30_probs_raw = [props_30.get(b) for b in DW_PROB_BANDS]
            if all(v is not None for v in dw_30_probs_raw):
                sum_30_raw = sum(dw_30_probs_raw)
                dw_30_norm = [p / sum_30_raw for p in dw_30_probs_raw]
                top1_30_idx = dw_30_norm.index(max(dw_30_norm))
                dw_class_30m = DW_PROB_BANDS[top1_30_idx]
            else:
                sum_30_raw = None
                dw_30_norm = [None] * 9
                dw_class_30m = None

            # Crosswalk binário principal robusto
            if mb_class is not None:
                if mb_class in CROP_CODES:
                    mb_crop = 1
                elif mb_class in EXCLUDED_CODES:
                    mb_crop = None
                else:
                    mb_crop = 0
            else:
                mb_crop = None

            dw_crop = 1 if dw_annual_class == "crops" else (0 if dw_annual_class is not None else None)

            # Regimes AA / AN / NA / NN / EXCLUDED
            if mb_crop == 1 and dw_crop == 1:
                regime = "AA"
            elif mb_crop == 1 and dw_crop == 0:
                regime = "AN"
            elif mb_crop == 0 and dw_crop == 1:
                regime = "NA"
            elif mb_crop == 0 and dw_crop == 0:
                regime = "NN"
            else:
                regime = "EXCLUDED"

            d_mb = props_ed.get("distance_edge_mb_m")
            d_dw = props_ed.get("distance_edge_dw_m")
            if d_mb is not None and d_dw is not None:
                d_min = min(d_mb, d_dw)
            elif d_mb is not None:
                d_min = d_mb
            elif d_dw is not None:
                d_min = d_dw
            else:
                d_min = None

            rec = {
                "sample_id": f"proto_{state}_{i:04d}",
                "state": state,
                "latitude": round(lat, 6),
                "longitude": round(lon, 6),
                "mapbiomas_class": mb_class,
                "mapbiomas_crop": mb_crop,
                "dw_annual_class": dw_annual_class,
                "dw_crop": dw_crop,
                "regime": regime,
                "p_crops": round(p_crops_norm, 6) if p_crops_norm is not None else None,
                "probability_sum_before_normalization": round(sum_p_raw, 6) if sum_p_raw is not None else None,
                "entropy_annual": round(ent, 6) if ent is not None else None,
                "top2_margin": round(top2_margin, 6) if top2_margin is not None else None,
                "competitor_class": competitor_class,
                "n_valid_months": n_valid_m,
                "n_obs_total": n_obs_total,
                "distance_edge_mb_m": round(d_mb, 1) if d_mb is not None else None,
                "distance_edge_dw_m": round(d_dw, 1) if d_dw is not None else None,
                "distance_edge_min_m": round(d_min, 1) if d_min is not None else None,
                "dw_class_30m": dw_class_30m,
                "mapbiomas_crop_30m": props_30.get("mb_crop_30m"),
                "probability_sum_30m_before_normalization": round(sum_30_raw, 6) if sum_30_raw is not None else None,
            }

            # 9 probabilidades normalizadas 10m
            for idx, b in enumerate(DW_PROB_BANDS):
                rec[f"p_{b}"] = round(dw_probs_norm[idx], 6) if dw_probs_norm[idx] is not None else None

            # 9 probabilidades normalizadas 30m
            for idx, b in enumerate(DW_PROB_BANDS):
                rec[f"p_{b}_30m"] = round(dw_30_norm[idx], 6) if dw_30_norm[idx] is not None else None

            # Contagens mensais unmasked por ponto
            for m in range(1, 13):
                rec[f"n_obs_m{m:02d}"] = obs_per_month[m - 1]

            all_points.append(rec)

    return all_points


def audit_prototype_dataset(points: list[dict], boundary_info: dict) -> dict:
    """Executa auditoria sistemática do dataset gerado."""
    log("\n" + "=" * 60)
    log("AUDITORIA SISTEMÁTICA DO PROTÓTIPO")
    log("=" * 60)

    audit = {
        "pass": [],
        "warning": [],
        "fail": [],
        "human_decision": [],
    }

    n_points = len(points)
    if 480 <= n_points <= 520:
        audit["pass"].append(f"Número de pontos esperado (~500): {n_points} pontos gerados")
    else:
        audit["fail"].append(f"Número de pontos inesperado: {n_points}")

    state_counts = Counter(p["state"] for p in points)
    for st in ["MA", "TO", "PI", "BA"]:
        cnt = state_counts.get(st, 0)
        if cnt >= 100:
            audit["pass"].append(f"Estado {st}: {cnt} pontos balanceados")
        else:
            audit["fail"].append(f"Estado {st}: apenas {cnt} pontos")

    # [0, 1] range e soma unitária exata das probabilidades normalizadas
    prob_cols = [f"p_{b}" for b in DW_PROB_BANDS]
    out_of_range = 0
    sums_norm = []
    sums_before = []
    for p in points:
        vals = [p[col] for col in prob_cols]
        if all(v is not None for v in vals):
            sums_norm.append(sum(vals))
            for v in vals:
                if v < -1e-6 or v > 1.0 + 1e-6:
                    out_of_range += 1
        if p.get("probability_sum_before_normalization") is not None:
            sums_before.append(p["probability_sum_before_normalization"])

    if out_of_range == 0:
        audit["pass"].append("Probabilidades Dynamic World estritamente em [0, 1]")
    else:
        audit["fail"].append(f"Valores de probabilidade fora de [0, 1]: {out_of_range}")

    dev_norm = max(abs(min(sums_norm) - 1.0), abs(max(sums_norm) - 1.0))
    if dev_norm < 1e-5:
        audit["pass"].append(
            f"Vetor de probabilidades normalizado estritamente unitário: sum = 1.000000 (desvio max: {dev_norm:.6f})"
        )
    else:
        audit["fail"].append(f"Falha na normalização: desvio {dev_norm:.6f}")

    if sums_before:
        audit["pass"].append(
            f"Soma antes da normalização preservada para auditoria: min={min(sums_before):.5f}, "
            f"mean={sum(sums_before)/len(sums_before):.5f}, max={max(sums_before):.5f}"
        )

    # Argmax consistency
    argmax_mismatch = 0
    for p in points:
        vals = {b: p[f"p_{b}"] for b in DW_PROB_BANDS}
        if all(v is not None for v in vals.values()) and p["dw_annual_class"] is not None:
            expected = max(vals, key=vals.get)
            if expected != p["dw_annual_class"]:
                argmax_mismatch += 1
    if argmax_mismatch == 0:
        audit["pass"].append("Classe anual Dynamic World 100% consistente com argmax")
    else:
        audit["fail"].append(f"Inconsistência de argmax: {argmax_mismatch} pontos")

    # Regimes
    regimes = Counter(p["regime"] for p in points)
    audit["pass"].append(f"Regimes AA/AN/NA/NN testados e gerados: {dict(regimes)}")

    # Bordas
    valid_dists = [p["distance_edge_min_m"] for p in points if p["distance_edge_min_m"] is not None]
    if valid_dists:
        audit["pass"].append(
            f"Distâncias de borda calculadas: min={min(valid_dists):.1f}m, max={max(valid_dists):.1f}m, "
            f"média={sum(valid_dists)/len(valid_dists):.1f}m (truncadas em 250m)"
        )
    else:
        audit["fail"].append("Falha no cálculo das distâncias de borda")

    # Cobertura temporal comprovada por ponto
    v_months = [p["n_valid_months"] for p in points]
    audit["pass"].append(
        f"Cobertura temporal comprovada por ponto: min={min(v_months)}, "
        f"média={sum(v_months)/len(v_months):.1f}, max={max(v_months)} meses válidos"
    )

    # Boundary oficial
    audit["pass"].append(
        f"Delimitação oficial congelada: {boundary_info['n_municipalities']} municípios, "
        f"Área={boundary_info['area_ha_epsg5880']:,.2f} ha (EPSG:5880), SHA-256={boundary_info['sha256'][:16]}..."
    )

    print("\n" + "=" * 60)
    print("RESUMO DA AUDITORIA:")
    for item in audit["pass"]:
        print(f"  [PASS] {item}")
    for item in audit["warning"]:
        print(f"  [WARN] {item}")
    for item in audit["fail"]:
        print(f"  [FAIL] {item}")
    print("=" * 60)

    return audit


def save_prototype_csv(points: list[dict]) -> Path:
    DATA_PROC.mkdir(parents=True, exist_ok=True)
    out_path = DATA_PROC / "prototype_samples.csv"
    fieldnames = list(points[0].keys())

    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(points)

    log(f"Protótipo salvo: {out_path} ({len(points)} linhas, {len(fieldnames)} colunas)")
    return out_path


def create_experiment_manifest(
    boundary_info: dict,
    dw_info: dict,
    mb_info: dict,
    legend_audit: dict,
    stability_info: dict,
) -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    cfg_path = CONFIG_DIR / "experiment.yaml"

    manifest = {
        "experiment": {
            "name": "Dynamic World x MapBiomas — MATOPIBA 2025",
            "year": 2025,
            "random_seed": RANDOM_SEED,
            "created": datetime.now(timezone.utc).isoformat(),
            "status": "CHECKPOINT_1_PROTOTYPE_AUDITED_AND_REVISED",
        },
        "study_area": {
            "name": "MATOPIBA",
            "boundary_file": "data/reference/matopiba_boundary.geojson",
            "municipalities_file": "data/reference/matopiba_municipalities.csv",
            "boundary_sha256": boundary_info["sha256"],
            "source": boundary_info["source"],
            "definition": boundary_info["definition"],
            "n_municipalities": boundary_info["n_municipalities"],
            "area_ha_epsg5880": boundary_info["area_ha_epsg5880"],
            "area_ha_gee_geodesic": boundary_info["area_ha_gee"],
            "states": boundary_info["states"],
        },
        "products": {
            "dynamic_world": {
                "asset": DW_COLLECTION,
                "start_date": DW_START,
                "end_date_exclusive": DW_END,
                "probability_bands": DW_PROB_BANDS,
                "label_band": "label",
            },
            "mapbiomas": {
                "asset": MB_ASSET,
                "band": MB_BAND,
                "collection": "Cobertura 10m Collection 4",
                "crs": mb_info["crs"],
                "crs_transform": mb_info["crs_transform"],
                "nominal_scale_m": mb_info["nominal_scale_m"],
            },
        },
        "crosswalk": {
            "principal": {
                "crop_codes": CROP_CODES,
                "crop_code_names": {19: "Lavoura Temporaria", 36: "Lavoura Perene"},
                "excluded_codes": EXCLUDED_CODES,
                "excluded_code_names": {21: "Mosaico de Usos", 18: "Agricultura (caso ocorra)"},
            },
            "sensitivity_strict": {
                "crop_codes": CROP_STRICT_CODES,
                "crop_code_names": {19: "Lavoura Temporaria"},
            },
        },
        "spatial": {
            "primary_support_m": 10,
            "sensitivity_support_m": 30,
            "distance_crs": DISTANCE_CRS,
            "grid_reference": "MapBiomas classification_2025",
            "dw_resampling": "bilinear (probabilidades continuas)",
            "mb_resampling": "nearest neighbor (categorico)",
            "spatial_aggregation_30m": {
                "dynamic_world": "reduceResolution(mean) a partir da grade 10m",
                "mapbiomas": "reduceResolution(mode/majority) sobre binario com excluded mascarados",
                "grid_30m": "derivada exatamente da grade 10m com transform dx*3, dy*3 e mesma origem",
            },
        },
        "temporal": {
            "primary_min_valid_months": 8,
            "fallback_min_valid_months": 6,
            "daily_composition": "neutral_mean_of_same_day_duplicates",
            "monthly_composition": "mean_of_valid_daily_composites",
            "annual_composition": "equal_weight_mean_of_valid_months",
            "class_derivation": "argmax_of_probability_vector",
            "missing_months": "no_imputation",
            "per_point_accounting": "contagem exata de observacoes unmasked por mes (n_obs_m01..m12)",
        },
        "sampling": {
            "design": "stratified_random_without_replacement",
            "strata": "state_x_agreement_regime",
            "main_n": 20000,
            "robust_n": 40000,
            "min_per_active_stratum_main": 400,
            "seed": RANDOM_SEED,
        },
        "edges": {
            "max_distance_m": EDGE_MAX_DISTANCE_M,
            "connectivity": 8,
            "sources": ["MapBiomas", "Dynamic World"],
            "metrics": ["distance_edge_mb_m", "distance_edge_dw_m", "distance_edge_min_m"],
            "excluded_masking": "classes 21 e 18 mascaradas antes do calculo da borda",
            "algorithm": "fastDistanceTransform direto sobre edge=1 (sem edge.Not())",
        },
        "probability_normalization": {
            "method": "renormalizacao_neutra p'_k = p_k / sum(p)",
            "raw_sum_preserved": "probability_sum_before_normalization mantido para auditoria",
            "scientific_metrics": "entropia, top2_margin, competitor_class e dw_annual_class baseados no vetor unitario",
        },
        "inference": {
            "bootstrap_replicates": 1999,
            "bootstrap_seed": RANDOM_SEED,
            "block_size": "to_be_determined_from_semivariogram",
        },
        "stability_sensitivity": {
            "years_available": stability_info.get("years_available", []),
            "feasible": stability_info.get("feasible", False),
        },
        "software": {
            "python": sys.version.split()[0],
            "earthengine_api": ee.__version__,
        },
    }

    with open(cfg_path, "w", encoding="utf-8") as f:
        yaml.dump(manifest, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

    log(f"Manifesto salvo: {cfg_path}")
    return cfg_path


def main() -> int:
    t0 = time.time()
    log("=" * 60)
    log("Executando pipeline revisado do protótipo técnico (Checkpoint 1)")
    log("=" * 60)

    try:
        initialize_ee()
        ee_geom, boundary_info = load_official_boundary()
        dw_info, mb_info = validate_sources()
        legend_audit = audit_mapbiomas_legend(ee_geom)
        stability_info = test_mapbiomas_stability()

        points = generate_prototype_samples(ee_geom)
        audit_results = audit_prototype_dataset(points, boundary_info)
        save_prototype_csv(points)
        create_experiment_manifest(boundary_info, dw_info, mb_info, legend_audit, stability_info)

        elapsed = time.time() - t0
        log(f"\nPipeline revisado concluído com sucesso em {elapsed:.1f}s ({elapsed/60:.1f} min)!")
        return 0

    except Exception as exc:
        log(f"\nERRO: {type(exc).__name__}: {exc}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
