"""
06_master_sample_pipeline.py — Master Sample Generation & Materialization from 10m Frame
========================================================================================
Generates the definitive 40,000-point master sampling pool (with 20,000 nested main points)
strictly from the audited 10m sampling frame and updated 10m quotas:
  - Hamilton largest-remainder allocation across active 10m slices proportional to N_hs_exact
  - Exact robust quotas per stratum summing to 40,000
  - Deterministic pseudo-random main subsampling via SHA256(25|main_rank|state|regime|lon|lat)
  - Separate inclusion probabilities and weights for robust and main
  - Verification of 100% stratum match on frozen 10m rasters
  - Nearest-neighbor distances and 50km grid occupancy in EPSG:5880
"""

from __future__ import annotations

import hashlib
import json
import math
import socket
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

import requests

# Ensure Earth Engine HTTP requests never hang indefinitely
_orig_request = requests.Session.request
def _patched_request(self, *args, **kwargs):
    if "timeout" not in kwargs or kwargs["timeout"] is None:
        kwargs["timeout"] = 240
    return _orig_request(self, *args, **kwargs)
requests.Session.request = _patched_request

socket.setdefaulttimeout(300)

import ee
import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.spatial import cKDTree
from shapely.geometry import box, shape

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

from src.gee.dw_annual import (
    PROJECT_ID,
    get_harmonized_crosswalk_layers,
    get_mapbiomas_projection,
)

DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"

STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"
QUOTAS_CSV = TABLES_DIR / "sampling_quotas.csv"
FRAME_10M_CSV = TABLES_DIR / "sampling_frame_10m.csv"
CHECKPOINT_10M_SLICES = DATA_PROC / "wall_to_wall_10m_slices_checkpoint.json"
CHECKPOINT_POINTS = DATA_PROC / "master_sample_10m_points_checkpoint.json"
OUT_CSV = DATA_PROC / "master_sampling_points.csv"
SLICE_DESIGN_CSV = TABLES_DIR / "slice_sampling_design_audit.csv"

STEP_DEG = 0.75
ROOT_SEED = 25
MAX_WORKERS = 4
LOCK = threading.Lock()

REGIME_MAP = {1: "AA", 2: "AN", 3: "NA", 4: "NN"}
REGIME_REV = {"AA": 1, "AN": 2, "NA": 3, "NN": 4}
ORDERED_STATES = ["MA", "TO", "PI", "BA"]
ORDERED_REGIMES = ["AA", "AN", "NA", "NN"]


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def load_points_checkpoint() -> dict[str, list[dict]]:
    if CHECKPOINT_POINTS.exists():
        try:
            with open(CHECKPOINT_POINTS, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_slice_points(slice_id: str, points: list[dict]) -> None:
    with LOCK:
        ckpt = load_points_checkpoint()
        ckpt[slice_id] = points
        with open(CHECKPOINT_POINTS, "w", encoding="utf-8") as f:
            json.dump(ckpt, f)


def partition_state(state: str, geom_shp, step: float = STEP_DEG) -> list[tuple[str, any]]:
    min_x, min_y, max_x, max_y = geom_shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    pieces = []
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = geom_shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                pieces.append((f"{state}_x{ix:02d}_y{iy:02d}", sub))
    return pieces


def compute_slice_allocations() -> tuple[dict[str, dict[str, int]], pd.DataFrame]:
    df_quotas = pd.read_csv(QUOTAS_CSV, keep_default_na=False)
    df_frame = pd.read_csv(FRAME_10M_CSV, keep_default_na=False)

    allocations = []
    slice_allocations: dict[str, dict[str, int]] = {}

    for _, q_row in df_quotas.iterrows():
        st = q_row["state"]
        reg = q_row["regime"]
        n_robust = int(q_row["n_robust"])

        sub = df_frame[(df_frame["state"] == st) & (df_frame["regime"] == reg) & (df_frame["N_hs_exact"] > 0)].copy()
        tot_N = sub["N_hs_exact"].sum()
        assert tot_N > 0, f"No pixels for {st}_{reg}"

        raw = (sub["N_hs_exact"] / tot_N) * n_robust
        integers = raw.apply(math.floor).astype(int)
        remainders = raw - integers
        deficit = n_robust - integers.sum()

        sub["n_pts"] = integers
        sub["rem"] = remainders
        sub = sub.sort_values(by=["rem", "slice_id"], ascending=[False, True])
        sub.iloc[:deficit, sub.columns.get_loc("n_pts")] += 1

        assert sub["n_pts"].sum() == n_robust
        allocations.append(sub[["state", "regime", "slice_id", "A_hs", "N_hs_exact", "n_pts"]])

        for _, r in sub.iterrows():
            s_id = r["slice_id"]
            if s_id not in slice_allocations:
                slice_allocations[s_id] = {}
            slice_allocations[s_id][reg] = int(r["n_pts"])

    df_alloc = pd.concat(allocations, ignore_index=True)
    return slice_allocations, df_alloc


def sample_slice(
    slice_id: str,
    geom_shp,
    target_quotas: dict[str, int],
    mb_proj: ee.Projection,
) -> list[dict]:
    active_regimes = {reg: n for reg, n in target_quotas.items() if n > 0}
    if not active_regimes:
        return []

    ee_geom = ee.Geometry(geom_shp.__geo_interface__)
    slice_seed = int(hashlib.sha256(f"{ROOT_SEED}_{slice_id}".encode("utf-8")).hexdigest()[:8], 16) % 2147483647

    layers = get_harmonized_crosswalk_layers(region=ee_geom, mb_proj=mb_proj)
    regime_code = layers["regime_code"]

    class_values = [REGIME_REV[reg] for reg in active_regimes.keys()]
    # Request small 10% buffer to guarantee exact quota
    class_points = [max(n + 3, int(math.ceil(n * 1.10))) for n in active_regimes.values()]

    max_retries = 4
    for attempt in range(1, max_retries + 1):
        try:
            samples = regime_code.stratifiedSample(
                numPoints=0,
                classBand="regime_code",
                classValues=class_values,
                classPoints=class_points,
                region=ee_geom,
                scale=10,
                seed=slice_seed,
                geometries=True,
            )
            res = samples.getInfo()
            feats = res.get("features", [])

            # Filter exact quota per regime
            by_reg = {reg: [] for reg in active_regimes.keys()}
            for f in feats:
                rc = f["properties"]["regime_code"]
                reg_name = REGIME_MAP.get(rc)
                if reg_name in by_reg and len(by_reg[reg_name]) < active_regimes[reg_name]:
                    coords = f["geometry"]["coordinates"]
                    by_reg[reg_name].append({
                        "lon": coords[0],
                        "lat": coords[1],
                        "regime": reg_name,
                        "slice_id": slice_id,
                    })

            # Check if all quotas satisfied
            final_points = []
            for reg, pts in by_reg.items():
                if len(pts) < active_regimes[reg]:
                    raise RuntimeError(f"Insufficient points in {slice_id} for {reg}: got {len(pts)}, needed {active_regimes[reg]}")
                final_points.extend(pts)

            return final_points
        except Exception as exc:
            log(f"  [ERRO] {slice_id} (tentativa {attempt}/{max_retries}): {exc}")
            if attempt == max_retries:
                raise
            time.sleep(5 * attempt)

    return []


def main():
    log("=" * 80)
    log("GERAÇÃO DA MASTER SAMPLE 40.000 (FRAME 10M, ROBUST=40K, MAIN=20K)")
    log("=" * 80)

    ee.Initialize(project=PROJECT_ID)
    mb_proj = get_mapbiomas_projection()

    with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
        states_data = json.load(f)

    # 1. Partition states into 10m slices
    state_slices: dict[str, any] = {}
    slice_to_state: dict[str, str] = {}
    for feat in states_data["features"]:
        st = feat["properties"]["state"]
        shp = shape(feat["geometry"])
        pieces = partition_state(st, shp, STEP_DEG)
        for s_id, s_geom in pieces:
            state_slices[s_id] = s_geom
            slice_to_state[s_id] = st

    log(f"Total de fatias 10m: {len(state_slices)}")

    # 2. Compute allocations
    slice_allocations, df_alloc = compute_slice_allocations()
    active_slices = [s_id for s_id, q in slice_allocations.items() if sum(q.values()) > 0]
    log(f"Fatias com cotas ativas (>0): {len(active_slices)}")

    # Checkpoint check
    ckpt = load_points_checkpoint()
    pending = [s_id for s_id in active_slices if s_id not in ckpt]
    log(f"Fatias já amostradas no checkpoint: {len(ckpt)}")
    log(f"Fatias pendentes para amostragem: {len(pending)}")

    def sample_worker(s_id: str):
        t0 = time.time()
        geom = state_slices[s_id]
        target_quotas = slice_allocations[s_id]
        pts = sample_slice(s_id, geom, target_quotas, mb_proj)
        save_slice_points(s_id, pts)
        dt = time.time() - t0
        return s_id, len(pts), dt

    if pending:
        log(f"Iniciando pool com {MAX_WORKERS} workers para amostragem...")
        completed_count = len(ckpt)
        t_start = time.time()
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {executor.submit(sample_worker, s_id): s_id for s_id in pending}
            for fut in as_completed(futures):
                s_id = futures[fut]
                try:
                    s_id, n_pts, dt = fut.result()
                    completed_count += 1
                    log(f"  [{completed_count}/{len(active_slices)}] Concluído {s_id}: {n_pts} pontos amostrados ({dt:.1f}s)")
                except Exception as e:
                    log(f"FALHA na amostragem da fatia {s_id}: {e}")
                    raise

    # Reload all points
    ckpt = load_points_checkpoint()
    all_points = []
    for s_id in active_slices:
        pts = ckpt.get(s_id, [])
        st = slice_to_state[s_id]
        for p in pts:
            p["state"] = st
            all_points.append(p)

    df_pts = pd.DataFrame(all_points)
    log(f"\nTotal bruto de pontos amostrados: {len(df_pts):,}")
    assert len(df_pts) == 40000, f"Expected 40,000 points, got {len(df_pts)}"

    # 3. Deterministic SHA256 Main Subsampling & Stratum Ranking
    df_pts["stratum_id"] = df_pts["state"] + "_" + df_pts["regime"]
    df_pts["hash_key"] = [
        hashlib.sha256(f"{ROOT_SEED}|main_rank|{r['state']}|{r['regime']}|{r['lon']:.8f}|{r['lat']:.8f}".encode("utf-8")).hexdigest()
        for _, r in df_pts.iterrows()
    ]

    df_quotas = pd.read_csv(QUOTAS_CSV, keep_default_na=False)
    q_map_main = df_quotas.set_index(["state", "regime"])["n_main"].to_dict()
    q_map_robust = df_quotas.set_index(["state", "regime"])["n_robust"].to_dict()

    # Sort deterministically within each (state, regime) by hash_key
    df_pts = df_pts.sort_values(["state", "regime", "hash_key"]).reset_index(drop=True)
    df_pts["rank_within_stratum"] = df_pts.groupby(["state", "regime"]).cumcount() + 1

    df_pts["n_main_target"] = df_pts.set_index(["state", "regime"]).index.map(q_map_main)
    df_pts["n_robust_target"] = df_pts.set_index(["state", "regime"]).index.map(q_map_robust)

    df_pts["main_sample"] = (df_pts["rank_within_stratum"] <= df_pts["n_main_target"]).astype(int)
    df_pts["robust_sample"] = 1

    # Sample ID
    df_pts["sample_id"] = [f"PT_{i+1:06d}" for i in range(len(df_pts))]
    df_pts["root_seed"] = ROOT_SEED
    df_pts["stratum_seed"] = [
        int(hashlib.sha256(f"{ROOT_SEED}_{r['stratum_id']}".encode("utf-8")).hexdigest()[:8], 16) % 2147483647
        for _, r in df_pts.iterrows()
    ]

    # 4. Inclusion Probabilities and Weights by Slice
    df_frame = pd.read_csv(FRAME_10M_CSV, keep_default_na=False)
    df_design = pd.merge(df_frame, df_alloc[["state", "regime", "slice_id", "n_pts"]], on=["state", "regime", "slice_id"], how="left")
    df_design["n_pts"] = df_design["n_pts"].fillna(0).astype(int)
    df_design = df_design.rename(columns={"n_pts": "n_robust_hs"})

    # Slice probabilities
    df_design["pi_robust_hs"] = np.where(
        df_design["N_hs_exact"] > 0,
        df_design["n_robust_hs"] / df_design["N_hs_exact"],
        0.0
    )
    df_design["design_weight_robust_hs"] = np.where(
        df_design["pi_robust_hs"] > 0,
        1.0 / df_design["pi_robust_hs"],
        0.0
    )
    df_design["area_weight_robust_hs"] = np.where(
        df_design["n_robust_hs"] > 0,
        (df_design["A_hs"] * 10000.0) / df_design["n_robust_hs"],
        0.0
    )

    df_design.to_csv(SLICE_DESIGN_CSV, index=False)
    log(f"Salvo desenho por slice: {SLICE_DESIGN_CSV}")

    # Map weights back to individual points
    slice_lookup = df_design.set_index(["state", "regime", "slice_id"])[
        ["pi_robust_hs", "design_weight_robust_hs", "area_weight_robust_hs"]
    ].to_dict(orient="index")

    pi_rob_list, dw_rob_list, aw_rob_list = [], [], []
    pi_main_list, dw_main_list, aw_main_list = [], [], []

    for _, pt in df_pts.iterrows():
        key = (pt["state"], pt["regime"], pt["slice_id"])
        s_info = slice_lookup.get(key)
        ratio_main = pt["n_main_target"] / pt["n_robust_target"]  # 0.5

        if s_info and s_info["pi_robust_hs"] > 0:
            pi_rob = s_info["pi_robust_hs"]
            dw_rob = s_info["design_weight_robust_hs"]
            aw_rob = s_info["area_weight_robust_hs"]
        else:
            n_exact_stratum = df_quotas.set_index(["state", "regime"]).loc[(pt["state"], pt["regime"]), "N_h"]
            area_m2_stratum = df_quotas.set_index(["state", "regime"]).loc[(pt["state"], pt["regime"]), "area_m2"]
            pi_rob = pt["n_robust_target"] / n_exact_stratum
            dw_rob = 1.0 / pi_rob
            aw_rob = area_m2_stratum / pt["n_robust_target"]

        pi_rob_list.append(pi_rob)
        dw_rob_list.append(dw_rob)
        aw_rob_list.append(aw_rob)

        if pt["main_sample"] == 1:
            pi_main = pi_rob * ratio_main
            dw_main = 1.0 / pi_main
            aw_main = aw_rob * 2.0
            pi_main_list.append(pi_main)
            dw_main_list.append(dw_main)
            aw_main_list.append(aw_main)
        else:
            pi_main_list.append(np.nan)
            dw_main_list.append(np.nan)
            aw_main_list.append(np.nan)

    df_pts["selection_probability_robust"] = pi_rob_list
    df_pts["design_weight_robust"] = dw_rob_list
    df_pts["area_weight_robust"] = aw_rob_list

    df_pts["selection_probability_main"] = pi_main_list
    df_pts["design_weight_main"] = dw_main_list
    df_pts["area_weight_main"] = aw_main_list

    # Sort final table neatly
    st_order = {"MA": 0, "TO": 1, "PI": 2, "BA": 3}
    reg_order = {"AA": 0, "AN": 1, "NA": 2, "NN": 3}
    df_pts["st_ord"] = df_pts["state"].map(st_order)
    df_pts["reg_ord"] = df_pts["regime"].map(reg_order)
    df_pts = df_pts.sort_values(["st_ord", "reg_ord", "rank_within_stratum"]).drop(
        columns=["st_ord", "reg_ord", "n_main_target", "n_robust_target", "hash_key"]
    ).reset_index(drop=True)

    # Re-order columns with separated main and robust weights
    final_cols = [
        "sample_id",
        "lat",
        "lon",
        "state",
        "stratum_id",
        "regime",
        "slice_id",
        "main_sample",
        "robust_sample",
        "rank_within_stratum",
        "root_seed",
        "stratum_seed",
        "selection_probability_robust",
        "design_weight_robust",
        "area_weight_robust",
        "selection_probability_main",
        "design_weight_main",
        "area_weight_main",
    ]
    df_pts = df_pts[final_cols]
    df_pts.to_csv(OUT_CSV, index=False)
    log(f"Salva Master Sample definitiva: {OUT_CSV}")

    # 5. Spatial Diagnostics in EPSG:5880
    log("\nExecutando diagnóstico espacial em EPSG:5880 (SIRGAS 2000 / Polyconic)...")
    trans = Transformer.from_crs("EPSG:4326", "EPSG:5880", always_xy=True)
    xs, ys = trans.transform(df_pts["lon"].values, df_pts["lat"].values)
    coords_5880 = np.column_stack([xs, ys])

    tree = cKDTree(coords_5880)
    dists, _ = tree.query(coords_5880, k=[2])
    nn_dists = dists.flatten()

    log(f"Distância ao vizinho mais próximo em EPSG:5880 (m):")
    log(f"  Mínimo:            {nn_dists.min():.1f} m")
    log(f"  Percentil 25 (Q1): {np.percentile(nn_dists, 25):.1f} m")
    log(f"  Mediana:           {np.median(nn_dists):.1f} m")
    log(f"  Média:             {np.mean(nn_dists):.1f} m")
    log(f"  Percentil 75 (Q3): {np.percentile(nn_dists, 75):.1f} m")
    log(f"  Máximo:            {nn_dists.max():.1f} m")

    grid_size = 50000.0  # 50km
    grid_cells = set(zip(np.floor(xs / grid_size), np.floor(ys / grid_size)))
    log(f"Ocupação de grade métrica (50 km x 50 km em EPSG:5880): {len(grid_cells)} células ocupadas")

    log("=" * 80)
    log("MASTER SAMPLE 10M MATERIALIZADA COM SUCESSO!")
    log("=" * 80)


if __name__ == "__main__":
    main()
