import time
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

# Let's test on PI state geometry
import json
with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

pi_feat = next(f for f in d["features"] if f["properties"]["state"] == "PI")
pi_geom = ee.Geometry(pi_feat["geometry"])

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

dw_col = (
    ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
    .filterBounds(pi_geom)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)
m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()
dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
dw_max = dw_10m.reduce(ee.Reducer.max())
dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

eligible_mask = valid_mb_mask.And(dw_crop.mask())

# Regime: 1=AA, 2=AN, 3=NA, 4=NN
regime_img = (
    ee.Image(0)
    .where(mb_crop.eq(1).And(dw_crop.eq(1)), 1)
    .where(mb_crop.eq(1).And(dw_crop.eq(0)), 2)
    .where(mb_crop.eq(0).And(dw_crop.eq(1)), 3)
    .where(mb_crop.eq(0).And(dw_crop.eq(0)), 4)
    .rename("regime")
    .updateMask(eligible_mask)
)

# Test 1: stratifiedSample directly on PI (total PI quota is 6,248 points)
# Can stratifiedSample extract points for all 4 classes at once?
print("Testing stratifiedSample on PI for 4 classes...")
t0 = time.time()
pts_strat = regime_img.stratifiedSample(
    numPoints=100, # small test of 100 per class
    classBand="regime",
    region=pi_geom,
    scale=10,
    seed=25,
    geometries=True
)
pts_list = pts_strat.getInfo()["features"]
print(f"stratifiedSample done in {time.time() - t0:.2f}s! Returned {len(pts_list)} points.")
for p in pts_list[:3]:
    print(" ", p["properties"], p["geometry"]["coordinates"])
