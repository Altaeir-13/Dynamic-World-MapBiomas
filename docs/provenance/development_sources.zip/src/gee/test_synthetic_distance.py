"""
test_synthetic_distance.py — Teste sintético numérico de fastDistanceTransform
=============================================================================
Demonstra numericamente:
- pixel de borda -> distância 0 m;
- pixel a 1 pixel da borda -> aproximadamente 10 m;
- pixel a 2 pixels da borda -> aproximadamente 20 m;
- pixel a 3 pixels da borda -> aproximadamente 30 m;
- pixel a 5 pixels da borda -> aproximadamente 50 m;
- valores distantes (>250m) -> truncados em 250 m.
"""

from __future__ import annotations

import ee


def run_synthetic_test():
    ee.Initialize(project="dynamicworld-x-mapbiomas")

    cx, cy = 5986630.0, 8880690.0

    # Linha vertical em EPSG:5880 no x = cx
    line = ee.Geometry.LineString([[cx, cy - 500], [cx, cy + 500]], "EPSG:5880", geodesic=False)

    # Imagem base com 0, e a linha pintada com valor 1 (largura 10m / 1 pixel)
    base_img = ee.Image(0).reproject(crs="EPSG:5880", scale=10)
    edge_img = base_img.paint(line, 1).reproject(crs="EPSG:5880", scale=10)

    # fastDistanceTransform diretamente no edge_img (pixels de borda = 1, outros = 0)
    # distance to nearest non-zero pixel:
    # units='pixels', metric='squared_euclidean' -> sqrt() * scale (10m) -> clamp(0, 250)
    dist_img = (
        edge_img.fastDistanceTransform(neighborhood=25, units="pixels", metric="squared_euclidean")
        .sqrt()
        .multiply(10)
        .clamp(0, 250)
        .rename("dist_m")
    )

    pts = ee.FeatureCollection([
        ee.Feature(ee.Geometry.Point([cx, cy], "EPSG:5880"), {"step": 0, "desc": "pixel de borda"}),
        ee.Feature(ee.Geometry.Point([cx + 10, cy], "EPSG:5880"), {"step": 1, "desc": "1 pixel da borda"}),
        ee.Feature(ee.Geometry.Point([cx + 20, cy], "EPSG:5880"), {"step": 2, "desc": "2 pixels da borda"}),
        ee.Feature(ee.Geometry.Point([cx + 30, cy], "EPSG:5880"), {"step": 3, "desc": "3 pixels da borda"}),
        ee.Feature(ee.Geometry.Point([cx + 50, cy], "EPSG:5880"), {"step": 5, "desc": "5 pixels da borda"}),
        ee.Feature(ee.Geometry.Point([cx + 300, cy], "EPSG:5880"), {"step": 30, "desc": "distante (>250m)"}),
    ])

    res = dist_img.reduceRegions(collection=pts, reducer=ee.Reducer.first(), scale=10, crs="EPSG:5880").getInfo()

    print("=" * 60)
    print("DEMONSTRAÇÃO NUMÉRICA DO TESTE SINTÉTICO (EPSG:5880, 10m):")
    print("=" * 60)
    results = []
    for f in res["features"]:
        p = f["properties"]
        desc = p["desc"]
        step = p["step"]
        dist = p["first"]
        results.append((desc, step, dist))
        print(f"  {desc:25s} (passo {step:2d} px) -> distância = {dist:6.2f} m")
    print("=" * 60)

    # Asserções matemáticas rigorosas:
    assert results[0][2] == 0.0, f"Borda esperada 0.0m, obtido {results[0][2]}"
    assert abs(results[1][2] - 10.0) < 1.0, f"1 px esperado ~10m, obtido {results[1][2]}"
    assert abs(results[2][2] - 20.0) < 1.0, f"2 px esperado ~20m, obtido {results[2][2]}"
    assert abs(results[3][2] - 30.0) < 1.0, f"3 px esperado ~30m, obtido {results[3][2]}"
    assert abs(results[4][2] - 50.0) < 1.0, f"5 px esperado ~50m, obtido {results[4][2]}"
    assert results[5][2] == 250.0, f"Distante esperado 250.0m (truncado), obtido {results[5][2]}"
    print("TESTE SINTÉTICO APROVADO COM SUCESSO!")
    return results


if __name__ == "__main__":
    run_synthetic_test()
