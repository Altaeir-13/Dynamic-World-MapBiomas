import time
import json
import ee
from collections import Counter
from shapely.geometry import shape, box, mapping

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

ma_feat = next(f for f in d["features"] if f["properties"]["state"] == "MA")
ma_shape = shape(ma_feat["geometry"])
min_x, min_y, max_x, max_y = ma_shape.bounds
mid_y = (min_y + max_y) / 2.0

b_south = box(min_x - 0.1, min_y - 0.1, max_x + 0.1, mid_y)
geom_s = ma_shape.intersection(b_south)
ee_geom_s = ee.Geometry(mapping(geom_s))

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask).rename("mb_crop")

dw_col = (
    ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
    .filterBounds(ee_geom_s)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)
m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()
dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
dw_max = dw_10m.reduce(ee.Reducer.max())
dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

eligible_mask = valid_mb_mask.And(dw_crop.mask())
stack = ee.Image.cat([mb_crop, dw_crop]).updateMask(eligible_mask)

# Test 4,000 points in MA_south
t0 = time.time()
pts = ee.FeatureCollection.randomPoints(region=ee_geom_s, points=4000, seed=25)
print(f"randomPoints(4000) created. Extracting in GEE...")
sampled = stack.reduceRegions(
    collection=pts,
    reducer=ee.Reducer.first(),
    scale=10
)
res = sampled.getInfo()["features"]
print(f"Extracted {len(res)} points in {time.time() - t0:.2f}s!")
valid_pts = [f for f in res if f["properties"].get("mb_crop") is not None and f["properties"].get("dw_crop") is not None]
counts = Counter((f["properties"]["mb_crop"], f["properties"]["dw_crop"]) for f in valid_pts)
print(f"Valid points: {len(valid_pts)} / {len(res)}")
print("Distribution (mb, dw):", counts)
