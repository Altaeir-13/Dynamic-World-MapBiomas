import json
import time
from pathlib import Path
import ee
from shapely.geometry import shape, box, mapping

ee.Initialize(project="dynamicworld-x-mapbiomas")

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_REF = BASE_DIR / "data" / "reference"
STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"

with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
    states_data = json.load(f)

ma_feat = next(f for f in states_data["features"] if f["properties"]["state"] == "MA")
ma_shape = shape(ma_feat["geometry"])
min_x, min_y, max_x, max_y = ma_shape.bounds
mid_y = (min_y + max_y) / 2.0  # -6.25

b_south = box(min_x - 0.1, min_y - 0.1, max_x + 0.1, mid_y)
b_north = box(min_x - 0.1, mid_y, max_x + 0.1, max_y + 0.1)

geom_s = ma_shape.intersection(b_south)
geom_n = ma_shape.intersection(b_north)

print(f"MA original area deg^2: {ma_shape.area:.6f}")
print(f"MA South: {geom_s.area:.6f}, MA North: {geom_n.area:.6f}")
print(f"Sum diff: {abs(ma_shape.area - (geom_s.area + geom_n.area)):.1e}")

# Test South piece in GEE
ee_geom_s = ee.Geometry(mapping(geom_s))

DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"

mb = ee.Image(MB_ASSET).select(MB_BAND)
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

dw_col = (
    ee.ImageCollection(DW_COLLECTION)
    .filterBounds(ee_geom_s)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)

m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()
dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
dw_max = dw_10m.reduce(ee.Reducer.max())
dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

eligible_mask = valid_mb_mask.And(dw_crop.mask())
pixel_area_ha = ee.Image.pixelArea().divide(10000.0)

area_stack = ee.Image.cat([
    pixel_area_ha.updateMask(eligible_mask).rename("area_eligible_ha"),
    pixel_area_ha.updateMask(is_excluded.updateMask(mb.mask())).rename("area_excluded_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(1).And(dw_crop.eq(1)).updateMask(eligible_mask)).rename("area_AA_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(1).And(dw_crop.eq(0)).updateMask(eligible_mask)).rename("area_AN_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(0).And(dw_crop.eq(1)).updateMask(eligible_mask)).rename("area_NA_ha"),
    pixel_area_ha.updateMask(mb_crop.eq(0).And(dw_crop.eq(0)).updateMask(eligible_mask)).rename("area_NN_ha"),
])

t0 = time.time()
print("Starting reduceRegion on MA South piece at scale=30...")
stats_s = area_stack.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=ee_geom_s,
    scale=30,
    maxPixels=1e13,
    tileScale=8,
).getInfo()
print(f"MA South done in {time.time() - t0:.2f}s: {stats_s}")
