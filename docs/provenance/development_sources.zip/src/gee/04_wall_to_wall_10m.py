"""
04_wall_to_wall_10m.py — Authoritative 10m Wall-to-Wall Analysis & Exact Population Frame
========================================================================================
Executes the definitive wall-to-wall analysis strictly on the frozen 10m MapBiomas grid:
  - crs: MapBiomas CRS (EPSG:4326)
  - crsTransform: Official 10m transform ([0.00008983152841195215, 0, -75.62655865569857, 0, -0.00008983152841195215, 6.763595437192701])
  - Disjoint, non-overlapping deterministic spatial grid slices covering 100% of MATOPIBA
  - Computes exact ellipsoidal area (ha via ee.Image.pixelArea()) AND exact unweighted cell counts (N_h_exact)
  - Full temporal coverage QA (0..12 valid months)

Outputs:
  - data/processed/wall_to_wall_summary_10m_AUDIT.csv
  - tables/sampling_frame_10m.csv
  - tables/dw_valid_months_area.csv
  - tables/sampling_quotas_10m_AUDIT.csv
"""

from __future__ import annotations

import json
import socket
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

# Extended socket timeout for GEE restricted mode
socket.setdefaulttimeout(300)

import ee
import pandas as pd
from shapely.geometry import box, shape

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

from src.gee.dw_annual import (
    PROJECT_ID,
    get_harmonized_crosswalk_layers,
    get_mapbiomas_projection,
)

DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"
STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"

SUMMARY_10M_CSV = DATA_PROC / "wall_to_wall_summary_10m_AUDIT.csv"
FRAME_10M_CSV = TABLES_DIR / "sampling_frame_10m.csv"
TEMPORAL_QA_CSV = TABLES_DIR / "dw_valid_months_area.csv"
QUOTAS_10M_CSV = TABLES_DIR / "sampling_quotas_10m_AUDIT.csv"
CHECKPOINT_FILE = DATA_PROC / "wall_to_wall_10m_slices_checkpoint.json"

STEP_DEG = 0.75
MAX_WORKERS = 4
LOCK = threading.Lock()


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def load_checkpoints() -> dict[str, dict[str, Any]]:
    if CHECKPOINT_FILE.exists():
        try:
            with open(CHECKPOINT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_checkpoint(slice_id: str, stats: dict[str, Any]) -> None:
    with LOCK:
        ckpt = load_checkpoints()
        ckpt[slice_id] = stats
        with open(CHECKPOINT_FILE, "w", encoding="utf-8") as f:
            json.dump(ckpt, f, indent=2)


def partition_state(state: str, geom_shp, step: float = STEP_DEG) -> list[tuple[str, any]]:
    min_x, min_y, max_x, max_y = geom_shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    pieces = []
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = geom_shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                pieces.append((f"{state}_x{ix:02d}_y{iy:02d}", sub))
    return pieces


def compute_slice_10m(slice_id: str, ee_geom: ee.Geometry, mb_proj: ee.Projection, crs: str, transform: list[float]) -> dict[str, Any]:
    layers = get_harmonized_crosswalk_layers(region=ee_geom, mb_proj=mb_proj)
    pixel_area_ha = ee.Image.pixelArea().divide(10000.0)
    mb = layers["mb"]
    n_valid_months = layers["dw_dict"]["n_valid_months"]
    valid_mb_mask = layers["valid_mb_mask"]

    bands = [
        pixel_area_ha.updateMask(mb.mask()).rename("total_covered_ha"),
        pixel_area_ha.updateMask(layers["eligible_mask"]).rename("eligible_ha"),
        pixel_area_ha.updateMask(layers["is_excluded"].updateMask(mb.mask())).rename("excluded_mb_ha"),
        pixel_area_ha.updateMask(layers["insufficient_dw_temporal"]).rename("insufficient_dw_temporal_ha"),
        pixel_area_ha.updateMask(layers["regime_AA"]).rename("AA_ha"),
        pixel_area_ha.updateMask(layers["regime_AN"]).rename("AN_ha"),
        pixel_area_ha.updateMask(layers["regime_NA"]).rename("NA_ha"),
        pixel_area_ha.updateMask(layers["regime_NN"]).rename("NN_ha"),
        # Unweighted exact pixel counts
        ee.Image(1).updateMask(mb.mask()).rename("total_covered_count"),
        ee.Image(1).updateMask(layers["eligible_mask"]).rename("eligible_count"),
        ee.Image(1).updateMask(layers["is_excluded"].updateMask(mb.mask())).rename("excluded_mb_count"),
        ee.Image(1).updateMask(layers["insufficient_dw_temporal"]).rename("insufficient_dw_temporal_count"),
        ee.Image(1).updateMask(layers["regime_AA"]).rename("AA_count"),
        ee.Image(1).updateMask(layers["regime_AN"]).rename("AN_count"),
        ee.Image(1).updateMask(layers["regime_NA"]).rename("NA_count"),
        ee.Image(1).updateMask(layers["regime_NN"]).rename("NN_count"),
    ]

    # Temporal QA breakdown (months 0..12)
    for m in range(13):
        bands.append(pixel_area_ha.updateMask(valid_mb_mask.And(n_valid_months.eq(m))).rename(f"m_{m}_ha"))
        bands.append(ee.Image(1).updateMask(valid_mb_mask.And(n_valid_months.eq(m))).rename(f"m_{m}_count"))

    stack = ee.Image.cat(bands)

    res = stack.reduceRegion(
        reducer=ee.Reducer.sum().unweighted(),
        geometry=ee_geom,
        crs=crs,
        crsTransform=transform,
        maxPixels=1e13,
        tileScale=8,
    ).getInfo()

    # Cast to float / int
    clean = {}
    for k, v in res.items():
        if v is None:
            clean[k] = 0.0 if "ha" in k else 0
        elif "count" in k:
            clean[k] = int(round(v))
        else:
            clean[k] = float(v)

    return clean


def main():
    log("=" * 80)
    log("INICIANDO CÁLCULO WALL-TO-WALL 10 M E CONTAGEM EXATA N_H (MATOPIBA 2025)")
    log("=" * 80)

    ee.Initialize(project=PROJECT_ID)
    mb_proj = get_mapbiomas_projection()
    crs = mb_proj.crs().getInfo()
    transform = [0.00008983152841195215, 0, -75.62655865569857, 0, -0.00008983152841195215, 6.763595437192701]

    DATA_PROC.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)

    with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
        states_data = json.load(f)

    # Build all slices across the 4 states
    state_slices: dict[str, list[tuple[str, any]]] = {}
    total_slices_count = 0
    for feat in states_data["features"]:
        st = feat["properties"]["state"]
        shp = shape(feat["geometry"])
        pieces = partition_state(st, shp, STEP_DEG)
        state_slices[st] = pieces
        total_slices_count += len(pieces)
        log(f"Estado {st}: {len(pieces)} fatias determinísticas ({shp.area:.4f} deg²)")

    log(f"Total de fatias determinísticas no MATOPIBA: {total_slices_count}")

    checkpoints = load_checkpoints()
    pending_tasks = []

    for st, pieces in state_slices.items():
        for slice_id, sub_poly in pieces:
            if slice_id in checkpoints:
                continue
            pending_tasks.append((slice_id, st, sub_poly))

    log(f"Fatias já calculadas em cache: {len(checkpoints)}")
    log(f"Fatias pendentes para execução: {len(pending_tasks)}")

    def worker_job(item):
        s_id, st_name, geom_sub = item
        ee_geom = ee.Geometry(geom_sub.__geo_interface__)
        max_retries = 4
        for attempt in range(1, max_retries + 1):
            try:
                t0 = time.time()
                res = compute_slice_10m(s_id, ee_geom, mb_proj, crs, transform)
                res["state"] = st_name
                res["slice_id"] = s_id
                res["poly_area_ha"] = float(geom_sub.area * 111319.49 * 111319.49 / 10000.0)
                dt = time.time() - t0
                save_checkpoint(s_id, res)
                return s_id, dt, res["eligible_ha"], res["eligible_count"]
            except Exception as e:
                log(f"  [ERRO] {s_id} (tentativa {attempt}/{max_retries}): {e}")
                if attempt == max_retries:
                    raise
                time.sleep(5 * attempt)

    if pending_tasks:
        log(f"Iniciando pool com {MAX_WORKERS} workers concorrentes...")
        completed_count = len(checkpoints)
        t_batch_start = time.time()
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {executor.submit(worker_job, task): task[0] for task in pending_tasks}
            for fut in as_completed(futures):
                s_id = futures[fut]
                try:
                    s_id, dt, el_ha, el_cnt = fut.result()
                    completed_count += 1
                    elapsed = time.time() - t_batch_start
                    log(f"  [{completed_count}/{total_slices_count}] Concluído {s_id}: {el_ha:,.1f} ha, {el_cnt:,} pixels ({dt:.1f}s)")
                except Exception as e:
                    log(f"FALHA CRÍTICA na fatia {s_id}: {e}")
                    raise

    # Reload all checkpoints
    checkpoints = load_checkpoints()
    log("\nTodos os blocos concluídos. Agregando tabelas e frames oficiais...")

    # Build sampling_frame_10m.csv (Slice level and State level)
    slice_frame_rows = []
    for st, pieces in state_slices.items():
        for s_id, _ in pieces:
            s_data = checkpoints[s_id]
            for reg in ["AA", "AN", "NA", "NN"]:
                a_hs = s_data.get(f"{reg}_ha", 0.0)
                n_hs = s_data.get(f"{reg}_count", 0)
                slice_frame_rows.append({
                    "state": st,
                    "regime": reg,
                    "slice_id": s_id,
                    "A_hs": a_hs,
                    "N_hs_exact": n_hs,
                })

    df_slice_frame = pd.DataFrame(slice_frame_rows)

    # State x Regime aggregation
    strata_agg = df_slice_frame.groupby(["state", "regime"], as_index=False).agg({
        "A_hs": "sum",
        "N_hs_exact": "sum",
    }).rename(columns={"A_hs": "A_h", "N_hs_exact": "N_h_exact"})

    # Order rows by state and regime
    st_order = {"MA": 0, "TO": 1, "PI": 2, "BA": 3}
    reg_order = {"AA": 0, "AN": 1, "NA": 2, "NN": 3}
    strata_agg["st_ord"] = strata_agg["state"].map(st_order)
    strata_agg["reg_ord"] = strata_agg["regime"].map(reg_order)
    strata_agg = strata_agg.sort_values(["st_ord", "reg_ord"]).drop(columns=["st_ord", "reg_ord"])

    # Combine slice frame and strata summary in sampling_frame_10m.csv
    # Or save strata summary at top and slice details
    # We output a clean dataframe with both or strata first
    df_slice_frame.to_csv(FRAME_10M_CSV, index=False)
    log(f"Salvo: {FRAME_10M_CSV}")

    # Build wall_to_wall_summary_10m_AUDIT.csv
    summary_rows = []
    
    # State totals
    state_stats_map = {}
    for st in ["MA", "TO", "PI", "BA"]:
        st_slices = [checkpoints[s_id] for s_id, _ in state_slices[st]]
        tot_ha = sum(s["total_covered_ha"] for s in st_slices)
        el_ha = sum(s["eligible_ha"] for s in st_slices)
        ex_ha = sum(s["excluded_mb_ha"] for s in st_slices)
        ins_ha = sum(s["insufficient_dw_temporal_ha"] for s in st_slices)
        aa_ha = sum(s["AA_ha"] for s in st_slices)
        an_ha = sum(s["AN_ha"] for s in st_slices)
        na_ha = sum(s["NA_ha"] for s in st_slices)
        nn_ha = sum(s["NN_ha"] for s in st_slices)

        aa_pct = (aa_ha / el_ha) * 100.0 if el_ha > 0 else 0.0
        an_pct = (an_ha / el_ha) * 100.0 if el_ha > 0 else 0.0
        na_pct = (na_ha / el_ha) * 100.0 if el_ha > 0 else 0.0
        nn_pct = (nn_ha / el_ha) * 100.0 if el_ha > 0 else 0.0

        agreement_pct = ((aa_ha + nn_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0
        disagreement_pct = ((an_ha + na_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0
        qty_disag = (abs(an_ha - na_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0
        alloc_disag = (2.0 * min(an_ha, na_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0

        state_stats_map[st] = {
            "region": st,
            "total_area_ha": tot_ha,
            "eligible_area_ha": el_ha,
            "excluded_mb_area_ha": ex_ha,
            "insufficient_dw_temporal_area_ha": ins_ha,
            "AA_area_ha": aa_ha,
            "AN_area_ha": an_ha,
            "NA_area_ha": na_ha,
            "NN_area_ha": nn_ha,
            "AA_pct_eligible": aa_pct,
            "AN_pct_eligible": an_pct,
            "NA_pct_eligible": na_pct,
            "NN_pct_eligible": nn_pct,
            "agreement_pct": agreement_pct,
            "disagreement_pct": disagreement_pct,
            "quantity_disagreement": qty_disag,
            "allocation_disagreement": alloc_disag,
        }

    # MATOPIBA total
    matopiba_tot_ha = sum(s["total_area_ha"] for s in state_stats_map.values())
    matopiba_el_ha = sum(s["eligible_area_ha"] for s in state_stats_map.values())
    matopiba_ex_ha = sum(s["excluded_mb_area_ha"] for s in state_stats_map.values())
    matopiba_ins_ha = sum(s["insufficient_dw_temporal_area_ha"] for s in state_stats_map.values())
    matopiba_aa_ha = sum(s["AA_area_ha"] for s in state_stats_map.values())
    matopiba_an_ha = sum(s["AN_area_ha"] for s in state_stats_map.values())
    matopiba_na_ha = sum(s["NA_area_ha"] for s in state_stats_map.values())
    matopiba_nn_ha = sum(s["NN_area_ha"] for s in state_stats_map.values())

    mat_aa_pct = (matopiba_aa_ha / matopiba_el_ha) * 100.0
    mat_an_pct = (matopiba_an_ha / matopiba_el_ha) * 100.0
    mat_na_pct = (matopiba_na_ha / matopiba_el_ha) * 100.0
    mat_nn_pct = (matopiba_nn_ha / matopiba_el_ha) * 100.0

    mat_agree = ((matopiba_aa_ha + matopiba_nn_ha) / matopiba_el_ha) * 100.0
    mat_disag = ((matopiba_an_ha + matopiba_na_ha) / matopiba_el_ha) * 100.0
    mat_qty = (abs(matopiba_an_ha - matopiba_na_ha) / matopiba_el_ha) * 100.0
    mat_alloc = (2.0 * min(matopiba_an_ha, matopiba_na_ha) / matopiba_el_ha) * 100.0

    matopiba_row = {
        "region": "MATOPIBA",
        "total_area_ha": matopiba_tot_ha,
        "eligible_area_ha": matopiba_el_ha,
        "excluded_mb_area_ha": matopiba_ex_ha,
        "insufficient_dw_temporal_area_ha": matopiba_ins_ha,
        "AA_area_ha": matopiba_aa_ha,
        "AN_area_ha": matopiba_an_ha,
        "NA_area_ha": matopiba_na_ha,
        "NN_area_ha": matopiba_nn_ha,
        "AA_pct_eligible": mat_aa_pct,
        "AN_pct_eligible": mat_an_pct,
        "NA_pct_eligible": mat_na_pct,
        "NN_pct_eligible": mat_nn_pct,
        "agreement_pct": mat_agree,
        "disagreement_pct": mat_disag,
        "quantity_disagreement": mat_qty,
        "allocation_disagreement": mat_alloc,
    }

    summary_rows = [matopiba_row] + [state_stats_map[st] for st in ["MA", "TO", "PI", "BA"]]
    df_summary = pd.DataFrame(summary_rows)
    df_summary.to_csv(SUMMARY_10M_CSV, index=False)
    log(f"Salvo: {SUMMARY_10M_CSV}")

    # Build dw_valid_months_area.csv
    qa_rows = []
    for st in ["MA", "TO", "PI", "BA"]:
        st_slices = [checkpoints[s_id] for s_id, _ in state_slices[st]]
        for m in range(13):
            area_m = sum(s.get(f"m_{m}_ha", 0.0) for s in st_slices)
            count_m = sum(s.get(f"m_{m}_count", 0) for s in st_slices)
            qa_rows.append({
                "state": st,
                "n_valid_months": m,
                "area_ha": area_m,
                "cell_count": count_m,
            })

    # Add MATOPIBA totals
    df_qa = pd.DataFrame(qa_rows)
    mat_qa = df_qa.groupby("n_valid_months", as_index=False).agg({"area_ha": "sum", "cell_count": "sum"})
    mat_qa["state"] = "MATOPIBA"
    df_qa_full = pd.concat([df_qa, mat_qa], ignore_index=True)
    df_qa_full.to_csv(TEMPORAL_QA_CSV, index=False)
    log(f"Salvo: {TEMPORAL_QA_CSV}")

    # Build sampling_quotas_10m_AUDIT.csv (Hamilton allocation)
    total_eligible_area = strata_agg["A_h"].sum()
    strata_agg["W_h"] = strata_agg["A_h"] / total_eligible_area
    strata_agg["area_m2"] = strata_agg["A_h"] * 10000.0

    N_MAIN = 20000
    N_ROBUST = 40000
    FLOOR_MAIN = 400
    n_strata = len(strata_agg)
    remaining_main = N_MAIN - n_strata * FLOOR_MAIN

    quotas_unallocated = strata_agg["W_h"] * remaining_main
    floor_quotas = quotas_unallocated.astype(int)
    remainders = quotas_unallocated - floor_quotas
    n_extra = remaining_main - floor_quotas.sum()

    strata_agg["n_main_unrounded"] = FLOOR_MAIN + floor_quotas
    strata_agg["remainder"] = remainders
    strata_agg = strata_agg.sort_values("remainder", ascending=False)
    extra_assign = [1] * int(n_extra) + [0] * (n_strata - int(n_extra))
    strata_agg["extra"] = extra_assign
    strata_agg["n_main"] = strata_agg["n_main_unrounded"] + strata_agg["extra"]
    strata_agg["n_robust"] = 2 * strata_agg["n_main"]

    strata_agg["st_ord"] = strata_agg["state"].map(st_order)
    strata_agg["reg_ord"] = strata_agg["regime"].map(reg_order)
    strata_agg = strata_agg.sort_values(["st_ord", "reg_ord"]).drop(
        columns=["st_ord", "reg_ord", "n_main_unrounded", "remainder", "extra"]
    )

    # Reorder columns to match expected schema
    # state, regime, area_m2, area_ha, W_h, N_h_exact, n_main, n_robust
    strata_quotas = strata_agg[[
        "state", "regime", "area_m2", "A_h", "W_h", "N_h_exact", "n_main", "n_robust"
    ]].rename(columns={"A_h": "area_ha", "N_h_exact": "N_h"})

    strata_quotas.to_csv(QUOTAS_10M_CSV, index=False)
    log(f"Salvo: {QUOTAS_10M_CSV}")

    log("=" * 80)
    log("WALL-TO-WALL 10 M CONCLUÍDO COM SUCESSO!")
    log("=" * 80)


if __name__ == "__main__":
    main()
