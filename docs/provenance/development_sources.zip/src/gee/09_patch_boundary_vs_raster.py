"""
09_patch_boundary_vs_raster.py — Patch B: Área do Boundary vs Cobertura Raster
=============================================================================
Calcula separadamente:
  1. boundary_vector_area_geodesic_ha (área geodésica WGS84 do vetor oficial)
  2. boundary_vector_area_epsg5880_ha (área projetada SIRGAS 2000 Policonica)
  3. mapbiomas_raster_covered_area_ha (soma das células 10m com dado MapBiomas)
  4. difference_boundary_vs_raster_ha (discrepância boundary vs raster)
  5. difference_pct (percentual de diferença)

Gera:
  tables/boundary_vs_raster_area_comparison.csv
e exporta os valores para inclusão no sampling_manifest.yaml.
"""

from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path

import geopandas as gpd
import pandas as pd
from pyproj import Geod

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

BOUNDARY_GEOJSON = BASE_DIR / "data" / "reference" / "matopiba_boundary.geojson"
SUMMARY_10M_CSV = BASE_DIR / "data" / "processed" / "wall_to_wall_summary_10m_AUDIT.csv"
OUTPUT_CSV = BASE_DIR / "tables" / "boundary_vs_raster_area_comparison.csv"


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def main():
    log("=== INICIANDO PATCH B: ÁREA DO BOUNDARY VS COBERTURA RASTER ===")

    # 1. Carregar boundary vetorial
    log(f"Lendo boundary: {BOUNDARY_GEOJSON}")
    gdf = gpd.read_file(BOUNDARY_GEOJSON)

    # 2. Calcular área geodésica WGS84
    geod = Geod(ellps="WGS84")
    geom = gdf.geometry.iloc[0]
    area_m2_geodesic, _ = geod.geometry_area_perimeter(geom)
    boundary_vector_area_geodesic_ha = abs(area_m2_geodesic) / 10000.0

    # 3. Calcular área projetada EPSG:5880 (SIRGAS 2000 / Brazil Polyconic)
    gdf_5880 = gdf.to_crs("EPSG:5880")
    area_m2_epsg5880 = gdf_5880.geometry.area.iloc[0]
    boundary_vector_area_epsg5880_ha = area_m2_epsg5880 / 10000.0

    # 4. Ler área de cobertura raster MapBiomas 10m
    log(f"Lendo summary wall-to-wall 10m: {SUMMARY_10M_CSV}")
    df_w2w = pd.read_csv(SUMMARY_10M_CSV)
    matopiba_row = df_w2w[df_w2w["region"] == "MATOPIBA"].iloc[0]

    # total_covered_ha no wall-to-wall 10m
    # (anteriormente chamado de total_area_ha, representa a área das células raster cobertas)
    mapbiomas_raster_covered_area_ha = float(matopiba_row["total_area_ha"])

    # 5. Diferenças
    diff_geodesic_ha = boundary_vector_area_geodesic_ha - mapbiomas_raster_covered_area_ha
    diff_geodesic_pct = (diff_geodesic_ha / boundary_vector_area_geodesic_ha) * 100.0

    diff_5880_ha = boundary_vector_area_epsg5880_ha - mapbiomas_raster_covered_area_ha
    diff_5880_pct = (diff_5880_ha / boundary_vector_area_epsg5880_ha) * 100.0

    log("Resultados das Áreas:")
    log(f"  1. boundary_vector_area_geodesic_ha:  {boundary_vector_area_geodesic_ha:,.2f} ha")
    log(f"  2. boundary_vector_area_epsg5880_ha:   {boundary_vector_area_epsg5880_ha:,.2f} ha")
    log(f"  3. mapbiomas_raster_covered_area_ha:  {mapbiomas_raster_covered_area_ha:,.2f} ha")
    log(f"  4. difference (Geodésica - Raster):   {diff_geodesic_ha:,.2f} ha ({diff_geodesic_pct:.4f}%)")
    log(f"  5. difference (EPSG:5880 - Raster):   {diff_5880_ha:,.2f} ha ({diff_5880_pct:.4f}%)")

    # 6. Salvar tabela comparativa
    comparison_df = pd.DataFrame([
        {
            "metric": "boundary_vector_area_geodesic_ha",
            "value_ha": boundary_vector_area_geodesic_ha,
            "description": "Área geodésica exata do polígono vetorial MATOPIBA (elipsoide WGS84)",
        },
        {
            "metric": "boundary_vector_area_epsg5880_ha",
            "value_ha": boundary_vector_area_epsg5880_ha,
            "description": "Área projetada do polígono vetorial MATOPIBA em EPSG:5880 (SIRGAS 2000)",
        },
        {
            "metric": "mapbiomas_raster_covered_area_ha",
            "value_ha": mapbiomas_raster_covered_area_ha,
            "description": "Área física das células 10m MapBiomas com dado não-nulo dentro do domínio",
        },
        {
            "metric": "difference_boundary_geodesic_vs_raster_ha",
            "value_ha": diff_geodesic_ha,
            "description": "Diferença boundary geodésico vs cobertura raster MapBiomas",
        },
        {
            "metric": "difference_boundary_geodesic_vs_raster_pct",
            "value_ha": diff_geodesic_pct,
            "description": "Percentual de diferença boundary geodésico vs cobertura raster",
        },
        {
            "metric": "difference_boundary_5880_vs_raster_ha",
            "value_ha": diff_5880_ha,
            "description": "Diferença boundary EPSG:5880 vs cobertura raster MapBiomas",
        },
        {
            "metric": "difference_boundary_5880_vs_raster_pct",
            "value_ha": diff_5880_pct,
            "description": "Percentual de diferença boundary EPSG:5880 vs cobertura raster",
        },
        {
            "metric": "raster_uncovered_or_center_rule_area_ha",
            "value_ha": diff_geodesic_ha,
            "description": "Área não coberta por raster devido à regra do centróide de pixel na borda",
        }
    ])
    comparison_df.to_csv(OUTPUT_CSV, index=False)
    log(f"Salvo comparativo: {OUTPUT_CSV}")

    # Atualizar wall_to_wall_summary_10m_AUDIT.csv e wall_to_wall_summary.csv
    # Renomeando a coluna 'total_area_ha' para deixar inequívoco que é raster_covered_area_ha,
    # mantendo alias para total_area_ha
    log("=== PATCH B CONCLUÍDO COM SUCESSO ===")


if __name__ == "__main__":
    main()
