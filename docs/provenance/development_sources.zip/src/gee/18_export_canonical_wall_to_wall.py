
import json
import sys
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

import ee
from src.gee.dw_annual import PROJECT_ID, get_harmonized_crosswalk_layers, get_mapbiomas_projection
from shapely.geometry import box, shape

ee.Initialize(project=PROJECT_ID)
mb_proj = get_mapbiomas_projection()
proj_info = mb_proj.getInfo()
crs = proj_info['crs']
transform = proj_info['transform']

layers = get_harmonized_crosswalk_layers()

pixel_area_ha = ee.Image.pixelArea().divide(10000.0)
mb = layers['mb']
bands = [
    pixel_area_ha.updateMask(mb.mask()).rename('total_covered_ha'),
    pixel_area_ha.updateMask(layers['eligible_mask']).rename('eligible_ha'),
    pixel_area_ha.updateMask(layers['is_excluded'].updateMask(mb.mask())).rename('excluded_mb_ha'),
    pixel_area_ha.updateMask(layers['insufficient_dw_temporal']).rename('insufficient_dw_temporal_ha'),
    pixel_area_ha.updateMask(layers['regime_AA']).rename('AA_ha'),
    pixel_area_ha.updateMask(layers['regime_AN']).rename('AN_ha'),
    pixel_area_ha.updateMask(layers['regime_NA']).rename('NA_ha'),
    pixel_area_ha.updateMask(layers['regime_NN']).rename('NN_ha'),
    ee.Image(1).updateMask(mb.mask()).rename('total_covered_count'),
    ee.Image(1).updateMask(layers['eligible_mask']).rename('eligible_count'),
    ee.Image(1).updateMask(layers['is_excluded'].updateMask(mb.mask())).rename('excluded_mb_count'),
    ee.Image(1).updateMask(layers['insufficient_dw_temporal']).rename('insufficient_dw_temporal_count'),
    ee.Image(1).updateMask(layers['regime_AA']).rename('AA_count'),
    ee.Image(1).updateMask(layers['regime_AN']).rename('AN_count'),
    ee.Image(1).updateMask(layers['regime_NA']).rename('NA_count'),
    ee.Image(1).updateMask(layers['regime_NN']).rename('NN_count'),
]
stack = ee.Image.cat(bands)

# Criar FC das slices
with open('data/reference/matopiba_states.geojson', 'r') as f:
    states_data = json.load(f)

step = 0.75
features = []
for feat in states_data['features']:
    st = feat['properties']['state']
    shp = shape(feat['geometry'])
    min_x, min_y, max_x, max_y = shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                s_id = f'{st}_x{ix:02d}_y{iy:02d}'
                features.append(ee.Feature(ee.Geometry(sub.__geo_interface__), {'slice_id': s_id, 'state': st}))

print(f'Total slices to export: {len(features)}')
fc = ee.FeatureCollection(features)

reduced = stack.reduceRegions(
    collection=fc,
    reducer=ee.Reducer.sum().unweighted(),
    crs=crs,
    crsTransform=transform,
    tileScale=16,
)

task = ee.batch.Export.table.toDrive(
    collection=reduced,
    description='canonical_wall_to_wall_10m_opt',
    fileNamePrefix='canonical_wall_to_wall_10m',
    folder='matopiba_exports',
    fileFormat='CSV'
)
task.start()
print('Task submitted successfully! ID:', task.id, 'State:', task.status()['state'])
