import time
import json
import ee
from shapely.geometry import shape, box, mapping

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

ma_feat = next(f for f in d["features"] if f["properties"]["state"] == "MA")
ma_shape = shape(ma_feat["geometry"])
min_x, min_y, max_x, max_y = ma_shape.bounds
mid_y = (min_y + max_y) / 2.0
b_south = box(min_x - 0.1, min_y - 0.1, max_x + 0.1, mid_y)
geom_s = ma_shape.intersection(b_south)
ee_geom_s = ee.Geometry(mapping(geom_s))

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

dw_col = (
    ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
    .filterBounds(ee_geom_s)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)
m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()
dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
dw_max = dw_10m.reduce(ee.Reducer.max())
dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

eligible_mask = valid_mb_mask.And(dw_crop.mask())

regime_img = (
    ee.Image(0)
    .where(mb_crop.eq(1).And(dw_crop.eq(1)), 1)
    .where(mb_crop.eq(1).And(dw_crop.eq(0)), 2)
    .where(mb_crop.eq(0).And(dw_crop.eq(1)), 3)
    .where(mb_crop.eq(0).And(dw_crop.eq(0)), 4)
    .rename("regime")
    .updateMask(eligible_mask)
)

t0 = time.time()
print("Testing stratifiedSample(100) on MA_south...")
pts = regime_img.stratifiedSample(
    numPoints=100,
    classBand="regime",
    region=ee_geom_s,
    scale=10,
    seed=25,
    geometries=True,
    tileScale=8
)
pts_list = pts.getInfo()["features"]
print(f"MA_south stratifiedSample completed in {time.time() - t0:.2f}s! Returned {len(pts_list)} points.")
from collections import Counter
counts = Counter(p["properties"]["regime"] for p in pts_list)
print("Regime distribution:", counts)
