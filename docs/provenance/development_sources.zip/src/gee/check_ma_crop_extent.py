import ee
import json

ee.Initialize(project="dynamicworld-x-mapbiomas")

# Check where AA is in MA_south
# AA is mb_crop == 1 and dw_crop == 1
# Let's sample AA pixels directly with sample(numPixels=100) on aa_only inside MA_south!
with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

ma_feat = next(f for f in d["features"] if f["properties"]["state"] == "MA")
ma_geom = ee.Geometry(ma_feat["geometry"])

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_crop = mb.remap([19, 36], [1, 1], 0)

# Sample 500 points where MapBiomas is crop (19 or 36) in MA
pts = mb_crop.eq(1).selfMask().sample(region=ma_geom, scale=1000, numPixels=500, geometries=True, seed=25)
coords = [f["geometry"]["coordinates"] for f in pts.getInfo()["features"]]
lons = [c[0] for c in coords]
lats = [c[1] for c in coords]
print(f"MA MapBiomas Crop extent: Lon=[{min(lons):.3f}, {max(lons):.3f}], Lat=[{min(lats):.3f}, {max(lats):.3f}], N={len(coords)}")
# Filter south of -6.25
south_coords = [c for c in coords if c[1] < -6.25]
s_lons = [c[0] for c in south_coords]
s_lats = [c[1] for c in south_coords]
print(f"MA South Crop extent: Lon=[{min(s_lons):.3f}, {max(s_lons):.3f}], Lat=[{min(s_lats):.3f}, {max(s_lats):.3f}], N={len(south_coords)}")
