import json
import math
import sys
import time
from pathlib import Path
import ee
import pandas as pd
import numpy as np

ee.Initialize(project="dynamicworld-x-mapbiomas")

BASE_DIR = Path(__file__).resolve().parent.parent.parent
CSV_PATH = BASE_DIR / "data" / "processed" / "prototype_samples.csv"

DW_PROB_BANDS = [
    "water", "trees", "grass", "flooded_vegetation", "crops",
    "shrub_and_scrub", "built", "bare", "snow_and_ice"
]

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"

mb = ee.Image(MB_ASSET).select(MB_BAND)
mb_proj = mb.projection()

PROTOTYPE_WINDOWS = {
    "MA": {"lon_min": -45.2, "lon_max": -44.8, "lat_min": -7.7, "lat_max": -7.3},
    "TO": {"lon_min": -49.2, "lon_max": -48.8, "lat_min": -11.0, "lat_max": -10.6},
    "PI": {"lon_min": -45.2, "lon_max": -44.8, "lat_min": -8.5, "lat_max": -8.1},
    "BA": {"lon_min": -46.2, "lon_max": -45.8, "lat_min": -12.2, "lat_max": -11.8},
}

df = pd.read_csv(CSV_PATH)
print(f"Loaded {len(df)} prototype samples. Running exhaustive identity test on ALL 500 points...")

all_matches = True
max_prob_diff = 0.0
total_checked = 0

for st in ["MA", "TO", "PI", "BA"]:
    t0 = time.time()
    win = PROTOTYPE_WINDOWS[st]
    bbox = ee.Geometry.BBox(win["lon_min"], win["lat_min"], win["lon_max"], win["lat_max"])
    
    st_pts = df[df["state"] == st]
    features = []
    for _, row in st_pts.iterrows():
        geom = ee.Geometry.Point([row["longitude"], row["latitude"]])
        feat = ee.Feature(geom, {"sample_id": row["sample_id"]})
        features.append(feat)
    pts_fc = ee.FeatureCollection(features)
    
    # Authoritative DW annual logic
    dw_col = (
        ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
        .filterBounds(bbox)
        .select(DW_PROB_BANDS + ["label"])
    )
    
    m_comps = []
    count_bands = []
    for m in range(1, 13):
        start = f"2025-{m:02d}-01"
        end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
        dw_m = dw_col.filterDate(start, end)
        
        n_obs_m = dw_m.select("label").count().rename(f"n_obs_m{m:02d}")
        count_bands.append(n_obs_m)
        
        dates_m = ee.List(dw_m.aggregate_array("system:time_start")).map(
            lambda t: ee.Date(t).format("YYYY-MM-dd")
        ).distinct()
        
        def make_daily(d):
            d_start = ee.Date(d)
            d_end = d_start.advance(1, "day")
            return dw_m.filterDate(d_start, d_end).select(DW_PROB_BANDS).mean().set("date", d)
            
        daily_col_m = ee.ImageCollection(dates_m.map(make_daily))
        m_comps.append(daily_col_m.mean())
        
    annual_dw = ee.ImageCollection(m_comps).mean()
    annual_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
    count_stack = ee.Image.cat(count_bands)
    
    stack = ee.Image.cat([annual_10m, count_stack])
    
    sampled = stack.reduceRegions(
        collection=pts_fc,
        reducer=ee.Reducer.first(),
        scale=10,
    ).getInfo()
    
    for feat in sampled["features"]:
        total_checked += 1
        props = feat["properties"]
        sid = props["sample_id"]
        row = df[df["sample_id"] == sid].iloc[0]
        
        obs_per_m = [int(props.get(f"n_obs_m{m:02d}") or 0) for m in range(1, 13)]
        n_valid = sum(c > 0 for c in obs_per_m)
        if n_valid != row["n_valid_months"]:
            print(f"MISMATCH in n_valid_months for {sid}: got {n_valid}, expected {row['n_valid_months']}")
            all_matches = False
            
        raw_probs = [props.get(b) for b in DW_PROB_BANDS]
        sum_raw = sum(raw_probs)
        raw_diff = abs(sum_raw - row["probability_sum_before_normalization"])
        if raw_diff > 1e-4:
            print(f"MISMATCH in raw sum for {sid}: got {sum_raw}, expected {row['probability_sum_before_normalization']}, diff={raw_diff}")
            all_matches = False
            
        norm_probs = [p / sum_raw for p in raw_probs]
        for idx, b in enumerate(DW_PROB_BANDS):
            diff = abs(norm_probs[idx] - row[f"p_{b}"])
            if diff > max_prob_diff:
                max_prob_diff = diff
            if diff > 1e-4:
                print(f"MISMATCH in p_{b} for {sid}: got {norm_probs[idx]}, expected {row[f'p_{b}']}, diff={diff}")
                all_matches = False
                
        argmax_cls = DW_PROB_BANDS[norm_probs.index(max(norm_probs))]
        if argmax_cls != row["dw_annual_class"]:
            print(f"MISMATCH in annual class for {sid}: got {argmax_cls}, expected {row['dw_annual_class']}")
            all_matches = False
            
    print(f"State {st} checked: 125/125 points in {time.time() - t0:.2f}s")

print(f"\nALL 500 POINTS CHECKED:")
print(f"Total checked: {total_checked}")
print(f"Max prob diff: {max_prob_diff:.6e}")
print(f"All matches: {all_matches}")
if not all_matches:
    sys.exit(1)
