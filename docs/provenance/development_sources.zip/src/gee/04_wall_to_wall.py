"""
04_wall_to_wall.py — Authoritative Wall-to-Wall Cropland Disagreement Analysis
=============================================================================
Calculates the wall-to-wall cropland agreement/disagreement for the entire MATOPIBA
domain in 2025 using ONLY:
  - Authoritative Annual Dynamic World 2025 (src/gee/dw_annual.py)
  - MapBiomas Cobertura 10m Collection 4 (classification_2025)
  - Frozen immutable crosswalk (CROP: 19, 36; EXCLUDED: 18, 21; NONCROP: other valid)
  - Real area via ee.Image.pixelArea() (never sample estimation)

Outputs:
  - data/processed/wall_to_wall_summary.csv
  - data/processed/wall_to_wall_slices_checkpoint.json
"""

from __future__ import annotations

import json
import socket
import sys
import time
from datetime import datetime
from pathlib import Path

socket.setdefaulttimeout(300)

import ee
import pandas as pd
from shapely.geometry import box, shape

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

from src.gee.dw_annual import (
    PROJECT_ID,
    get_harmonized_crosswalk_layers,
    get_mapbiomas_projection,
)

DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"
SUMMARY_CSV = DATA_PROC / "wall_to_wall_summary.csv"
CHECKPOINT_FILE = DATA_PROC / "wall_to_wall_slices_checkpoint.json"

STATE_SLICES_CFG = {
    "PI": 4,   # ~8.2M ha -> ~2.0M ha per slice
    "BA": 6,   # ~21.3M ha -> ~3.5M ha per slice
    "MA": 6,   # ~15.8M ha -> ~2.6M ha per slice
    "TO": 8,   # ~27.7M ha -> ~3.5M ha per slice
}


def log(msg: str) -> None:
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}", flush=True)


def load_checkpoints() -> dict[str, dict[str, float]]:
    if CHECKPOINT_FILE.exists():
        try:
            with open(CHECKPOINT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_checkpoint(slice_id: str, stats: dict[str, float]) -> None:
    ckpt = load_checkpoints()
    ckpt[slice_id] = stats
    with open(CHECKPOINT_FILE, "w", encoding="utf-8") as f:
        json.dump(ckpt, f, indent=2)


def partition_polygon(state: str, geom_shp, n_slices: int = 1) -> list[tuple[str, any]]:
    min_x, min_y, max_x, max_y = geom_shp.bounds
    dy = (max_y - min_y) / n_slices
    pieces = []
    for i in range(n_slices):
        y0 = min_y + i * dy
        y1 = min_y + (i + 1) * dy
        b = box(min_x - 0.01, y0, max_x + 0.01, y1)
        sub = geom_shp.intersection(b)
        if sub.is_empty:
            continue
        slice_base = f"slice_{i:02d}"
        if state in ["PI", "BA"]:
            pieces.append((slice_base, sub))
        elif state == "MA":
            if i in [0, 1, 2, 3, 5]:
                pieces.append((slice_base, sub))
            else:
                sub_min_x, _, sub_max_x, _ = sub.bounds
                mid_x = (sub_min_x + sub_max_x) / 2
                bw = box(sub_min_x - 0.01, y0, mid_x, y1)
                be = box(mid_x, y0, sub_max_x + 0.01, y1)
                sw = sub.intersection(bw)
                se = sub.intersection(be)
                if not sw.is_empty:
                    pieces.append((f"{slice_base}_w", sw))
                if not se.is_empty:
                    pieces.append((f"{slice_base}_e", se))
        elif state == "TO":
            sub_min_x, _, sub_max_x, _ = sub.bounds
            width = sub_max_x - sub_min_x
            if width > 2.5:
                mid_x = (sub_min_x + sub_max_x) / 2
                bw = box(sub_min_x - 0.01, y0, mid_x, y1)
                be = box(mid_x, y0, sub_max_x + 0.01, y1)
                sw = sub.intersection(bw)
                se = sub.intersection(be)
                if not sw.is_empty:
                    pieces.append((f"{slice_base}_w", sw))
                if not se.is_empty:
                    pieces.append((f"{slice_base}_e", se))
            else:
                pieces.append((slice_base, sub))
    return pieces


def compute_slice(ee_geom: ee.Geometry, mb_proj: ee.Projection) -> dict[str, float]:
    layers = get_harmonized_crosswalk_layers(region=ee_geom, mb_proj=mb_proj)
    mb = layers["mb"]
    pixel_area_ha = ee.Image.pixelArea().divide(10000.0)

    stack = ee.Image.cat([
        pixel_area_ha.updateMask(mb.mask()).rename("total_covered_ha"),
        pixel_area_ha.updateMask(layers["eligible_mask"]).rename("eligible_ha"),
        pixel_area_ha.updateMask(layers["is_excluded"].updateMask(mb.mask())).rename("excluded_mb_ha"),
        pixel_area_ha.updateMask(layers["insufficient_dw_temporal"]).rename("insufficient_dw_temporal_ha"),
        pixel_area_ha.updateMask(layers["regime_AA"]).rename("AA_ha"),
        pixel_area_ha.updateMask(layers["regime_AN"]).rename("AN_ha"),
        pixel_area_ha.updateMask(layers["regime_NA"]).rename("NA_ha"),
        pixel_area_ha.updateMask(layers["regime_NN"]).rename("NN_ha"),
    ])

    stats = stack.reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=ee_geom,
        scale=30,
        maxPixels=1e13,
        tileScale=8,
    ).getInfo()

    # Also compute geodesic polygon area
    poly_area_ha = ee_geom.area(maxError=100).divide(10000.0).getInfo()
    stats["polygon_area_ha"] = float(poly_area_ha)

    return {k: float(v) for k, v in stats.items()}


def run_wall_to_wall() -> pd.DataFrame:
    log("=" * 80)
    log("INICIANDO CÁLCULO WALL-TO-WALL MATOPIBA 2025")
    log("=" * 80)

    ee.Initialize(project=PROJECT_ID)
    mb_proj = get_mapbiomas_projection()

    with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
        states_data = json.load(f)

    DATA_PROC.mkdir(parents=True, exist_ok=True)
    checkpoints = load_checkpoints()

    state_totals = {}

    for st, n_slices in STATE_SLICES_CFG.items():
        feat = next(f for f in states_data["features"] if f["properties"]["state"] == st)
        shp = shape(feat["geometry"])
        slices = partition_polygon(st, shp, n_slices)
        log(f"\nEstado {st}: total {len(slices)} fatias determinísticas.")

        st_stats = {
            "polygon_area_ha": 0.0,
            "total_covered_ha": 0.0,
            "eligible_ha": 0.0,
            "excluded_mb_ha": 0.0,
            "insufficient_dw_temporal_ha": 0.0,
            "AA_ha": 0.0,
            "AN_ha": 0.0,
            "NA_ha": 0.0,
            "NN_ha": 0.0,
        }

        for s_idx, (slice_label, sub_poly) in enumerate(slices):
            slice_key = f"{st}_{slice_label}"
            if slice_key in checkpoints:
                log(f"  [{st} {slice_label}] Carregado do checkpoint: {checkpoints[slice_key]['eligible_ha']:,.1f} ha elegíveis")
                s_res = checkpoints[slice_key]
            else:
                max_retries = 3
                s_res = None
                for attempt in range(1, max_retries + 1):
                    try:
                        t0 = time.time()
                        ee_geom = ee.Geometry(sub_poly.__geo_interface__)
                        log(f"  [{st} {slice_label}] Processando via Earth Engine (tentativa {attempt}/{max_retries})...")
                        s_res = compute_slice(ee_geom, mb_proj)
                        save_checkpoint(slice_key, s_res)
                        log(f"  [{st} {slice_label}] Concluído em {time.time() - t0:.1f}s | Elig: {s_res['eligible_ha']:,.1f} ha, AA: {s_res['AA_ha']:,.1f} ha")
                        break
                    except Exception as exc:
                        log(f"  [{st} {slice_label}] Erro na tentativa {attempt}: {exc}")
                        if attempt == max_retries:
                            raise
                        time.sleep(10)

            for k in st_stats:
                st_stats[k] += s_res.get(k, 0.0)

        # Validate state balance
        regimes_sum = st_stats["AA_ha"] + st_stats["AN_ha"] + st_stats["NA_ha"] + st_stats["NN_ha"]
        diff_regimes = abs(regimes_sum - st_stats["eligible_ha"])
        partition_sum = st_stats["eligible_ha"] + st_stats["excluded_mb_ha"] + st_stats["insufficient_dw_temporal_ha"]
        diff_part = abs(partition_sum - st_stats["total_covered_ha"])

        log(f"--> {st} Concluído: {st_stats['eligible_ha']:,.1f} ha elegíveis")
        log(f"    Validação 1: AA+AN+NA+NN = {regimes_sum:,.2f} ha vs {st_stats['eligible_ha']:,.2f} ha (diff: {diff_regimes:.4f} ha)")
        log(f"    Validação 2: Eleg+Excl+Insuff = {partition_sum:,.2f} ha vs {st_stats['total_covered_ha']:,.2f} ha (diff: {diff_part:.4f} ha)")

        state_totals[st] = st_stats

    # MATOPIBA total
    matopiba_stats = {
        "polygon_area_ha": sum(s["polygon_area_ha"] for s in state_totals.values()),
        "total_covered_ha": sum(s["total_covered_ha"] for s in state_totals.values()),
        "eligible_ha": sum(s["eligible_ha"] for s in state_totals.values()),
        "excluded_mb_ha": sum(s["excluded_mb_ha"] for s in state_totals.values()),
        "insufficient_dw_temporal_ha": sum(s["insufficient_dw_temporal_ha"] for s in state_totals.values()),
        "AA_ha": sum(s["AA_ha"] for s in state_totals.values()),
        "AN_ha": sum(s["AN_ha"] for s in state_totals.values()),
        "NA_ha": sum(s["NA_ha"] for s in state_totals.values()),
        "NN_ha": sum(s["NN_ha"] for s in state_totals.values()),
    }
    state_totals["MATOPIBA"] = matopiba_stats

    # Build final summary table
    rows = []
    order = ["MATOPIBA", "MA", "TO", "PI", "BA"]
    for reg in order:
        st = state_totals[reg]
        el = st["eligible_ha"]
        aa = st["AA_ha"]
        an = st["AN_ha"]
        na = st["NA_ha"]
        nn = st["NN_ha"]

        aa_pct = (100.0 * aa / el) if el > 0 else 0.0
        an_pct = (100.0 * an / el) if el > 0 else 0.0
        na_pct = (100.0 * na / el) if el > 0 else 0.0
        nn_pct = (100.0 * nn / el) if el > 0 else 0.0

        agree_pct = aa_pct + nn_pct
        disagree_pct = an_pct + na_pct
        quantity_disagree = abs(an_pct - na_pct)
        allocation_disagree = 2.0 * min(an_pct, na_pct)

        rows.append({
            "region": reg,
            "total_area_ha": round(st["polygon_area_ha"], 2),
            "eligible_area_ha": round(el, 2),
            "excluded_mb_area_ha": round(st["excluded_mb_ha"], 2),
            "insufficient_dw_temporal_area_ha": round(st["insufficient_dw_temporal_ha"], 2),
            "AA_area_ha": round(aa, 2),
            "AN_area_ha": round(an, 2),
            "NA_area_ha": round(na, 2),
            "NN_area_ha": round(nn, 2),
            "AA_pct_eligible": round(aa_pct, 4),
            "AN_pct_eligible": round(an_pct, 4),
            "NA_pct_eligible": round(na_pct, 4),
            "NN_pct_eligible": round(nn_pct, 4),
            "agreement_pct": round(agree_pct, 4),
            "disagreement_pct": round(disagree_pct, 4),
            "quantity_disagreement": round(quantity_disagree, 4),
            "allocation_disagreement": round(allocation_disagree, 4),
        })

    summary_df = pd.DataFrame(rows)
    summary_df.to_csv(SUMMARY_CSV, index=False)
    log(f"\nSalvo com sucesso: {SUMMARY_CSV}")
    print(summary_df.to_string())

    return summary_df


if __name__ == "__main__":
    run_wall_to_wall()
