"""
test_wall_to_wall.py — Teste de cálculo wall-to-wall de áreas por estado
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import ee

BASE_DIR = Path(__file__).resolve().parent.parent.parent
STATES_GEOJSON = BASE_DIR / "data" / "reference" / "matopiba_states.geojson"

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"
DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
DW_PROB_BANDS = [
    "water", "trees", "grass", "flooded_vegetation", "crops",
    "shrub_and_scrub", "built", "bare", "snow_and_ice"
]


def test_pi_wall_to_wall():
    ee.Initialize(project="dynamicworld-x-mapbiomas")

    with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
        s_data = json.load(f)

    pi_geom = None
    for feat in s_data["features"]:
        if feat["properties"]["state"] == "PI":
            pi_geom = ee.Geometry(feat["geometry"])
            break

    assert pi_geom is not None

    mb = ee.Image(MB_ASSET).select(MB_BAND)
    mb_proj = mb.projection()

    print("Calculando áreas wall-to-wall para o Piauí (PI)...")
    t0 = time.time()
    dw_col = (
        ee.ImageCollection(DW_COLLECTION)
        .filterBounds(pi_geom)
        .filterDate("2025-01-01", "2026-01-01")
        .select(DW_PROB_BANDS)
    )

    m_comps = []
    for m in range(1, 13):
        start = f"2025-{m:02d}-01"
        end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
        m_comps.append(dw_col.filterDate(start, end).mean())

    annual_dw = ee.ImageCollection(m_comps).mean()
    dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)

    dw_max = dw_10m.reduce(ee.Reducer.max())
    dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

    # MapBiomas crop
    is_excluded = mb.eq(21).Or(mb.eq(18))
    valid_mb_mask = is_excluded.Not().And(mb.mask())
    mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask).rename("mb_crop")

    eligible_mask = valid_mb_mask.And(dw_crop.mask())

    aa = mb_crop.eq(1).And(dw_crop.eq(1)).updateMask(eligible_mask)
    an = mb_crop.eq(1).And(dw_crop.eq(0)).updateMask(eligible_mask)
    na = mb_crop.eq(0).And(dw_crop.eq(1)).updateMask(eligible_mask)
    nn = mb_crop.eq(0).And(dw_crop.eq(0)).updateMask(eligible_mask)
    excluded = is_excluded.updateMask(mb.mask())

    pixel_area_ha = ee.Image.pixelArea().divide(10000)

    area_stack = ee.Image.cat([
        pixel_area_ha.updateMask(eligible_mask).rename("area_eligible_ha"),
        pixel_area_ha.updateMask(excluded).rename("area_excluded_ha"),
        pixel_area_ha.updateMask(aa).rename("area_AA_ha"),
        pixel_area_ha.updateMask(an).rename("area_AN_ha"),
        pixel_area_ha.updateMask(na).rename("area_NA_ha"),
        pixel_area_ha.updateMask(nn).rename("area_NN_ha"),
    ])

    stats = area_stack.reduceRegion(
        reducer=ee.Reducer.sum(),
        geometry=pi_geom,
        scale=30,  # test scale
        maxPixels=1e13,
        tileScale=8,
    ).getInfo()

    elapsed = time.time() - t0
    print(f"Áreas calculadas em {elapsed:.1f}s:")
    for k, v in stats.items():
        print(f"  {k:20s}: {v:,.2f} ha")


if __name__ == "__main__":
    test_pi_wall_to_wall()
