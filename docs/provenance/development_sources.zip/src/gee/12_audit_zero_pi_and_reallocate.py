"""
12_audit_zero_pi_and_reallocate.py — Auditoria de Pi=0 e Nova Alocação Operacional
================================================================================
Atende integralmente às Seções A e B da auditoria:
  1. Identifica todas as subpopulações (state x regime x slice_id) com N_hs_exact > 0 e n_robust_hs == 0
  2. Produz tables/zero_inclusion_substrata_audit.csv
  3. Valida a diferença exata de 5.218,30 ha em relação à área total elegível
  4. Implementa a nova regra de alocação operacional Hamilton com garantia n_robust_hs >= 1
  5. Salva tables/slice_sampling_allocation_final.csv
"""

from __future__ import annotations

import math
from pathlib import Path
import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent.parent
TABLES_DIR = BASE_DIR / "tables"
DATA_PROC = BASE_DIR / "data" / "processed"

FRAME_10M_CSV = TABLES_DIR / "sampling_frame_10m.csv"
SLICE_AUDIT_CSV = TABLES_DIR / "slice_sampling_design_audit.csv"
QUOTAS_CSV = TABLES_DIR / "sampling_quotas.csv"
ZERO_PI_OUT = TABLES_DIR / "zero_inclusion_substrata_audit.csv"
FINAL_ALLOC_OUT = TABLES_DIR / "slice_sampling_allocation_final.csv"


def main():
    print("=" * 80)
    print("FASE 1: AUDITORIA DE COBERTURA COMPLETA E CORREÇÃO DE PI = 0")
    print("=" * 80)

    # 1. Carregar artefatos oficiais
    df_frame = pd.read_csv(FRAME_10M_CSV, keep_default_na=False)
    df_design = pd.read_csv(SLICE_AUDIT_CSV, keep_default_na=False)
    df_quotas = pd.read_csv(QUOTAS_CSV, keep_default_na=False)

    full_eligible_ha = df_frame["A_hs"].sum()
    covered_ha_old = df_design[df_design["n_robust_hs"] > 0]["A_hs"].sum()
    diff_ha = full_eligible_ha - covered_ha_old

    print(f"Área elegível total no frame 10m:     {full_eligible_ha:,.2f} ha")
    print(f"Área representada no desenho antigo:  {covered_ha_old:,.2f} ha")
    print(f"Diferença não representada:          {diff_ha:,.2f} ha")

    # 2. Identificar subestratos com N > 0 e n == 0
    zero_pi = df_design[(df_design["N_hs_exact"] > 0) & (df_design["n_robust_hs"] == 0)].copy()

    # Formatar colunas solicitadas: state, regime, slice_id, A_hs, N_hs_exact, n_robust_hs, n_main_expected_if_relevant, pi_robust_hs
    zero_pi["n_main_expected_if_relevant"] = 0
    zero_pi["pi_robust_hs"] = 0.0

    cols_zero = [
        "state", "regime", "slice_id", "A_hs", "N_hs_exact",
        "n_robust_hs", "n_main_expected_if_relevant", "pi_robust_hs"
    ]
    df_zero_out = zero_pi[cols_zero].sort_values(by=["state", "regime", "A_hs"], ascending=[True, True, False])
    df_zero_out.to_csv(ZERO_PI_OUT, index=False)
    print(f"\nSalvo: {ZERO_PI_OUT} ({len(df_zero_out)} linhas)")

    # Estatísticas da auditoria
    n_sub = len(zero_pi)
    sum_N = zero_pi["N_hs_exact"].sum()
    sum_A = zero_pi["A_hs"].sum()
    print(f"\nEstatísticas dos subestratos com pi = 0:")
    print(f"  Número de subpopulações: {n_sub}")
    print(f"  Total de pixels (N_hs_exact): {sum_N:,}")
    print(f"  Área total não representada (A_hs): {sum_A:,.2f} ha ({sum_A:.6f} ha)")

    print("\nÁrea por estado (ha):")
    by_st = zero_pi.groupby("state")["A_hs"].agg(["count", "sum"])
    for st, row in by_st.iterrows():
        print(f"  {st}: {int(row['count']):2d} subestratos, {row['sum']:10.2f} ha")

    print("\nÁrea por regime (ha):")
    by_reg = zero_pi.groupby("regime")["A_hs"].agg(["count", "sum"])
    for reg, row in by_reg.iterrows():
        print(f"  {reg}: {int(row['count']):2d} subestratos, {row['sum']:10.2f} ha")

    print("\nValidação numérica:")
    print(f"  Diferença observada: {diff_ha:.6f} ha")
    print(f"  Soma de A_hs com n=0: {sum_A:.6f} ha")
    assert abs(diff_ha - sum_A) < 1e-6, "A diferença observada diverge da soma dos subestratos com n=0!"
    print("  -> CONFERÊNCIA EXATA: 100% dos 5.218,30 ha são explicados pelas 47 subpopulações com pi=0.")

    # 3. Implementação da nova alocação operacional (Seção B)
    print("\n" + "=" * 80)
    print("SEÇÃO B: NOVA ALOCAÇÃO OPERACIONAL HAMILTON COM n_robust_hs >= 1")
    print("=" * 80)

    alloc_rows = []

    for _, q_row in df_quotas.iterrows():
        st = q_row["state"]
        reg = q_row["regime"]
        n_rob_target = int(q_row["n_robust"])
        n_main_target = int(q_row["n_main"])

        # Todas as slices ativas para este state x regime
        sub = df_frame[(df_frame["state"] == st) & (df_frame["regime"] == reg) & (df_frame["N_hs_exact"] > 0)].copy()
        k_slices = len(sub)
        assert k_slices > 0, f"Nenhuma fatia com pixels para {st}_{reg}"
        assert n_rob_target >= k_slices, f"Quota robusta ({n_rob_target}) menor que número de fatias ativas ({k_slices}) para {st}_{reg}"

        # 1. Atribuição inicial de 1 ponto robusto para cada fatia ativa
        sub["n_base"] = 1
        points_to_distribute = n_rob_target - k_slices

        # 2. Distribuição do restante proporcional a N_hs_exact via Hamilton
        tot_N = sub["N_hs_exact"].sum()
        sub["raw_share"] = (sub["N_hs_exact"] / tot_N) * points_to_distribute
        sub["int_part"] = sub["raw_share"].apply(math.floor).astype(int)
        sub["remainder"] = sub["raw_share"] - sub["int_part"]

        allocated_int = sub["int_part"].sum()
        leftover = points_to_distribute - allocated_int

        sub = sub.sort_values(by=["remainder", "slice_id"], ascending=[False, True]).reset_index(drop=True)
        sub["extra"] = 0
        if leftover > 0:
            sub.loc[:leftover - 1, "extra"] = 1

        sub["n_robust_hs"] = sub["n_base"] + sub["int_part"] + sub["extra"]

        # Verificação rigorosa
        assert sub["n_robust_hs"].sum() == n_rob_target, f"Erro na soma robusta para {st}_{reg}"
        assert (sub["n_robust_hs"] >= 1).all(), f"Alguma fatia ativa ficou com n < 1 em {st}_{reg}"

        # Probabilidade e pesos
        sub["pi_robust_hs"] = sub["n_robust_hs"] / sub["N_hs_exact"]
        sub["design_weight_robust_hs"] = 1.0 / sub["pi_robust_hs"]
        sub["area_weight_robust_hs"] = (sub["A_hs"] * 10000.0) / sub["n_robust_hs"]

        alloc_rows.append(sub)

    df_alloc_final = pd.concat(alloc_rows, ignore_index=True)

    # Ordenação canônica
    st_cat = pd.Categorical(df_alloc_final["state"], categories=["MA", "TO", "PI", "BA"], ordered=True)
    reg_cat = pd.Categorical(df_alloc_final["regime"], categories=["AA", "AN", "NA", "NN"], ordered=True)
    df_alloc_final["st_ord"] = st_cat
    df_alloc_final["reg_ord"] = reg_cat
    df_alloc_final = df_alloc_final.sort_values(by=["st_ord", "reg_ord", "slice_id"]).drop(
        columns=["st_ord", "reg_ord", "n_base", "raw_share", "int_part", "remainder", "extra"]
    ).reset_index(drop=True)

    # Salvar tabela final de alocação
    out_cols = [
        "state", "regime", "slice_id", "A_hs", "N_hs_exact",
        "n_robust_hs", "pi_robust_hs", "design_weight_robust_hs", "area_weight_robust_hs"
    ]
    df_alloc_final = df_alloc_final[out_cols]
    df_alloc_final.to_csv(FINAL_ALLOC_OUT, index=False)
    print(f"\nSalva tabela de alocação final: {FINAL_ALLOC_OUT} ({len(df_alloc_final)} fatias ativas)")

    # Verificações finais
    total_robust = df_alloc_final["n_robust_hs"].sum()
    min_n = df_alloc_final["n_robust_hs"].min()
    covered_ha_new = df_alloc_final["A_hs"].sum()

    print(f"\nValidação da Nova Alocação Operacional:")
    print(f"  Total de pontos robustos alocados: {total_robust:,} (esperado 40.000)")
    print(f"  Menor quota alocada a uma fatia ativa: {min_n} (garantia n >= 1)")
    print(f"  Fatias ativas no desenho: {len(df_alloc_final)}")
    print(f"  Área elegível coberta no novo desenho: {covered_ha_new:,.2f} ha")
    print(f"  Área elegível total no frame:          {full_eligible_ha:,.2f} ha")
    print(f"  Diferença residual de cobertura:      {full_eligible_ha - covered_ha_new:.6f} ha")

    assert total_robust == 40000, "Total de pontos robustos alocados diverge de 40.000!"
    assert min_n >= 1, "Existem unidades elegíveis com n < 1!"
    assert abs(full_eligible_ha - covered_ha_new) < 1e-6, "A cobertura não é 100% da área elegível!"
    print("\n-> ALOCAÇÃO OPERACIONAL APROVADA: 100% DE COBERTURA, ZERO UNIDADES COM PI = 0.")


if __name__ == "__main__":
    main()
