import io
import json
from pathlib import Path
import ee.oauth
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

def get_drive_service():
    creds_args = ee.oauth.get_credentials_arguments()
    creds = Credentials(
        None,
        refresh_token=creds_args["refresh_token"],
        token_uri=creds_args["token_uri"],
        client_id=creds_args["client_id"],
        client_secret=creds_args["client_secret"],
        scopes=["https://www.googleapis.com/auth/drive"],
    )
    return build("drive", "v3", credentials=creds)

def find_file(drive_service, filename="canonical_wall_to_wall_10m.csv"):
    query = f"name = '{filename}' and trashed = false"
    results = drive_service.files().list(
        q=query,
        pageSize=10,
        fields="files(id, name, createdTime, size, mimeType)",
    ).execute()
    files = results.get("files", [])
    return files

def download_file(drive_service, file_id, destination_path):
    request = drive_service.files().get_media(fileId=file_id)
    fh = io.FileIO(destination_path, "wb")
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while not done:
        status, done = downloader.next_chunk()
        if status:
            print(f"Download {int(status.progress() * 100)}%")
    print(f"Downloaded successfully to {destination_path}")

if __name__ == "__main__":
    service = get_drive_service()
    files = find_file(service, "canonical_wall_to_wall_10m.csv")
    if files:
        print("Found file:", files[0])
        dest = Path("data/processed/canonical_wall_to_wall_10m.csv")
        download_file(service, files[0]["id"], dest)
    else:
        print("File 'canonical_wall_to_wall_10m.csv' not found yet on Drive.")
