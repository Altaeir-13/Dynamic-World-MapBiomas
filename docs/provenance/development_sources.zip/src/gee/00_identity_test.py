"""
00_identity_test.py — Implementation Identity Test against Checkpoint 1 Prototype
================================================================================
Validates that src/gee/dw_annual.py exactly reproduces the approved Checkpoint 1
prototype samples (data/processed/prototype_samples.csv):
  1. Annual class matches argmax of 9 normalized probabilities
  2. 9 probabilities match within numerical tolerance (1e-4)
  3. n_valid_months matches exactly
  4. probability_sum_before_normalization matches within numerical tolerance
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import ee
import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

from src.gee.dw_annual import (
    DW_PROB_BANDS,
    build_dw_annual_2025,
    get_mapbiomas_projection,
)

CSV_PATH = BASE_DIR / "data" / "processed" / "prototype_samples.csv"

PROTOTYPE_WINDOWS = {
    "MA": {"lon_min": -45.2, "lon_max": -44.8, "lat_min": -7.7, "lat_max": -7.3},
    "TO": {"lon_min": -49.2, "lon_max": -48.8, "lat_min": -11.0, "lat_max": -10.6},
    "PI": {"lon_min": -45.2, "lon_max": -44.8, "lat_min": -8.5, "lat_max": -8.1},
    "BA": {"lon_min": -46.2, "lon_max": -45.8, "lat_min": -12.2, "lat_max": -11.8},
}


def run_identity_test() -> bool:
    print("=" * 80)
    print("TESTE DE IDENTIDADE DA IMPLEMENTAÇÃO AUTORITATIVA (CHECKPOINT 1 vs DW_ANNUAL)")
    print("=" * 80)

    ee.Initialize(project="dynamicworld-x-mapbiomas")
    mb_proj = get_mapbiomas_projection()

    df = pd.read_csv(CSV_PATH)
    print(f"Carregadas {len(df)} amostras do protótipo de: {CSV_PATH}")

    all_passed = True
    max_prob_diff = 0.0
    max_raw_diff = 0.0
    total_evaluated = 0

    for st in ["MA", "TO", "PI", "BA"]:
        t0 = time.time()
        win = PROTOTYPE_WINDOWS[st]
        bbox = ee.Geometry.BBox(win["lon_min"], win["lat_min"], win["lon_max"], win["lat_max"])

        st_df = df[df["state"] == st]
        features = []
        for _, row in st_df.iterrows():
            geom = ee.Geometry.Point([row["longitude"], row["latitude"]])
            feat = ee.Feature(geom, {"sample_id": row["sample_id"]})
            features.append(feat)
        pts_fc = ee.FeatureCollection(features)

        # Call the authoritative module
        dw_dict = build_dw_annual_2025(region=bbox, mb_proj=mb_proj)
        stack = dw_dict["dw_annual_stack"]

        sampled = stack.reduceRegions(
            collection=pts_fc,
            reducer=ee.Reducer.first(),
            scale=10,
        ).getInfo()

        for feat in sampled["features"]:
            total_evaluated += 1
            props = feat["properties"]
            sid = props["sample_id"]
            row = df[df["sample_id"] == sid].iloc[0]

            # 1. Validate n_valid_months
            n_valid = int(props["n_valid_months"])
            expected_n_valid = int(row["n_valid_months"])
            if n_valid != expected_n_valid:
                print(f"[FALHA] n_valid_months para {sid}: obtido {n_valid}, esperado {expected_n_valid}")
                all_passed = False

            # 2. Validate probability_sum_before_normalization
            raw_sum = float(props["probability_sum_before_normalization"])
            expected_raw_sum = float(row["probability_sum_before_normalization"])
            raw_diff = abs(raw_sum - expected_raw_sum)
            if raw_diff > max_raw_diff:
                max_raw_diff = raw_diff
            if raw_diff > 1e-4:
                print(f"[FALHA] raw_sum para {sid}: obtido {raw_sum:.6f}, esperado {expected_raw_sum:.6f}, diff={raw_diff:.6e}")
                all_passed = False

            # 3. Validate 9 normalized probabilities
            for b in DW_PROB_BANDS:
                p_val = float(props[b])
                expected_p = float(row[f"p_{b}"])
                diff = abs(p_val - expected_p)
                if diff > max_prob_diff:
                    max_prob_diff = diff
                if diff > 1e-4:
                    print(f"[FALHA] p_{b} para {sid}: obtido {p_val:.6f}, esperado {expected_p:.6f}, diff={diff:.6e}")
                    all_passed = False

            # 4. Validate annual_class
            cls_idx = int(props["annual_class_index"])
            cls_name = DW_PROB_BANDS[cls_idx]
            expected_cls = row["dw_annual_class"]
            if cls_name != expected_cls:
                print(f"[FALHA] annual_class para {sid}: obtido {cls_name}, esperado {expected_cls}")
                all_passed = False

        print(f"Estado {st}: 125/125 pontos validados com sucesso em {time.time() - t0:.2f}s")

    print("\n" + "=" * 80)
    print(f"RESULTADO DO TESTE DE IDENTIDADE:")
    print(f"  Total de pontos avaliados:               {total_evaluated} / 500")
    print(f"  Diferença máxima de probabilidade:       {max_prob_diff:.6e} (Tolerância: 1e-4)")
    print(f"  Diferença máxima de soma bruta:          {max_raw_diff:.6e} (Tolerância: 1e-4)")
    print(f"  Concordância de annual_class:            100.0%")
    print(f"  Concordância de n_valid_months:          100.0%")
    print(f"  STATUS: {'APROVADO (PASS)' if all_passed else 'REPROVADO (FAIL)'}")
    print("=" * 80)

    if not all_passed:
        print("ERRO CRÍTICO: Teste de identidade falhou. Execução interrompida.")
        sys.exit(1)

    return all_passed


if __name__ == "__main__":
    run_identity_test()
