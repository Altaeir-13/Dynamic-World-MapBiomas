"""Audit downloaded CSV schemas, rows, slices, and match against manifest."""
import os
import glob
import pandas as pd

manifest = pd.read_csv('tables/canonical_w2w_batch_manifest.csv')
print(f"Total manifest rows: {len(manifest)}")
print(f"Unique slice_ids in manifest: {manifest['slice_id'].nunique()}")

batch_dir = 'data/processed/batches'
csv_files = sorted(glob.glob(os.path.join(batch_dir, 'canonical_w2w_batch_*_10m.csv')))

all_dfs = []
for p in csv_files:
    fname = os.path.basename(p)
    df = pd.read_csv(p)
    all_dfs.append(df)
    n_rows = len(df)
    n_slices = df['slice_id'].nunique() if 'slice_id' in df.columns else 0
    dups = df['slice_id'].duplicated().sum() if 'slice_id' in df.columns else 0
    print(f"{fname:32} | rows:{n_rows:2} | unique_slices:{n_slices:2} | dups:{dups} | cols:{len(df.columns)}")

combined = pd.concat(all_dfs, ignore_index=True)
print("\n=== CONSOLIDATED DOWNLOADED AUDIT ===")
print(f"Total downloaded rows: {len(combined)}")
print(f"Total unique downloaded slices: {combined['slice_id'].nunique()}")
print(f"Any duplicated slice_id across files: {combined['slice_id'].duplicated().sum()}")

# Check columns consistency
first_cols = list(all_dfs[0].columns)
cols_match = all(list(d.columns) == first_cols for d in all_dfs)
print(f"All files have identical column schema: {cols_match} ({len(first_cols)} columns)")

# Check vs manifest for the completed batches
succeeded_batches = [
    'canonical_w2w_batch_00a', 'canonical_w2w_batch_00b', 'canonical_w2w_batch_01', 
    'canonical_w2w_batch_02', 'canonical_w2w_batch_03', 'canonical_w2w_batch_04a', 
    'canonical_w2w_batch_04b', 'canonical_w2w_batch_05'
]
manifest_succ = manifest[manifest['batch_id'].isin(succeeded_batches)]
diff_missing = set(manifest_succ['slice_id']) - set(combined['slice_id'])
diff_unexpected = set(combined['slice_id']) - set(manifest_succ['slice_id'])
print(f"Missing slices vs manifest (succeeded batches): {len(diff_missing)}")
print(f"Unexpected slices vs manifest: {len(diff_unexpected)}")

failed_batches = ['canonical_w2w_batch_06', 'canonical_w2w_batch_07', 'canonical_w2w_batch_08', 'canonical_w2w_batch_09']
manifest_failed = manifest[manifest['batch_id'].isin(failed_batches)]
print(f"Slices remaining in failed batches (06-09): {len(manifest_failed)}")
for fb in failed_batches:
    sub = manifest[manifest['batch_id'] == fb]
    print(f"  {fb}: {len(sub)} slices")
