import time
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

# Test 1: Window
bbox = ee.Geometry.BBox(-45.2, -7.7, -44.8, -7.3)
t0 = time.time()
dw_m = ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1").filterBounds(bbox).filterDate("2025-01-01", "2025-02-01")
dates = ee.List(dw_m.aggregate_array("system:time_start")).map(lambda t: ee.Date(t).format("YYYY-MM-dd")).distinct().getInfo()
print(f"Window test: {len(dates)} dates in {time.time() - t0:.2f}s: {dates}")

# Test 2: Piauí state
import json
with open("data/reference/matopiba_states.geojson", "r") as f:
    st_data = json.load(f)
pi_feat = next(feat for feat in st_data["features"] if feat["properties"]["state"] == "PI")
pi_geom = ee.Geometry(pi_feat["geometry"])

t0 = time.time()
dw_pi = ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1").filterBounds(pi_geom).filterDate("2025-01-01", "2025-02-01")
count = dw_pi.size().getInfo()
print(f"Piauí Jan: {count} scenes in collection, getting distinct dates...")
dates_pi = ee.List(dw_pi.aggregate_array("system:time_start")).map(lambda t: ee.Date(t).format("YYYY-MM-dd")).distinct().getInfo()
print(f"Piauí test: {len(dates_pi)} dates in {time.time() - t0:.2f}s: {dates_pi[:5]}...")
