import time
import json
import ee
from shapely.geometry import shape, box, mapping
from collections import Counter

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

ma_feat = next(f for f in d["features"] if f["properties"]["state"] == "MA")
ma_shape = shape(ma_feat["geometry"])
min_x, min_y, max_x, max_y = ma_shape.bounds
mid_y = (min_y + max_y) / 2.0
b_south = box(min_x - 0.1, min_y - 0.1, max_x + 0.1, mid_y)
geom_s = ma_shape.intersection(b_south)
ee_geom_s = ee.Geometry(mapping(geom_s))

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")
mb_proj = mb.projection()

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask).rename("mb_crop")

# Sample candidate points from mb_crop == 1
mb_crop_only = ee.Image(1).rename("crop").updateMask(mb_crop.eq(1))

t0 = time.time()
print("Sampling candidate points from mb_crop == 1 in MA_south...")
pts = mb_crop_only.sample(
    region=ee_geom_s,
    scale=10,
    numPixels=10000,
    seed=25,
    geometries=True,
    tileScale=8
)
pts_list = pts.getInfo()["features"]
print(f"Sampled {len(pts_list)} points in {time.time() - t0:.2f}s!")

# Now extract DW at these points
dw_col = (
    ee.ImageCollection("GOOGLE/DYNAMICWORLD/V1")
    .filterBounds(ee_geom_s)
    .filterDate("2025-01-01", "2026-01-01")
    .select(["crops", "water", "trees", "grass", "flooded_vegetation", "shrub_and_scrub", "built", "bare", "snow_and_ice"])
)
m_comps = [dw_col.filterDate(f"2025-{m:02d}-01", f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01").mean() for m in range(1, 13)]
annual_dw = ee.ImageCollection(m_comps).mean()
dw_10m = annual_dw.resample("bilinear").reproject(crs=mb_proj)
dw_max = dw_10m.reduce(ee.Reducer.max())
dw_crop = dw_10m.select("crops").eq(dw_max).rename("dw_crop")

t1 = time.time()
sampled = dw_crop.reduceRegions(
    collection=pts,
    reducer=ee.Reducer.first(),
    scale=10
)
res = sampled.getInfo()["features"]
print(f"Extracted DW at {len(res)} points in {time.time() - t1:.2f}s!")
valid = [f for f in res if f["properties"].get("first") is not None]
counts = Counter(f["properties"]["first"] for f in valid)
print(f"DW crop (1=AA, 0=AN) counts: {counts}")
