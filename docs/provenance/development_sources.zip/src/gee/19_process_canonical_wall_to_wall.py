"""
19_process_canonical_wall_to_wall.py — Post-Processing of Canonical 10m Census
=============================================================================
This script executes immediately after the Earth Engine export task finishes:
  1. Downloads 'canonical_wall_to_wall_10m.csv' from Google Drive (matopiba_exports folder)
  2. Aggregates pixel counts and ellipsoidal areas (ha) across all 182 slices
  3. Produces data/processed/wall_to_wall_summary.csv (MATOPIBA + 4 States)
     - Validates closure: Total = Eligible + Excluded + Insufficient Temporal
     - Validates closure: Eligible = AA + AN + NA + NN
     - Computes Agreement, Disagreement, Quantity Disagreement, Allocation Disagreement
  4. Produces tables/sampling_frame_10m.csv (16 state x regime strata, N_h_exact and A_h)
  5. Computes sampling quotas via Hamilton method (floor=400, N_main=20k, N_robust=40k)
     - Produces tables/sampling_quotas.csv
     - Compares old (slice-dependent) vs new (fixed-domain canonical) quotas
  6. Computes operational slice allocation with n_robust_hs >= 1 for all active subestratos
     - Produces tables/slice_sampling_allocation_final.csv
     - Formally verifies pi_robust_hs > 0 for 100% of the eligible population
"""

from __future__ import annotations

import io
import json
import math
from pathlib import Path
import ee.oauth
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"
DATA_REF = BASE_DIR / "data" / "reference"

EXPORT_CSV_LOCAL = DATA_PROC / "canonical_wall_to_wall_10m_raw.csv"
SUMMARY_CSV = DATA_PROC / "wall_to_wall_summary.csv"
FRAME_CSV = TABLES_DIR / "sampling_frame_10m.csv"
QUOTAS_CSV = TABLES_DIR / "sampling_quotas.csv"
FINAL_ALLOC_CSV = TABLES_DIR / "slice_sampling_allocation_final.csv"

# Preserved invalid artifacts for comparison
OLD_W2W_CSV = DATA_PROC / "wall_to_wall_summary_SLICE_DEPENDENT_INVALID.csv"
OLD_QUOTAS_CSV = TABLES_DIR / "sampling_quotas_SLICE_DEPENDENT_INVALID.csv"


def get_drive_service():
    creds_args = ee.oauth.get_credentials_arguments()
    creds = Credentials(
        None,
        refresh_token=creds_args["refresh_token"],
        token_uri=creds_args["token_uri"],
        client_id=creds_args["client_id"],
        client_secret=creds_args["client_secret"],
        scopes=["https://www.googleapis.com/auth/drive"],
    )
    return build("drive", "v3", credentials=creds)


def download_export_from_drive() -> bool:
    if EXPORT_CSV_LOCAL.exists() and EXPORT_CSV_LOCAL.stat().st_size > 1000:
        print(f"Local export file already exists: {EXPORT_CSV_LOCAL} ({EXPORT_CSV_LOCAL.stat().st_size} bytes)")
        return True

    service = get_drive_service()
    query = "name contains 'canonical_wall_to_wall_10m' and trashed = false"
    results = service.files().list(
        q=query,
        pageSize=10,
        fields="files(id, name, createdTime, size)",
        orderBy="createdTime desc",
    ).execute()
    files = results.get("files", [])
    if not files:
        print("Export file not found yet on Drive.")
        return False

    file_id = files[0]["id"]
    print(f"Found export file on Drive: {files[0]['name']} (ID: {file_id}, Size: {files[0].get('size')} bytes)")
    request = service.files().get_media(fileId=file_id)
    fh = io.FileIO(EXPORT_CSV_LOCAL, "wb")
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    while not done:
        status, done = downloader.next_chunk()
        if status:
            print(f"Download {int(status.progress() * 100)}%")
    print(f"Export downloaded to {EXPORT_CSV_LOCAL}")
def load_data_source() -> pd.DataFrame | None:
    # 1. Check if local CSV already exists
    if EXPORT_CSV_LOCAL.exists() and EXPORT_CSV_LOCAL.stat().st_size > 1000:
        print(f"Loaded existing raw CSV: {EXPORT_CSV_LOCAL}")
        return pd.read_csv(EXPORT_CSV_LOCAL)

    # 2. Check Drive export
    if download_export_from_drive():
        return pd.read_csv(EXPORT_CSV_LOCAL)

    # 3. Check JSON slice checkpoint file
    ckpt_path = DATA_PROC / "canonical_wall_to_wall_slices_checkpoint.json"
    if ckpt_path.exists():
        with open(ckpt_path, "r", encoding="utf-8") as f:
            d = json.load(f)
        if len(d) == 183:
            print(f"All 183 slices available in {ckpt_path}! Processing from checkpoint.")
            df_ckpt = pd.DataFrame(list(d.values()))
            df_ckpt.to_csv(EXPORT_CSV_LOCAL, index=False)
            return df_ckpt
        else:
            print(f"Checkpoint has {len(d)} / 183 slices completed so far.")

    return None


def process_wall_to_wall(df_raw: pd.DataFrame | None = None):
    print("=" * 80)
    print("PROCESSING CANONICAL 10M WALL-TO-WALL EXPORT")
    print("=" * 80)

    if df_raw is None:
        df_raw = pd.read_csv(EXPORT_CSV_LOCAL)
    print(f"Loaded {len(df_raw)} slice records from export.")

    # Numeric columns to sum
    sum_cols = [
        "total_covered_ha", "eligible_ha", "excluded_mb_ha", "insufficient_dw_temporal_ha",
        "AA_ha", "AN_ha", "NA_ha", "NN_ha",
        "total_covered_count", "eligible_count", "excluded_mb_count", "insufficient_dw_temporal_count",
        "AA_count", "AN_count", "NA_count", "NN_count",
    ]

    for col in sum_cols:
        df_raw[col] = pd.to_numeric(df_raw[col], errors="coerce").fillna(0.0)

    # 1. Build sampling_frame_10m.csv with all active subestratos
    frame_rows = []
    regimes = ["AA", "AN", "NA", "NN"]
    for _, row in df_raw.iterrows():
        st = row["state"]
        s_id = row["slice_id"]
        for reg in regimes:
            a_hs = float(row[f"{reg}_ha"])
            n_hs = int(round(row[f"{reg}_count"]))
            frame_rows.append({
                "state": st,
                "regime": reg,
                "slice_id": s_id,
                "A_hs": a_hs,
                "N_hs_exact": n_hs,
            })

    df_frame = pd.DataFrame(frame_rows)
    # Order canonically: MA, TO, PI, BA; then AA, AN, NA, NN; then slice_id
    st_order = {"MA": 0, "TO": 1, "PI": 2, "BA": 3}
    reg_order = {"AA": 0, "AN": 1, "NA": 2, "NN": 3}
    df_frame["st_ord"] = df_frame["state"].map(st_order)
    df_frame["reg_ord"] = df_frame["regime"].map(reg_order)
    df_frame = df_frame.sort_values(["st_ord", "reg_ord", "slice_id"]).drop(columns=["st_ord", "reg_ord"])
    df_frame.to_csv(FRAME_CSV, index=False)
    print(f"Saved: {FRAME_CSV} ({len(df_frame)} rows)")

    # 2. Build wall_to_wall_summary.csv
    states = ["MA", "TO", "PI", "BA"]
    summary_rows = []
    state_summaries = {}

    for st in states:
        sub = df_raw[df_raw["state"] == st]
        tot_ha = sub["total_covered_ha"].sum()
        el_ha = sub["eligible_ha"].sum()
        ex_ha = sub["excluded_mb_ha"].sum()
        ins_ha = sub["insufficient_dw_temporal_ha"].sum()
        aa_ha = sub["AA_ha"].sum()
        an_ha = sub["AN_ha"].sum()
        na_ha = sub["NA_ha"].sum()
        nn_ha = sub["NN_ha"].sum()

        # Validation of closures
        diff_tot = abs(tot_ha - (el_ha + ex_ha + ins_ha))
        diff_el = abs(el_ha - (aa_ha + an_ha + na_ha + nn_ha))
        assert diff_tot < 1.0, f"Total area closure failed for {st}: diff={diff_tot}"
        assert diff_el < 1.0, f"Eligible area closure failed for {st}: diff={diff_el}"

        aa_pct = (aa_ha / el_ha) * 100.0 if el_ha > 0 else 0.0
        an_pct = (an_ha / el_ha) * 100.0 if el_ha > 0 else 0.0
        na_pct = (na_ha / el_ha) * 100.0 if el_ha > 0 else 0.0
        nn_pct = (nn_ha / el_ha) * 100.0 if el_ha > 0 else 0.0

        agreement_pct = ((aa_ha + nn_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0
        disagreement_pct = ((an_ha + na_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0
        qty_disag = (abs(an_ha - na_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0
        alloc_disag = (2.0 * min(an_ha, na_ha) / el_ha) * 100.0 if el_ha > 0 else 0.0

        state_summaries[st] = {
            "region": st,
            "total_area_ha": tot_ha,
            "eligible_area_ha": el_ha,
            "excluded_mb_area_ha": ex_ha,
            "insufficient_dw_temporal_area_ha": ins_ha,
            "AA_area_ha": aa_ha,
            "AN_area_ha": an_ha,
            "NA_area_ha": na_ha,
            "NN_area_ha": nn_ha,
            "AA_pct_eligible": aa_pct,
            "AN_pct_eligible": an_pct,
            "NA_pct_eligible": na_pct,
            "NN_pct_eligible": nn_pct,
            "agreement_pct": agreement_pct,
            "disagreement_pct": disagreement_pct,
            "quantity_disagreement": qty_disag,
            "allocation_disagreement": alloc_disag,
        }

    # MATOPIBA Biome Total
    mat_tot_ha = sum(s["total_area_ha"] for s in state_summaries.values())
    mat_el_ha = sum(s["eligible_area_ha"] for s in state_summaries.values())
    mat_ex_ha = sum(s["excluded_mb_area_ha"] for s in state_summaries.values())
    mat_ins_ha = sum(s["insufficient_dw_temporal_area_ha"] for s in state_summaries.values())
    mat_aa_ha = sum(s["AA_area_ha"] for s in state_summaries.values())
    mat_an_ha = sum(s["AN_area_ha"] for s in state_summaries.values())
    mat_na_ha = sum(s["NA_area_ha"] for s in state_summaries.values())
    mat_nn_ha = sum(s["NN_area_ha"] for s in state_summaries.values())

    mat_aa_pct = (mat_aa_ha / mat_el_ha) * 100.0
    mat_an_pct = (mat_an_ha / mat_el_ha) * 100.0
    mat_na_pct = (mat_na_ha / mat_el_ha) * 100.0
    mat_nn_pct = (mat_nn_ha / mat_el_ha) * 100.0

    mat_agree = ((mat_aa_ha + mat_nn_ha) / mat_el_ha) * 100.0
    mat_disag = ((mat_an_ha + mat_na_ha) / mat_el_ha) * 100.0
    mat_qty = (abs(mat_an_ha - mat_na_ha) / mat_el_ha) * 100.0
    mat_alloc = (2.0 * min(mat_an_ha, mat_na_ha) / mat_el_ha) * 100.0

    matopiba_row = {
        "region": "MATOPIBA",
        "total_area_ha": mat_tot_ha,
        "eligible_area_ha": mat_el_ha,
        "excluded_mb_area_ha": mat_ex_ha,
        "insufficient_dw_temporal_area_ha": mat_ins_ha,
        "AA_area_ha": mat_aa_ha,
        "AN_area_ha": mat_an_ha,
        "NA_area_ha": mat_na_ha,
        "NN_area_ha": mat_nn_ha,
        "AA_pct_eligible": mat_aa_pct,
        "AN_pct_eligible": mat_an_pct,
        "NA_pct_eligible": mat_na_pct,
        "NN_pct_eligible": mat_nn_pct,
        "agreement_pct": mat_agree,
        "disagreement_pct": mat_disag,
        "quantity_disagreement": mat_qty,
        "allocation_disagreement": mat_alloc,
    }

    df_summary = pd.DataFrame([matopiba_row] + [state_summaries[st] for st in states])
    df_summary.to_csv(SUMMARY_CSV, index=False)
    print(f"Saved: {SUMMARY_CSV}")

    # 3. Compute sampling quotas (16 strata) via Hamilton
    print("\n" + "=" * 80)
    print("COMPUTING CANONICAL SAMPLING QUOTAS (HAMILTON METHOD)")
    print("=" * 80)
    strata_rows = []
    total_el_ha = mat_el_ha
    total_el_m2 = total_el_ha * 10000.0

    for st in states:
        for reg in regimes:
            area_ha = state_summaries[st][f"{reg}_area_ha"]
            area_m2 = area_ha * 10000.0
            w_h = area_m2 / total_el_m2
            # Sum N_hs_exact from frame
            n_cells = df_frame[(df_frame["state"] == st) & (df_frame["regime"] == reg)]["N_hs_exact"].sum()
            strata_rows.append({
                "state": st,
                "regime": reg,
                "stratum_id": f"{st}_{reg}",
                "area_ha": area_ha,
                "area_m2": area_m2,
                "W_h": w_h,
                "N_h": int(n_cells),
            })

    df_strata = pd.DataFrame(strata_rows)
    N_TOTAL = 20000
    N_MIN = 400
    N_STRATA = len(df_strata)
    BASE_POINTS = N_STRATA * N_MIN  # 6400
    REMAINDER_POINTS = N_TOTAL - BASE_POINTS  # 13600

    df_strata["raw_remainder"] = df_strata["W_h"] * REMAINDER_POINTS
    df_strata["integer_part"] = df_strata["raw_remainder"].apply(math.floor).astype(int)
    df_strata["fractional_part"] = df_strata["raw_remainder"] - df_strata["integer_part"]

    allocated_remainder = df_strata["integer_part"].sum()
    points_left = REMAINDER_POINTS - allocated_remainder

    # Deterministic sort for largest remainder
    df_strata = df_strata.sort_values(by=["fractional_part", "stratum_id"], ascending=[False, True]).reset_index(drop=True)
    df_strata["extra_point"] = 0
    df_strata.loc[:points_left - 1, "extra_point"] = 1

    df_strata["n_main"] = N_MIN + df_strata["integer_part"] + df_strata["extra_point"]
    df_strata["n_robust"] = 2 * df_strata["n_main"]

    # Sort canonically
    df_strata["st_ord"] = df_strata["state"].map(st_order)
    df_strata["reg_ord"] = df_strata["regime"].map(reg_order)
    df_strata = df_strata.sort_values(["st_ord", "reg_ord"]).reset_index(drop=True)

    out_cols = ["state", "regime", "area_m2", "area_ha", "W_h", "N_h", "n_main", "n_robust"]
    df_quotas_out = df_strata[out_cols].copy()
    df_quotas_out["W_h"] = df_quotas_out["W_h"].round(8)
    df_quotas_out.to_csv(QUOTAS_CSV, index=False)
    print(f"Saved: {QUOTAS_CSV}")
    print(df_quotas_out.to_string(index=False))

    # Compare with old quotas
    if OLD_QUOTAS_CSV.exists():
        df_old_q = pd.read_csv(OLD_QUOTAS_CSV)
        print("\n" + "=" * 80)
        print("COMPARISON: OLD (SLICE-DEPENDENT) vs NEW (CANONICAL FIXED-DOMAIN) QUOTAS:")
        print("=" * 80)
        df_comp = df_quotas_out.merge(df_old_q, on=["state", "regime"], suffixes=("_new", "_old"))
        df_comp["delta_area_ha"] = df_comp["area_ha_new"] - df_comp["area_ha_old"]
        df_comp["delta_N_h"] = df_comp["N_h_new"] - df_comp["N_h_old"]
        df_comp["delta_n_main"] = df_comp["n_main_new"] - df_comp["n_main_old"]
        df_comp["delta_n_robust"] = df_comp["n_robust_new"] - df_comp["n_robust_old"]
        print(df_comp[["state", "regime", "area_ha_old", "area_ha_new", "delta_area_ha", "n_main_old", "n_main_new", "delta_n_main"]].to_string(index=False))

    # 4. Compute operational slice allocation with n_robust_hs >= 1 for all active subestratos
    print("\n" + "=" * 80)
    print("COMPUTING OPERATIONAL SLICE ALLOCATION (GUARANTEEING pi > 0)")
    print("=" * 80)

    alloc_rows = []
    for _, q_row in df_quotas_out.iterrows():
        st = q_row["state"]
        reg = q_row["regime"]
        n_rob_target = int(q_row["n_robust"])

        sub = df_frame[(df_frame["state"] == st) & (df_frame["regime"] == reg) & (df_frame["N_hs_exact"] > 0)].copy()
        k_slices = len(sub)
        assert k_slices > 0, f"No active slices for {st}_{reg}"
        assert n_rob_target >= k_slices, f"Quota {n_rob_target} < active slices {k_slices} for {st}_{reg}"

        sub["n_base"] = 1
        points_to_distribute = n_rob_target - k_slices

        tot_N = sub["N_hs_exact"].sum()
        sub["raw_share"] = (sub["N_hs_exact"] / tot_N) * points_to_distribute
        sub["int_part"] = sub["raw_share"].apply(math.floor).astype(int)
        sub["remainder"] = sub["raw_share"] - sub["int_part"]

        allocated_int = sub["int_part"].sum()
        leftover = points_to_distribute - allocated_int

        sub = sub.sort_values(by=["remainder", "slice_id"], ascending=[False, True]).reset_index(drop=True)
        sub["extra"] = 0
        if leftover > 0:
            sub.loc[:leftover - 1, "extra"] = 1

        sub["n_robust_hs"] = sub["n_base"] + sub["int_part"] + sub["extra"]
        assert sub["n_robust_hs"].sum() == n_rob_target
        assert (sub["n_robust_hs"] >= 1).all()

        sub["pi_robust_hs"] = sub["n_robust_hs"] / sub["N_hs_exact"]
        sub["design_weight_robust_hs"] = 1.0 / sub["pi_robust_hs"]
        sub["area_weight_robust_hs"] = (sub["A_hs"] * 10000.0) / sub["n_robust_hs"]
        alloc_rows.append(sub)

    df_alloc = pd.concat(alloc_rows, ignore_index=True)
    df_alloc["st_ord"] = df_alloc["state"].map(st_order)
    df_alloc["reg_ord"] = df_alloc["regime"].map(reg_order)
    df_alloc = df_alloc.sort_values(["st_ord", "reg_ord", "slice_id"]).drop(
        columns=["st_ord", "reg_ord", "n_base", "raw_share", "int_part", "remainder", "extra"]
    ).reset_index(drop=True)

    alloc_out_cols = [
        "state", "regime", "slice_id", "A_hs", "N_hs_exact",
        "n_robust_hs", "pi_robust_hs", "design_weight_robust_hs", "area_weight_robust_hs"
    ]
    df_alloc[alloc_out_cols].to_csv(FINAL_ALLOC_CSV, index=False)
    print(f"Saved: {FINAL_ALLOC_CSV} ({len(df_alloc)} active subestratos)")
    print(f"Total n_robust allocated: {df_alloc['n_robust_hs'].sum()} (Target: 40000)")
    print(f"Min pi_robust_hs: {df_alloc['pi_robust_hs'].min():.8e} (Must be > 0)")
    assert (df_alloc["pi_robust_hs"] > 0).all(), "Found subestrato with pi == 0!"
    print("PROVA FORMAL DE pi > 0: PASS (100% dos subestratos ativos têm probabilidade estritamente positiva)")


if __name__ == "__main__":
    df = load_data_source()
    if df is not None:
        process_wall_to_wall(df)
    else:
        print("Data source not ready yet (waiting for batch export or complete checkpoint).")
