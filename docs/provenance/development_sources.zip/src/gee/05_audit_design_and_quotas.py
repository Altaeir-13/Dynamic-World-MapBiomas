"""
05_audit_design_and_quotas.py — Complete Audit of 10m Frame, Slice Design, Main Subsampling & EPSG:5880
======================================================================================================
Implements all required audits for Checkpoint 2B:
  1. Quotas comparison: 30m vs 10m frame
  2. Audit of the real design by slice:
     - N_hs_exact, A_hs, n_robust_hs
     - pi_robust_hs, design_weight_robust, area_weight_robust
     - min(pi), max(pi), CV(pi) within each state x regime
  3. Deterministic pseudo-random main subsampling via SHA256:
     - rank_within_stratum based on SHA256(25|main_rank|state|regime|lon|lat)
     - exactly 20,000 main points nested in 40,000 robust points
     - distinct inclusion probabilities and design/area weights for main and robust
  4. Spatial diagnostics in EPSG:5880 (SIRGAS 2000 / Brazil Polyconic):
     - Nearest-neighbor distances (m)
     - Metric grid occupancy (50km x 50km)
  5. Rigorous scientific validation and verification of all Checkpoint 2B criteria.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.spatial import cKDTree
from shapely.geometry import box, shape

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"

STATES_GEOJSON = DATA_REF / "matopiba_states.geojson"
SUMMARY_30M_CSV = DATA_PROC / "wall_to_wall_summary.csv"
SUMMARY_10M_CSV = DATA_PROC / "wall_to_wall_summary_10m_AUDIT.csv"
FRAME_10M_CSV = TABLES_DIR / "sampling_frame_10m.csv"
TEMPORAL_QA_CSV = TABLES_DIR / "dw_valid_months_area.csv"
QUOTAS_30M_CSV = TABLES_DIR / "sampling_quotas.csv"
QUOTAS_10M_CSV = TABLES_DIR / "sampling_quotas_10m_AUDIT.csv"
POINTS_CSV = DATA_PROC / "master_sampling_points.csv"
CHECKPOINT_10M = DATA_PROC / "wall_to_wall_10m_slices_checkpoint.json"

STEP_DEG = 0.75
ROOT_SEED = 25


def sha256_rank_key(root_seed: int, state: str, regime: str, lon: float, lat: float) -> str:
    msg = f"{root_seed}|main_rank|{state}|{regime}|{lon:.8f}|{lat:.8f}".encode("utf-8")
    return hashlib.sha256(msg).hexdigest()


def partition_state(state: str, geom_shp, step: float = STEP_DEG) -> list[tuple[str, any]]:
    min_x, min_y, max_x, max_y = geom_shp.bounds
    nx = int((max_x - min_x) / step) + 1
    ny = int((max_y - min_y) / step) + 1
    dx = (max_x - min_x) / nx
    dy = (max_y - min_y) / ny
    pieces = []
    for ix in range(nx):
        for iy in range(ny):
            b = box(min_x + ix * dx, min_y + iy * dy, min_x + (ix + 1) * dx, min_y + (iy + 1) * dy)
            sub = geom_shp.intersection(b)
            if not sub.is_empty and sub.area > 1e-6:
                pieces.append((f"{state}_x{ix:02d}_y{iy:02d}", sub))
    return pieces


def audit_and_update_design():
    print("=" * 80)
    print("AUDITORIA COMPLETA DO DESIGN 10M, PESOS E PROBABILIDADES (CHECKPOINT 2B)")
    print("=" * 80)

    # 1. Compare Quotas: 30m vs 10m
    df_q30 = pd.read_csv(QUOTAS_30M_CSV, keep_default_na=False)
    df_q10 = pd.read_csv(QUOTAS_10M_CSV, keep_default_na=False)

    merged_q = pd.merge(
        df_q30, df_q10, on=["state", "regime"], suffixes=("_30m", "_10m")
    )
    merged_q["diff_n_main"] = merged_q["n_main_10m"] - merged_q["n_main_30m"]
    merged_q["diff_n_robust"] = merged_q["n_robust_10m"] - merged_q["n_robust_30m"]

    same_quotas_count = (merged_q["diff_n_robust"] == 0).sum()
    print(f"\n1. COMPARAÇÃO DE COTAS (30m vs 10m):")
    print(f"  Total de estratos: 16")
    print(f"  Estratos com quotas idênticas: {same_quotas_count} / 16")
    if same_quotas_count < 16:
        changed = merged_q[merged_q["diff_n_robust"] != 0]
        print(f"  Estratos com quotas alteradas ({len(changed)}):")
        for _, r in changed.iterrows():
            print(f"    - {r['state']} {r['regime']}: n_main {r['n_main_30m']} -> {r['n_main_10m']} (diff {r['diff_n_main']}), n_robust {r['n_robust_30m']} -> {r['n_robust_10m']} (diff {r['diff_n_robust']})")
    else:
        print("  TODAS as 16 cotas robustas e principais permaneceram rigorosamente idênticas!")

    # 2. Match points to 10m slices
    with open(STATES_GEOJSON, "r", encoding="utf-8") as f:
        states_data = json.load(f)

    slice_geoms = {}
    for feat in states_data["features"]:
        st = feat["properties"]["state"]
        shp = shape(feat["geometry"])
        pieces = partition_state(st, shp, STEP_DEG)
        for s_id, s_geom in pieces:
            slice_geoms[s_id] = s_geom

    df_points = pd.read_csv(POINTS_CSV, keep_default_na=False)
    print(f"\n2. Carregados {len(df_points):,} pontos amostrais de: {POINTS_CSV}")

    # Assign slice_id to each point
    # Fast spatial index via bounds
    slice_list = list(slice_geoms.items())
    assigned_slices = []
    for _, pt in df_points.iterrows():
        p_x, p_y = pt["lon"], pt["lat"]
        matched_slice = None
        for s_id, s_poly in slice_list:
            if s_id.startswith(pt["state"]):
                minx, miny, maxx, maxy = s_poly.bounds
                if minx <= p_x <= maxx and miny <= p_y <= maxy:
                    if s_poly.contains(shape({"type": "Point", "coordinates": [p_x, p_y]})) or s_poly.intersects(shape({"type": "Point", "coordinates": [p_x, p_y]})):
                        matched_slice = s_id
                        break
        assigned_slices.append(matched_slice)

    df_points["slice_id"] = assigned_slices
    unassigned = df_points["slice_id"].isna().sum()
    print(f"  Pontos mapeados para fatias 10m: {len(df_points) - unassigned:,} / {len(df_points):,} (Não mapeados: {unassigned})")

    # 3. Load 10m slice frame
    df_frame = pd.read_csv(FRAME_10M_CSV, keep_default_na=False)

    # Count sampled points per state x regime x slice_id
    sample_counts_hs = df_points.groupby(["state", "regime", "slice_id"]).size().reset_index(name="n_robust_hs")
    df_slice_design = pd.merge(df_frame, sample_counts_hs, on=["state", "regime", "slice_id"], how="left")
    df_slice_design["n_robust_hs"] = df_slice_design["n_robust_hs"].fillna(0).astype(int)

    # Filter only active slices where N_hs_exact > 0
    active_slices = df_slice_design[df_slice_design["N_hs_exact"] > 0].copy()

    # Calculate probabilities and weights by slice
    # For slices with n_robust_hs > 0:
    active_slices["pi_robust_hs"] = np.where(
        active_slices["N_hs_exact"] > 0,
        active_slices["n_robust_hs"] / active_slices["N_hs_exact"],
        0.0
    )
    active_slices["design_weight_robust_hs"] = np.where(
        active_slices["pi_robust_hs"] > 0,
        1.0 / active_slices["pi_robust_hs"],
        0.0
    )
    active_slices["area_weight_robust_hs"] = np.where(
        active_slices["n_robust_hs"] > 0,
        (active_slices["A_hs"] * 10000.0) / active_slices["n_robust_hs"],
        0.0
    )

    # Calculate CV of pi within each stratum
    cv_summary = []
    for (st, reg), grp in active_slices[active_slices["n_robust_hs"] > 0].groupby(["state", "regime"]):
        pis = grp["pi_robust_hs"]
        min_pi = pis.min()
        max_pi = pis.max()
        mean_pi = pis.mean()
        cv_pi = (pis.std() / mean_pi) if mean_pi > 0 and len(pis) > 1 else 0.0
        cv_summary.append({
            "state": st,
            "regime": reg,
            "n_slices": len(grp),
            "min_pi": min_pi,
            "max_pi": max_pi,
            "mean_pi": mean_pi,
            "cv_pi": cv_pi,
        })
    df_cv = pd.DataFrame(cv_summary)
    print("\n3. AUDITORIA DA DISTRIBUIÇÃO DAS PROBABILIDADES DE INCLUSÃO (PI) POR SLICE:")
    print(df_cv.to_string(index=False))

    # Save detailed slice design table
    SLICE_DESIGN_CSV = TABLES_DIR / "slice_sampling_design_audit.csv"
    active_slices.to_csv(SLICE_DESIGN_CSV, index=False)
    print(f"\n  Tabela de desenho real por slice salva: {SLICE_DESIGN_CSV}")

    # 4. Generate SHA256 Deterministic Main Rank & Assign Separate Main/Robust Weights
    print("\n4. ORDENAÇÃO PSEUDOALEATÓRIA DETERMINÍSTICA MAIN (SHA256):")
    df_points["hash_key"] = [
        sha256_rank_key(ROOT_SEED, r["state"], r["regime"], r["lon"], r["lat"])
        for _, r in df_points.iterrows()
    ]

    # Map target quotas
    q_map_main = df_q10.set_index(["state", "regime"])["n_main"].to_dict()
    q_map_robust = df_q10.set_index(["state", "regime"])["n_robust"].to_dict()

    # Sort deterministically within each (state, regime) by hash_key
    df_points = df_points.sort_values(["state", "regime", "hash_key"]).reset_index(drop=True)
    df_points["rank_within_stratum"] = df_points.groupby(["state", "regime"]).cumcount() + 1

    # Assign main_sample flag based on quota
    df_points["n_main_target"] = df_points.set_index(["state", "regime"]).index.map(q_map_main)
    df_points["n_robust_target"] = df_points.set_index(["state", "regime"]).index.map(q_map_robust)
    df_points["main_sample"] = (df_points["rank_within_stratum"] <= df_points["n_main_target"]).astype(int)
    df_points["robust_sample"] = 1

    # Map slice-level probabilities back to each point
    slice_pi_map = active_slices.set_index(["state", "regime", "slice_id"])[
        ["pi_robust_hs", "design_weight_robust_hs", "area_weight_robust_hs"]
    ].to_dict(orient="index")

    pi_robust_list = []
    dw_robust_list = []
    aw_robust_list = []

    pi_main_list = []
    dw_main_list = []
    aw_main_list = []

    for _, pt in df_points.iterrows():
        key = (pt["state"], pt["regime"], pt["slice_id"])
        slice_info = slice_pi_map.get(key, None)
        n_main_h = pt["n_main_target"]
        n_robust_h = pt["n_robust_target"]
        ratio_main = n_main_h / n_robust_h  # 0.5 exactly

        if slice_info and slice_info["pi_robust_hs"] > 0:
            pi_rob = slice_info["pi_robust_hs"]
            dw_rob = slice_info["design_weight_robust_hs"]
            aw_rob = slice_info["area_weight_robust_hs"]
        else:
            # Fallback to stratum level
            n_exact_stratum = df_q10.set_index(["state", "regime"]).loc[(pt["state"], pt["regime"]), "N_h"]
            area_m2_stratum = df_q10.set_index(["state", "regime"]).loc[(pt["state"], pt["regime"]), "area_m2"]
            pi_rob = n_robust_h / n_exact_stratum
            dw_rob = 1.0 / pi_rob
            aw_rob = area_m2_stratum / n_robust_h

        pi_robust_list.append(pi_rob)
        dw_robust_list.append(dw_rob)
        aw_robust_list.append(aw_rob)

        if pt["main_sample"] == 1:
            pi_main = pi_rob * ratio_main
            dw_main = 1.0 / pi_main
            aw_main = aw_rob * 2.0  # Area allocated per main point is 2x robust point
            pi_main_list.append(pi_main)
            dw_main_list.append(dw_main)
            aw_main_list.append(aw_main)
        else:
            pi_main_list.append(np.nan)
            dw_main_list.append(np.nan)
            aw_main_list.append(np.nan)

    df_points["selection_probability_robust"] = pi_robust_list
    df_points["design_weight_robust"] = dw_robust_list
    df_points["area_weight_robust"] = aw_robust_list

    df_points["selection_probability_main"] = pi_main_list
    df_points["design_weight_main"] = dw_main_list
    df_points["area_weight_main"] = aw_main_list

    # Sort final table neatly
    st_order = {"MA": 0, "TO": 1, "PI": 2, "BA": 3}
    reg_order = {"AA": 0, "AN": 1, "NA": 2, "NN": 3}
    df_points["st_ord"] = df_points["state"].map(st_order)
    df_points["reg_ord"] = df_points["regime"].map(reg_order)
    df_points = df_points.sort_values(["st_ord", "reg_ord", "rank_within_stratum"]).drop(
        columns=["st_ord", "reg_ord", "n_main_target", "n_robust_target", "hash_key"]
    ).reset_index(drop=True)

    # Re-order columns with separated main and robust weights
    final_cols = [
        "sample_id",
        "lat",
        "lon",
        "state",
        "stratum_id",
        "regime",
        "slice_id",
        "main_sample",
        "robust_sample",
        "rank_within_stratum",
        "root_seed",
        "stratum_seed",
        "selection_probability_robust",
        "design_weight_robust",
        "area_weight_robust",
        "selection_probability_main",
        "design_weight_main",
        "area_weight_main",
    ]
    df_points = df_points[final_cols]
    df_points.to_csv(POINTS_CSV, index=False)
    print(f"  Master sample atualizada com ranking SHA256 e pesos separados: {POINTS_CSV}")

    # 5. Spatial Diagnostics in EPSG:5880
    print("\n5. DIAGNÓSTICO ESPACIAL RIGOROSO EM EPSG:5880 (SIRGAS 2000 / POLYCONIC):")
    trans = Transformer.from_crs("EPSG:4326", "EPSG:5880", always_xy=True)
    xs, ys = trans.transform(df_points["lon"].values, df_points["lat"].values)
    coords_5880 = np.column_stack([xs, ys])

    tree = cKDTree(coords_5880)
    dists, _ = tree.query(coords_5880, k=[2])
    nn_dists = dists.flatten()

    print("  Estatísticas de Distância ao Vizinho Mais Próximo (EPSG:5880 - metros):")
    print(f"    Mínimo:            {nn_dists.min():.1f} m")
    print(f"    Percentil 25 (Q1): {np.percentile(nn_dists, 25):.1f} m")
    print(f"    Mediana:           {np.median(nn_dists):.1f} m")
    print(f"    Média:             {np.mean(nn_dists):.1f} m")
    print(f"    Percentil 75 (Q3): {np.percentile(nn_dists, 75):.1f} m")
    print(f"    Máximo:            {nn_dists.max():.1f} m")

    grid_size = 50000.0  # 50km
    grid_cells = set(zip(np.floor(xs / grid_size), np.floor(ys / grid_size)))
    print(f"  Ocupação de Grade Métrica (50 km x 50 km em EPSG:5880): {len(grid_cells)} células ocupadas")

    # 6. Summary of criteria
    print("\n" + "=" * 80)
    print("VERIFICAÇÃO DE CRITÉRIOS DE AUDITORIA:")
    print(f"  Total de pontos: {len(df_points):,} (Exigido: 40,000)")
    print(f"  Subamostra principal: {(df_points['main_sample'] == 1).sum():,} (Exigido: 20,000)")
    print(f"  Subamostra robustez: {(df_points['robust_sample'] == 1).sum():,} (Exigido: 40,000)")
    print(f"  Duplicatas de coordenadas: {df_points.duplicated(subset=['lon', 'lat']).sum()} (Exigido: 0)")
    print(f"  Pesos main e robust distintos: {not np.allclose(df_points.loc[df_points['main_sample']==1, 'design_weight_main'], df_points.loc[df_points['main_sample']==1, 'design_weight_robust'])}")
    print("=" * 80)


if __name__ == "__main__":
    audit_and_update_design()
