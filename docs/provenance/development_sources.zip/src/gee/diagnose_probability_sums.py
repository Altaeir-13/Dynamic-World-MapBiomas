"""
diagnose_probability_sums.py — Diagnóstico minucioso da soma das 9 probabilidades
=================================================================================
Audita separadamente nos mesmos pontos amostrais:
A. observação Dynamic World original;
B. composição diária;
C. composição mensal antes de reprojeção;
D. vetor anual antes de reprojeção;
E. vetor anual após harmonização à grade MapBiomas 10 m;
F. vetor após extração nos pontos.

Para cada estágio, calcula e reporta:
min, Q1, median, mean, Q3, max, max(abs(sum_p - 1))
"""

from __future__ import annotations

import json
from pathlib import Path

import ee
import numpy as np
import pandas as pd

DW_COLLECTION = "GOOGLE/DYNAMICWORLD/V1"
MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
MB_BAND = "classification_2025"

DW_PROB_BANDS = [
    "water", "trees", "grass", "flooded_vegetation", "crops",
    "shrub_and_scrub", "built", "bare", "snow_and_ice"
]


def stats_dict(vals: list[float] | np.ndarray) -> dict:
    arr = np.array(vals)
    return {
        "min": float(np.min(arr)),
        "Q1": float(np.percentile(arr, 25)),
        "median": float(np.median(arr)),
        "mean": float(np.mean(arr)),
        "Q3": float(np.percentile(arr, 75)),
        "max": float(np.max(arr)),
        "max_abs_dev": float(np.max(np.abs(arr - 1.0))),
    }


def run_diagnosis():
    ee.Initialize(project="dynamicworld-x-mapbiomas")

    # Carrega pontos do protótipo gerado anteriormente para usar exatamente os mesmos pontos
    csv_path = Path("data/processed/prototype_samples.csv")
    df = pd.read_csv(csv_path, keep_default_na=False)
    # Seleciona 50 pontos de MA para diagnóstico rápido e preciso
    sub = df[df["state"] == "MA"].head(50)

    features = []
    for _, row in sub.iterrows():
        pt = ee.Geometry.Point([row["longitude"], row["latitude"]])
        features.append(ee.Feature(pt, {"sample_id": row["sample_id"]}))
    fc_pts = ee.FeatureCollection(features)

    region = fc_pts.geometry().bounds().buffer(5000)

    # Asset MapBiomas para obter projeção de referência
    mb = ee.Image(MB_ASSET).select(MB_BAND)
    mb_proj = mb.projection()

    dw_col = (
        ee.ImageCollection(DW_COLLECTION)
        .filterBounds(region)
        .filterDate("2025-01-01", "2026-01-01")
        .select(DW_PROB_BANDS)
    )

    # -------------------------------------------------------------
    # Estágio A: Observação Dynamic World original (primeira cena válida sobre a região)
    # -------------------------------------------------------------
    img_first = dw_col.first()
    sum_A = img_first.reduce(ee.Reducer.sum()).rename("sum_A")

    # -------------------------------------------------------------
    # Estágio B: Composição diária (exemplo: dia 2025-07-15)
    # -------------------------------------------------------------
    day_col = dw_col.filterDate("2025-07-01", "2025-07-02")
    # Se dia vazio, pega data da primeira imagem
    first_date = ee.Date(img_first.get("system:time_start"))
    day_start = first_date.format("YYYY-MM-dd")
    day_end = first_date.advance(1, "day").format("YYYY-MM-dd")
    daily_img = dw_col.filterDate(day_start, day_end).mean()
    sum_B = daily_img.reduce(ee.Reducer.sum()).rename("sum_B")

    # -------------------------------------------------------------
    # Estágio C: Composição mensal antes de reprojeção (mês 07)
    # -------------------------------------------------------------
    month_col = dw_col.filterDate("2025-07-01", "2025-08-01")
    monthly_img = month_col.mean()
    sum_C = monthly_img.reduce(ee.Reducer.sum()).rename("sum_C")

    # -------------------------------------------------------------
    # Estágio D: Vetor anual antes de reprojeção (média dos 12 meses nativos)
    # -------------------------------------------------------------
    m_comps = []
    for m in range(1, 13):
        start = f"2025-{m:02d}-01"
        end = f"2025-{m+1:02d}-01" if m < 12 else "2026-01-01"
        mc = dw_col.filterDate(start, end).mean()
        m_comps.append(mc)
    annual_dw_native = ee.ImageCollection(m_comps).mean()
    sum_D = annual_dw_native.reduce(ee.Reducer.sum()).rename("sum_D")

    # -------------------------------------------------------------
    # Estágio E: Vetor anual após harmonização à grade MapBiomas 10 m
    # Testaremos 2 versões:
    # E1: com resample('bilinear').reproject(crs=mb_proj, scale=10)
    # E2: reproject sem bilinear (vizinho mais próximo)
    # E3: sem reproject explícito (deixando reduceRegions amostrar na escala do MapBiomas)
    # -------------------------------------------------------------
    annual_dw_bilinear = annual_dw_native.resample("bilinear").reproject(crs=mb_proj, scale=10)
    sum_E_bilinear = annual_dw_bilinear.reduce(ee.Reducer.sum()).rename("sum_E_bilinear")

    annual_dw_nearest = annual_dw_native.reproject(crs=mb_proj, scale=10)
    sum_E_nearest = annual_dw_nearest.reduce(ee.Reducer.sum()).rename("sum_E_nearest")

    # Imagem combinada com todas as somas
    diag_stack = ee.Image.cat([
        sum_A,
        sum_B,
        sum_C,
        sum_D,
        sum_E_bilinear,
        sum_E_nearest,
    ])

    # Extrai nos 50 pontos
    sampled = diag_stack.reduceRegions(
        collection=fc_pts,
        reducer=ee.Reducer.first(),
        scale=10,
    ).getInfo()

    # Coleta valores
    vals = {
        "A_original": [],
        "B_daily": [],
        "C_monthly": [],
        "D_annual_native": [],
        "E_annual_bilinear": [],
        "E_annual_nearest": [],
    }

    for f in sampled["features"]:
        props = f["properties"]
        for k, v in [
            ("A_original", "sum_A"),
            ("B_daily", "sum_B"),
            ("C_monthly", "sum_C"),
            ("D_annual_native", "sum_D"),
            ("E_annual_bilinear", "sum_E_bilinear"),
            ("E_annual_nearest", "sum_E_nearest"),
        ]:
            val = props.get(v)
            if val is not None:
                vals[k].append(val)

    print("=" * 80)
    print("DIAGNÓSTICO QUANTITATIVO DA SOMA DAS 9 PROBABILIDADES EM 6 ESTÁGIOS:")
    print("=" * 80)
    header = f"{'Estágio':30s} | {'min':7s} | {'Q1':7s} | {'median':7s} | {'mean':7s} | {'Q3':7s} | {'max':7s} | {'max|dev|':7s}"
    print(header)
    print("-" * 80)

    for k, vlist in vals.items():
        if vlist:
            s = stats_dict(vlist)
            line = f"{k:30s} | {s['min']:7.5f} | {s['Q1']:7.5f} | {s['median']:7.5f} | {s['mean']:7.5f} | {s['Q3']:7.5f} | {s['max']:7.5f} | {s['max_abs_dev']:7.5f}"
            print(line)
        else:
            print(f"{k:30s} | SEM DADOS")
    print("=" * 80)


if __name__ == "__main__":
    run_diagnosis()
