import json
import sys
import time
from pathlib import Path
from shapely.geometry import box, shape
import ee

BASE_DIR = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(BASE_DIR))

ee.Initialize(project="dynamicworld-x-mapbiomas")
from src.gee.dw_annual import get_harmonized_crosswalk_layers, get_mapbiomas_projection

with open("data/reference/matopiba_states.geojson", "r") as f:
    st_data = json.load(f)
pi_feat = next(feat for feat in st_data["features"] if feat["properties"]["state"] == "PI")
shp = shape(pi_feat["geometry"])
min_x, min_y, max_x, max_y = shp.bounds
dy = (max_y - min_y) / 4
b0 = box(min_x, min_y, max_x, min_y + dy)
ee_geom0 = ee.Geometry(shp.intersection(b0).__geo_interface__)

mb_proj = get_mapbiomas_projection()
layers = get_harmonized_crosswalk_layers(region=ee_geom0, mb_proj=mb_proj)
mb = layers["mb"]
pixel_area_ha = ee.Image.pixelArea().divide(10000.0)

stack = ee.Image.cat([
    pixel_area_ha.updateMask(mb.mask()).rename("total_covered_ha"),
    pixel_area_ha.updateMask(layers["eligible_mask"]).rename("eligible_ha"),
    pixel_area_ha.updateMask(layers["is_excluded"].updateMask(mb.mask())).rename("excluded_ha"),
    pixel_area_ha.updateMask(layers["insufficient_dw_temporal"]).rename("insufficient_dw_ha"),
    pixel_area_ha.updateMask(layers["regime_AA"]).rename("AA_ha"),
    pixel_area_ha.updateMask(layers["regime_AN"]).rename("AN_ha"),
    pixel_area_ha.updateMask(layers["regime_NA"]).rename("NA_ha"),
    pixel_area_ha.updateMask(layers["regime_NN"]).rename("NN_ha"),
])

t0 = time.time()
res = stack.reduceRegion(
    reducer=ee.Reducer.sum(),
    geometry=ee_geom0,
    scale=30,
    maxPixels=1e13,
    tileScale=8
).getInfo()

print(f"Full partition stats computed in {time.time() - t0:.1f}s:")
for k, v in res.items():
    print(f"  {k:20s}: {v:,.2f} ha")

sum_regimes = res["AA_ha"] + res["AN_ha"] + res["NA_ha"] + res["NN_ha"]
diff_regimes = abs(sum_regimes - res["eligible_ha"])
print(f"\nValidation 1 (AA + AN + NA + NN == eligible):")
print(f"  Sum regimes: {sum_regimes:,.2f} ha vs eligible: {res['eligible_ha']:,.2f} ha (diff: {diff_regimes:.4f} ha)")

sum_partition = res["eligible_ha"] + res["excluded_ha"] + res["insufficient_dw_ha"]
diff_partition = abs(sum_partition - res["total_covered_ha"])
print(f"\nValidation 2 (eligible + excluded + insufficient_dw == total_covered):")
print(f"  Sum partition: {sum_partition:,.2f} ha vs covered: {res['total_covered_ha']:,.2f} ha (diff: {diff_partition:.4f} ha)")
