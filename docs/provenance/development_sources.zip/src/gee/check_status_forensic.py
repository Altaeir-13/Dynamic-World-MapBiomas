import ee
import pandas as pd
from pathlib import Path
from datetime import datetime

ee.Initialize(project='dynamicworld-x-mapbiomas')

tasks_df = pd.read_csv('tables/canonical_w2w_batch_tasks.csv')
manifest_df = pd.read_csv('tables/canonical_w2w_batch_manifest.csv')

print('=== CANONICAL W2W BATCH MANIFEST SUMMARY ===')
print(f'Total manifest rows: {len(manifest_df)}')
print(f'Unique slice_ids: {manifest_df["slice_id"].nunique()}')
print(f'Unique batch_ids: {manifest_df["batch_id"].nunique()}')
batch_slice_counts = manifest_df.groupby('batch_id')['slice_id'].count().to_dict()

print('\n=== CONSULTING GEE FOR ALL REGISTERED TASKS ===')
gee_status_records = []
for idx, row in tasks_df.iterrows():
    b_id = row['batch_id']
    t_id = row['task_id']
    csv_file = Path('data/processed/batches') / f'{b_id}_10m.csv'
    csv_exists = csv_file.exists()
    n_expected = batch_slice_counts.get(b_id, 0)
    
    n_local = 0
    if csv_exists:
        try:
            df_local = pd.read_csv(csv_file)
            n_local = len(df_local)
        except Exception as e:
            n_local = f'ERR: {e}'
            
    try:
        status = ee.data.getTaskStatus(t_id)[0]
        state = status.get('state')
        start_ms = status.get('start_timestamp_ms', status.get('creation_timestamp_ms'))
        update_ms = status.get('update_timestamp_ms')
        start_time = datetime.utcfromtimestamp(start_ms / 1000.0).isoformat() if start_ms else None
        update_time = datetime.utcfromtimestamp(update_ms / 1000.0).isoformat() if update_ms else None
        error_msg = status.get('error_message', '')
    except Exception as e:
        state = f'ERR: {e}'
        start_time = None
        update_time = None
        error_msg = str(e)
        
    gee_status_records.append({
        'batch_id': b_id,
        'task_id': t_id,
        'state': state,
        'start_time': start_time,
        'update_time': update_time,
        'error_message': error_msg,
        'downloaded': row.get('downloaded', False),
        'csv_local_exists': csv_exists,
        'n_slices_expected': n_expected,
        'n_slices_local': n_local
    })

res_df = pd.DataFrame(gee_status_records)
print(res_df.to_string(index=False))

print('\n=== CHECKING ALL LOCAL CSVs FOR SCHEMA & CLOSURE ===')
batches_dir = Path('data/processed/batches')
for f in sorted(batches_dir.glob('*.csv')):
    try:
        df = pd.read_csv(f)
        n_cols = len(df.columns)
        n_rows = len(df)
        n_dup = df['slice_id'].duplicated().sum() if 'slice_id' in df.columns else 'NO_SLICE_ID'
        
        # Check area closure if columns exist
        closure_err = None
        if all(c in df.columns for c in ['AA', 'AN', 'NA', 'NN', 'eligible']):
            regime_sum = df['AA'] + df['AN'] + df['NA'] + df['NN']
            diff = (regime_sum - df['eligible']).abs().max()
            closure_err = f'max|diff|={diff:.4f}'
            
        print(f'{f.name:35} | {n_rows:>3} rows | {n_cols:>2} cols | dups={n_dup} | closure={closure_err}')
    except Exception as e:
        print(f'{f.name:35} | ERROR: {e}')
