"""
10_generate_manifest.py — Geração do Sampling Manifest Congelado (Checkpoint 3B)
================================================================================
Cria config/sampling_manifest.yaml consolidando todos os metadados,
regras probabilísticas, estratos, fatias, fórmulas e hashes SHA-256
dos artefatos congelados da amostragem no MATOPIBA com cobertura 100%.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import yaml

BASE_DIR = Path(__file__).resolve().parent.parent.parent
CONFIG_DIR = BASE_DIR / "config"
DATA_REF = BASE_DIR / "data" / "reference"
DATA_PROC = BASE_DIR / "data" / "processed"
TABLES_DIR = BASE_DIR / "tables"

MANIFEST_PATH = CONFIG_DIR / "sampling_manifest.yaml"


def sha256(path: Path) -> str:
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def main():
    print("Gerando config/sampling_manifest.yaml...")

    boundary_path = DATA_REF / "matopiba_boundary.geojson"
    muni_path = DATA_REF / "matopiba_municipalities.csv"
    states_path = DATA_REF / "matopiba_states.geojson"
    experiment_path = CONFIG_DIR / "experiment.yaml"
    w2w_path = DATA_PROC / "wall_to_wall_summary.csv"
    w2w_audit_path = DATA_PROC / "wall_to_wall_summary_10m_AUDIT.csv"
    frame_path = TABLES_DIR / "sampling_frame_10m.csv"
    quotas_path = TABLES_DIR / "sampling_quotas.csv"
    alloc_final_path = TABLES_DIR / "slice_sampling_allocation_final.csv"
    zero_pi_audit_path = TABLES_DIR / "zero_inclusion_substrata_audit.csv"
    dw_diag_path = TABLES_DIR / "dw_annual_identity_diagnostic.csv"
    master_path = DATA_PROC / "master_sampling_points.csv"
    audit_slice_path = TABLES_DIR / "slice_sampling_design_audit.csv"
    boundary_vs_raster_path = TABLES_DIR / "boundary_vs_raster_area_comparison.csv"
    dw_monthly_path = DATA_PROC / "dw_monthly.parquet"
    samples_annual_pq_path = DATA_PROC / "samples_annual.parquet"
    samples_annual_csv_path = DATA_PROC / "samples_annual.csv"

    df_quotas = pd.read_csv(quotas_path, keep_default_na=False)
    df_frame = pd.read_csv(frame_path, keep_default_na=False)
    df_bvr = pd.read_csv(boundary_vs_raster_path)
    bvr_dict = dict(zip(df_bvr["metric"], df_bvr["value_ha"]))

    strata_list = []
    for _, row in df_quotas.iterrows():
        st = str(row["state"])
        reg = str(row["regime"])
        stratum_id = f"{st}_{reg}"
        strata_list.append({
            "stratum_id": stratum_id,
            "state": st,
            "regime": reg,
            "A_h_ha": float(row["area_ha"]),
            "N_h_exact": int(row["N_h"]),
            "n_main": int(row["n_main"]),
            "n_robust": int(row["n_robust"]),
        })

    unique_slices = sorted(df_frame["slice_id"].unique().tolist())
    slice_counts = {
        st: len([s for s in unique_slices if s.startswith(st)])
        for st in ["MA", "TO", "PI", "BA"]
    }

    manifest = {
        "manifest_version": "1.1.0",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "status": "FROZEN_AUTHORIZED",
        "checkpoint": "CHECKPOINT_3B",
        "description": "Manifesto oficial e congelado de amostragem probabilística do estudo Dynamic World x MapBiomas no MATOPIBA 2025 com cobertura de 100% da população-alvo (zero pi=0).",
        
        "domain": {
            "name": "MATOPIBA",
            "boundary_file": "data/reference/matopiba_boundary.geojson",
            "boundary_sha256": sha256(boundary_path),
            "municipalities_file": "data/reference/matopiba_municipalities.csv",
            "municipalities_sha256": sha256(muni_path),
            "n_municipalities": 337,
            "states": ["MA", "TO", "PI", "BA"],
            "boundary_area_ha": {
                "boundary_vector_area_geodesic_ha": float(bvr_dict["boundary_vector_area_geodesic_ha"]),
                "boundary_vector_area_epsg5880_ha": float(bvr_dict["boundary_vector_area_epsg5880_ha"]),
                "mapbiomas_raster_covered_area_ha": float(bvr_dict["mapbiomas_raster_covered_area_ha"]),
                "difference_geodesic_vs_raster_ha": float(bvr_dict["difference_boundary_geodesic_vs_raster_ha"]),
                "difference_geodesic_vs_raster_pct": float(bvr_dict["difference_boundary_geodesic_vs_raster_pct"]),
                "raster_uncovered_or_center_rule_area_ha": float(bvr_dict["raster_uncovered_or_center_rule_area_ha"]),
            }
        },

        "grid_and_projection": {
            "crs": "EPSG:4326",
            "crsTransform": [
                8.983152841195215e-05,
                0.0,
                -75.62655865569857,
                0.0,
                -8.983152841195215e-05,
                6.763595437192701
            ],
            "nominal_resolution_m": 10.0,
            "metric_projected_crs": "EPSG:5880",
            "pixel_area_source": "ee.Image.pixelArea()",
        },

        "official_assets": {
            "dynamic_world": {
                "collection": "GOOGLE/DYNAMICWORLD/V1",
                "period": {
                    "start": "2025-01-01",
                    "end": "2026-01-01"
                },
                "bands": [
                    "water", "trees", "grass", "flooded_vegetation", "crops",
                    "shrub_and_scrub", "built", "bare", "snow_and_ice"
                ],
                "crops_index": 4,
            },
            "mapbiomas": {
                "asset": "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1",
                "band": "classification_2025",
                "historical_series_asset": "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1",
                "historical_years": list(range(2017, 2026)),
            }
        },

        "frozen_crosswalk": {
            "mapbiomas": {
                "crop": [19, 36],
                "excluded": [18, 21],
                "noncrop": "todas as demais classes validas (inclui 15 pastagem, 9 silvicultura)"
            },
            "dynamic_world": {
                "crop": "annual_class_index == 4 ('crops')",
                "noncrop": "annual_class_index != 4"
            },
            "temporal_eligibility": {
                "metric": "n_valid_months",
                "threshold": ">= 8",
                "total_months": 12
            },
            "regimes": {
                "AA": "MapBiomas Crop (1) AND Dynamic World Crop (1)",
                "AN": "MapBiomas Crop (1) AND Dynamic World Noncrop (0)",
                "NA": "MapBiomas Noncrop (0) AND Dynamic World Crop (1)",
                "NN": "MapBiomas Noncrop (0) AND Dynamic World Noncrop (0)"
            }
        },

        "sampling_design": {
            "root_seed": 25,
            "strata_count": 16,
            "operational_slices_count": len(unique_slices),
            "slice_counts_by_state": slice_counts,
            "total_target_sample_size_robust": 40000,
            "total_target_sample_size_main": 20000,
            "scientific_allocation_rule": "Hamilton Largest Remainder com piso min_stratum=400 na amostra main, robust = 2 * main",
            "operational_allocation_rule": "Hamilton Largest Remainder com garantia n_robust_hs >= 1 para todo subestrato com N_hs_exact > 0",
            
            "strata_definitions": strata_list,

            "operational_slice_sampling": {
                "method": "Stratified sampling por fatia operacional (state x regime x slice_id)",
                "zero_pi_guarantee": "pi_robust_hs > 0 para 100% dos pixels da populacao-alvo",
                "inclusion_probability_robust_formula": "pi_robust_hs = n_robust_hs / N_hs_exact",
                "design_weight_robust_formula": "w_design_robust = 1 / pi_robust_hs",
                "area_weight_robust_formula": "w_area_robust = pixel_area_m2 / pi_robust_hs",
                "main_subsampling_rule": "Deterministic SHA256 ranking: SHA256(root_seed=25 | 'main_rank' | state | regime | lon | lat)",
                "main_selection_probability_formula": "pi_main_i = pi_robust_hs * (n_main_h / n_robust_h) = 0.5 * pi_robust_hs",
                "design_weight_main_formula": "w_design_main = 1 / pi_main_i = 2 * w_design_robust",
                "area_weight_main_formula": "w_area_main = pixel_area_m2 / pi_main_i = 2 * w_area_robust (somente para main_sample == 1, NaN para outros)",
            }
        },

        "frozen_artifacts_sha256": {
            "data/reference/matopiba_boundary.geojson": sha256(boundary_path),
            "data/reference/matopiba_municipalities.csv": sha256(muni_path),
            "data/reference/matopiba_states.geojson": sha256(states_path),
            "config/experiment.yaml": sha256(experiment_path),
            "data/processed/wall_to_wall_summary.csv": sha256(w2w_path),
            "data/processed/wall_to_wall_summary_10m_AUDIT.csv": sha256(w2w_audit_path),
            "tables/sampling_frame_10m.csv": sha256(frame_path),
            "tables/sampling_quotas.csv": sha256(quotas_path),
            "tables/slice_sampling_allocation_final.csv": sha256(alloc_final_path),
            "tables/zero_inclusion_substrata_audit.csv": sha256(zero_pi_audit_path),
            "tables/dw_annual_identity_diagnostic.csv": sha256(dw_diag_path),
            "tables/boundary_vs_raster_area_comparison.csv": sha256(boundary_vs_raster_path),
            "data/processed/master_sampling_points.csv": sha256(master_path),
            "data/processed/dw_monthly.parquet": sha256(dw_monthly_path),
            "data/processed/samples_annual.parquet": sha256(samples_annual_pq_path),
            "data/processed/samples_annual.csv": sha256(samples_annual_csv_path),
        }
    }

    with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
        yaml.dump(manifest, f, allow_unicode=True, sort_keys=False, indent=2)

    print(f"Manifesto salvo com sucesso: {MANIFEST_PATH}")
    print(f"SHA-256 do manifesto: {sha256(MANIFEST_PATH)}")


if __name__ == "__main__":
    main()
