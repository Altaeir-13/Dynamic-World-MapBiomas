import time
import json
import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

with open("data/reference/matopiba_states.geojson") as f:
    d = json.load(f)

pi_feat = next(f for f in d["features"] if f["properties"]["state"] == "PI")
pi_geom = ee.Geometry(pi_feat["geometry"])

MB_ASSET = "projects/mapbiomas-public/assets/brazil/lulc_10m/collection4/mapbiomas_10m_collection4_coverage_v1"
mb = ee.Image(MB_ASSET).select("classification_2025")

is_excluded = mb.eq(21).Or(mb.eq(18))
valid_mb_mask = is_excluded.Not().And(mb.mask())
mb_crop = mb.remap([19, 36], [1, 1], 0).rename("crop").updateMask(valid_mb_mask)

# Test: stratifiedSample on mb_crop directly
# class 1 (crop): 3000 points; class 0 (noncrop): 3000 points
t0 = time.time()
print("Testing stratifiedSample on static mb_crop for 3,000 crop and 3,000 noncrop points...")
pts = mb_crop.stratifiedSample(
    numPoints=0,
    classBand="crop",
    region=pi_geom,
    scale=10,
    seed=25,
    classValues=[0, 1],
    classPoints=[3000, 3000],
    geometries=True,
    tileScale=8
)
cnt = pts.size().getInfo()
print(f"Completed in {time.time() - t0:.2f}s! Total points: {cnt}")
