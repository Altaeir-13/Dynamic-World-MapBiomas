import json
from pathlib import Path

transcript_path = Path(r"C:\Users\Altair\.gemini\antigravity-ide\brain\6e02b075-103d-4846-9e8d-39f759245f0b\.system_generated\logs\transcript_full.jsonl")

with open(transcript_path, "r", encoding="utf-8") as f:
    lines = f.readlines()

cmd = json.loads(lines[2325])["tool_calls"][0]["args"]["CommandLine"]
idx = cmd.find("-c ")
if idx != -1:
    code = cmd[idx+3:].strip()
    if code.startswith('"') and code.endswith('"'):
        code = code[1:-1]
    # Handle escaping
    code = code.encode("utf-8").decode("unicode_escape")
    target = Path("src/gee/18_export_canonical_wall_to_wall.py")
    with open(target, "w", encoding="utf-8") as out:
        out.write(code)
    print("Wrote export script to:", target)
else:
    print("No -c found in cmd")
