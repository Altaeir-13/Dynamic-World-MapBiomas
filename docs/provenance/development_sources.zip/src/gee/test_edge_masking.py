"""
test_edge_masking.py — Teste de detecção de bordas com mascaramento de classes excluídas
=======================================================================================
Verifica que:
1. Pixels excluídos (21 Mosaico, 18 Agricultura) são mascarados antes da detecção;
2. Transições envolvendo classes excluídas NÃO disparam borda;
3. Borda entre CROP (19, 36) e NONCROP válido é corretamente identificada;
4. fastDistanceTransform opera diretamente sobre edge=1 (sem edge.Not()).
"""

from __future__ import annotations

import ee


def run_test():
    ee.Initialize(project="dynamicworld-x-mapbiomas")

    cx, cy = 5986630.0, 8880690.0
    kernel = ee.Kernel.square(1)

    # Cria polígonos sintéticos:
    # 1. crop_poly: [cx, cy-100] a [cx+100, cy+100] (valor 19)
    # 2. excluded_poly: [cx-100, cy-50] a [cx, cy+50] (valor 21 - Mosaico)
    # 3. background: valor 3 (Formação Florestal - NONCROP válido)
    crop_poly = ee.Geometry.Polygon([[cx, cy - 100], [cx + 100, cy - 100], [cx + 100, cy + 100], [cx, cy + 100], [cx, cy - 100]], "EPSG:5880", geodesic=False)
    excluded_poly = ee.Geometry.Polygon([[cx - 100, cy - 50], [cx, cy - 50], [cx, cy + 50], [cx - 100, cy + 50], [cx - 100, cy - 50]], "EPSG:5880", geodesic=False)

    base = ee.Image(3).reproject(crs="EPSG:5880", scale=10)
    raw_mb = base.paint(crop_poly, 19).paint(excluded_poly, 21).reproject(crs="EPSG:5880", scale=10)

    # Mascaramento de classes excluídas
    is_excluded = raw_mb.eq(21).Or(raw_mb.eq(18))
    valid_mb_mask = is_excluded.Not().And(raw_mb.mask())

    mb_crop_binary = raw_mb.remap([19, 36], [1, 1], 0).updateMask(valid_mb_mask)

    is_crop = mb_crop_binary.eq(1).unmask(0)
    is_noncrop = mb_crop_binary.eq(0).updateMask(valid_mb_mask).unmask(0)

    n_crop = is_crop.reduceNeighborhood(ee.Reducer.sum(), kernel)
    n_noncrop = is_noncrop.reduceNeighborhood(ee.Reducer.sum(), kernel)

    # Borda: válida e com pelo menos 1 vizinho válido de classe oposta
    mb_edge = valid_mb_mask.And(
        (is_crop.And(n_noncrop.gte(1))).Or(is_noncrop.And(n_crop.gte(1)))
    ).rename("edge")

    dist_img = (
        mb_edge.fastDistanceTransform(neighborhood=25, units="pixels", metric="squared_euclidean")
        .sqrt()
        .multiply(10)
        .clamp(0, 250)
        .rename("dist_m")
    )

    # Amostragem:
    # 1. Ponto na borda crop/noncrop (y = cy + 80, x = cx)
    # 2. Ponto 1 pixel afastado da borda crop/noncrop (y = cy + 80, x = cx + 10)
    # 3. Ponto no limite crop/excluded (y = cy, x = cx) -> não deve ter noncrop válido adjacente a oeste
    # 4. Ponto dentro do excluded (y = cy, x = cx - 20)
    pts = ee.FeatureCollection([
        ee.Feature(ee.Geometry.Point([cx, cy + 80], "EPSG:5880"), {"desc": "borda crop/noncrop normal"}),
        ee.Feature(ee.Geometry.Point([cx + 10, cy + 80], "EPSG:5880"), {"desc": "1 px dentro do crop"}),
        ee.Feature(ee.Geometry.Point([cx + 20, cy + 80], "EPSG:5880"), {"desc": "2 px dentro do crop"}),
        ee.Feature(ee.Geometry.Point([cx - 20, cy], "EPSG:5880"), {"desc": "dentro do patch excluded (21)"}),
    ])

    res = dist_img.reduceRegions(collection=pts, reducer=ee.Reducer.first(), scale=10, crs="EPSG:5880").getInfo()
    print("=" * 65)
    print("TESTE DE BORDA COM MASCARAMENTO DE EXCLUDED (21 Mosaico):")
    print("=" * 65)
    for f in res["features"]:
        p = f["properties"]
        print(f"  {p['desc']:35s} -> distância = {p['first']:6.2f} m")
    print("=" * 65)


if __name__ == "__main__":
    run_test()
