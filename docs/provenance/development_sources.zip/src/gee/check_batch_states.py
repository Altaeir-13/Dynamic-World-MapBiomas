"""Direct GEE task status audit and reconciliation."""
import ee
import os
import pandas as pd

PROJECT_ID = 'dynamicworld-x-mapbiomas'
ee.Initialize(project=PROJECT_ID)

manifest = pd.read_csv('tables/canonical_w2w_batch_manifest.csv')
tasks_df = pd.read_csv('tables/canonical_w2w_batch_tasks.csv')
batch_dir = 'data/processed/batches'

print("=" * 110)
print("DIRECT GEE AUDIT OF ALL BATCH TASKS")
print("=" * 110)

results = []
for _, row in tasks_df.iterrows():
    b_id = str(row['batch_id']).strip()
    t_id = str(row['task_id']).strip()
    csv_name = f"{b_id}_10m.csv"
    csv_path = os.path.join(batch_dir, csv_name)
    csv_exists = os.path.exists(csv_path)
    
    # expected slices from manifest
    expected_slices = len(manifest[manifest['batch_id'] == b_id])
    
    # local slices
    n_slices_local = 0
    if csv_exists:
        try:
            df_local = pd.read_csv(csv_path)
            n_slices_local = df_local['slice_id'].nunique()
        except Exception as e:
            n_slices_local = f"ERR: {e}"
            
    # GEE query
    gee_state = 'UNKNOWN'
    start_time = '-'
    update_time = '-'
    error_msg = '-'
    try:
        op = ee.data.getOperation(f"projects/{PROJECT_ID}/operations/{t_id}")
        meta = op.get('metadata', {})
        gee_state = meta.get('state', 'UNKNOWN')
        start_time = meta.get('startTime', '-')
        update_time = meta.get('updateTime', '-')
        if 'error' in op:
            error_msg = op['error'].get('message', 'error')
    except Exception as e:
        gee_state = f"QUERY_ERROR: {e}"
        
    results.append({
        'batch_id': b_id,
        'task_id': t_id,
        'gee_state': gee_state,
        'start_time': start_time,
        'update_time': update_time,
        'error_msg': error_msg,
        'csv_exists': csv_exists,
        'n_expected': expected_slices,
        'n_local': n_slices_local
    })

res_df = pd.DataFrame(results)
for _, r in res_df.iterrows():
    print(f"{r['batch_id']:25} | {r['task_id']:25} | {r['gee_state']:10} | exp:{r['n_expected']:2} | loc:{r['n_local']} | csv:{str(r['csv_exists']):5} | err:{r['error_msg'][:35]}")

print("=" * 110)
print(f"Total batches in tasks: {len(res_df)}")
print(f"Total SUCCEEDED: {len(res_df[res_df['gee_state'] == 'SUCCEEDED'])}")
print(f"Total FAILED: {len(res_df[res_df['gee_state'] == 'FAILED'])}")
print(f"Total RUNNING/PENDING: {len(res_df[res_df['gee_state'].isin(['RUNNING', 'PENDING', 'READY'])])}")
print("=" * 110)
