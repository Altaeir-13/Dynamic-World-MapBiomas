import ee

ee.Initialize(project="dynamicworld-x-mapbiomas")

# Create a small dummy feature collection
fc = ee.FeatureCollection([
    ee.Feature(ee.Geometry.Point([-45.0, -10.0]), {"id": 1, "test": "ok"})
])

task = ee.batch.Export.table.toDrive(
    collection=fc,
    description="test_export_check",
    fileFormat="CSV"
)
task.start()
print("Export task started! Task ID:", task.id, "Status:", task.status()["state"])
