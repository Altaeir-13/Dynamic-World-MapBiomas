"""Read-only scientific cross-checks and document QA; writes only paper/ QA.

No Earth Engine, sampling, model fitting, or bootstrap execution. The monthly
cache check compares already materialized vectors; it does not generate data.
"""
from pathlib import Path
import sys, csv, json, hashlib, re
from collections import Counter
from docx import Document
from docx.oxml.ns import qn
from pypdf import PdfReader
import pdfplumber
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent.parent
PAPER=ROOT/'paper';QA=PAPER/'qa_final_review'
STEM='manuscript_space_week_nordeste_2026_final_review'
mm=lambda x:x*25.4/72
normalize=lambda x:re.sub(r'\s+','',x)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def audit():
    report={}
    manifest=list(csv.DictReader((ROOT/'tables/manuscript_results_manifest.csv').open(encoding='utf-8-sig')))
    failures=[r['relative_path'] for r in manifest if sha(ROOT/r['relative_path'])!=r['sha256']]
    before=json.loads((QA/'protected_before.json').read_text(encoding='utf-8'))
    changed=[p for p,h in before.items() if not (ROOT/p).is_file() or sha(ROOT/p)!=h]
    report['preservation']={'manifest_artifacts':len(manifest),'manifest_failures':failures,'protected_files':len(before),'changed_protected_files':changed}
    assert not failures and not changed
    doc=Document(PAPER/(STEM+'.docx'));reader=PdfReader(PAPER/(STEM+'.pdf'))
    dxtext=''.join(doc.element.body.xpath('.//w:t/text()'))
    pdtext=''.join(p.extract_text() for p in reader.pages)
    report['docx_pdf_text_equal_ignoring_whitespace']=normalize(dxtext)==normalize(pdtext)
    assert report['docx_pdf_text_equal_ignoring_whitespace']
    report['pages']=len(reader.pages);assert len(reader.pages)<=5
    report['pdf_metadata']=dict(reader.metadata)
    fonts={}
    for pg in reader.pages:
        for ref in pg['/Resources']['/Font'].get_object().values():
            f=ref.get_object();df=f['/DescendantFonts'][0].get_object() if '/DescendantFonts' in f else f
            descriptor=df.get('/FontDescriptor')
            embedded=bool(descriptor and any(k in descriptor.get_object() for k in ['/FontFile','/FontFile2','/FontFile3']))
            fonts[str(f['/BaseFont'])]={'embedded':embedded,'subtype':str(f['/Subtype'])}
    report['pdf_fonts']=fonts
    assert all('TimesNewRoman' in f and info['embedded'] for f,info in fonts.items())
    pages=[];font_sizes=Counter();tables=[]
    with pdfplumber.open(PAPER/(STEM+'.pdf')) as pdf:
        for i,pg in enumerate(pdf.pages):
            chars=[c for c in pg.chars if c['text'].strip()]
            font_sizes.update((c['fontname'],round(c['size'],2)) for c in pg.chars)
            bad=[c for c in chars if mm(c['x0'])<18.85 or mm(c['x1'])>197.15 or mm(c['top'])<24.85 or mm(c['bottom'])>254.15]
            imgs=[]
            for im in pg.images:
                dpi=[im['srcsize'][0]/im['width']*72,im['srcsize'][1]/im['height']*72]
                imgs.append({'dimensions_px':im['srcsize'],'width_mm':mm(im['width']),'height_mm':mm(im['height']),'dpi':dpi})
                assert min(dpi)>299
            entry={'page':i+1,'dimensions_mm':[mm(pg.width),mm(pg.height)],'text_bounds_mm':[mm(min(c['x0'] for c in chars)),mm(min(c['top'] for c in chars)),mm(max(c['x1'] for c in chars)),mm(max(c['bottom'] for c in chars))],'out_of_print_area':len(bad),'images':imgs}
            if i==4:
                entry['column_bottoms_mm']=[mm(max(c['bottom'] for c in chars if c['x0']<300)),mm(max(c['bottom'] for c in chars if c['x0']>300))]
            pages.append(entry)
            assert not bad
            for t in pg.find_tables():
                contents=t.extract()
                tables.append({'page':i+1,'rows':len(contents),'columns':len(contents[0]),'bbox_mm':[mm(v) for v in t.bbox],'width_mm':mm(t.bbox[2]-t.bbox[0])})
                assert mm(t.bbox[0])>=18.85 and mm(t.bbox[2])<=197.15
        report['title_glyph_top_mm']=mm(pdf.pages[0].chars[0]['top'])
    report['page_layout']=pages
    report['pdf_font_size_counts']=[{'font':font,'points':size,'characters':count} for (font,size),count in sorted(font_sizes.items())]
    assert set(size for font,size in font_sizes)=={9.,10.,14.}
    report['pdf_tables']=tables
    assert [(t['page'],t['rows'],t['columns']) for t in tables]==[(3,10,5),(4,12,4)]
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    assert all(r.font.size.pt==10 and r.font.name=='Times New Roman' for r in p.runs if r.text)
    report['docx_sections']=[{'page_mm':[s.page_width.mm,s.page_height.mm],'margins_mm':[s.top_margin.mm,s.right_margin.mm,s.bottom_margin.mm,s.left_margin.mm],'columns':s._sectPr.find(qn('w:cols')).get(qn('w:num')),'column_gap_twips':s._sectPr.find(qn('w:cols')).get(qn('w:space'))} for s in doc.sections]
    assert not doc.element.body.xpath('.//w:fldSimple | .//w:instrText')
    report['page_number_fields']=0
    paragraphs=[''.join(p._p.xpath('.//w:t/text()')) for p in doc.paragraphs]
    refs=[p for p in paragraphs if re.match(r'^\[\d+\]',p)]
    occurrences=[]
    for p in paragraphs:
        if p.startswith('[1]'):break
        for n in re.findall(r'\[(\d+)\]',p):
            if n not in occurrences:occurrences.append(n)
    report['references']={'count':len(refs),'first_citation_order':occurrences}
    assert occurrences==[str(x) for x in range(1,9)] and len(refs)==8
    report['abstract_word_counts']={}
    for label in ['RESUMO','ABSTRACT']:
        idx=paragraphs.index(label);n=len(paragraphs[idx+1].split());report['abstract_word_counts'][label]=n;assert 150<=n<=200
    report['cross_references']={label:sum(label in p for p in paragraphs) for label in ['Figura 1','Figura 2','Tabela 1','Tabela 2']}
    assert all(n>=2 for n in report['cross_references'].values())
    # CSV lexical protection matters: NA is an actual regime code, not missing.
    cols=['sample_id','main_sample','regime','n_valid_months','selection_probability_main','design_weight_main','design_weight_robust','area_weight_main','entropy_annual','jsd_temporal','stability','distance_edge_min_m','annual_class_index','dw_crop']
    bands=['water','trees','grass','flooded_vegetation','crops','shrub_and_scrub','built','bare','snow_and_ice']
    data=pd.read_csv(ROOT/'data/processed/samples_annual.csv',keep_default_na=False,usecols=cols+['p_'+b for b in bands])
    for c in data.columns:
        if c not in ['sample_id','regime']:data[c]=pd.to_numeric(data[c],errors='coerce')
    main=data[data.main_sample==1];disc=main.regime.isin(['AN','NA'])
    report['sample_validation']={'main_n':len(main),'robust_n':len(data),'min_valid_months':int(data.n_valid_months.min()),'positive_main_weights':bool((main.design_weight_main>0).all()),'pixel_disagreement_pct':float(100*main.loc[disc,'design_weight_main'].sum()/main.design_weight_main.sum()),'area_disagreement_pct':float(100*main.loc[disc,'area_weight_main'].sum()/main.area_weight_main.sum())}
    assert len(main)==20000 and len(data)==40000 and data.n_valid_months.min()==8
    h4checks=[]
    for f,wname in [(main,'design_weight_main'),(data,'design_weight_robust')]:
        def quant(c,q):
            x=f.sort_values(c);cum=x[wname].cumsum();return float(x.iloc[np.searchsorted(cum,q*cum.iloc[-1])][c])
        h,j,s=quant('entropy_annual',.25),quant('jsd_temporal',.25),quant('stability',.75)
        d=f.regime.isin(['AN','NA']);flag=d&(f.entropy_annual<=h)&(f.jsd_temporal<=j)&(f.stability>=s)&(f.distance_edge_min_m>=30)
        h4checks.append({'n':len(f),'discordant_n':int(d.sum()),'h4_n':int(flag.sum()),'weighted_pct':float(100*f.loc[flag,wname].sum()/f.loc[d,wname].sum()),'q1_H':h,'q1_JSD':j,'q3_S':s})
    report['h4_validation']=h4checks
    assert [h['h4_n'] for h in h4checks]==[207,404]
    # Independent comparison of materialized corrected monthly cache to annual
    # vectors. No recomputation of research metrics or modification of data.
    cached=ROOT/'data/processed/extraction_slices_bilinear'
    by_id=data.set_index('sample_id');diffs=[];arg_div=0;crop_div=0;count=0
    for path in sorted(cached.glob('*.json')):
        for props in json.loads(path.read_text(encoding='utf-8')):
            sid=props['sample_id'];vectors=[]
            for month in range(1,13):
                vec=np.array([float(props.get(f'{b}_m{month:02d}',0.0)) for b in bands]);total=vec.sum()
                if int(props.get(f'n_days_m{month:02d}',0))>0 and total>0.01:vectors.append(vec/total)
            if not vectors:raise ValueError('No valid cached months')
            avg=np.mean(vectors,axis=0);avg/=avg.sum();ann=by_id.loc[sid,['p_'+b for b in bands]].to_numpy(dtype=float)
            diffs.append(float(np.mean(np.abs(avg-ann))))
            arg_div+=int(np.argmax(avg)!=int(by_id.loc[sid,'annual_class_index']))
            crop_div+=int((np.argmax(avg)==4)!=bool(by_id.loc[sid,'dw_crop']));count+=1
    report['residual_support_validation']={'cached_points':count,'mean_absolute_difference':float(np.mean(diffs)),'argmax_divergent_n':arg_div,'argmax_divergent_pct':100*arg_div/count,'crop_divergent_n':crop_div,'crop_divergent_pct':100*crop_div/count}
    assert count==40000 and arg_div==3296 and crop_div==1035
    assert abs(np.mean(diffs)-.004983)<.000001
    report['deliverable_sha256']={STEM+ext:sha(PAPER/(STEM+ext)) for ext in ['.docx','.pdf','.md']}
    (QA/'final_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['pages','docx_pdf_text_equal_ignoring_whitespace','abstract_word_counts','preservation','sample_validation','h4_validation','residual_support_validation']},ensure_ascii=False,indent=2))

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');audit()
