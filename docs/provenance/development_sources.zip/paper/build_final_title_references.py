"""Targeted title/citation edits to the geometry-approved editable master.
No experiments, model fitting, data generation or dataset modifications.
"""
from pathlib import Path
from collections import Counter
import sys, re, json, hashlib, shutil
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import build_author_review as renderer

PAPER=Path(__file__).resolve().parent
QA=PAPER/'qa_final_references'
SOURCE='manuscript_space_week_nordeste_2026_author_review_corrected'
STEM='manuscript_space_week_nordeste_2026_final_title_references'
TITLE='ANÁLISE ESPACIAL E PROBABILÍSTICA DA DISCORDÂNCIA NO MAPEAMENTO DE LAVOURAS DO MATOPIBA: DYNAMIC WORLD E MAPBIOMAS'

def text(p):return ''.join(p._p.xpath('.//w:t/text()'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def replace_markup(p,value,size=10,bold=False):
    for el in list(p._p):
        if not el.tag.endswith('}pPr'):p._p.remove(el)
    for part in re.split(r'(\*[^*]+\*)',value):
        if not part:continue
        marked=part.startswith('*') and part.endswith('*') and len(part)>2
        r=p.add_run(part[1:-1] if marked else part)
        r.font.name='Times New Roman';r.font.size=Pt(size)
        r.font.bold=bold;r.font.italic=marked;r.font.color.rgb=RGBColor(0,0,0)
        fonts=r._r.get_or_add_rPr().rFonts
        from docx.oxml.ns import qn
        for k in ['ascii','hAnsi','eastAsia','cs']:fonts.set(qn('w:'+k),'Times New Roman')

def build():
    QA.mkdir(exist_ok=True)
    before={SOURCE+ext:sha(PAPER/(SOURCE+ext)) for ext in ['.docx','.pdf']}
    d=Document(PAPER/(SOURCE+'.docx'));old=Document(PAPER/(SOURCE+'.docx'))
    edits=[]
    p=d.paragraphs[0];edits.append({'kind':'title','before':text(p),'after':TITLE})
    replace_markup(p,TITLE,14,True);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    d.core_properties.title=TITLE
    d.core_properties.author='Randerson Sousa de Sá Nunes'
    d.core_properties.last_modified_by='Randerson Sousa de Sá Nunes'
    for p in d.paragraphs[1:]:
        previous=text(p);value=None;reason=None
        if previous=='3. RESULTADOS':
            # Prevent a heading alone at the end of the methods page when the
            # complete following table must move to the next page.
            p.paragraph_format.page_break_before=True
        if previous=='5. CONCLUSÕES':
            # Keep the conclusion heading with its complete paragraph.
            p.paragraph_format.keep_with_next=True
        if previous.startswith('Em 2025, os produtos discordam '):
            p.paragraph_format.keep_together=True
        if previous.startswith('A expansão de lavouras no Cerrado '):
            value=previous.replace('A expansão de lavouras no Cerrado e no MATOPIBA demanda monitoramento territorial [1].','A expansão de lavouras no Cerrado e no MATOPIBA foi documentada [1] e motiva o monitoramento territorial.')
            value=value.replace('Ambos utilizam imagens Sentinel-2, portanto não constituem fontes plenamente independentes.','Ambos utilizam imagens Sentinel-2 [2,3] e compartilham parte da base observacional.')
            value=value.replace('Dynamic World','*Dynamic World*')
            reason='Cite expansion itself; source common sensor explicitly, without implying quantified error dependence.'
        elif previous.startswith('No MapBiomas, o crosswalk '):
            value=previous.replace('lavoura temporária e perene.','lavoura temporária e perene [3].').replace('crops (índice 4).','crops (índice 4) [2].')
            value=value.replace('crosswalk','*crosswalk*').replace('crops','*crops*')
            reason='Put verified product/legend references next to the terminology; binary mapping choices remain original.'
        elif previous.startswith('Observações DW do mesmo dia '):
            value='Neste estudo, '+previous[0].lower()+previous[1:]
            value=value.replace('argmax','*argmax*')
            reason='Explicitly mark the daily/monthly/annual aggregation as this project’s processing, not the producer’s native annual product.'
        elif previous.startswith('A seleção aleatória sem reposição utiliza '):
            value=previous.replace('A seleção aleatória sem reposição utiliza ','A seleção aleatória sem reposição [7] utiliza ').replace('da célula a [7].','da célula a.')
            reason='Reference probability-sampling principles; do not attribute the project’s 410 substrata and nested probabilities to Olofsson.'
        elif previous.startswith('A inferência utiliza spatial block bootstrap '):
            value=previous.replace('A inferência utiliza spatial block bootstrap [8],','A inferência usa uma adaptação espacial do *bootstrap* em blocos para observações dependentes [8],')
            reason='Künsch establishes blocks for stationary dependent sequences, not direct validation of this spatial grid.'
        elif previous.startswith('A discordância censitária soma '):
            value=previous.replace('A decomposição em área resulta em','A decomposição em área [4] resulta, neste censo, em').replace('de alocação [4].','de alocação.')
            reason='Reference the quantity/allocation method before the original census values, avoiding source misattribution.'
        if value is not None:
            replace_markup(p,value)
            edits.append({'kind':'citation_scope','before':previous,'after':text(p),'reason':reason})
    assert len(edits)==7
    table_values=lambda doc:[[[c.text for c in row.cells] for row in t.rows] for t in doc.tables]
    assert table_values(d)==table_values(old)
    def no_refs_numbers(doc):
        paragraphs=[]
        for p in doc.paragraphs[1:]:
            if text(p)=='6. REFERÊNCIAS':break
            paragraphs.append(re.sub(r'\[\d+(?:\s*,\s*\d+)*\]','',text(p)))
        return re.findall(r'\d+(?:[.,]\d+)*',' '.join(paragraphs))
    assert no_refs_numbers(d)==no_refs_numbers(old),'Experimental numbers/order changed'
    references=lambda doc:[text(p) for p in doc.paragraphs if re.match(r'^\[\d+\]',text(p))]
    assert references(d)==references(old),'Bibliographic entries changed without authorization'
    old_map={e['before']:e['after'] for e in edits}
    assert [old_map.get(text(p),text(p)) for p in old.paragraphs]==[text(p) for p in d.paragraphs]
    d.save(PAPER/(STEM+'.docx'))
    assert all(sha(PAPER/n)==h for n,h in before.items())
    checks={'preserved_source_files':before,'scientific_results_preserved':True,'scientific_body_and_table_values_verbatim':False,'table_values_verbatim':True,'experimental_numbers_verbatim':True,'references_verbatim':True,'author_confirmed_by_user':True,'caption_changes':{},'editorial_changes':edits}
    (QA/'build_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    # Editable-master text companion is derived from the actual document nodes.
    from docx.oxml.ns import qn
    lines=[]
    for el in d.element.body:
        if el.tag==qn('w:p'):
            value=''.join(el.xpath('.//w:t/text()'))
            if value:lines.extend([value,''])
        elif el.tag==qn('w:tbl'):
            for row in el.xpath('./w:tr'):
                lines.append('| '+' | '.join(''.join(c.xpath('.//w:t/text()')) for c in row.xpath('./w:tc'))+' |')
            lines.append('')
    (PAPER/(STEM+'.md')).write_text('\n'.join(lines),encoding='utf-8')
    print('Definitive title and targeted citation edits saved. Experimental numbers and bibliography entries unchanged.')

def render():
    renderer.STEM=STEM;renderer.QA=QA;renderer.render()

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    if '--export-only' in sys.argv:render()
    else:
        build()
        if '--render' in sys.argv:render()
