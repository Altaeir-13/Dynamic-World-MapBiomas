"""Editorial build only. Reads frozen CSVs; never runs experimental code.

Use the bundled Codex Python runtime. DOCX is the editable master; the PDF is
exported by render_docx.py with native LibreOffice on Windows.
"""
from pathlib import Path
import csv, hashlib, json, re, shutil, subprocess, os, sys
from collections import defaultdict
from docx import Document
from docx.shared import Mm, Pt, RGBColor
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
PAPER = ROOT / 'paper'
QA = PAPER / 'qa_final_review'
ASSETS = PAPER / 'final_review_assets'
STEM = 'manuscript_space_week_nordeste_2026_final_review'
RUNTIME = Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies'
SKILL = Path.home()/'.codex/plugins/cache/openai-primary-runtime/documents/26.1011.11113/skills/documents'
MB_URL = 'https://brasil.mapbiomas.org/iniciativas-e-produtos/cobertura-e-uso-da-terra/cobertura-10m/cobertura/'

def rows(name):
    with (ROOT/'tables'/name).open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))

def fmt(x, digits=4):
    return f'{float(x):,.{digits}f}'.replace(',', '_').replace('.', ',').replace('_', '.')

def snapshot():
    QA.mkdir(parents=True,exist_ok=True)
    target=QA/'protected_before.json'
    if not target.exists():
        files=[]
        for directory in ['tables','figures','data','config','src','docs','tables_legacy_raw','figures_legacy_raw']:
            files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file())
        files.extend(p for p in PAPER.glob('*') if p.is_file() and 'final' not in p.name and p.name != Path(__file__).name)
        files.extend([ROOT/'PROJECT_BRIEF.md', ROOT/'normas_trabalhos_cientificos_swn_2026.pdf', ROOT/'instrucoes2_autores_swn_2026.pdf'])
        target.write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2),encoding='utf-8')

def chart_font(bold=False):
    return ImageFont.truetype(str(Path('C:/Windows/Fonts')/('timesbd.ttf' if bold else 'times.ttf')),round(10*300/72))

def chart_text(draw,xy,text,bold=False,anchor=None):
    draw.text(xy,text,font=chart_font(bold),fill='#111111',anchor=anchor)

def charts():
    """Draw publication copies from tabulated statistics, without recalculation."""
    ASSETS.mkdir(exist_ok=True)
    rp=rows('descriptive_regime_proportions.csv')[:4]
    sp={r['state']:float(r['pct_within_state']) for r in rows('descriptive_state_proportions.csv') if r['regime']=='Total Discordância'}
    im=Image.new('RGB',(round(178/25.4*300),round(63/25.4*300)),'white');d=ImageDraw.Draw(im)
    colors=['#2e8b75','#bd6718','#7771b1','#365e80']
    for panel,(labels,vals,title,maxval) in enumerate([
        ([r['regime'] for r in rp],[float(r['weighted_pct']) for r in rp],'A. Regimes na amostra (%)',100),
        (['MA','TO','PI','BA'],[sp[x] for x in ['MA','TO','PI','BA']],'B. Discordância por estado (%)',30)]):
        off=panel*1080
        chart_text(d,(off+500,12),title,True,'mt')
        left,top,right,bottom=off+110,105,off+990,620
        for y in ([0,20,40,60,80,100] if panel==0 else [0,10,20,30]):
            yy=bottom-(bottom-top)*y/maxval
            d.line((left,yy,right,yy),fill='#dddddd',width=2)
            chart_text(d,(left-18,yy),str(y),anchor='rm')
        d.line((left,top,left,bottom,right,bottom),fill='#222222',width=3)
        for i,(lab,val) in enumerate(zip(labels,vals)):
            xx=left+110+i*220;yy=bottom-(bottom-top)*val/maxval
            d.rectangle((xx-57,yy,xx+57,bottom),fill=colors[i] if panel==0 else '#365e80',outline='#111111',width=2)
            chart_text(d,(xx,yy-9),fmt(val,2),True,'mb')
            chart_text(d,(xx,bottom+15),lab,anchor='mt')
    im.save(ASSETS/'figure1.png',dpi=(300,300))
    hb=rows('hypothesis_h3_distance_bins.csv'); sb=rows('spatial_bootstrap_distance_bins.csv')
    im=Image.new('RGB',(round(86/25.4*300),round(71/25.4*300)),'white');d=ImageDraw.Draw(im)
    chart_text(d,(12,6),'Discordância por faixa (%)',True)
    left,right,top,bottom=265,965,100,685
    for v in [0,20,40,60]:
        xx=left+(right-left)*v/60
        d.line((xx,top,xx,bottom),fill='#dddddd',width=2)
        chart_text(d,(xx,bottom+15),str(v),anchor='mt')
    for i,(h,b) in enumerate(zip(hb,sb)):
        yy=top+40+i*96
        label=['0-10','10-30','30-60','60-100','100-250','≥250'][i]
        chart_text(d,(left-25,yy),label,anchor='rm')
        x=lambda v:left+(right-left)*float(v)/60
        lo,hi=x(b['ci95_spatial_lower']),x(b['ci95_spatial_upper'])
        val=x(h['disagreement_pct'])
        d.line((lo,yy,hi,yy),fill='#111111',width=5)
        for xx in [lo,hi]:d.line((xx,yy-13,xx,yy+13),fill='#111111',width=4)
        d.ellipse((val-9,yy-9,val+9,yy+9),fill='#365e80')
    chart_text(d,(12,im.height-48),'Distância à borda (m)',anchor=None)
    im.save(ASSETS/'figure2.png',dpi=(300,300))

def configure_section(sec, columns=2):
    # Official model PDF has a US Letter MediaBox (612 x 792 pt).
    # Explicit print area governs margins; no logo is mandated in normative text.
    sec.page_width=Mm(215.9);sec.page_height=Mm(279.4)
    sec.left_margin=Mm(19);sec.right_margin=Mm(18.9)
    sec.top_margin=Mm(25);sec.bottom_margin=Mm(25.4)
    sec.header_distance=Mm(0);sec.footer_distance=Mm(0)
    cols=sec._sectPr.find(qn('w:cols'))
    if cols is None:cols=OxmlElement('w:cols');sec._sectPr.append(cols)
    cols.set(qn('w:num'),str(columns));cols.set(qn('w:space'),'340')
    cols.set(qn('w:equalWidth'),'1')

def set_font(run,size=10,bold=False,italic=False):
    run.font.name='Times New Roman';run.font.size=Pt(size)
    run.font.bold=bold;run.font.italic=italic;run.font.color.rgb=RGBColor(0,0,0)
    rf=run._r.get_or_add_rPr().rFonts
    for key in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+key),'Times New Roman')

def add_markup(p,text,size=10,bold=False,italic=False):
    for part in re.split(r'(\*[^*]+\*)',text):
        if part:
            marked=part.startswith('*') and part.endswith('*') and len(part)>2
            r=p.add_run(part[1:-1] if marked else part);set_font(r,size,bold,italic or marked)

def para(doc,text='',indent=False,italic=False,keep=False,align=WD_ALIGN_PARAGRAPH.JUSTIFY):
    p=doc.add_paragraph();p.alignment=align
    pf=p.paragraph_format;pf.space_before=Pt(0);pf.space_after=Pt(2)
    pf.line_spacing=1.0;pf.first_line_indent=Mm(6.3 if indent else 0)
    pf.widow_control=True;pf.keep_with_next=keep
    add_markup(p,text,italic=italic)
    return p

def heading(doc,text,level=1,italic=False):
    p=doc.add_paragraph(style='Heading '+str(level));p.alignment=WD_ALIGN_PARAGRAPH.CENTER if level==1 else WD_ALIGN_PARAGRAPH.LEFT
    pf=p.paragraph_format;pf.space_before=Pt(11.5 if level==1 else 6);pf.space_after=Pt(11.5 if level==1 else 3)
    pf.keep_with_next=True;pf.line_spacing=1.0;pf.first_line_indent=Mm(0)
    add_markup(p,text,bold=True,italic=italic)
    return p

def caption(doc,text):
    p=doc.add_paragraph(style='Caption');p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    pf=p.paragraph_format;pf.space_before=Pt(3);pf.space_after=Pt(5);pf.line_spacing=1.0
    pf.keep_together=True;pf.keep_with_next=False
    add_markup(p,text,9,True)

def image(doc,name,width,description):
    p=para(doc,keep=True,align=WD_ALIGN_PARAGRAPH.CENTER)
    run=p.add_run();set_font(run)
    shape=run.add_picture(str(ASSETS/name),width=Mm(width))
    shape._inline.docPr.set('descr',description)

def new_section(doc,cols=2,new_page=False):
    sec=doc.add_section(WD_SECTION_START.NEW_PAGE if new_page else WD_SECTION_START.CONTINUOUS)
    configure_section(sec,cols)
    # Section separator contains no content and must not add a visible blank line.
    p=doc.paragraphs[-1];p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0)
    p.paragraph_format.line_spacing=Pt(1);set_font(p.add_run(),10)
    return sec

def table(doc,data,widths):
    t=doc.add_table(rows=0,cols=len(widths));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    for col,width in zip(t.columns,widths):col.width=Mm(width)
    pr=t._tbl.tblPr
    w=pr.find(qn('w:tblW'));w.set(qn('w:w'),str(round(sum(widths)/25.4*1440)));w.set(qn('w:type'),'dxa')
    borders=OxmlElement('w:tblBorders')
    for edge in ['top','bottom','left','right','insideH','insideV']:
        e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
    pr.append(borders)
    for ri,row in enumerate(data):
        cells=t.add_row().cells
        trpr=t.rows[-1]._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
        if ri==0:trpr.append(OxmlElement('w:tblHeader'))
        for ci,(cell,val,width) in enumerate(zip(cells,row,widths)):
            cell.width=Mm(width);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=cell._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
            for edge,size in [('top',45),('bottom',45),('left',65),('right',65)]:
                el=OxmlElement('w:'+edge);el.set(qn('w:w'),str(size));el.set(qn('w:type'),'dxa');mar.append(el)
            cp.append(mar)
            if ri==0:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'EEEEEE');cp.append(sh)
            p=cell.paragraphs[0];p.alignment=WD_ALIGN_PARAGRAPH.LEFT if ci==0 else WD_ALIGN_PARAGRAPH.CENTER
            pf=p.paragraph_format;pf.space_before=Pt(0);pf.space_after=Pt(0);pf.line_spacing=1.0
            pf.keep_with_next=ri<len(data)-1;pf.keep_together=True
            add_markup(p,str(val),10,bold=ri==0)
    return t

RESUMO = (
    'Este estudo caracteriza a discordância de lavouras entre *Dynamic World* V1 e MapBiomas Cobertura 10 m, Coleção 4, em 2025, no MATOPIBA. '
    'Compararam-se produtos cartográficos sem referência de campo independente, em uma população elegível de 52,34 milhões de hectares com pelo menos oito meses válidos. '
    'O censo foi complementado por amostras probabilísticas estratificadas de 20.000 e 40.000 pontos, ponderadas pelas probabilidades de inclusão. '
    'A discordância censitária foi de 14,2852% por área e 14,3110% por pixels. '
    'Com reamostragem espacial em blocos de 30 km e 1.999 réplicas, as células discordantes apresentaram maior entropia anual normalizada (ΔH = +0,0162), '
    'maior divergência Jensen-Shannon temporal (ΔJSD = +0,0075) e menor estabilidade categórica relativa à classe anual (ΔS = -0,0790). '
    'A proporção amostral ponderada de discordância em distâncias inferiores a 30 m foi 3,87 vezes a observada a pelo menos 250 m. '
    'Os critérios conjuntos de baixa ambiguidade, baixa heterogeneidade temporal, alta estabilidade e afastamento das bordas selecionaram 207 casos na amostra principal, equivalentes a 4,2773% dos pixels discordantes estimados. '
    'Os padrões descrevem associações observacionais e não determinam qual produto está correto.'
)
ABSTRACT = (
    'This study characterizes cropland disagreement between Dynamic World V1 and MapBiomas 10 m land cover, Collection 4, for 2025 in MATOPIBA, Brazil. '
    'The comparison covers 52.34 million eligible hectares with at least eight valid months and uses no independent field reference. '
    'A wall-to-wall census was complemented by stratified probability samples of 20,000 and 40,000 points, weighted by inverse inclusion probabilities. '
    'Census disagreement was 14.2852% by area and 14.3110% by pixels. '
    'Spatial block bootstrap inference with 30 km blocks and 1,999 replicates indicated higher normalized annual entropy (ΔH = +0.0162), '
    'higher temporal Jensen-Shannon divergence (ΔJSD = +0.0075), and lower categorical stability relative to the annual class (ΔS = -0.0790) in disagreeing cells. '
    'Weighted sample disagreement below 30 m from thematic edges was 3.87 times that observed at distances of at least 250 m. '
    'Joint criteria of low ambiguity, low temporal heterogeneity, high stability, and edge separation selected 207 cases in the main sample, representing 4.2773% of estimated disagreeing pixels. '
    'These observational associations neither establish causal mechanisms nor identify which product is correct.'
)

def build():
    snapshot();charts()
    doc=Document();configure_section(doc.sections[0],1)
    doc.core_properties.title='Discordância de lavouras entre Dynamic World e MapBiomas no MATOPIBA em 2025'
    doc.core_properties.author='';doc.core_properties.last_modified_by='';doc.core_properties.comments=''
    for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
        st=doc.styles[name];st.font.name='Times New Roman';st.font.size=Pt(10);st.font.color.rgb=RGBColor(0,0,0)
        st.paragraph_format.line_spacing=1.0
    # The bundled default template includes a decorative Title border.
    # Remove it from every style; the event model has no rule below the title.
    for st in doc.styles:
        for border in list(st.element.xpath('.//w:pBdr')):
            border.getparent().remove(border)
    title=doc.add_paragraph(style='Title');title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before=Mm(10);title.paragraph_format.space_after=Pt(5);title.paragraph_format.line_spacing=1.0
    set_font(title.add_run('DISCORDÂNCIA DE LAVOURAS ENTRE DYNAMIC WORLD E MAPBIOMAS NO MATOPIBA EM 2025'),14,True)
    p=para(doc,'[Nome do Primeiro Autor]¹*, [Nome do Segundo Autor]², [Nome do Terceiro Autor]³ e [Nome do Último Autor]⁴',align=WD_ALIGN_PARAGRAPH.CENTER)
    for r in p.runs:r.bold=True
    for n in range(1,5):
        para(doc,f'{"¹²³⁴"[n-1]} [Instituição do Autor {n}] - [Sigla/Depto], [Cidade] - [UF], Brasil; [email.autor{n}@instituicao.edu.br]',align=WD_ALIGN_PARAGRAPH.CENTER)
    para(doc,'*Autor correspondente: [email.autor1@instituicao.edu.br]',align=WD_ALIGN_PARAGRAPH.CENTER)
    new_section(doc)
    heading(doc,'RESUMO');para(doc,RESUMO)
    para(doc,'Palavras-chave - *Dynamic World*; MapBiomas; MATOPIBA; discordância temática; estabilidade temporal.',italic=False)
    heading(doc,'ABSTRACT',italic=True);para(doc,ABSTRACT,italic=True)
    para(doc,'Key words - Dynamic World; MapBiomas; MATOPIBA; thematic disagreement; temporal stability.',italic=True)
    heading(doc,'1. INTRODUÇÃO')
    para(doc,'A expansão de lavouras no Cerrado e no MATOPIBA demanda monitoramento territorial [1]. *Dynamic World* (DW) V1 produz nove probabilidades de cobertura por observação Sentinel-2 [2]; MapBiomas Cobertura 10 m, Coleção 4, disponibiliza mapas anuais [3]. Diferenças de legenda, agregação temporal e suporte espacial podem gerar discordância entre esses produtos. Ambos utilizam imagens Sentinel-2, portanto não constituem fontes plenamente independentes.')
    para(doc,'Sem referência de campo independente, concordância não prova correção e discordância não identifica erro de um produto. Adota-se uma comparação simétrica dos regimes temáticos e da discordância de quantidade e alocação [4]. O objetivo é caracterizar onde os produtos discordam sobre lavouras em 2025 e como essa discordância se associa a indicadores do DW e à proximidade de bordas.',indent=True)
    para(doc,'Avaliam-se quatro hipóteses operacionais: H1, maior entropia anual nas células discordantes; H2, maior divergência probabilística temporal (H2a) e menor estabilidade categórica (H2b); H3, maior proporção de discordância próxima às bordas que no interior; e H4, existência de discordâncias que satisfazem conjuntamente baixa ambiguidade, baixa heterogeneidade temporal, alta estabilidade e distância de pelo menos 30 m às bordas.',indent=True)

    new_section(doc,new_page=True)
    heading(doc,'2. MATERIAL E MÉTODOS')
    heading(doc,'2.1. Domínio e produtos',2)
    para(doc,'O domínio operacional compreende os 337 municípios do MATOPIBA, nos estados MA, TO, PI e BA, conforme a geometria congelada. A população elegível contém 5.354.669.418 células de resolução nominal de 10 m e 52.342.114,75 ha. Exige-se classificação válida nos dois produtos e pelo menos oito meses válidos de DW em 2025; meses ausentes não são imputados.')
    para(doc,'No MapBiomas, o *crosswalk* principal define lavoura pelas classes {19,36}, lavoura temporária e perene. As classes 21 (mosaico de usos) e 18 (agricultura agregada, caso presente), códigos desconhecidos e ausência de dados são excluídos; as demais classes válidas integram não-lavoura. No DW, lavoura corresponde a *crops* (índice 4). A comparação ocorre na grade nativa MapBiomas (EPSG:4326, escala nominal de 10 m), com probabilidades DW interpoladas bilinearmente e categorias MapBiomas preservadas. Operações métricas de distância e blocos utilizam EPSG:5880.',indent=True)
    heading(doc,'2.2. Agregação e indicadores',2)
    para(doc,'Observações DW do mesmo dia são compostas por média neutra; as médias diárias formam as médias mensais. O vetor anual atribui igual peso aos meses válidos. A classe anual é o *argmax* das nove probabilidades após alinhamento e normalização, e não o modo das classes mensais. O vetor anual canônico define os regimes e a entropia H; a série mensal harmonizada define JSD e S.')
    para(doc,'Para um vetor unitário p, a entropia normalizada de Shannon [5] é H(p) = -Σ p(k) ln p(k) / ln 9, com k = 1,...,9 e 0 ln 0 = 0. A JSD temporal generalizada [6] é JSD = H(pmed) - (1/M)Σ H(p(m)), em que pmed é a média dos vetores mensais e M é o número de meses válidos. A normalização é por ln 9, não por ln M. A estabilidade é S = (1/M)Σ I[c(m) = c(anual)], isto é, a fração dos meses cujo *argmax* coincide com a classe anual canônica. S mede persistência dessa decisão anual e não a frequência do modo mensal.',indent=True)
    para(doc,'A distância d é o mínimo das distâncias euclidianas às bordas das máscaras binárias lavoura/não-lavoura do DW e do MapBiomas. Consideram-se transições entre vizinhos de conectividade oito, excluindo células mascaradas. O cálculo é truncado em 250 m: a categoria ≥250 m reúne distâncias iguais ou superiores a esse limite. Bordas temáticas raster não representam limites cadastrais de parcelas.',indent=True)
    heading(doc,'2.3. Amostragem e inferência',2)
    para(doc,'A seleção aleatória sem reposição utiliza 16 estratos científicos (estado × regime) e 410 subestratos operacionais ativos (hs). A amostra de 40.000 pontos tem π(40k,hs) = n(40k,hs)/N(hs), com n ≥ 1; a amostra principal de 20.000 é aninhada, selecionada por ordenação determinística dentro de cada estrato científico, com probabilidade marginal π(20k) = 0,5π(40k). Pesos de desenho w = 1/π expandem pixels; pesos a/π expandem a área da célula a [7]. Os contrastes, a regressão e H4 usam pesos de desenho; percentuais de área são identificados separadamente.')
    para(doc,'AA significa lavoura nos dois produtos; AN, lavoura apenas no MapBiomas; NA, lavoura apenas no DW; e NN, não-lavoura nos dois. A discordância D vale 1 em AN ou NA e 0 em AA ou NN. O censo territorial fornece proporções sem erro amostral da população elegível.',indent=True)
    para(doc,'A inferência utiliza *spatial block bootstrap* [8], com blocos de 30 × 30 km, 1.999 réplicas e semente 25. O semivariograma exponencial de D estimou alcance prático de 25,62 km, arredondado ao múltiplo superior de 5 km. Os intervalos espaciais de 95% são percentis 2,5 e 97,5 das réplicas de blocos inteiros, sem fixar as margens dos estratos; representam variabilidade sob reamostragem espacial e não erro amostral do censo.',indent=True)
    para(doc,'O modelo logístico ponderado ajusta D por H, JSD, S, distância linear d e estado (BA como referência). Os *odds ratios* (OR) expressam razões de chances, não razões de probabilidades. H4 exige D = 1, H ≤ Q1(H), JSD ≤ Q1(JSD), S ≥ Q3(S) e d ≥ 30 m; os quartis são ponderados pelo desenho e calculados separadamente em cada amostra.',indent=True)
    new_section(doc,2)  # Balance the methods columns before starting results.

    new_section(doc,1,new_page=True)
    # Results heading remains in the column flow preceding the full-width table.
    new_section(doc,2)
    heading(doc,'3. RESULTADOS')
    para(doc,'A discordância censitária soma 7.477.177,23 ha (14,2852% da área elegível) e 766.304.630 pixels (14,3110%). A Tabela 1 distingue esses parâmetros dos percentuais amostrais ponderados por pixels. A estimativa de área da amostra principal é 7.479.568,87 ha e 14,2897%; a proximidade com o censo decorre também da estratificação por regime, não de validação independente. A decomposição em área resulta em 4,99 pontos percentuais de discordância de quantidade e 9,30 de alocação [4].')
    new_section(doc,1)
    frame=rows('sampling_frame_10m.csv');totalA=sum(float(x['A_hs']) for x in frame);totalN=sum(int(x['N_hs_exact']) for x in frame)
    rp={r['regime']:r for r in rows('descriptive_regime_proportions.csv')}
    sp={r['state']:r for r in rows('descriptive_state_proportions.csv') if r['regime']=='Total Discordância'}
    data=[['Regime / estado','Área censitária\n(ha)','Censo área\n(%)','Censo pixels\n(%)','Amostra 20k\npixels (%)']]
    for reg in ['AA','AN','NA','NN','D']:
        sub=[x for x in frame if x['regime']==reg or (reg=='D' and x['regime'] in ['AN','NA'])]
        a=sum(float(x['A_hs']) for x in sub);n=sum(int(x['N_hs_exact']) for x in sub)
        data.append([reg if reg!='D' else 'D = AN + NA',fmt(a,2),fmt(a/totalA*100),fmt(n/totalN*100),fmt(rp[reg if reg!='D' else 'Total Discordância (AN+NA)']['weighted_pct'])])
    for state in ['MA','TO','PI','BA']:
        sub=[x for x in frame if x['state']==state];ds=[x for x in sub if x['regime'] in ['AN','NA']]
        a=sum(float(x['A_hs']) for x in ds);n=sum(int(x['N_hs_exact']) for x in ds)
        data.append([f'{state} (D)',fmt(a,2),fmt(a/sum(float(x['A_hs']) for x in sub)*100),fmt(n/sum(int(x['N_hs_exact']) for x in sub)*100),fmt(sp[state]['pct_within_state'])])
    table(doc,data,[38,42,32,32,34])
    caption(doc,'Tabela 1. Regimes e discordância por estado em 2025. Censo: soma dos subestratos do quadro elegível. Amostra: proporção ponderada por 1/π. Linhas estaduais usam o respectivo domínio elegível como denominador; não são aplicados IC amostrais ao censo.')
    image(doc,'figure1.png',178,'Regimes e discordância estadual na amostra principal, em percentuais ponderados por pixels.')
    caption(doc,'Figura 1. Amostra principal: (A) proporções de pixels AA, AN, NA e NN; (B) proporção de discordância por estado. Pesos de desenho 1/π. Valores amostrais, sem interpretação de acurácia ou de omissão de um produto.')
    new_section(doc,2)
    para(doc,'A Figura 1 resume as estimativas amostrais por regime e estado. No censo por área, BA apresenta 27,9214% de discordância, PI 21,8114%, MA 10,9703% e TO 5,9059%. O predomínio de NN caracteriza o domínio territorial elegível, que inclui áreas de não-lavoura.')
    para(doc,'Os contrastes H1–H3 e os OR ajustados são apresentados na Tabela 2. H1 e H2 mostram maior H e JSD e menor S nas células discordantes; seus intervalos espaciais excluem zero. Em H3, a proporção é 45,91% para d < 30 m e 11,87% para d ≥ 250 m, com razão 3,87. A Figura 2 apresenta os intervalos por faixa e evidencia a ausência de monotonicidade estrita: 30-60 m tem 45,77%, frente a 44,59% em 10-30 m.',indent=True)
    para(doc,'H4 seleciona 207 de 5.143 pontos discordantes na amostra principal (4,0249% bruto; 4,2773% ponderado por pixels) e 404 de 10.286 na amostra de 40.000 (3,9277% bruto; 4,1687% ponderado). Os indicadores de ambiguidade e estabilidade pertencem exclusivamente ao DW. Esses casos não constituem erros confirmados.',indent=True)

    new_section(doc,1,new_page=True)
    hc=rows('hypothesis_h1_results.csv')+rows('hypothesis_h2_results.csv');bc=rows('spatial_bootstrap_contrasts.csv')
    data=[['Contraste / termo','Escala','Estimativa','IC espacial 95%']]
    for i,(label,h) in enumerate(zip(['H1: ΔH','H2a: ΔJSD','H2b: ΔS'],hc)):
        val=float(h['mean_diff']);low=float(bc[i]['ci95_spatial_lower']);high=float(bc[i]['ci95_spatial_upper'])
        signed=lambda x:('+' if x>0 else '-')+fmt(abs(x))
        data.append([label,'D = 1 menos D = 0',signed(val),f'[{signed(low)}; {signed(high)}]'])
    data.append(['H3: borda / interior','<30 m / ≥250 m','3,87','Por faixa: Figura 2'])
    rg={r['term']:r for r in rows('regression_logistic_rescaled_odds_ratios.csv')}
    for term,label,scale in [('distance_edge_min_m','OR: distância','+100 m'),('entropy_annual','OR: entropia H','+0,10'),('stability','OR: estabilidade S','+0,10'),('jsd_temporal','OR: JSD temporal','+0,01'),('state_PI','OR: PI / BA','BA: referência'),('state_MA','OR: MA / BA','BA: referência'),('state_TO','OR: TO / BA','BA: referência')]:
        r=rg[term];lo,hi=json.loads(r['ci95_spatial_scaled'])
        data.append([label,scale,fmt(r['odds_ratio_scaled'],3),f'[{fmt(lo,3)}; {fmt(hi,3)}]'])
    table(doc,data,[54,45,29,50])
    caption(doc,'Tabela 2. Contrastes ponderados H1–H3 e regressão logística multivariada. IC percentis do *bootstrap* espacial (30 km; 1.999 réplicas). H3 apresenta razão pontual; IC por faixa na Figura 2. OR ajustados por H, JSD, S, d linear e estado.')
    new_section(doc,2)
    image(doc,'figure2.png',86,'Proporções pontuais ponderadas de discordância nas seis faixas de distância e intervalos espaciais de 95%.')
    caption(doc,'Figura 2. H3: pontos são proporções ponderadas por 1/π; barras são IC de 95% do bootstrap espacial. Faixas [a,b), em metros; ≥250 reúne distâncias truncadas. A borda é a mais próxima entre DW e MapBiomas.')
    para(doc,'A regressão associa distância e S inversamente à discordância, e H positivamente (Tabela 2). O IC da JSD inclui 1; essa imprecisão da associação ajustada não estabelece mediação causal nem ausência de utilidade preditiva. Para PI/BA, o IC analítico é [0,709; 0,900], mas o espacial é [0,507; 1,212]. Incluir 1 não demonstra igualdade entre os estados.')
    para(doc,'Na amostra de 40.000, os contrastes mantêm os sinais: ΔH = +0,0167, ΔJSD = +0,0071 e ΔS = -0,0774. A discordância ponderada por pixels é 14,2782% sob o *crosswalk* estrito {19} e 12,1255% no subconjunto MapBiomas estável de 2017-2025 (17.957 pontos). Este último restringe a população analisada; não substitui o resultado territorial principal.',indent=True)
    heading(doc,'4. DISCUSSÃO')
    para(doc,'A associação com bordas é compatível com diferenças de suporte e mistura espectral; a associação temporal admite hipóteses ligadas à sazonalidade e às decisões dos classificadores. O desenho observacional não identifica esses mecanismos. Não foram medidos calendário agrícola, fenologia ou limites de parcelas, e o indicador S também depende da agregação vetorial anual. Não se pode atribuir o restante das discordâncias a causas explicadas pelos filtros de H4.')
    para(doc,'Há uma limitação de suporte temporal residual: a média mensal harmonizada difere do vetor anual canônico. A comparação dos dois suportes nos 40.000 pontos registra diferença absoluta média de 0,004983 nas probabilidades, mudança de *argmax* em 8,24% e inversão lavoura/não-lavoura em 2,59%. A ordem da agregação e da interpolação com máscaras variáveis pode produzir essa diferença. Os indicadores temporais e a classe anual têm essas definições distintas; os resíduos não são prova de mudança no terreno.',indent=True)
    para(doc,'A elegibilidade de pelo menos oito meses restringe a inferência às células observáveis e não autoriza extrapolação às áreas excluídas. O censo não tem erro amostral, mas continua sujeito às limitações dos produtos e do processamento. Os intervalos do bootstrap dependem da representação espacial e da escolha de blocos. H4 delimita casos para eventual validação independente, sem transferir probabilidades ou confiança do DW ao MapBiomas.',indent=True)
    new_section(doc,2)
    new_section(doc,2,new_page=True)
    heading(doc,'5. CONCLUSÕES')
    para(doc,'Em 2025, os produtos discordam sobre lavouras em 14,2852% da área elegível do MATOPIBA. As discordâncias associam-se a maior ambiguidade e heterogeneidade temporal do DW, menor persistência categórica e maior proximidade de bordas. H4 identifica 207 e 404 casos nas amostras principal e robusta, sob critérios relativos a cada distribuição. A análise caracteriza a divergência cartográfica sem atribuir superioridade de acurácia, causalidade ou correção a qualquer produto.')
    heading(doc,'6. REFERÊNCIAS')
    refs=[
        '[1] S. A. Spera et al. *Land-use change affects water recycling in Brazil’s last agricultural frontier. Global Change Biology*, 22(10):3405-3413, 2016. DOI: 10.1111/gcb.13298.',
        '[2] C. F. Brown et al. *Dynamic World, Near real-time global 10 m land use land cover mapping. Scientific Data*, 9:251, 2022. DOI: 10.1038/s41597-022-01307-4.',
        '[3] MapBiomas. Cobertura 10 m, Coleção 4, série 2017-2025. Documentação e acesso aos dados. Acesso em 12 out. 2026.',
        '[4] R. G. Pontius Jr. e M. Millones. *Death to Kappa: birth of quantity disagreement and allocation disagreement for accuracy assessment. International Journal of Remote Sensing*, 32(15):4407-4429, 2011. DOI: 10.1080/01431161.2011.552923.',
        '[5] C. E. Shannon. *A mathematical theory of communication. Bell System Technical Journal*, 27(3):379-423, 1948. DOI: 10.1002/j.1538-7305.1948.tb01338.x.',
        '[6] J. Lin. *Divergence measures based on the Shannon entropy. IEEE Transactions on Information Theory*, 37(1):145-151, 1991. DOI: 10.1109/18.61115.',
        '[7] P. Olofsson et al. *Good practices for estimating area and assessing accuracy of land change. Remote Sensing of Environment*, 148:42-57, 2014. DOI: 10.1016/j.rse.2014.02.015.',
        '[8] H. R. Künsch. *The jackknife and the bootstrap for general stationary observations. Annals of Statistics*, 17(3):1217-1241, 1989. DOI: 10.1214/aos/1176347265.'
    ]
    for i,text in enumerate(refs):
        p=para(doc,text);p.paragraph_format.keep_together=True
        p.paragraph_format.left_indent=Mm(4);p.paragraph_format.first_line_indent=Mm(-4)
        if i==2:
            # URL is preserved as a clickable bibliography entry, without an
            # unbroken 130-character string forcing the narrow column wider.
            for r in list(p.runs):p._p.remove(r._r)
            before,after=text.split('Documentação e acesso aos dados.')
            add_markup(p,before)
            link=OxmlElement('w:hyperlink');link.set(qn('r:id'),p.part.relate_to(MB_URL,RT.HYPERLINK,is_external=True))
            r=OxmlElement('w:r');pr=OxmlElement('w:rPr')
            ff=OxmlElement('w:rFonts');ff.set(qn('w:ascii'),'Times New Roman');ff.set(qn('w:hAnsi'),'Times New Roman');pr.append(ff)
            sz=OxmlElement('w:sz');sz.set(qn('w:val'),'20');pr.append(sz);r.append(pr)
            txt=OxmlElement('w:t');txt.text='Documentação e acesso aos dados.';r.append(txt);link.append(r);p._p.append(link)
            add_markup(p,after)
    new_section(doc,2)  # Balance the final page, as requested by the model.
    doc.save(PAPER/(STEM+'.docx'))
    # Text companion derives from DOCX nodes, in actual document order.
    lines=[]
    for child in doc.element.body:
        if child.tag==qn('w:p'):
            value=''.join(child.xpath('.//w:t/text()'))
            if value:lines.extend([value,''])
        elif child.tag==qn('w:tbl'):
            for row in child.xpath('./w:tr'):
                lines.append('| '+' | '.join(''.join(c.xpath('.//w:t/text()')).replace('\n',' / ') for c in row.xpath('./w:tc'))+' |')
            lines.append('')
    (PAPER/(STEM+'.md')).write_text('\n'.join(lines),encoding='utf-8')
    print('Abstract word counts',len(RESUMO.replace('*','').split()),len(ABSTRACT.split()))
    print('Saved DOCX master',PAPER/(STEM+'.docx'))

def render():
    temp=QA/'temp';temp.mkdir(exist_ok=True)
    env=os.environ.copy();env['TMP']=str(temp);env['TEMP']=str(temp)
    env['PATH']=';'.join([r'C:\Program Files\LibreOffice\program',str(RUNTIME/'native/poppler/Library/bin'),env.get('PATH','')])
    env['PYTHONIOENCODING']='utf-8'
    subprocess.run([str(RUNTIME/'python/python.exe'),str(SKILL/'render_docx.py'),str(PAPER/(STEM+'.docx')),'--output_dir',str(QA/'final_docx'),'--emit_pdf','--verbose'],check=True,env=env)
    shutil.copyfile(QA/'final_docx'/(STEM+'.pdf'),PAPER/(STEM+'.pdf'))
    print('PDF exported from DOCX only',PAPER/(STEM+'.pdf'))

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    build()
    if '--render' in sys.argv:render()
