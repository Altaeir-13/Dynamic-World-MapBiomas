"""Edit the existing final_review DOCX; do not read or run scientific code.

Preserves every scientific paragraph, table, image, and reference verbatim.
Writes only author_review files and QA in paper/. PDF comes from this DOCX.
"""
from pathlib import Path
from copy import deepcopy
import os, sys, json, re, hashlib, subprocess, shutil
from docx import Document
from docx.shared import Pt, RGBColor, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent.parent
PAPER=ROOT/'paper';QA=PAPER/'qa_geometry_review'
SOURCE='manuscript_space_week_nordeste_2026_final_review'
AUTHOR_REVIEW_INPUT='manuscript_space_week_nordeste_2026_author_review'
STEM='manuscript_space_week_nordeste_2026_author_review_corrected'
AUTHOR='Randerson Sousa de Sá Nunes'
EMAIL='randerson.sdsn@gmail.com'
RUNTIME=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies'
SKILL=Path.home()/'.codex/plugins/cache/openai-primary-runtime/documents/26.1011.11113/skills/documents'

def text(el):return ''.join(el.xpath('.//w:t/text()'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cols(sp):return sp.find(qn('w:cols')).get(qn('w:num'))

def align_graphics(d):
    """Set explicit geometry, without resizing or replacing image content."""
    count=0
    for p in d.paragraphs:
        if p._p.xpath('.//w:drawing'):
            pf=p.paragraph_format
            pf.left_indent=Pt(0);pf.right_indent=Pt(0);pf.first_line_indent=Pt(0)
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT
            for inline in p._p.xpath('.//wp:inline'):
                for side in ['distT','distB','distL','distR']:inline.set(side,'0')
            count+=len(p._p.xpath('.//w:drawing'))
    return count

def inset_table_borders(d):
    """Leave room for painted border strokes inside the 178 mm print area."""
    target=round(177.6/25.4*1440)
    for t in d.tables:
        original=[int(c.get(qn('w:w'))) for c in t._tbl.tblGrid]
        widths=[round(v*target/sum(original)) for v in original]
        widths[-1]+=target-sum(widths)
        for c,w in zip(t._tbl.tblGrid,widths):c.set(qn('w:w'),str(w))
        for row in t.rows:
            for cell,w in zip(row.cells,widths):cell.width=Twips(w)
        total=t._tbl.tblPr.find(qn('w:tblW'))
        total.set(qn('w:w'),str(target));total.set(qn('w:type'),'dxa')

def fix_geometry():
    """Correct a copy of the current author_review master; preserve it."""
    QA.mkdir(exist_ok=True)
    before={AUTHOR_REVIEW_INPUT+ext:digest(PAPER/(AUTHOR_REVIEW_INPUT+ext)) for ext in ['.docx','.pdf']}
    d=Document(PAPER/(AUTHOR_REVIEW_INPUT+'.docx'))
    original_text=text(d.element.body)
    original_images={str(v.partname):digest_bytes(v.blob) for v in d.part.related_parts.values() if '/media/' in str(v.partname)}
    original_sizes=[(s.width,s.height) for s in d.inline_shapes]
    assert align_graphics(d)==2
    inset_table_borders(d)
    assert original_text==text(d.element.body)
    assert original_sizes==[(s.width,s.height) for s in d.inline_shapes]
    assert original_images=={str(v.partname):digest_bytes(v.blob) for v in d.part.related_parts.values() if '/media/' in str(v.partname)}
    d.save(PAPER/(STEM+'.docx'))
    checks=json.loads((PAPER/'qa_author_review/build_checks.json').read_text(encoding='utf-8'))
    checks['preserved_source_files'].update(before)
    checks['geometry_only_edit']={'all_text_unchanged':True,'image_bytes_unchanged':True,'image_dimensions_unchanged':True,'graphic_paragraphs':'left alignment; left, right and first-line indents explicitly zero','tables':'177.6 mm centered width to keep painted border strokes inside the print area'}
    (QA/'build_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
    for name,h in before.items():assert digest(PAPER/name)==h
    print('Corrected copy saved; previous author_review master and PDF preserved.')

def replace(p,value,bold=False):
    for el in list(p._p):
        if el.tag!=qn('w:pPr'):p._p.remove(el)
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    pf=p.paragraph_format;pf.line_spacing=1.0;pf.space_before=Pt(0);pf.space_after=Pt(2)
    pf.keep_with_next=True;pf.first_line_indent=Pt(0)
    r=p.add_run(value);r.font.name='Times New Roman';r.font.size=Pt(10)
    r.font.bold=bold;r.font.italic=False;r.font.color.rgb=RGBColor(0,0,0)
    rf=r._r.get_or_add_rPr().rFonts
    for x in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+x),'Times New Roman')

def separator(sp,columns):
    p=OxmlElement('w:p');pr=OxmlElement('w:pPr');p.append(pr)
    spacing=OxmlElement('w:spacing')
    spacing.set(qn('w:before'),'0');spacing.set(qn('w:after'),'0')
    spacing.set(qn('w:line'),'20');spacing.set(qn('w:lineRule'),'exact');pr.append(spacing)
    sec=deepcopy(sp)
    typ=sec.find(qn('w:type'))
    if typ is None:typ=OxmlElement('w:type');sec.insert(0,typ)
    typ.set(qn('w:val'),'continuous')
    sec.find(qn('w:cols')).set(qn('w:num'),str(columns));pr.append(sec)
    return p

def build():
    QA.mkdir(exist_ok=True)
    before={SOURCE+ext:digest(PAPER/(SOURCE+ext)) for ext in ['.docx','.pdf','.md']}
    (QA/'source_hashes.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
    d=Document(PAPER/(SOURCE+'.docx'))
    source_scientific=[text(e) for e in list(d.element.body)[8:] if text(e)]
    source_media={k:digest_bytes(v.blob) for k,v in d.part.related_parts.items() if '/media/' in str(v.partname)}
    base1=deepcopy(d.sections[0]._sectPr);base2=deepcopy(d.sections[1]._sectPr)
    p=d.paragraphs
    replace(p[1],AUTHOR,True)
    replace(p[2],'Instituto Federal de Educação, Ciência e Tecnologia do Maranhão (IFMA) - Campus Caxias')
    replace(p[3],'Bacharelado em Ciência da Computação - Caxias - MA, Brasil')
    replace(p[6],EMAIL)
    for old in [p[4],p[5]]:old._p.getparent().remove(old._p)
    d.core_properties.author=AUTHOR;d.core_properties.last_modified_by=AUTHOR
    d.core_properties.comments='';d.core_properties.subject='Space Week Nordeste 2026'
    # The model prescribes single line spacing and first-line indents. Extra
    # paragraph-after spacing is optional and need not consume column height.
    caption_changes={}
    for p in d.paragraphs:
        value=text(p._p)
        if value.startswith('Tabela 1. '):
            new='Tabela 1. Regimes e discordância por estado em 2025. Censo: quadro elegível. Amostra: proporções ponderadas por 1/π. Linhas estaduais usam o domínio elegível de cada estado como denominador; censo sem IC amostral.'
            caption_changes[value]=new
            for r in list(p.runs):p._p.remove(r._r)
            r=p.add_run(new);r.font.name='Times New Roman';r.font.size=Pt(9);r.bold=True
        if p.style.name=='Caption':p.paragraph_format.space_after=Pt(3)
        elif value and p.style.name=='Normal' and p.alignment==WD_ALIGN_PARAGRAPH.JUSTIFY:
            p.paragraph_format.space_after=Pt(0)
    # Remove only empty separators; inline images and all scientific nodes stay.
    content=[]
    for e in list(d.element.body):
        if e.tag==qn('w:sectPr'):continue
        if e.tag==qn('w:p'):
            for sp in list(e.xpath('./w:pPr/w:sectPr')):sp.getparent().remove(sp)
            if not text(e) and not e.xpath('.//w:drawing'):continue
        content.append(e)
    # Put the census explanation immediately after Table 1. This lets the whole
    # table occupy the end of the methods page, without reducing its typography.
    lead=next(e for e in content if text(e).startswith('A discordância censitária soma '))
    content.remove(lead)
    cap1=next(i for i,e in enumerate(content) if text(e).startswith('Tabela 1. '))
    content.insert(cap1+1,lead)
    for e in list(d.element.body):d.element.body.remove(e)
    for e in content:
        d.element.body.append(e)
        value=text(e)
        if value==EMAIL:d.element.body.append(separator(base1,1))
        elif value.startswith('O modelo logístico ponderado ajusta '):d.element.body.append(separator(base2,2))
        elif value=='3. RESULTADOS':d.element.body.append(separator(base2,2))
        elif value.startswith('Tabela 1. '):d.element.body.append(separator(base1,1))
        elif value.startswith('A discordância censitária soma '):d.element.body.append(separator(base2,2))
        elif value.startswith('Figura 1. '):d.element.body.append(separator(base1,1))
        elif value.startswith('H4 seleciona '):d.element.body.append(separator(base2,2))
        elif value.startswith('Tabela 2. '):d.element.body.append(separator(base1,1))
    # Ending continuous section balances only the last page of two-column text.
    d.element.body.append(separator(base2,2))
    final=deepcopy(base2);final.find(qn('w:type')).set(qn('w:val'),'continuous')
    d.element.body.append(final)
    # Keep each complete table with its own caption, without chaining figures.
    for t in d.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:p.paragraph_format.keep_with_next=True
                margins=cell._tc.get_or_add_tcPr().find(qn('w:tcMar'))
                for side in ['top','bottom']:
                    margins.find(qn('w:'+side)).set(qn('w:w'),'20')
    align_graphics(d)
    inset_table_borders(d)
    out=PAPER/(STEM+'.docx');d.save(out)
    new_scientific=[];started=False
    for e in d.element.body:
        if text(e)=='RESUMO':started=True
        if started and text(e):new_scientific.append(text(e))
    expected=[caption_changes.get(value,value) for value in source_scientific]
    assert sorted(expected)==sorted(new_scientific),'Scientific content changed beyond the documented caption edit'
    assert source_media=={k:digest_bytes(v.blob) for k,v in d.part.related_parts.items() if '/media/' in str(v.partname)},'Images changed'
    for name,h in before.items():assert digest(PAPER/name)==h
    (QA/'build_checks.json').write_text(json.dumps({'scientific_body_and_table_values_verbatim':True,'caption_changes':caption_changes,'paragraph_repositioned':'Census explanation moved immediately after Table 1','scientific_image_bytes_unchanged':True,'preserved_source_files':before,'author':AUTHOR,'email':EMAIL,'name_and_email_require_confirmation':True},ensure_ascii=False,indent=2),encoding='utf-8')
    print('DOCX saved from current master; scientific body, table values and images preserved; Table 1 caption shortened.')

def digest_bytes(blob):return hashlib.sha256(blob).hexdigest()

def render():
    temp=QA/'temp';temp.mkdir(exist_ok=True)
    env=os.environ.copy();env['TMP']=str(temp);env['TEMP']=str(temp)
    env['PATH']=';'.join([r'C:\Program Files\LibreOffice\program',str(RUNTIME/'native/poppler/Library/bin'),env.get('PATH','')])
    env['PYTHONIOENCODING']='utf-8'
    subprocess.run([str(RUNTIME/'python/python.exe'),str(SKILL/'render_docx.py'),str(PAPER/(STEM+'.docx')),'--output_dir',str(QA/'render'),'--emit_pdf','--verbose'],check=True,env=env)
    shutil.copyfile(QA/'render'/(STEM+'.pdf'),PAPER/(STEM+'.pdf'))
    print('PDF exported from author_review DOCX.')

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    if '--export-only' in sys.argv:
        render()  # Preserve manual edits to the editable author_review master.
    elif '--fix-geometry' in sys.argv:
        fix_geometry()
        if '--render' in sys.argv:render()
    else:
        build()
        if '--render' in sys.argv:render()
