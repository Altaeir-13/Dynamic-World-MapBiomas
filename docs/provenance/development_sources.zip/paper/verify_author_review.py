"""Document-only QA. Does not read datasets or run scientific analyses."""
from pathlib import Path
import sys, re, json, hashlib, zipfile
from collections import Counter
from docx import Document
from docx.oxml.ns import qn
from pypdf import PdfReader
import pdfplumber

PAPER=Path(__file__).resolve().parent
QA=PAPER/'qa_geometry_review'
STEM='manuscript_space_week_nordeste_2026_author_review_corrected'
SOURCE='manuscript_space_week_nordeste_2026_final_review'
AUTHOR='Randerson Sousa de Sá Nunes'
EMAIL='randerson.sdsn@gmail.com'
norm=lambda s:re.sub(r'\s+','',s)
mm=lambda x:x*25.4/72
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
GRAPHICS_TOL_MM=.05  # PDF/twip quantization only, not a layout allowance.

def bbox_mm(obj):return [mm(obj[k]) for k in ['x0','top','x1','bottom']]

def within(box,limit,tol=GRAPHICS_TOL_MM):
    return box[0]>=limit[0]-tol and box[1]>=limit[1]-tol and box[2]<=limit[2]+tol and box[3]<=limit[3]+tol

def drawing_specs(d):
    """Map each DOCX image to its actual section's printable column width."""
    body=list(d.element.body);specs=[]
    for i,e in enumerate(body):
        for drawing in e.xpath('.//w:drawing'):
            section=None
            for following in body[i:]:
                candidates=following.xpath('./w:pPr/w:sectPr')
                if following.tag==qn('w:sectPr'):candidates=[following]
                if candidates:section=candidates[0];break
            assert section is not None
            extent=drawing.xpath('.//wp:extent')[0]
            description=drawing.xpath('.//wp:docPr')[0].get('descr','')
            specs.append({'columns':int(section.find(qn('w:cols')).get(qn('w:num'),'1')),'width_mm':int(extent.get('cx'))/36000,'height_mm':int(extent.get('cy'))/36000,'description':description})
    return specs

def verify():
    d=Document(PAPER/(STEM+'.docx'));old=Document(PAPER/(SOURCE+'.docx'))
    p=PdfReader(PAPER/(STEM+'.pdf'))
    text=''.join(d.element.body.xpath('.//w:t/text()'))
    pdftext=''.join(pg.extract_text() for pg in p.pages)
    result={'pages':len(p.pages),'text_equivalence_ignoring_whitespace':norm(text)==norm(pdftext),'metadata':dict(p.metadata)}
    assert 1<=result['pages']<=5 and result['text_equivalence_ignoring_whitespace']
    assert p.metadata['/Author']==AUTHOR and d.core_properties.author==AUTHOR
    assert d.core_properties.last_modified_by==AUTHOR
    assert text.count(AUTHOR)==1 and text.count(EMAIL)==1
    assert '[Nome do' not in text and '[Instituição do' not in text and '[email.autor' not in text
    assert not re.search('[¹²³⁴]',text)
    result['single_author_and_contact']={'name':AUTHOR,'email':EMAIL,'author_occurrences':1,'contact_occurrences':1,'confirmation_required':True}
    assert len(d.tables)==len(old.tables)==2
    table_text=lambda t:[[c.text for c in row.cells] for row in t.rows]
    assert [table_text(t) for t in d.tables]==[table_text(t) for t in old.tables]
    result['table_values_identical_to_master']=True
    with zipfile.ZipFile(PAPER/(SOURCE+'.docx')) as a,zipfile.ZipFile(PAPER/(STEM+'.docx')) as b:
        media=lambda z:{k:hashlib.sha256(z.read(k)).hexdigest() for k in z.namelist() if k.startswith('word/media/')}
        assert media(a)==media(b);result['image_bytes_identical_to_master']=True
    checks=json.loads((QA/'build_checks.json').read_text(encoding='utf-8'))
    for name,h in checks['preserved_source_files'].items():assert sha(PAPER/name)==h
    result['source_files_preserved']=checks['preserved_source_files']
    result['scientific_content_preserved']=checks['scientific_body_and_table_values_verbatim']
    result['caption_changes']=checks['caption_changes']
    fonts={}
    for pg in p.pages:
        for ref in pg['/Resources']['/Font'].get_object().values():
            f=ref.get_object();df=f['/DescendantFonts'][0].get_object() if '/DescendantFonts' in f else f
            desc=df.get('/FontDescriptor');embedded=bool(desc and any(k in desc.get_object() for k in ['/FontFile','/FontFile2','/FontFile3']))
            fonts[str(f['/BaseFont'])]=embedded
    assert all('TimesNewRoman' in f and e for f,e in fonts.items());result['embedded_fonts']=fonts
    sizes=Counter();pages=[];tables=[];graphics=[];specs=drawing_specs(d);image_index=0
    with pdfplumber.open(PAPER/(STEM+'.pdf')) as pdf:
        for i,pg in enumerate(pdf.pages):
            sizes.update((c['fontname'],round(c['size'],2)) for c in pg.chars)
            ink=[c for c in pg.chars if c['text'].strip()]
            bad=[c for c in ink if mm(c['x0'])<18.85 or mm(c['x1'])>197.15 or mm(c['top'])<24.85 or mm(c['bottom'])>254.15]
            assert not bad
            imgs=[]
            for im in pg.images:
                assert image_index<len(specs),'PDF image has no checked DOCX drawing'
                spec=specs[image_index];image_index+=1
                box=bbox_mm(im)
                assert within(box,[19,25,197,254]),f'Image outside print area on page {i+1}: {box}'
                if spec['columns']==2:
                    permitted=[[19,25,105,254],[111,25,197,254]]
                    assert any(within(box,limit) for limit in permitted),f'Image crosses its column on page {i+1}: {box}'
                else:
                    permitted=[[19,25,197,254]]
                dpi=[im['srcsize'][0]*72/im['width'],im['srcsize'][1]*72/im['height']]
                assert min(dpi)>299
                assert abs(mm(im['width'])-spec['width_mm'])<.05
                entry={'figure':image_index,'page':i+1,'bbox_mm':box,'permitted_bbox_mm':permitted,'section_columns':spec['columns'],'width_mm':mm(im['width']),'height_mm':mm(im['height']),'pixels':im['srcsize'],'dpi':dpi}
                imgs.append(entry);graphics.append(entry)
            # Include vector objects such as table borders, fills and paths.
            vector_checks={}
            for kind in ['lines','rects','curves']:
                objects=getattr(pg,kind)
                for obj in objects:
                    box=bbox_mm(obj)
                    assert within(box,[19,25,197,254]),f'{kind} outside print area on page {i+1}: {box}'
                vector_checks[kind]=len(objects)
            bounds=[mm(min(c['x0'] for c in ink)),mm(min(c['top'] for c in ink)),mm(max(c['x1'] for c in ink)),mm(max(c['bottom'] for c in ink))]
            entry={'page':i+1,'dimensions_mm':[mm(pg.width),mm(pg.height)],'ink_bounds_mm':bounds,'unused_bottom_of_print_area_mm':254-bounds[3],'images':imgs,'vector_objects_checked':vector_checks}
            if i==len(pdf.pages)-1:
                entry['column_bottoms_mm']=[mm(max(c['bottom'] for c in ink if c['x0']<300)),mm(max(c['bottom'] for c in ink if c['x0']>300))]
            pages.append(entry)
            for t in pg.find_tables():
                rows=t.extract();tables.append({'page':i+1,'rows':len(rows),'columns':len(rows[0]),'bbox_mm':[mm(v) for v in t.bbox]})
                tc=[c for c in ink if c['x0']>=t.bbox[0] and c['x1']<=t.bbox[2]+.3 and c['top']>=t.bbox[1] and c['bottom']<=t.bbox[3]]
                assert all(round(c['size'],2)==10 for c in tc)
                assert mm(t.bbox[0])>=18.85 and mm(t.bbox[2])<=197.15
    assert [(t['rows'],t['columns']) for t in tables]==[(10,5),(12,4)]
    assert set(sz for f,sz in sizes)=={9,10,14}
    result['font_sizes']=[{'font':f,'pt':s,'characters':n} for (f,s),n in sorted(sizes.items())]
    result['layout']=pages;result['tables']=tables
    result['graphic_object_geometry']=graphics
    result['graphics_quantization_tolerance_mm']=GRAPHICS_TOL_MM
    assert image_index==len(specs)==2,'Not all graphic objects were checked'
    assert len([im for pg in pages for im in pg['images']])==2
    assert len(pages[2]['images'])==1 and len(pages[3]['images'])==1
    sections=[]
    for s in d.sections:
        assert abs(s.page_width.mm-215.9)<.02 and abs(s.page_height.mm-279.4)<.02
        c=s._sectPr.find(qn('w:cols'))
        sections.append({'columns':c.get(qn('w:num')),'gap_twips':c.get(qn('w:space')),'page_mm':[s.page_width.mm,s.page_height.mm],'margins_mm':[s.top_margin.mm,s.right_margin.mm,s.bottom_margin.mm,s.left_margin.mm]})
        assert c.get(qn('w:space'))=='340'
        assert all(abs(a-b)<.02 for a,b in zip([s.top_margin.mm,s.right_margin.mm,s.bottom_margin.mm,s.left_margin.mm],[25,18.9,25.4,19]))
    result['sections']=sections
    assert not d.element.body.xpath('.//w:instrText | .//w:fldSimple')
    paragraphs=[''.join(p._p.xpath('.//w:t/text()')) for p in d.paragraphs]
    counts={label:len(paragraphs[paragraphs.index(label)+1].split()) for label in ['RESUMO','ABSTRACT']}
    assert counts=={'RESUMO':177,'ABSTRACT':171};result['abstract_word_counts']=counts
    refs=[t for t in paragraphs if re.match(r'^\[\d+\]',t)]
    oldrefs=[''.join(p._p.xpath('.//w:t/text()')) for p in old.paragraphs if re.match(r'^\[\d+\]', ''.join(p._p.xpath('.//w:t/text()')))]
    assert refs==oldrefs and len(refs)==8
    citation_order=[]
    for paragraph in paragraphs:
        if paragraph=='6. REFERÊNCIAS':break
        for number in re.findall(r'\[(\d+)\]',paragraph):
            if number not in citation_order:citation_order.append(number)
    assert citation_order==list(map(str,range(1,9)))
    result['first_citation_order']=citation_order
    result['references_verbatim_and_numbered']=True
    result['cross_references']={label:sum(label in t for t in paragraphs) for label in ['Tabela 1','Tabela 2','Figura 1','Figura 2']}
    assert all(n>=2 for n in result['cross_references'].values())
    baseline=[]
    with pdfplumber.open(PAPER/(SOURCE+'.pdf')) as pdf:
        for i,pg in enumerate(pdf.pages):
            ink=[c for c in pg.chars if c['text'].strip()]
            baseline.append({'page':i+1,'ink_bottom_mm':mm(max(c['bottom'] for c in ink)),'unused_bottom_mm':254-mm(max(c['bottom'] for c in ink))})
    result['original_layout_comparison']=baseline
    result['sha256']={STEM+ext:sha(PAPER/(STEM+ext)) for ext in ['.docx','.pdf']}
    (QA/'document_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['pages','text_equivalence_ignoring_whitespace','single_author_and_contact','abstract_word_counts','tables','layout','original_layout_comparison']},ensure_ascii=False,indent=2))

if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8');verify()
