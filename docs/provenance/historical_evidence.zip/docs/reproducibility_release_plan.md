# Plano de Lançamento, Versionamento e Reprodutibilidade Científica
## Estudo: Dynamic World × MapBiomas no MATOPIBA (2025)

---

## 1. Visão Geral e Princípios de Governança

O estudo **Dynamic World × MapBiomas no MATOPIBA (2025)** foi desenvolvido segundo os preceitos de Ciência Aberta e reprodutibilidade estrita. Todos os resultados científicos congelados possuem proveniência garantida por assinaturas digitais SHA-256 e manifestos determinísticos.

Este documento define o **Plano de Versionamento e Lançamento (Release Plan)** necessário para ancorar formalmente o repositório antes da submissão do manuscrito científico, sem comprometer dados sensíveis, sem violar restrições de tamanho do Git e garantindo reprodutibilidade local e remota.

---

## 2. Auditoria e Integridade dos Hashes SHA-256

A integridade dos artefatos do estudo foi auditada e confirmada em duas suítes formais:

### 2.1. Suíte de Resultados do Manuscrito (`tables/manuscript_results_checksums.sha256`)
- **Total de artefatos auditados:** 31 arquivos.
- **Resultado da verificação:** **31 PASSED, 0 FAILED (100% de integridade).**
- Abrangência:
  - 4 tabelas descritivas (`tables/descriptive_*.csv`);
  - 4 tabelas de testes de hipótese H1–H4 (`tables/hypothesis_*.csv`);
  - 4 tabelas de regressão e diagnóstico (`tables/regression_*.csv`);
  - 5 tabelas de incerteza por bootstrap espacial (`tables/spatial_bootstrap_*.csv`, semivariograma e sensibilidade);
  - 4 tabelas de robustez R1–R3 e sumário (`tables/robustness_*.csv`);
  - 6 figuras de alta resolução em PNG (`figures/fig1` a `fig6`);
  - 1 emenda de protocolo congelada (`docs/protocol_amendment_checkpoint_3d.md`);
  - 3 arquivos de delimitação e proveniência territorial (`data/reference/matopiba_boundary.geojson`, `matopiba_municipalities.csv`, `matopiba_states.geojson`).

### 2.2. Suíte de Amostragem e Extração do Checkpoint 3D (`tables/checkpoint_3d_checksums.sha256`)
- **Total de artefatos auditados:** 10 arquivos.
- **Resultado da verificação:** **10 PASSED, 0 FAILED (100% de integridade).**
- Abrangência:
  - `canonical_wall_to_wall_by_slice.csv` (SHA-256: `238ce3ba...`)
  - `wall_to_wall_summary.csv` (SHA-256: `615c5df7...`)
  - `sampling_frame_10m.csv` (SHA-256: `076dd8ae...`)
  - `sampling_quotas.csv` (SHA-256: `ce6682d6...`)
  - `slice_sampling_allocation_final.csv` (SHA-256: `f3433c08...`)
  - `master_sampling_points.csv` (SHA-256: `744a2a2f...`)
  - `pagination_invariance_audit.csv` (SHA-256: `eebf5173...`)
  - `dw_monthly.parquet` (SHA-256: `3ccd200a...`)
  - `samples_annual.parquet` (SHA-256: `66f6d846...`)
  - `samples_annual.csv` (SHA-256: `ee7525ec...`)

---

## 3. Arquitetura de Versionamento Git e Política de Exclusão

### 3.1. Diagnóstico do Repositório Git Atual
Atualmente, o repositório Git local possui apenas 5 commits iniciais datados de 26/09/2026. Todos os módulos analíticos (`src/analysis/`), a quase totalidade dos scripts de processamento (`src/gee/`), configurações (`config/`), documentação (`docs/`), figuras (`figures/`) e tabelas (`tables/`) encontram-se não rastreados (*untracked*).

Para preparar o repositório público e auditável, deve ser estabelecida uma política rigorosa de inclusão e exclusão no `.gitignore`.

### 3.2. Regras de Exclusão e Segurança no `.gitignore`

O arquivo `.gitignore` definitivo deve impedir o commit de:
1. **Credenciais e Segurança:**
   - `credentials*`
   - `.env`
   - `client_secret*.json`
   - Tokens de acesso OAuth do Google Cloud e Earth Engine.
2. **Ambiente e Caches:**
   - `.venv/`
   - `__pycache__/`
   - `.ipynb_checkpoints/`
   - `scratch/` (scripts e diagnósticos temporários)
3. **Arquivos Pesados de Processamento Intermediário:**
   - `data/processed/extraction_slices/*.json` (182 checkpoints JSON brutos da API GEE, totalizando > 100 MB).
   - `data/raw/*`
   - `*.tif`, `*.tiff`
4. **Artefatos Invalidados por Auditoria:**
   - Tabelas históricas sufixadas com `*_INVALID*`, `*_BEFORE_AREA_WEIGHT_PATCH*` e `*_PRE_ZERO_PI_FIX*` (devem ser preservadas em arquivo local ou branch de auditoria histórica, não no release limpo de publicação).

### 3.3. Configuração do `.gitignore` Recomendada

```gitignore
# Ambientes e caches
.venv/
__pycache__/
*.py[cod]
.ipynb_checkpoints/
scratch/

# Segurança e credenciais
.env
credentials*
client_secret*.json
*.token

# Imagens raster pesadas e dados brutos
*.tif
*.tiff
data/raw/
data/processed/extraction_slices/

# Caches de auditoria e desenvolvimento
*.tmp
pixel_area_m2_checkpoint.json
master_sample_canonical_checkpoint.json
pixel_area_m2_canonical_checkpoint.json

# Preservar no Git:
# - data/reference/ (fronteiras operacionais, listas oficiais IBGE)
# - data/processed/*.parquet e *.csv (tabelas mestres)
# - tables/ (todas as tabelas do artigo e manifestos)
# - figures/ (todos os PNGs de publicação)
# - src/ e config/
# - docs/
```

---

## 4. Gestão e Referenciação de Datasets Grandes

Os dois datasets analíticos principais possuem os seguintes tamanhos:
- `data/processed/samples_annual.parquet`: **$4,9 \text{ MB}$** (40.000 pontos, 51 colunas) $\to$ perfeitamente adequado para versionamento direto no Git.
- `data/processed/samples_annual.csv`: **$15,8 \text{ MB}$** $\to$ adequado para Git.
- `data/processed/dw_monthly.parquet`: **$22,4 \text{ MB}$** (480.000 linhas) $\to$ adequado para Git.
- `data/processed/master_sampling_points.csv`: **$6,8 \text{ MB}$** $\to$ adequado para Git.

Como nenhum dos arquivos processados finais excede o limite padrão de $50 \text{ MB}$ do GitHub, **todos os arquivos analíticos congelados podem ser versionados diretamente no repositório Git**, garantindo que qualquer pesquisador possa clonar o repositório e executar 100% da análise estatística imediatamente sem depender de downloads externos.

Para garantia de longo prazo e DOI acadêmico:
- Recomenda-se criar um depósito no **Zenodo** (ou Figshare) contendo o pacote `matopiba_dw_mb_2025_dataset_v1.zip` (com `samples_annual.parquet`, `dw_monthly.parquet`, `master_sampling_points.csv` e `tables/`), citando o DOI no artigo e vinculando ao commit do repositório.

---

## 5. Protocolo de Execução e Reprodutibilidade

O pipeline foi estruturado em dois níveis de reprodutibilidade:

### Nível 1: Reprodutibilidade Local Analítica (Sem Dependência de GEE)
Qualquer avaliador ou pesquisador pode reproduzir todas as tabelas, testes de hipótese, semivariograma, bootstrap espacial, análises de robustez e figuras do artigo em menos de 5 minutos utilizando unicamente a CPU local:

```bash
# 1. Ativar ambiente Python
.venv\Scripts\activate   # Windows
# source .venv/bin/activate # Linux/Mac

# 2. Executar suíte analítica mestre (scripts 02 a 07)
python src/analysis/08_master_h1_h4_runner.py
```

O script mestre executa sequencialmente:
- `02_weighted_descriptive_analysis.py` $\to$ gera `tables/descriptive_*.csv`
- `03_hypothesis_tests_h1_h4.py` $\to$ gera `tables/hypothesis_*.csv`
- `04_weighted_regression_model.py` $\to$ gera `tables/regression_*.csv`
- `05_spatial_block_bootstrap.py` $\to$ gera `tables/spatial_bootstrap_*.csv`
- `06_robustness_analysis.py` $\to$ gera `tables/robustness_*.csv`
- `07_generate_publication_figures.py` $\to$ gera `figures/fig1` a `fig6`

### Nível 2: Reprodutibilidade Completa de Ponta a Ponta (Com Earth Engine)
Exige conta ativa no Google Cloud e permissão de acesso ao Earth Engine com projeto configurado:

1. `python src/gee/02_boundary.py`: gera a geometria operacional dos 337 municípios a partir da malha IBGE 2025.
2. `python src/gee/18_export_canonical_wall_to_wall.py` & `src/gee/submit_canonical_batch_exports.py`: submete as tarefas de exportação do censo wall-to-wall por fatias.
3. `python src/gee/monitor_and_process_batches.py`: agrega os 182 lotes no censo `canonical_wall_to_wall_by_slice.csv`.
4. `python src/gee/19_process_canonical_wall_to_wall.py`: gera quotas, alocação e sumário censitário.
5. `python src/gee/12_audit_zero_pi_and_reallocate.py`: garante piso $n \ge 1$ e cobertura $100\%$.
6. `python src/gee/14_regenerate_master_sample.py`: sorteia os 40.000 pontos (`seed=25`) e extrai `pixel_area_m2`.
7. `python src/gee/11_extract_analytical_dataset.py`: extrai o stack anual e a série mensal Sentinel-2/DW para os 40.000 pontos, gerando `samples_annual.parquet` e `dw_monthly.parquet`.
8. `python src/analysis/08_master_h1_h4_runner.py`: executa a inferência estatística completa.

---

## 6. Procedimento de Lançamento e Congelamento (Git Release)

Quando a autorização humana para commit e tag for concedida, o procedimento recomendado é:

```bash
# 1. Configurar .gitignore limpo
git add .gitignore

# 2. Adicionar arquivos de configuração, código e tabelas congeladas
git add config/
git add src/
git add tables/
git add figures/
git add docs/
git add data/reference/
git add data/processed/samples_annual.parquet
git add data/processed/dw_monthly.parquet
git add data/processed/master_sampling_points.csv
git add data/processed/canonical_wall_to_wall_by_slice.csv
git add data/processed/wall_to_wall_summary.csv

# 3. Commit de congelamento
git commit -m "feat(release): freeze canonical dataset, spatial analysis and publication artifacts (Checkpoints 3D to 4C)"

# 4. Criar tag imutável correspondente ao manuscrito
git tag -a v1.0.0-manuscript -m "Definitive frozen release for Space Week Nordeste 2026 manuscript"
```

---
*Fim do plano de reprodutibilidade e versionamento.*
