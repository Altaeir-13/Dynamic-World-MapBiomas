# Retrospectiva Completa do Experimento — Dynamic World × MapBiomas no MATOPIBA (2025)

> **Status deste documento:** reconstrução retrospectiva, somente leitura. Nenhum experimento foi reexecutado, nenhum dado ou critério congelado foi alterado. Todos os números vêm de tabelas congeladas em `tables/` (31 artefatos com hash em `tables/manuscript_results_manifest.csv` e `tables/manuscript_results_checksums.sha256`, validados no Checkpoint 4C) ou de `data/processed/`.
>
> **Aviso sobre versões anteriores:** uma versão anterior deste arquivo continha erros (arquivos inexistentes, hashes inventados, definições de AN/NA invertidas, critério H4 incorreto, "16 batches"). Ela foi **descartada e substituída**. Onde a evidência não existe, este texto diz "não documentado".
>
> **Convenção de evidência:** `[E: caminho]` = arquivo que sustenta a afirmação. `[NÃO VERIFICADO]` = afirmação sem artefato localizado.

---

## 0. Sumário executivo

- **Pergunta:** em lavouras no MATOPIBA (2025), onde e por que o Dynamic World (DW, V1, 10 m, probabilidades) e o MapBiomas Cobertura 10 m Coleção 4 (MB) discordam sobre "lavoura × não lavoura"?
- **Natureza do estudo:** comparação **simétrica** entre dois produtos. **Não há ground truth.** MB não é verdade de campo. Nenhum classificador foi treinado, ajustado (fine-tuning) ou validado; o único modelo ajustado é uma **regressão logística ponderada** (inferência estatística).
- **Desenho:** wall-to-wall no Earth Engine (GEE) sobre domínio fixo MATOPIBA + 5 km → amostra probabilística estratificada (4 UF × 4 regimes = 16 estratos científicos; 20.000 pontos principais, 40.000 robustos) → extração de indicadores de incerteza do DW e de borda temática → H1–H4 → regressão logística → bootstrap espacial por blocos (30 km, 1.999 réplicas) → robustez.
- **Achados centrais (números congelados):**
  - Discordância geral amostral ponderada ≈ **14,31%** (IC espacial [12,66; 16,01]); censo wall-to-wall: **14,285%** (concordância 85,715%).
  - H1 (entropia anual): ΔH = +0,0162, IC espacial [0,0103; 0,0221] → efeito pequeno-moderado (d = 0,318).
  - H2a (JSD temporal): Δ = +0,0179 [0,0140; 0,0218] (d = 0,529). H2b (estabilidade S): Δ = −0,4179 [−0,4318; −0,4034] (d = −1,609, muito grande).
  - H3 (bordas): discordância 47,51% (0–10 m) → 11,87% (≥250 m); **não estritamente monotônica** (30–60 m > 10–30 m) → **suporte parcial**.
  - H4: **0 observações** satisfazem simultaneamente H≤Q1, JSD≤Q1, S≥Q3 e d≥30 m, entre 5.143 pontos discordantes (20k) e 10.286 (40k). H4 **não é sustentada** como "discordância robusta".
- **Principais limitações reais:** ausência de verdade independente; dependência conceitual/de insumos entre os produtos; 21,7% do domínio fora do critério `n_valid_months ≥ 8` (≈51% do MA); sensibilidades ≥6 meses e 30 m **não executadas**; resultados não ancorados em um commit Git; IC analíticos da regressão são aproximações, não estimadores de desenho completos.
- **Veredito de integridade:** os artefatos científicos congelados são internamente consistentes (Checkpoint 4C = PASS). Há lacunas documentais listadas na §13.

---

## 1. Investigação do repositório (o que foi realmente examinado)

| Fonte | Conteúdo |
|---|---|
| `PROJECT_BRIEF.md` (versão definitiva de 26/09/2026) | Título, RQ, H1–H4, crosswalk, pipeline temporal, regras de amostragem, bootstrap e figuras planejadas |
| `docs/protocol_amendment_checkpoint_3d.md` | Emenda pré-desfecho (07/10/2026): `n_valid_months ≥ 8` congelado; fallback ≥6 anulado como circular |
| `docs/checkpoint_4b_interpretation_audit.md`, `docs/checkpoint_4c_final_consistency.md` | Auditorias de interpretação e consistência |
| `config/experiment.yaml`, `config/sampling_manifest.yaml` | Configuração e manifesto de amostragem (FROZEN_AUTHORIZED, CHECKPOINT_3B) |
| `src/gee/` (≈ 25 scripts numerados 00–21 + `dw_annual.py` + ≈ 25 auxiliares `test_*`/`check_*`) | Pipeline GEE e auditorias |
| `src/analysis/02…08_*.py` | Descritivas, H1–H4, regressão, bootstrap, robustez, figuras, runner |
| `tables/` (42 arquivos), `data/processed/`, `figures/` (6 PNG) | Resultados, auditorias e invalidações preservadas |
| `.git` | 5 commits, todos em 2026-09-26 (init, refactor, 2024→2025, ignore `.agents`, brief definitivo) |

**Fato de proveniência crítico:** o Git só registra o início (brief). `config/`, `docs/`, `src/analysis/`, `tables/`, `figures/` e a maior parte de `src/gee/` estão **não rastreados**. Não existe commit associado aos resultados. A proveniência efetiva é dada por hashes SHA-256 (`tables/checkpoint_3d_checksums.sha256` e `tables/manuscript_results_checksums.sha256`). Isto contraria a intenção do PROJECT_BRIEF §38 e deve ser sanado (commit/tag) antes da submissão — **não foi feito aqui por restrição do pedido**.

---

## 2. Origem e motivação

**Problema.** Mapas de uso e cobertura da terra (LULC) são usados como referência ou como insumo em políticas agrícolas, mas diferem conceitualmente e tecnicamente. DW fornece probabilidades por pixel por observação Sentinel-2 (quase tempo real, classificador treinado globalmente); MB 10 m (Coleção 4) fornece mapas anuais temáticos construídos com treinamento e pós-processamento regionais/temáticos. Entender **onde** e **por que** discordam é pré-requisito para uso conjunto.

**Por que DW × MB.** Dois produtos de 10 m, abertos e acessíveis no GEE, com paradigmas diferentes (probabilístico/contínuo versus temático/anual). O DW expõe incerteza explícita (probabilidades), permitindo testar se a discordância se associa a incerteza interna.

**Por que MATOPIBA.** Fronteira agrícola do Cerrado (MA, TO, PI, BA) com grande contraste de sistemas (soja/algodão/milho em área extensa, mosaicos, pastagem, savana) — cenário em que a distinção lavoura/não lavoura é difícil e relevante. O estudo usa uma **delimitação operacional** de 337 municípios.

**Por que 2025.** O projeto foi originalmente ancorado em 2024 e alterado para 2025 (commit `dfec096`), buscando o ano mais recente disponível com as coleções oficiais. Justificativa científica adicional além disso: [NÃO VERIFICADO] em documento separado.

**Por que lavoura.** Foco em uma classe-alvo evita misturar a confusão entre muitas classes; a lavoura é a classe com maior interesse agronômico e com forte heterogeneidade temporal (fenologia), o que torna plausível a relação discordância × variabilidade temporal.

**Lacuna / contribuição pretendida.** Não apenas "quanto discordam", mas **se a discordância está associada a indicadores intrínsecos de incerteza (entropia, JSD temporal, estabilidade) e à proximidade de bordas temáticas**, com inferência espacialmente correta (bootstrap por blocos) e amostragem probabilística com pesos de desenho. Contribuição metodológica para GeoAI/SR: diagnóstico de discordância com incerteza probabilística de um mapa sem referência externa. **Não é** uma comparação simples de mapas porque: (i) usa indicador probabilístico de cada pixel/ano; (ii) controla a ordem de agregação temporal; (iii) usa amostra probabilística e inferência espacial; (iv) testa e reporta hipóteses pré-registradas, incluindo uma negativa (H4).

**Pergunta de pesquisa e hipóteses** (PROJECT_BRIEF §2–§3):

| Hip. | Enunciado operacional |
|---|---|
| H1 | Pontos discordantes têm maior entropia anual normalizada do DW que concordantes |
| H2 | (a) maior JSD temporal e (b) menor estabilidade categórica temporal S nos discordantes |
| H3 | Discordância aumenta com a proximidade de bordas temáticas |
| H4 | Existem discordâncias "robustas" (baixa incerteza DW + alta estabilidade + longe de bordas), isto é, não explicáveis pelos indicadores acima |

---

## 3. Tecnologias, produtos e dados

| Item | O que é | Função | Limitações |
|---|---|---|---|
| Dynamic World V1 (`GOOGLE/DYNAMICWORLD/V1`) | Classificação LULC global em 10 m por cena Sentinel-2 com 9 probabilidades | Fonte das probabilidades → entropia, JSD, estabilidade, classe anual | Sem agregação anual oficial; sensível a nuvem/sombra/revisita; exige agregação definida pelo estudo |
| MapBiomas Cobertura 10 m, Coleção 4 | Mapa temático anual 10 m (classes MapBiomas) | Referência *comparativa* (não verdade) | Conceitos de classe próprios; pós-processamento temporal; possível dependência de insumos Sentinel-2 comuns |
| Malha municipal IBGE 2025 (Serviço de Dados, `data=2025`, qualidade máxima) + lista MATOPIBA_2021.xls | Delimitação operacional de 337 municípios | Domínio de estudo | Delimitação operacional, não "oficial" estrita |
| Google Earth Engine | Plataforma de análise geoespacial | Todo processamento wall-to-wall e extração | Quotas, *timeouts*, memória; exigiu divisão em lotes |
| Python (`.venv`) | pandas/NumPy/SciPy/statsmodels/GeoPandas etc. | Amostragem, regressão, bootstrap, figuras | Versões em `requirements.txt` (não reproduzidas aqui) |
| Formatos | CSV, Parquet, GeoJSON, YAML, PNG | Tabelas, dataset analítico, fronteiras, configs, figuras | — |
| Git | Versionamento | 5 commits iniciais apenas | Resultados não rastreados |
| Recursos computacionais | [NÃO VERIFICADO] hardware local; GEE em nuvem | — | Sem registro de RAM/CPU nos artefatos |

**Governança de aprendizado de máquina.**
- **Nenhum modelo foi treinado. Nenhum fine-tuning. Nenhum classificador novo.**
- O DW e o MB são **modelos de terceiros previamente treinados**; este projeto apenas consome suas saídas.
- Não há conjuntos de treino/validação/teste no sentido de ML. "Amostra" aqui é **amostra probabilística de pontos para estimação de populações** (survey sampling).
- Procedimentos executados são: testes de implementação, auditorias de QA, inferência estatística descritiva e uma regressão logística de *associação* (não preditiva; sem *holdout*), bootstrap espacial e análises de robustez.

---

## 4. Reconstrução cronológica

Datas: Git (26/09), `experiment.yaml` (27/09), `sampling_manifest.yaml` (29/09), exportações (30/09–07/10), emenda (07/10). Datas de etapas intermediárias sem log próprio são inferidas pela ordem dos artefatos; quando incerto, indicado.

### Fase 0 — Bootstrap e conceito (26/09)
- **Feito:** init do repositório, estrutura de pastas, mudança 2024→2025, brief definitivo (versão do protocolo).
- **Por quê:** congelar o enquadramento (simétrico, sem ground truth) e hipóteses antes de analisar.
- **Evidência:** `.git/logs/HEAD`; `PROJECT_BRIEF.md`.
- **Mantido:** sim.

### Fase 1 — Acesso, identidade e boundary (scripts `00_`, `01_`, `02_boundary.py`)
- **Feito:** teste de identidade/acesso ao GEE e aos assets DW/MB; construção da delimitação a partir da lista oficial e da malha IBGE 2025.
- **Resultado:** 337 municípios (MA 135, TO 139, PI 33, BA 30); `data/reference/matopiba_boundary.geojson` (SHA256 `716df136…`), `matopiba_municipalities.csv` (`a6adf8e6…`).
- **Problema:** discrepância de áreas entre registros: `sampling_manifest.yaml` 73.082.921 ha (geodésica) e 73.777.179 ha (EPSG:5880); `experiment.yaml` lista `area_ha_gee_geodesic` = 73.384.292,58. **Inconsistência documental não resolvida** (não afeta amostragem, que usa raster canônico). `tables/boundary_vs_raster_area_comparison.csv` documenta a comparação fronteira × raster.
- **Mantido:** boundary sim; valor de área do `experiment.yaml` é divergência a corrigir.

### Fase 2 — Protótipo (Checkpoint 1, ≈500 pontos; `02_prototype_pipeline`, `03_audit_prototype`)
- **Feito:** protótipo de ~500 amostras em quatro janelas, auditoria do protótipo (skill `audit-gee-prototype`).
- **Por quê:** validar crosswalk, agregação temporal e viabilidade antes do esforço definitivo.
- **Status:** **exploratório**. Seus números **não** compõem o resultado científico.
- **Evidência:** scripts citados; resultados do protótipo [NÃO VERIFICADO] como tabela congelada atual.

### Fase 3 — Wall-to-wall inicial e quotas (scripts `04_wall_to_wall*`, `05_*`)
- **Feito:** cálculo do censo de regimes AA/AN/NA/NN por fatias (slices de 0,75° por UF → 182), quotas e desenho (mínimo 400 por estrato + proporcional à área).
- **Problema descoberto:** o DW era processado **dentro da geometria de cada slice**, tornando classes anuais dependentes da paginação (ver §10, item 1).
- **Descartado:** `*_SLICE_DEPENDENT_INVALID` (quotas, frame, alocação, manifesto). **Preservados** com sufixo para auditoria.

### Fase 4 — Amostra mestre preliminar e patches (scripts `06`–`10`)
- **Feito:** primeira amostra mestre, auditoria, *patch* de pesos de área, *patch* boundary-vs-raster, manifesto.
- **Problemas:** pesos de área inconsistentes (`*_BEFORE_AREA_WEIGHT_PATCH`); versões `*_PRELIM_INVALID` e `*_DEBUG_INVALID`.
- **Mantido:** apenas a lógica; os artefatos antigos foram invalidados e regerados.

### Fase 5 — Falha de invariância e diagnóstico (scripts `13`, `16`, `17`)
- **Feito:** `13_` diagnosticou identidade das probabilidades anuais (200 pontos, `dw_annual_identity_diagnostic.csv`); `16_` auditou invariância por partição (1.000 pontos; contextos A slice / B slice+0,05° / C estado / D MATOPIBA; `dw_partition_invariance_audit.csv`); `17_` testou convergência de domínio (suportes +1/+5/+10 km; `domain_convergence_audit.csv`, 758 KB).
- **Resultado qualitativo:** classes anuais variaram entre contextos (ex.: PT_017925: `crops` na autoritativa vs `shrub_and_scrub` na reconstrução). A causa precisa do mecanismo (efeito de suporte espacial/máscara na agregação) é plausível mas **o relatório não reproduziu a análise causal**; o que está comprovado é a **dependência** e a **convergência** com suporte maior.
- **Decisão:** domínio científico fixo = **MATOPIBA + 5 km**, independente de slices; slices só para paginação.
- **Mantido:** sim (decisão central).

### Fase 6 — Raster canônico e exportação em lotes (scripts `18`, `submit_canonical_batch_exports.py`, `split_*`, `monitor_and_process_batches.py`, `19`)
- **Feito:** projeto de 10 lotes (00–09) × 182 slices × 42 bandas; falhas de *timeout*/memória levaram a **divisões determinísticas** (`split_manifest_batches.py`, `split_batch_08a.py`, `split_batch_08a1.py`).
- **Resultado:** **21 tarefas** SUCCEEDED (00a, 00b, 01, 02, 03, 04a, 04b, 05, 06a, 06b, 07a1, 07a2, 07b1, 07b2, 08a1a, 08a1b, 08a2, 08b1, 08b2, 09a, 09b); criadas 30/09–04/10, concluídas até 07/10 (`tables/canonical_w2w_batch_tasks.csv`). Montagem: `canonical_wall_to_wall_by_slice.csv` (182 linhas, 182 slices únicos, 0 duplicatas).
- **Nota:** o docstring do script 19 diz "183 slices" (erro textual; dados dizem 182). **Não são "16 batches"**.
- **Mantido:** sim.

### Fase 7 — Invariância de paginação (script `20`)
- **Feito:** reteste com 1.000 pontos sob o raster canônico. **Resultado:** ≈100% invariante; diferença máxima de probabilidade ≈ 1e-8 (`pagination_invariance_audit.csv`).
- **Conclusão:** a paginação não afeta o resultado científico (nos limites do teste).

### Fase 8 — Probabilidade de inclusão nula e realocação (scripts `12`, `14`)
- **Problema:** subestratos operacionais (UF×regime×slice) com N>0 e alocação zero → π = 0. Auditoria: **5.218,30 ha** sem representação (`zero_inclusion_substrata_audit.csv`).
- **Correção:** alocação de Hamilton com n ≥ 1 para todo subestrato com N>0; regeneração da amostra mestre (`*_PRE_ZERO_PI_FIX` preservado).
- **Mantido:** sim.

### Fase 9 — Amostra mestre final e QA 3B (scripts `14`, `15`)
- **Resultado:** `master_sampling_points.csv` (40.000 linhas; colunas `sample_id, lat, lon, state, stratum_id, regime, slice_id, main_sample, robust_sample, rank_within_stratum, root_seed=25, stratum_seed, selection_probability_*, design_weight_*, pixel_area_m2, area_weight_*`). 410 subestratos operacionais com N>0 (182 slices distintos). Quotas: `sampling_quotas.csv`.

### Fase 10 — Extração analítica (Checkpoint 3D; `11`, `21`)
- **Feito:** extração das variáveis para os 40.000 pontos (`samples_annual.parquet/csv`, `dw_monthly.parquet`) e validação da suíte (`21_`).
- **Emenda pré-desfecho (07/10/2026 21:16):** critério primário `n_valid_months ≥ 8`; a regra reserva ≥6 foi **anulada** por circularidade (a amostra mestre já exigia ≥8, portanto "0 pontos <8" não prova que cobertura <8 meses seja desprezível). **Sensibilidade ≥6 meses: não executada.**
- **Hashes congelados 3D:** `tables/checkpoint_3d_checksums.sha256` (ex.: `samples_annual.parquet` `66f6d846…`; `master_sampling_points.csv` `744a2a2f…`).

### Fase 11 — Experimentos científicos (Checkpoint 4; `src/analysis/02–08`)
- Descritivas, H1–H4, regressão logística, semivariograma e bootstrap espacial (30 km, 1.999 réplicas, seed 25), robustez R1/R3 e R2 (rótulo do script = crosswalk estrito), 6 figuras.

### Fase 12 — Auditorias 4B e 4C
- **4B:** corrigiu a alegação de monotonicidade em H3 (não estritamente monotônica), reformulou H4, removeu a alegação "3,5× de subestimação" de SE, esclareceu pseudo-R² de McFadden.
- **4C:** resolveu conflito 20 km × 30 km do bloco (primário = 30 km; alcance prático 25,62 km → arredondado a múltiplo de 5 km = 30), padronizou texto, gerou manifesto e hashes (31 artefatos). Veredito: **PASS**.

---

## 5. Metodologia final

### 5.1 Delimitação
- 337 municípios: **MA 135, TO 139, PI 33, BA 30**. Origem: lista IBGE MATOPIBA_2021.xls + malha IBGE 2025. CRS original EPSG:4674; GeoJSON em EPSG:4326; áreas em EPSG:5880. Domínio científico fixo = MATOPIBA + 5 km. Área total do censo (raster): 73.057.911,87 ha. Frase canônica: "delimitação operacional … lista oficial de 337 municípios … malha municipal IBGE 2025".

### 5.2 Harmonização DW × MB
- **Grade comum 10 m** (EPSG de processamento canônico no GEE).
- **Crosswalk principal:** DW lavoura = argmax do vetor anual = `crops`; MB lavoura = {19 (Temporary Crop), 36 (Perennial Crop)}; **estrito** = {19}. Classes MB 21 (mosaico), 18 e desconhecidas → **excluídas** (ambíguas); área excluída: 4.830.175,65 ha.
- **Regimes:** **AA** = ambos lavoura; **AN** = MB lavoura & DW não; **NA** = MB não & DW lavoura; **NN** = nenhum. Discordância D = AN ∪ NA.
- **Simetria:** nenhum produto é tratado como verdade; "discordância" é simétrica e MB **não** é ground truth.

### 5.3 Agregação temporal do DW
1. Seleção das imagens DW 2025 (Sentinel-2).
2. Mesmo dia: média neutra das probabilidades.
3. Mensal: média das probabilidades diárias.
4. Anual: média com **peso igual por mês válido**.
5. Normalização das 9 probabilidades.
6. Classe anual = argmax. Critério **`n_valid_months ≥ 8`**.
- **A ordem importa:** calcular argmax mensal e depois majoritário produz classe diferente de média de probabilidades; e média por observação favoreceria meses com mais passagens.
- **Exclusão:** pixels com < 8 meses válidos (15.885.607,58 ha = **21,7% do domínio**; ~51% do MA — 12,23 de 23,91 Mha). Área elegível: 52.342.114,75 ha.

### 5.4 Domínio científico × paginação
- Slices por UF de 0,75° (182) são **só paginação computacional**. O domínio científico é fixo (MATOPIBA+5 km). Evidências: `dw_partition_invariance_audit.csv` (dependência do esquema antigo), `domain_convergence_audit.csv` (convergência), `pagination_invariance_audit.csv` (≈100% invariância final, Δprob ≲ 1e-8, 1.000 pontos).
- **Limite:** invariância verificada em amostra de 1.000 pontos, não em todos os pixels.

### 5.5 Amostragem
- **Por quê:** o censo wall-to-wall dá áreas, mas o cálculo de entropia/JSD/estabilidade e das distâncias de borda por pixel em 5,35 bilhões de pixels elegíveis é custoso; amostra probabilística estratificada permite estimar com erros controlados.
- **Estratos:** UF × regime (16). Estratificar assegura presença de regimes raros (AA 2,4%, NA 4,6%).
- **Tamanhos:** 20.000 (principal) e 40.000 (robusta = 2×); semente 25.
- **Cotas:** mínimo 400/estrato + restante proporcional à área (Hamilton), ex.: MA_AA 405/810; TO_NN 5.932/11.864.
- **Alocação operacional:** por slice (410 subestratos).
- **π nulo:** ver Fase 8.
- **π e pesos:** π = n_h/N_h (por subestrato); peso de desenho = 1/π (`design_weight_*`); **peso de área** (`area_weight_*`, colunas de `master_sampling_points.csv` junto de `pixel_area_m2`; fórmula exata no script 08, não reconferida aqui) — destinado a estimar *área*, ao passo que o peso de desenho estima *proporções de pontos/população de pixels*. Scripts de análise usam `design_weight_main`.
- **Integridade:** scripts 07, 15 e 21 (somas de pesos, unicidade, nenhum π nulo).

### 5.6 Variáveis
| Variável | Definição | Interpretação |
|---|---|---|
| `entropy_annual` | Entropia de Shannon do vetor anual normalizado por ln 9 | 1 = máxima incerteza |
| `jsd_temporal` | max(0, H(média dos vetores mensais normalizados) − média H(vetor mensal)), dividido por ln 9 | Heterogeneidade entre meses |
| entropia mensal | H por mês | Incerteza instantânea |
| `stability` (S) | meses cuja classe argmax coincide com a anual / meses válidos | Persistência temporal de classe |
| top-1, top-2, margem | Probabilidades máxima e segunda; margem = p1 − p2 | Ambiguidade de classe |
| `distance_edge_mb_m` / `_dw_m` / `_min_m` | Distância ao pixel de classe binária diferente (8-conexo), EPSG:5880, truncada em 250 m; min = menor das duas | Proximidade de borda temática |
| estabilidade MB 2017–2025 | Constância binária lavoura/não lavoura ao longo de 2017–2025 | Subconjunto estável (R3) |

A definição de JSD é a do script `11_extract_analytical_dataset.py` (é um JSD entre meses, **não** média por pares). Divergência conhecida de definição durante o desenvolvimento ficou resolvida por esse código.

---

## 6. Inventário experimental

O inventário completo e classificado está em [experiment_inventory.csv](experiment_inventory.csv) (colunas: `ID, Categoria, Experimento, Objetivo, Método, Dados, Resultado, Decisão, Arquivo de evidência`). Categorias (não misturadas): Exploratório · Teste técnico · Auditoria/QA · Experimento científico principal · Análise de robustez · Planejado, não executado · Descartado/invalidado.

Resumo das categorias:

| Categoria | Exemplos |
|---|---|
| Exploratório | Protótipo 500 pts; `test_*` auxiliares |
| Teste técnico | Acesso GEE; identidade; reprodução de Hamilton |
| Auditoria/QA | Invariância de partição, convergência de domínio, paginação, π nulo, 3B, 3D, 4B, 4C |
| Científico principal | Descritivas, H1–H4, regressão, bootstrap espacial |
| Robustez | R1 40k, R2 estrito, R3 estável MB, blocos 10/20/40 km, M2 log-dist |
| Planejado, não executado | ≥6 meses; suporte 30 m; perfil mensal p(crops); direção do competidor |
| Descartado/invalidado | Slice-dependent, PRE_ZERO_PI, DEBUG, PRELIM, BEFORE_AREA_WEIGHT_PATCH |

---

## 7. H1–H4 (valores congelados)

**Distribuição ponderada dos regimes** (amostra 20k): NN 83,25%; AN 9,66%; NA 4,66%; AA 2,44%; D=1 14,31%. Censo: AA 2,434; AN 9,637; NA 4,648; NN 83,281; concordância 85,715%; discordância 14,285% (**quantidade 4,989 pp; alocação 9,296 pp**, Pontius & Millones).

**Diferenças estaduais (discordância):** MA 10,98% · TO 5,90% · PI 21,80% · BA 27,95% (amostra, `descriptive_state_proportions.csv`); censo: MA 10,97 · TO 5,91 · PI 21,81 · BA 27,92.

### H1 — Entropia anual
- Pergunta: discordantes são mais incertos? Operacionalização: contraste ponderado ΔH = H(D=1) − H(D=0).
- Resultado: médias descritivas 0,8519 (D=1) vs 0,8357 (D=0). **ΔH = +0,0162; IC espacial [0,0103; 0,0221]; d = 0,318.**
- Conclusão: **sustentada**, efeito pequeno-moderado. Entropia anual é muito alta em geral (média 0,838), pouco discriminante isoladamente.
- Interpretação incorreta: "entropia alta causa discordância".

### H2 — JSD e estabilidade
- H2a: ΔJSD = +0,0179 [0,0140; 0,0218]; d = 0,529 → **sustentada**.
- H2b: S = 0,4679 (D=0) vs 0,0500 (D=1); Δ = −0,4179 [−0,4318; −0,4034]; d = −1,609 → **sustentada, efeito muito grande**. Em D=1, mediana e Q3 de S são 0: em pelo menos 75% dos pontos discordantes (não ponderado) nenhum mês coincide com a classe anual.
- Interpretação incorreta: "S mede acurácia".

### H3 — Bordas
| Faixa | Discordância (%) | IC espacial 95% (bootstrap) |
|---|---|---|
| 0–10 m | 47,51 | [40,36; 54,92] |
| 10–30 m | 44,59 | [37,67; 52,68] |
| 30–60 m | 45,77 | [38,92; 52,51] |
| 60–100 m | 36,96 | [31,65; 42,50] |
| 100–250 m | 36,79 | [32,92; 40,86] |
| ≥250 m | 11,87 | [10,20; 13,65] |

Borda (<30 m) 45,91% vs ≥250 m 11,87% (razão 3,87). **Suporte parcial:** forte associação inversa global, **sem** monotonicidade estrita (30–60 m > 10–30 m); as quatro primeiras faixas têm ICs sobrepostos. Apenas 8,82% da área ponderada está a <250 m de uma borda (1,77% a <30 m). Interpretação incorreta: "gradiente monotônico", "borda causa discordância".

### H4 — Discordância robusta
Critérios congelados: Q1(H) = 0,809031; Q1(JSD) = 0,020682; Q3(S) = 0,666667; d ≥ 30 m. Entre os 5.143 pontos D=1 (20k):
- H ≤ Q1: 985 (19,15% não pond. / 21,26% pond.)
- JSD ≤ Q1: 656 (12,76% / 11,54%)
- S ≥ Q3: 45 (0,875% / 0,955%)
- d ≥ 30 m: 4.866 (94,61% / 94,33%)
- H≤Q1 ∩ S≥Q3 = 0; **interseção total = 0**; na amostra de 40k (10.286 D=1) também 0.
**Resultado: H4 não sustentada.** O gargalo é S ≥ Q3 (quase todo ponto discordante tem S baixa). Leitura: no recorte e critérios testados, a discordância sempre vem acompanhada de alguma sinalização de incerteza/instabilidade temporal do DW. Interpretação incorreta: "não há discordância real" ou "todos os erros são do DW".

---

## 8. Regressão e análise espacial

- **Modelo:** logística ponderada (`design_weight_main` normalizado); D (1 = discordância) ~ H + JSD + S + `distance_edge_min_m` (linear, **desvio em relação ao brief que previa log(d+1)**; o modelo M2 com log foi comparado: pseudo-R² 0,4808 vs 0,4881, AIC 8544,2 vs 8424,7 — M1 melhor) + UF (ref. BA).
- **Por quê logística:** resposta binária; explorar associações condicionais. É descrição/associação, **não causalidade**.
- **Diagnóstico:** VIF máximo 1,069. **Pseudo-R² McFadden = 0,488** (não equivale a "88% deviance explained"; não é R² linear).
- **OR escalonados [IC espacial 95%]:** H +0,10 → 1,379 [1,049; 1,891]; JSD +0,01 → 1,344 [1,287; 1,409]; S +0,10 → 0,309 [0,269; 0,351]; d +100 m → 0,437 [0,375; 0,502]. UF vs BA: MA 0,220 [0,143; 0,342]; TO 0,098 [0,068; 0,144]; **PI 0,823 [0,535; 1,275] (IC espacial inclui 1; o IC analítico [0,704; 0,963] não)** → diferença PI×BA **não sustentada** sob inferência espacial.
- **Aviso:** os SE analíticos são aproximação ponderada, sem variância de desenho completa (sem FPC, estratificação sem reposição ou dependência espacial). Os ICs espaciais são os primários.
- **Semivariograma:** nugget 0,0693; partial sill 0,1267; sill total 0,1959; **alcance prático 25,62 km** (subamostra 6.000; 17.997.000 pares). Regra: arredondar a múltiplo de 5 km → **30 km**; teto 100 km.
- **Bootstrap por blocos:** blocos de 30 km, **1.999 réplicas**, seed 25. IC pelos percentis. Resultado: **confirmou** H1, H2, H3(global) e a regressão; **alterou** a conclusão de PI (analítico significativo → espacial não).
- **Por que 1.999:** convenção para percentis 2,5%/97,5% em bootstrap (B+1 múltiplo de 20/1000) conforme brief; [NÃO VERIFICADO] justificativa mais explícita.
- **Contrastes (espacial):** taxa geral 14,32% [12,66; 16,01].

---

## 9. Robustez

| Análise | Foi alterado | Fixo | Resultado | Conclusão |
|---|---|---|---|---|
| R1: 20k vs 40k | Tamanho amostral | Crosswalk, critérios | Discordância 14,31 vs 14,31; ΔH 0,0162 vs 0,0167; ΔJSD 0,0179 vs 0,0181; ΔS −0,418 vs −0,421; borda/núcleo 3,87 vs 3,72; regimes ±0,01 pp | Mantida |
| R2: crosswalk estrito {19} | MB lavoura = só 19 | Amostra 20k | Discordância 14,28 (Δ −0,037 pp); ΔH 0,0163; ΔJSD 0,0180; ΔS −0,418; 13 pontos de classe 36 (0,042% pond.) | Mantida; efeito mínimo porque a classe 36 é rara na amostra |
| R3: MB estável 2017–2025 | Subconjunto estável (17.957 pts = 89,79%) | Critérios | Discordância 12,13%; ΔH 0,0195; ΔJSD 0,0163; ΔS −0,434; borda 32,08% vs núcleo 10,77% (razão 2,98) | Direção mantida; magnitude de H3 reduzida (razão 3,87→2,98) |
| Sensibilidade de bloco 10/20/40 km | Tamanho do bloco | Dados | Taxa geral IC [13,54; 15,04] (10 km), [13,09; 15,59] (20), [12,46; 16,45] (40); ΔH IC [0,0134; 0,0190], [0,0116; 0,0206], [0,0094; 0,0234]; ΔS sempre ≈ −0,43…−0,40 | IC alarga com bloco; conclusões qualitativas mantidas. **Desvio:** o brief previa 0,5× e 2× (15/60 km) |
| M2: log-dist | Forma da distância | Variáveis | pseudo-R² 0,481 (M1 0,488) | M1 preferido |

**Não executadas:** sensibilidade a ≥6 meses (cobertura temporal), sensibilidade ao suporte 30 m, perfil mensal de p(crops), análise de classe/direção do competidor DW. **Não declarar como concluídas.** O "R2" dos scripts é o crosswalk estrito, não o 30 m do brief.

---

## 10. Dificuldades — problema → causa → evidência → correção → consequência

| # | Problema | Causa | Evidência | Correção | Consequência |
|---|---|---|---|---|---|
| 1 | Resultados dependentes das slices | DW processado dentro da geometria da slice | `dw_partition_invariance_audit.csv`, `dw_annual_identity_diagnostic.csv`, `*_SLICE_DEPENDENT_INVALID` | Domínio fixo MATOPIBA+5 km | Resolvido; artefatos antigos invalidados |
| 2 | Convergência do domínio incerta | Suporte espacial | `domain_convergence_audit.csv` (+1/+5/+10 km) | Escolha de +5 km | Resolvido (escolha documentada; decisão de 5 km é de projeto) |
| 3 | Timeouts/memória no GEE | Exportação 182 slices × 42 bandas por lote | `canonical_w2w_batch_tasks.csv` (21 tarefas) | Divisão determinística de lotes | Resolvido; nenhuma consequência científica |
| 4 | π = 0 em subestratos | Alocação zero com N>0 | `zero_inclusion_substrata_audit.csv` (5.218,30 ha) | Hamilton n ≥ 1 | Resolvido |
| 5 | Pesos de área inconsistentes | Patch posterior | `*_BEFORE_AREA_WEIGHT_PATCH` | Regeneração | Resolvido |
| 6 | Critério ≥6 circular | Frame exigia ≥8 | `protocol_amendment_checkpoint_3d.md` | Emenda pré-desfecho | Resolvido formalmente; **limitação remanescente** (sem sensibilidade) |
| 7 | Alegação "monotônica" em H3 | Interpretação | 4B | Reformulação | Resolvido |
| 8 | Bloco 20 vs 30 km | Texto 4B inconsistente | 4C | 30 km | Resolvido |
| 9 | JSD ambíguo | Múltiplas formulações durante desenvolvimento | Código do script 11 | Definição única | Resolvido; [NÃO VERIFICADO] histórico detalhado |
| 10 | Brief × execução | Desvios (ver §13) | — | Documentados aqui | **Limitação persistente** |
| 11 | Áreas do domínio divergentes | Três fontes | manifest vs experiment.yaml | Não corrigido | **Pendente** |
| 12 | Docstring "183 slices" | Erro textual | script 19 | Não corrigido | Pendente (cosmético) |

---

## 11. Síntese interpretativa

- **Observado:** discordância ~14,3% (quantidade 5,0 pp; alocação 9,3 pp: a maior parte é de **localização**, não de quantidade). Concentrada em BA e PI e perto de bordas. Associada a maior entropia, maior JSD e **muito** menor estabilidade.
- **Interpretação sustentada:** discordância correlaciona-se com instabilidade temporal da própria probabilidade do DW e com bordas; a estabilidade é o discriminador mais forte (d = −1,6; OR 0,309 por +0,10; univariado pseudo-R² 0,293).
- **Hipótese ainda não demonstrada:** que a causa seja fenologia, mosaicos, resolução ou erro de um dos produtos — não foi testado (sem ground truth). O papel de MB (tratar lavoura permanente/rotação) também não.
- **Contrariou expectativas:** H4 vazio (nenhuma discordância "limpa") e H3 sem monotonicidade; PI×BA desaparece com bootstrap espacial.
- **Não se pode concluir:** qual produto está certo; causalidade; generalização a outros anos/regiões; comportamento em 21,7% do domínio sem cobertura ≥8 meses.

---

## 12. Do experimento ao artigo

Ver [manuscript_blueprint.md](manuscript_blueprint.md).

---

## 13. Limitações e ameaças à validade

**Reais:** (1) sem ground truth independente; (2) conceitos de classe distintos (MB lavoura inclui perene/temporária; DW `crops` é vegetação anual de cultivo); (3) potencial dependência (insumos Sentinel-2 comuns); (4) média anual do DW pode misturar fenologia; (5) exclusão de 21,7% do domínio por cobertura <8 meses — **viés de seleção não quantificado**, sobretudo no MA; (6) estimadores analíticos sem variância de desenho completa; (7) dependência espacial residual; (8) distância truncada em 250 m (mediana = 250 m) limita análise de gradiente fino; (9) amostras de ≥250 m dominam (91,2% da área) → H3 dominado por baixo grupo de pontos próximos a bordas (221 + 276 + 265 pontos nas três primeiras faixas); (10) generalização limitada a MATOPIBA 2025; (11) sensibilidades não executadas (≥6 meses, 30 m).

**Desvios do brief declarados:** regressão com d linear; blocos de sensibilidade 10/20/40; pesos `design_weight_main` (e não `area_weight`) nas análises contínuas; "R2" = crosswalk estrito; Figura 1 = barras (sem mapa); Figura 4 do brief (perfil mensal) não gerada.

**Corrigidas (não são limitações):** dependência de slices, π nulo, timeouts, monotonicidade, 20/30 km.

---

## 14. Reprodutibilidade

- **Estrutura:** `config/` (YAML), `src/gee/` (00–21), `src/analysis/` (02–08), `data/reference|processed`, `tables/`, `figures/`, `docs/`, `paper/`, `references/`.
- **Sequência:** `02_boundary` → `04_wall_to_wall*` (diagnóstico) → `13`,`16`,`17` (auditorias) → `18`/`submit_canonical_batch_exports.py` → `monitor_and_process_batches.py`/`19` → `20` → `12`,`14` → `15` → `11` → `21` → `src/analysis/08_*` (executa 02–07).
- **Seeds:** 25 (root, bootstrap).
- **Hashes:** `tables/checkpoint_3d_checksums.sha256` e `tables/manuscript_results_checksums.sha256`; manifesto com 31 artefatos.
- **Custo:** exportações GEE (21 tarefas; 30/09–07/10) são as caras; requerem credencial/quota do GEE.
- **Local-only:** com `samples_annual.parquet`, `master_sampling_points.csv`, `dw_monthly.parquet` e as tabelas, a análise `src/analysis` pode ser reproduzida sem GEE.
- **Lacuna:** sem commit/tag dos resultados; versões de bibliotecas só em `requirements.txt`.

---

**Fim do relatório.**
