# Auditoria de Inferência Estatística, Amostragem e Incerteza Espacial
## Estudo: Dynamic World × MapBiomas no MATOPIBA (2025)

---

## 1. Introdução e Escopo da Auditoria

Este documento estabelece a auditoria matemática e metodológica formal dos procedimentos de amostragem probabilística, cálculo de pesos, formulação de estimandos populacionais e inferência espacial por *Spatial Block Bootstrap* do estudo **Dynamic World × MapBiomas no MATOPIBA (2025)**.

A auditoria foi motivada pela necessidade de elucidar três questões cruciais antes da redação do artigo científico:
1. **Diferenciação formal de estimandos:** como os pesos de desenho (`design_weight_main`) e os pesos de área (`area_weight_main`) se relacionam matematicamente, quais são as probabilidades reais de inclusão e qual a diferença numérica entre estimar proporções de pixels e proporções de área física.
2. **Interpretação do censo versus estimativa amostral:** por que a discordância amostral ponderada (~14,31%) e a discordância censitária wall-to-wall (~14,285%) são quase idênticas, e por que a atribuição de um intervalo de confiança amostral de população finita à proporção censitária é um erro conceitual.
3. **Validade do Spatial Block Bootstrap:** se a reamostragem espacial de blocos de 30 km sem estratificação distorce as margens dos 16 estratos científicos conhecidos, qual a interpretação estatística correta dos intervalos obtidos e se os contrastes das hipóteses H1–H3 permanecem robustos sob recalibração pós-estratificada.

Todos os testes e valores apresentados foram calculados a partir dos dados consolidados em `tables/` e `data/processed/`, com reprodutibilidade estrita.

---

## 2. Desenho Amostral e Formulação Matemática dos Pesos

### 2.1. População Alvo, Frame e Estratificação

A população alvo finita $U$ consiste em todos os pixels de 10 m da grade canônica do MapBiomas localizados dentro dos 337 municípios operacionais do MATOPIBA que satisfazem os critérios de elegibilidade:
- Classificação temática do MapBiomas válida (excluindo classes 18 e 21);
- Dados válidos do Dynamic World com cobertura temporal suficiente ($n_{\text{valid\_months}} \ge 8$).

O frame amostral (`tables/sampling_frame_10m.csv`) totaliza:
$$N = 5.354.669.418 \text{ pixels}$$
$$A = 52.342.114,75 \text{ hectares}$$

A população é particionada em:
- **16 estratos científicos primários** $h = 1, \dots, 16$, definidos pelo cruzamento de 4 Unidades Federativas ($\text{UF} \in \{\text{MA, TO, PI, BA}\}$) e 4 regimes de concordância/discordância temática ($\text{Regime} \in \{\text{AA, AN, NA, NN}\}$).
- **410 subestratos operacionais ativos** $hs$ ($h = \text{estrato científico}$, $s = \text{slice}$ espacial de $0,75^\circ \times 0,75^\circ$), onde $N_{hs} > 0$.

### 2.2. Probabilidades Reais de Inclusão e Positividade

Na amostragem estratificada aleatória sem reposição dentro de cada subestrato operacional $hs$, foram alocadas cotas $n_{\text{robust}, hs} \ge 1$ (amostra robusta de 40.000 pontos) via método de Hamilton com piso unitário (Checkpoint 3B / Script `12_audit_zero_pi_and_reallocate.py`), eliminando qualquer possibilidade de probabilidade de inclusão nula ($\pi_{hs} = 0$).

Para cada ponto $i$ pertencente ao subestrato operacional $hs$:
1. **Amostra Robusta ($n = 40.000$):**
   $$\pi_{\text{robust}, i} = \frac{n_{\text{robust}, hs}}{N_{hs}}$$
2. **Amostra Principal ($n = 20.000$):**
   A amostra principal foi selecionada como uma subamostra determinística de 50% da amostra robusta através de ranking determinístico de dispersão SHA-256 (`rank_within_stratum` $\le n_{\text{main}, h}$):
   $$\pi_{\text{main}, i} = \pi_{\text{robust}, i} \times 0,5 = \frac{n_{\text{main}, hs}}{N_{hs}}$$

**Verificação de Positividade:**
- $\min(\pi_{\text{main}}) = 2,71103 \times 10^{-6}$
- $\max(\pi_{\text{main}}) = 1,72414 \times 10^{-2}$
- Proporção de pontos com $\pi \le 0$ ou $\pi = \text{NaN}$: **$0,000\%$ (Positividade estrita garantida para 100% da população elegível).**

### 2.3. Pesos de Desenho (Design Weights)

O peso de desenho $w_{\text{des}, i}$ é o inverso exato da probabilidade de inclusão (estimador de Horvitz-Thompson / expansion factor de pixels):
$$w_{\text{des}, i} = \frac{1}{\pi_{\text{main}, i}} = \frac{N_{hs}}{n_{\text{main}, hs}}$$

Para uma variável indicadora ou quantitativa $y_i$, o estimador do total de pixels na população é:
$$\hat{Y}_{\text{pixel}} = \sum_{i \in s} w_{\text{des}, i} y_i$$
E a proporção estimada em número de pixels é o estimador de razão de Hájek:
$$\hat{P}_{\text{pixel}} = \frac{\sum_{i \in s} w_{\text{des}, i} y_i}{\sum_{i \in s} w_{\text{des}, i}}$$

### 2.4. Pesos de Área (Area Weights)

Cada pixel $i$ amostrado possui uma área geográfica ellipsoidal real $a_i = \text{pixel\_area\_m2}_i$, extraída no Google Earth Engine a partir de `ee.Image.pixelArea().reproject(crs=mb_proj)` no elipsoide WGS84.

O peso de área $w_{\text{area}, i}$ (em metros quadrados) é dado por:
$$w_{\text{area}, i} = \frac{a_i}{\pi_{\text{main}, i}} = a_i \times w_{\text{des}, i}$$

O total estimado de área física (em hectares) é:
$$\hat{A}_{\text{ha}} = \frac{1}{10.000} \sum_{i \in s} w_{\text{area}, i} y_i$$
E a proporção estimada em área geográfica é:
$$\hat{P}_{\text{area}} = \frac{\sum_{i \in s} w_{\text{area}, i} y_i}{\sum_{i \in s} w_{\text{area}, i}}$$

---

## 3. Fechamento Populacional e Comparação Empírica de Estimandos

### 3.1. Fechamento Populacional

Avaliamos a aderência das somas ponderadas das amostras em relação aos parâmetros censitários do frame elegível:

| Métrica | Parâmetro Censitário (Frame) | Estimativa Amostra 20k (Main) | Estimativa Amostra 40k (Robust) | Erro Relativo (20k) |
|---|---|---|---|---|
| **Contagem de Pixels** ($N$) | 5.354.669.418 | 5.354.646.637,09 | 5.354.669.418,00 | $-0,00042\%$ |
| **Área Física Elegível** ($A$) | 52.342.114,75 ha | 52.342.388,21 ha | 52.342.090,73 ha | $+0,00052\%$ |

A discrepância residual de apenas 22.781 pixels (em 5,35 bilhões) e 273 ha (em 52,3 milhões de hectares) na amostra de 20k decorre unicamente de arredondamentos inteiros na alocação operacional ao repartir cotas ímpares pela metade entre a amostra robusta e a principal. Na amostra robusta de 40k, o fechamento em pixels é **exatamente zero** ($5.354.669.418,00$).

### 3.2. Variação Espacial de `pixel_area_m2`

Na projeção oficial de 10 m do MapBiomas sobre o MATOPIBA (latitudes de aproximadamente $-2^\circ$ a $-15^\circ$ Sul):
- Mínimo: $95,9414 \text{ m}^2$ (extremo sul da Bahia)
- Média: $97,7880 \text{ m}^2$
- Mediana: $97,8105 \text{ m}^2$
- Máximo: $99,2502 \text{ m}^2$ (extremo norte do Maranhão)
- Desvio Padrão: $0,7104 \text{ m}^2$

A variação da área de pixel em todo o MATOPIBA é inferior a $\pm 1,7\%$ em torno da média.

### 3.3. Comparação Numérica: Proporções de Pixels versus Proporções de Área

Calculamos as proporções populacionais utilizando estritamente os pesos de desenho ($\hat{P}_{\text{pixel}}$) e os pesos de área ($\hat{P}_{\text{area}}$) na amostra principal de 20.000 pontos:

| Regime / Estimando | $\hat{P}_{\text{pixel}}$ (via `w_des`) | $\hat{P}_{\text{area}}$ (via `w_area`) | Diferença ($\text{pp}$) | Censo Wall-to-Wall |
|---|---|---|---|---|
| **AA** (Acordo Lavoura) | $2,439776\%$ | $2,433437\%$ | $-0,006338\text{ pp}$ | $2,434093\%$ |
| **AN** (MB Lavoura, DW Não) | $9,655679\%$ | $9,646524\%$ | $-0,009155\text{ pp}$ | $9,637200\%$ |
| **NA** (DW Lavoura, MB Não) | $4,659164\%$ | $4,643174\%$ | $-0,015991\text{ pp}$ | $4,648003\%$ |
| **NN** (Acordo Não-Lavoura) | $83,245381\%$ | $83,276865\%$ | $+0,031484\text{ pp}$ | $83,280704\%$ |
| **Taxa Geral de Discordância** ($D=1$) | **$14,314843\%$** | **$14,289697\%$** | **$-0,025146\text{ pp}$** | **$14,285203\%$** |

**Taxa de Discordância por Estado:**
- **Maranhão (MA):** Pixel = $10,975674\%$, Área = $10,958231\%$ (Dif: $-0,0174\text{ pp}$; Censo = $10,9703\%$)
- **Tocantins (TO):** Pixel = $5,901189\%$, Área = $5,902698\%$ (Dif: $+0,0015\text{ pp}$; Censo = $5,9059\%$)
- **Piauí (PI):** Pixel = $21,795575\%$, Área = $21,824180\%$ (Dif: $+0,0286\text{ pp}$; Censo = $21,8114\%$)
- **Bahia (BA):** Pixel = $27,951908Code$, Área = $27,943469\%$ (Dif: $-0,0084\text{ pp}$; Censo = $27,9214\%$)

**Contrastes de Indicadores Contínuos (H1, H2a, H2b):**
- **$\Delta H$ (Entropia Anual):** Pixel = $+0,016214$, Área = $+0,016220$ (Diferença: $+0,000006$)
- **$\Delta \text{JSD}$ (Temporal):** Pixel = $+0,017864$, Área = $+0,017938$ (Diferença: $+0,000074$)
- **$\Delta S$ (Estabilidade):** Pixel = $-0,417896$, Área = $-0,418011$ (Diferença: $-0,000114$)

### 3.4. Conclusão Metodológica sobre o Uso dos Pesos

1. **Equivalência Prática:** a diferença entre estimar proporção de pixels e proporção de área é inferior a $0,03$ pontos percentuais na taxa geral e nos regimes, e inferior a $0,0001$ no tamanho de efeito das hipóteses H1–H2.
2. **Definição Canônica para o Manuscrito:**
   - **Tabelas de área e regimes geográficos:** reportar os valores censitários wall-to-wall em hectares e percentuais de área física (onde a discordância é de $14,285\%$).
   - **Modelagem estatística e contrastes H1–H4:** os scripts utilizam `design_weight_main`, que estima formalmente as médias populacionais dos pixels. O relatório confirma que os resultados são numericamente invariantes à escolha entre peso de desenho e peso de área.

---

## 4. Auditoria da Interpretação Censitária versus Intervalo Amostral

### 4.1. Por que as estimativas da amostra e do censo são tão próximas?

A taxa geral de discordância calculada no censo wall-to-wall é de **$14,285\%$**, enquanto a estimativa obtida pela amostra principal ponderada é de **$14,315\%$** (via `w_des`) e **$14,290\%$** (via `w_area`).

Essa proximidade não é um acaso amostral: ela decorre **diretamente do desenho estratificado por regime**. 
Como a variável dependente de discordância $D_i \in \{0, 1\}$ é definida inteiramente pelo regime temático ($D_i = 1 \iff \text{Regime}_i \in \{\text{AN, NA}\}$), e os regimes foram utilizados como estratos de amostragem cujos totais populacionais $N_h$ foram fixados pelo censo, a variabilidade amostral de $\hat{P}(D=1)$ sob o desenho estratificado é virtualmente nula:
$$\mathbb{V}_{\text{design}}(\hat{P}(D=1)) \approx 0$$

### 4.2. O que representa o intervalo $[12,66\%; 16,01\%]$?

O intervalo de $95\%$ $[12,66\%; 16,01\%]$, obtido pelo *Spatial Block Bootstrap* em `tables/spatial_bootstrap_contrasts.csv`, **não representa a incerteza amostral da população finita do MATOPIBA em 2025**.

No censo realizado sobre os 5,35 bilhões de pixels elegíveis, o valor $14,285\%$ é um parâmetro populacional conhecido e observado sem erro amostral.

O intervalo $[12,66\%; 16,01\%]$ foi gerado porque o bootstrap reamostrou **blocos espaciais de 30 km com reposição sem estratificação por regime**. Em réplicas onde mais blocos da Bahia (discordância de $27,9\%$) ou do Piauí ($21,8\%$) foram sorteados, a taxa de discordância da réplica subiu; em réplicas com mais blocos do Tocantins ($5,9\%$), a taxa desceu.

Portanto:
> **Regra Científica de Apresentação:**
> A taxa de discordância de $14,285\%$ (ou $14,29\%$) deve ser apresentada no artigo como o **resultado censitário da população elegível**, sem qualquer intervalo de confiança amostral. O intervalo $[12,66\%; 16,01\%]$ deve ser estritamente rotulado como a **variabilidade espacial de paisagem entre blocos de 30 km sob um modelo de superpopulação espacial**, e não como erro de estimação da população observada.

---

## 5. Auditoria Formal do Spatial Block Bootstrap

### 5.1. Estrutura da Implementação

Inspecionamos a implementação real em `src/analysis/05_spatial_block_bootstrap.py`:
- **Projeção:** coordenadas projetadas em CRS métrico SIRGAS 2000 / Polyconic Brazil (EPSG:5880).
- **Semivariograma Empírico:** ajustado sobre o indicador binário $D$ usando subamostra determinística de 6.000 pontos (17.997.000 pares de distâncias). Parâmetros estimados:
  - Efeito Pepita ($c_0$): $0,0693$
  - Patamar Parcial ($c$): $0,1267$
  - Patamar Total: $0,1959$
  - Alcance Prático ($a$): $25,62\text{ km}$
  - Tamanho de Bloco Eleito: $30\text{ km}$ (regra pré-registrada: teto no múltiplo superior de 5 km).
- **Particionamento Espacial:** a grade de $30\text{ km} \times 30\text{ km}$ particionou os 20.000 pontos em **856 blocos ativos**.
  - Mínimo de pontos por bloco: 1
  - Mediana: 21,5 pontos
  - Média: 23,36 pontos
  - Máximo: 307 pontos
  - Blocos transfronteiriços (cruzam divisas estaduais): 63 blocos ($7,36\%$).
  - Blocos puros (apenas $D=0$ ou apenas $D=1$): 401 blocos ($46,85\%$).
- **Reamostragem:** $B = 1.999$ réplicas com reposição, sorteando 856 blocos a cada réplica, com semente mestre `seed=25`.

### 5.2. O Problema da Não-Preservação dos Estratos e a Solução por Recalibração

Na reamostragem puramente espacial de blocos, as proporções dos 16 estratos científicos sofrem flutuações amostrais em cada réplica:
- Exemplo: o estrato `TO_NN` (fixo em $40,71\%$ da população) oscilou entre $37,19\%$ e $44,14\%$ nas réplicas do bootstrap não calibrado.
- O estrato `BA_AA` (fixo em $1,91\%$) oscilou entre $1,26\%$ e $2,68\%$.

Para avaliar se essa flutuação compromete os intervalos das hipóteses científicas H1, H2a, H2b e H3, implementamos e executamos um **Spatial Block Bootstrap com Recalibração Pós-Estratificada (Post-Stratified Block Bootstrap)**, onde em cada réplica $r$ os pesos foram calibrados para reproduzir exatamente as margens populacionais conhecidas $N_h$ dos 16 estratos:
$$w_{i}^{(r), \text{recal}} = w_i \times \frac{N_h}{\sum_{j \in \text{boot}^{(r)} \cap h} w_j}$$

### 5.3. Resultados Comparativos: Bootstrap Original versus Recalibrado (1.999 Réplicas)

| Estatística / Contraste | Valor Pontual Amostral | IC 95% Espacial Original (Não-Calibrado) | IC 95% Espacial Recalibrado (Estratos Fixos) | Impacto nas Conclusões |
|---|---|---|---|---|
| **H1: $\Delta H_{\text{annual}}$** | $+0,0162$ | $[+0,0103; +0,0221]$ | $[+0,0116; +0,0213]$ | **Nenhum.** Efeito permanece positivo e significativo ($p < 0,001$). |
| **H2a: $\Delta \text{JSD}_{\text{temporal}}$** | $+0,0179$ | $[+0,0140; +0,0218]$ | $[+0,0159; +0,0200]$ | **Nenhum.** Efeito permanece positivo e significativo ($p < 0,001$). |
| **H2b: $\Delta \text{Stability } S$** | $-0,4179$ | $[-0,4318; -0,4034]$ | $[-0,4316; -0,4040]$ | **Nenhum.** Efeito permanece muito grande e negativo ($p < 0,001$). |
| **Taxa Geral Discordância** | $14,31\%$ | $[12,66\%; 16,01\%]$ | $[14,31\%; 14,31\%]$ | **Confirmação:** A variabilidade era puramente flutuação de blocos. |

**Faixas de Distância H3 (Taxa Ponderada de Discordância):**
- **0–10 m:** Original = $[40,36\%; 54,92\%]$, Recalibrado = $[40,17\%; 55,53\%]$
- **10–30 m:** Original = $[37,67\%; 52,68\%]$, Recalibrado = $[37,42\%; 53,14\%]$
- **30–60 m:** Original = $[38,92\%; 52,51\%]$, Recalibrado = $[38,90\%; 53,46\%]$
- **60–100 m:** Original = $[31,65\%; 42,50\%]$, Recalibrado = $[31,61\%; 43,09\%]$
- **100–250 m:** Original = $[32,92\%; 40,86\%]$, Recalibrado = $[33,36\%; 40,63\%]$
- **$\ge 250$ m:** Original = $[10,20\%; 13,65\%]$, Recalibrado = $[11,61\%; 12,08\%]$

### 5.4. Formulação Metodológica e Limites da Inferência Espacial

1. **Estimandos e Ponderação:**
   - Os estimandos científicos primários não são totais populacionais incondicionais, mas **contrastes condicionais ponderados**:
     $$\Delta H = \bar{H}_{D=1} - \bar{H}_{D=0}, \quad \Delta \text{JSD} = \overline{\text{JSD}}_{D=1} - \overline{\text{JSD}}_{D=0}, \quad \Delta S = \bar{S}_{D=1} - \bar{S}_{D=0}$$
     onde cada média é calculada utilizando os pesos de desenho de Horvitz-Thompson $w_i = 1/\pi_i$.
   - Para H3, os estimandos são as taxas de discordância condicionais a cada faixa de distância $d_b$: $P(D=1 \mid d \in d_b)$.

2. **Reamostragem por Blocos de 30 km:**
   - Com base no semivariograma empírico ($a = 25,62\text{ km}$), o domínio foi particionado em uma grade fixa de blocos de $30 \times 30\text{ km}$ ($856$ blocos com pontos ativos).
   - O sorteio com reposição de blocos inteiros preserva a estrutura de autocorrelação espacial intra-bloco entre os pontos amostrais vizinhos.

3. **Análise de Sensibilidade Pós-Estratificada:**
   - Como a reamostragem em bloco pode selecionar aleatoriamente mais blocos de determinados regimes ou estados, as margens amostrais dos 16 estratos oscilam em torno de seus valores populacionais conhecidos $N_h$.
   - A recalibração pós-estratificada foi implementada como uma **análise adicional de sensibilidade**, reponderando cada réplica para fixar $\sum_{j \in h} w_j^{(r)} = N_h$.
   - A constatação de que os intervalos de $\Delta H$, $\Delta \text{JSD}$, $\Delta S$ e faixas de H3 permanecem praticamente idênticos entre o bootstrap original e o recalibrado **não constitui prova formal da validade exata do estimador**, mas evidencia empiricamente que os contrastes substantivos são robustos às flutuações de margens entre blocos.

4. **Pressupostos e Limites da Inferência Espacial:**
   - *Modelo de Superpopulação:* os intervalos refletem a variabilidade de uma superpopulação espacial geradora de paisagens sob processo estocástico estacionário de segunda ordem, e não a amostragem de uma população finita fixa (cujo censo $14,285\%$ não tem variância amostral).
   - *Dependência Transfronteiriça:* $7,36\%$ dos blocos interceptam fronteiras estaduais, gerando mistura marginal que é tratada adequadamente pela ponderação de Horvitz-Thompson.
   - *Conservadorismo:* o bootstrap de blocos tende a gerar intervalos ligeiramente conservadores (mais largos) devido ao efeito de borda do corte dos blocos artificiais.

---

## 6. Auditoria da Identidade Temporal Anual versus Mensal (40.000 Pontos)

### 6.1. Especificação da Investigação
Investigou-se em todos os $40.000$ pontos da Master Sample a identidade teórica entre o vetor de 9 probabilidades anuais armazenado em `samples_annual.parquet` e o vetor anual reconstruído pela média simples dos meses válidos em `dw_monthly.parquet`, conforme previsto pela Equação (12) do `PROJECT_BRIEF.md`:
$$\mathbf{p}_{year} \stackrel{?}{=} \frac{1}{M}\sum_{m \in valid} \mathbf{p}_m$$

### 6.2. Resultados Quantitativos (360.000 Comparações)
- **Pontos Comparados:** $40.000$ pontos ($100\%$ da Master Sample).
- **Diferença Absoluta Máxima:** $0,731293$ (na classe `built`; `water`: $0,7188$; `trees`: $0,6842$).
- **Diferença Absoluta Mediana:** $0,015746$ ($1,57\text{ pp}$).
- **Diferença Absoluta Média:** $0,058487$.
- **Percentil 95 das Diferenças:** $0,246215$.
- **Percentil 99 das Diferenças:** $0,380296$.
- **Pontos com `argmax` Anual Divergente:** $23.381 / 40.000$ ($58,45\%$).
- **Pontos com `dw_crop` Divergente:** $9.908 / 40.000$ ($24,77\%$).
  - Regime AA: $907 / 3.862$ ($23,49\%$).
  - Regime AN: $4.258 / 5.822$ ($73,14\%$).
  - Regime NA: $4.402 / 4.464$ ($98,61\%$).
  - Regime NN: $341 / 25.852$ ($1,32\%$).
- **Diferenças em `n_valid_months`:** apenas $3 / 40.000$ pontos ($0,0075\%$: `PT_027693`, `PT_028919`, `PT_004132`).
- **Veredito sobre a Identidade:** **NÃO SATISFEITA NUMERICAMENTE** entre os artefatos entregues.

### 6.3. Diagnóstico e Causa Técnica (Caso do Ponto `PT_010352`)
- O ponto `PT_010352` (Maranhão, slice `MA_x06_y04`, estrato `MA_AN`) motivou verificações por apresentar $S = 0,0000$ apesar de ter `crops` dominante em 5 dos 8 meses válidos (com média mensal $p=0,4618$ vs $p_{\text{trees}}=0,0305$). No raster anual autoritativo, o ponto foi classificado como `trees` ($p=0,3241$ vs $p_{\text{crops}}=0,1749$).
- **Isolamento da Causa:** a divergência decorre da resamostragem espacial bilinear aplicada em `build_dw_annual_2025()` na reprojeção para a grade MapBiomas 10m (`mb_proj`), que suaviza pixels de borda contra a matriz florestal circundante. Na extração mensal (`11_extract_analytical_dataset.py`), as bandas foram amostradas na resolução nativa do Sentinel-2 sem bilinear, e normalizadas mês a mês.
- **Impacto Metodológico:** H1 ($\Delta H > 0$) e H2a ($\Delta \text{JSD} > 0$) mantêm-se suportadas sob ambas as métricas. Em H2b, a magnitude do efeito negativo de $S$ é amplificada pela divergência na borda, mas o sinal permanece estritamente negativo. H4 permanece com zero casos em ambas as abordagens.

---

## 7. Síntese Geral da Auditoria

1. **Pesos e Inclusão:** $100\%$ dos 5,35 bilhões de pixels elegíveis possuem probabilidade de inclusão positiva. Pesos de desenho e pesos de área são consistentes e fecham a população alvo em pixels e hectares com desvio inferior a $0,0005\%$.
2. **Censo:** a taxa de discordância de $14,285\%$ é um dado censitário e não possui incerteza amostral de população finita.
3. **Bootstrap Espacial:** o Spatial Block Bootstrap de 30 km é estatisticamente adequado para lidar com a dependência espacial, com sensibilidade pós-estratificada confirmando a robustez dos contrastes H1, H2a, H2b e H3.
4. **Identidade Temporal:** a divergência quantificada entre o vetor anual resamostrado e a média mensal nativa é documentada como uma diferença de definição computacional de escala e suavização espacial, não como erro oculto.

---
*Fim do documento de auditoria.*
