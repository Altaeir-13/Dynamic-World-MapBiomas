# Síntese Científica Didática — Dynamic World × MapBiomas no MATOPIBA (2025)

*(Para quem tem formação em Ciência da Computação. Todos os números vêm de `tables/` congeladas.)*

## 1. A ideia em um parágrafo
Dois mapas de lavoura em 10 m — **Dynamic World (DW)** e **MapBiomas (MB)** — foram comparados em 2025 no MATOPIBA. Nenhum é verdade de campo, então a pergunta não é "quem acertou", e sim **"onde discordam e a discordância se associa a sinais de incerteza do DW e a bordas?"**.

## 2. O que NÃO fizemos (importante)
- **Não treinamos nenhum modelo de ML**, não houve fine-tuning, nem treino/validação/teste em sentido de ML.
- DW e MB são modelos de terceiros; usamos suas saídas.
- O único modelo ajustado foi uma **regressão logística** para medir associações (não para prever).
- Não há ground truth independente. Não há inferência causal.

## 3. Como foi feito (resumo)
1. Domínio: 337 municípios (MA 135, TO 139, PI 33, BA 30) + faixa de 5 km.
2. No Earth Engine: DW 2025 agregado (dia → mês → ano, peso igual por mês válido), exigindo ≥8 meses válidos; MB com lavoura = classes {19, 36}.
3. Cada pixel recebe um regime: **AA** (ambos lavoura), **AN** (MB lavoura, DW não), **NA** (MB não, DW lavoura), **NN** (nenhum). Discordância = AN + NA.
4. Amostra aleatória estratificada: 20.000 pontos (e 40.000 como checagem) com pesos de desenho.
5. Para cada ponto: entropia anual (H), divergência temporal (JSD), estabilidade (S) e distância às bordas.
6. Testes (H1–H4), regressão logística e **bootstrap espacial** (blocos de 30 km, 1.999 réplicas).

## 4. Um aprendizado metodológico que virou regra
No início, o DW era processado dentro de "fatias" (slices) do mapa, e os resultados mudavam conforme a fatia — um artefato computacional. A solução foi fixar um **domínio científico único (MATOPIBA + 5 km)** e usar as fatias só para paginar o processamento (por limites do GEE). Foi comprovado que a paginação final não altera o resultado (≈100% de invariância em 1.000 pontos).

## 5. Resultados em números
| Quantidade | Valor |
|---|---|
| Discordância (censo wall-to-wall) | 14,285% (concordância 85,715%) |
| Quantidade vs. alocação | 4,989 pp vs. 9,296 pp (maior parte é erro de **localização**) |
| Discordância por UF | MA 10,97% · TO 5,91% · PI 21,81% · BA 27,92% |
| Composição ponderada | NN 83,25% · AN 9,66% · NA 4,66% · AA 2,44% |

| Hipótese | Efeito | IC espacial 95% | Veredito |
|---|---|---|---|
| H1 entropia | +0,0162 (d=0,318) | [0,0103; 0,0221] | Sustentada (pequeno-moderado) |
| H2a JSD | +0,0179 (d=0,529) | [0,0140; 0,0218] | Sustentada |
| H2b estabilidade | −0,4179 (d=−1,609) | [−0,4318; −0,4034] | Sustentada (muito grande) |
| H3 bordas | 47,5% (0–10 m) → 11,9% (≥250 m) | por faixa, ver relatório | **Parcial** (não monotônica) |
| H4 discordância robusta | 0 de 5.143 pontos | — | **Não sustentada** |

## 6. Como ler os resultados
- **Entropia** mede o quão "indeciso" o DW está; discordantes são um pouco mais indecisos (diferença pequena, pois a entropia é alta em geral, média 0,84).
- **Estabilidade S** (fração de meses em que a classe mensal coincide com a anual) é o sinal mais forte: em pontos discordantes a S média é 0,05, contra 0,47 nos concordantes.
- **Bordas:** a discordância é ~4× maior a menos de 30 m de uma borda temática do que a ≥250 m. Mas a queda não é perfeitamente monotônica (30–60 m ≥ 10–30 m).
- **H4 = 0:** nenhuma discordância "limpa" (baixa entropia + baixa JSD + alta estabilidade + longe da borda). O filtro mais restritivo é "S alta" (só 45 pontos); isso sugere que, nos critérios testados, discordar quase sempre vem com instabilidade temporal. Isso **não** prova que o DW erre.
- **Regressão:** pseudo-R² de McFadden = 0,488 (não é "48,8% da variância explicada"). Em OR: +0,10 em S → OR 0,309; +100 m de distância → OR 0,437. PI×BA deixa de ser significativo com IC espacial.

## 7. Por que bootstrap espacial?
Pontos próximos se parecem (autocorrelação). O semivariograma indicou alcance prático de 25,62 km, arredondado para blocos de 30 km. Reamostrar blocos (não pontos) dá ICs mais honestos; ICs "analíticos" ignoram essa dependência.

## 8. Robustez (executada)
- 20k vs 40k: discordância 14,31% vs 14,31% — praticamente idêntico.
- Crosswalk estrito (só classe 19): 14,28%.
- MB estável 2017–2025: discordância 12,13%; relação borda/núcleo cai de 3,87 para 2,98.
- Blocos 10/20/40 km: ICs variam, conclusões iguais.

**Não executadas:** sensibilidade ≥6 meses e suporte 30 m.

## 9. O que se pode e não se pode afirmar
| Categoria | Texto |
|---|---|
| Observado | ~14% de discordância; associada a maior H e JSD, menor S, proximidade a bordas |
| Sustentado | Discordância correlaciona-se com instabilidade temporal do DW e com bordas |
| Hipótese não testada | Que isso seja causado por fenologia, mosaicos, definição de classe ou erro específico de um produto |
| Não concluir | Qual produto está certo; causalidade; outros anos/regiões; áreas com <8 meses válidos (21,7% do domínio) |

## 10. Limitações a reconhecer
Sem ground truth; conceitos de classe diferentes; possível dependência entre produtos; 21,7% do domínio fora do critério temporal (≈51% do MA); ICs analíticos aproximados; sem commit Git dos resultados.
