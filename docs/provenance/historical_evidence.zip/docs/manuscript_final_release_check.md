# Fechamento Editorial e de Proveniência Pré-Manuscrito

> **Data de Emissão:** 11 de outubro de 2026  
> **Status:** Verificação Final de Fechamento Editorial e Proveniência  
> **Documento:** `docs/manuscript_final_release_check.md`  
> **Veredito:** `MANUSCRIPT RELEASE: APPROVED`

---

## 1. Área Censitária Correta e Rigorosa Diferenciação

### 1.1. Valores Censitários Wall-to-Wall Autoritativos
A consulta ao quadro amostral censitário oficial (`tables/sampling_frame_10m.csv`) consolida os parâmetros exatos do domínio elegível de 10 m no MATOPIBA ($n_{\text{valid\_months}} \ge 8$):

- **Área Elegível Total:** **$52.342.114,75\text{ ha}$** ($5.354.669.418$ células de 10 m).
- **Área de Concordância AA (Acordo Lavoura):** **$1.274.056,40\text{ ha}$** ($2,4341\%$).
- **Área de Discordância AN (MapBiomas Lavoura, DW Não):** **$5.044.314,15\text{ ha}$** ($9,6372\%$).
- **Área de Discordância NA (DW Lavoura, MapBiomas Não):** **$2.432.863,07\text{ ha}$** ($4,6480\%$).
- **Área de Concordância NN (Acordo Não-Lavoura):** **$43.590.881,12\text{ ha}$** ($83,2807\%$).

**Soma das Áreas Discordantes (AN + NA):**
$$\text{Área Discordante Censitária} = 5.044.314,15\text{ ha} + 2.432.863,07\text{ ha} = \mathbf{7.477.177,23\text{ ha}}$$

**Taxa Censitária de Discordância:**
$$\text{Taxa Censitária} = \frac{7.477.177,23\text{ ha}}{52.342.114,75\text{ ha}} \times 100 = \mathbf{14,2852\%}$$
*(Em contagem censitária de pixels de 10 m: $766.304.630 / 5.354.669.418 = 14,3110\%$).*

### 1.2. Diferenciação com a Estimativa Amostral Ponderada
Diferencia-se rigorosamente a taxa censitária da estimativa pontual amostral calculada sobre os 20.000 pontos da Master Sample (`tables/descriptive_regime_proportions.csv`):
- **Área Ponderada Discordante Estimada:** **$7.479.568,87\text{ ha}$**;
- **Taxa Ponderada de Discordância (Amostra 20k):** **$14,3148\%$** ($\approx \mathbf{14,31\%}$; IC 95%: $[13,79\%, 14,84\%]$).

### 1.3. Origem e Eliminação do Valor Espúrio "30.957.514 ha"
O valor de $30.957.514\text{ ha}$ que constava em uma linha de tabela de rascunho anterior foi identificado como uma alucinação/concatenação textual espúria gerada em versões preliminares de documentação. O valor é fisicamente impossível no estudo, uma vez que a discordância total no MATOPIBA é de ~7,48 milhões de hectares dentro de um universo elegível de 52,34 milhões de hectares. Todas as tabelas e relatórios foram corrigidos para exibir estritamente $7.477.177\text{ ha}$ ($14,2852\%$) para o censo e $7.479.569\text{ ha}$ ($14,31\%$) para a amostra.

---

## 2. Confirmação das Categorias de Distância

### 2.1. Diagnóstico do Limite de 250 m nos 1.035 Casos de Lavoura Divergente
A auditoria dos 1.035 pontos com inversão lavoura/não-lavoura revelou que:
- Exatamente **866 pontos** possuem distância à borda truncada exatamente em **$250,0\text{ m}$**.
- O script diagnóstico preliminar utilizava `bins=[-1, 10, 30, 60, 100, 250, np.inf]` com `right=True`, o que causava o fechamento $(100, 250]$ na categoria 100–250 m, capturando os 866 pontos de 250 m e inflando essa faixa para 952 casos, deixando $\ge 250\text{ m}$ erroneamente com zero.

### 2.2. Distribuição Corrigida sob Intervalos Mutuamente Exclusivos $[a, b)$
Aplicando a convenção padrão do protocolo (`right=False`, $[0, 10)$, $[10, 30)$, $[30, 60)$, $[60, 100)$, $[100, 250)$, $[250, \infty)$):
- **$\ge 250\text{ m}$:** **$866$ casos ($83,67\%$)**;
- **$100\text{--}250\text{ m}$:** **$88$ casos ($8,50\%$)**;
- **$30\text{--}60\text{ m}$:** **$25$ casos ($2,42\%$)**;
- **$60\text{--}100\text{ m}$:** **$23$ casos ($2,22\%$)**;
- **$10\text{--}30\text{ m}$:** **$19$ casos ($1,84\%$)**;
- **$0\text{--}10\text{ m}$:** **$14$ casos ($1,35\%$)**.
- **Total:** **$1.035$ casos ($100,0\%$)**.

*Interpretação Fenomenológica:* No interior profundo da paisagem ($\ge 250\text{ m}$), existem 35.382 pontos na amostra de 40k. Os 866 casos de divergência representam uma taxa de apenas **$2,45\%$** ($866 / 35.382$), concentrada quase exclusivamente em pixels de quase-empate absoluto entre lavoura e vegetação natural (margem média de apenas 0,0147).

### 2.3. Auditoria do Pipeline Principal de H3
Auditamos o código oficial de H3 em [`src/analysis/03_hypothesis_tests_h1_h4.py`](file:///c:/Users/Altair/Documents/Dynamic%20World%20x%20MapBiomas/Dynamic-World-MapBiomas/src/analysis/03_hypothesis_tests_h1_h4.py) (linhas 165–170) e a tabela gerada [`tables/hypothesis_h3_distance_bins.csv`](file:///c:/Users/Altair/Documents/Dynamic%20World%20x%20MapBiomas/Dynamic-World-MapBiomas/tables/hypothesis_h3_distance_bins.csv):
- O código de H3 **já utilizava estritamente `right=False`**:  
  `main["dist_bin"] = pd.cut(main["distance_edge_min_m"], bins=bins, labels=labels, right=False)`
- Os pontos com $250,0\text{ m}$ foram corretamente classificados na categoria $\ge 250\text{ m}$ desde a execução original ($17.691$ pontos na faixa $\ge 250\text{ m}$, taxa de discordância de $11,87\%$).
- **Veredito:** Os resultados principais de H3 não sofreram nenhuma contaminação e permanecem 100% corretos e preservados. O problema existia estritamente no script diagnóstico de inspeção dos 1.035 casos, o qual foi devidamente corrigido.

---

## 3. Manifesto SHA-256 e Validação Criptográfica

### 3.1. Procedimento Determinístico e Limpeza de Auto-Inclusão
O manifesto de integridade foi regenerado com critérios estritos:
1. **Exclusão de Manifestos:** O próprio `tables/manuscript_results_manifest.csv` e o arquivo `tables/manuscript_results_checksums.sha256` foram excluídos da listagem de dados catalogados.
2. **Reconciliação de Schema:** O schema oficial foi restaurado para conformidade com consumidores existentes:  
   `category,relative_path,sha256,size_bytes,description`
3. **Escopo dos Artefatos:** 33 artefatos essenciais catalogados (21 tabelas estatísticas + 6 figuras de publicação + 1 emenda de protocolo + 3 contornos de referência + 2 parquets processados).

### 3.2. Passe de Verificação Independente Pós-Gravação
Após a gravação de `tables/manuscript_results_manifest.csv` e `tables/manuscript_results_checksums.sha256`, executou-se uma rotina independente que leu cada linha e comparou o hash registrado contra o arquivo físico em disco.

**Resultado da Verificação:**
$$\mathbf{ALL\ 33\ ARTIFACT\ HASHES\ VERIFIED\ 100\%\ MATCH\ ON\ DISK}$$

### 3.3. Tabela Completa de Hashes Oficiais
| Categoria | Caminho Relativo | Hash SHA-256 | Tamanho |
|---|---|---|---|
| `descriptive_tables` | `tables/descriptive_regime_proportions.csv` | `74fbf2865ca7d881115837c214f892952de9058e8091673a20ae8eb02f635a7f` | 880 B |
| `descriptive_tables` | `tables/descriptive_state_proportions.csv` | `5033c5cfe8fc7ae3f9e9c31aec07e8005d77a8427cf51a944d95921aa0d2ff97` | 1.094 B |
| `descriptive_tables` | `tables/descriptive_continuous_indicators.csv` | `0553c44c21bfc9c46fb9752c35c64b8dae1bd8ecffd659aaf99755a798cea15d` | 3.518 B |
| `descriptive_tables` | `tables/descriptive_robust_40k_comparison.csv` | `ed2d4dd57963bb9b652c8f6e28eb85d003454810e4f206a810b066e2cfd064aa` | 440 B |
| `h1_table` | `tables/hypothesis_h1_results.csv` | `61444d599ebc06054d718408b19670a2d002a85c497c74a8d1511f6744981bc1` | 567 B |
| `h2_table` | `tables/hypothesis_h2_results.csv` | `2d428401567da864c669de0a9ff075ef0e9bdd28c26b884369fb5b11acb03a9f` | 867 B |
| `h3_table` | `tables/hypothesis_h3_distance_bins.csv` | `577aefc58c6d466882cf2c37cb802405a558931ba7d21821e4e987ea2ddbd900` | 773 B |
| `h4_table` | `tables/hypothesis_h4_robust_disagreement.csv` | `7ef23029ecda4658ebf55d04492a957a50547b5c1107813fde842cf09b1c4d98` | 436 B |
| `regression_table_primary` | `tables/regression_logistic_rescaled_odds_ratios.csv` | `16f5a95b9c41e378871bd4bc5587904dd6522a3d18a7976ef97b018cff185b18` | 1.128 B |
| `regression_table_supplementary` | `tables/regression_logistic_primary_model.csv` | `4954682d087fce6ea9c309d84e7c7d1fe78f0ff1042e078f0f81aa6f3ba9a0f5` | 1.279 B |
| `regression_table_comparison` | `tables/regression_model_comparison.csv` | `d6f0f82b2ce034fa300252eea713624ca93d42e368caf1b0093b86fe53c22ef6` | 918 B |
| `regression_table_diagnostics` | `tables/regression_collinearity_diagnostics.csv` | `c7ccfe1ce00270ad6eaa724a9e80531747ae6c822417fd6445d7583a37b951c0` | 153 B |
| `spatial_bootstrap_tables` | `tables/spatial_semivariogram_parameters.csv` | `60a4081c5b74f355647c382206af85978501295d92166c01722346619dc14a15` | 207 B |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_contrasts.csv` | `61f6c4ff43322bc6d734cfdb7ca60942007ceb24345d3e0b73c9f28df1d50c7c` | 529 B |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_distance_bins.csv` | `57f781df5e7bc055c65f9046c4f0611a91d1e434771df6bc63914a19da40d588` | 585 B |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_logistic_model.csv` | `fc2c6a0b226e6d1eb973e4b7bca0612c974868f7422f6d2b638a16dbd759ba08` | 1.304 B |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_block_sensitivity.csv` | `0fa0cf9a1efbfebbe48f51a44e5ce6c321034f5df55aa3e3518aeb3d222d4f23` | 492 B |
| `robustness_tables` | `tables/robustness_r1_sample_size_comparison.csv` | `df36cc4e443393bddf8a3aabb00bcc4864596e443bf62f9ca6e293c2a0ac25bf` | 286 B |
| `robustness_tables` | `tables/robustness_r2_strict_crosswalk_comparison.csv` | `bc72f586a6f02471d4141a9c849a80221190fb86554870ec31eb57afbf106c0e` | 193 B |
| `robustness_tables` | `tables/robustness_r3_mapbiomas_stability_subset.csv` | `7d9ab008c05909bfeda17169b1e2415ed9b4ad86642c87a48497f10754d5315c` | 229 B |
| `robustness_tables` | `tables/robustness_comprehensive_summary.csv` | `98a5cd7f6948ea774faf5120b9092e319524887dd6db5b11c79882a2e4f478de` | 990 B |
| `figures` | `figures/fig1_composition_regimes.png` | `51ece63120ed9a647195801948683c818e073d75d4ca7512fb8efa4d3e6886b8` | 227.194 B |
| `figures` | `figures/fig2_h_annual_distribution.png` | `4493343a86970bd253a0efa609ae8aa2a6fa21cb51072f3d7ba4531e7d35c35d` | 233.690 B |
| `figures` | `figures/fig3_jsd_temporal_distribution.png` | `7daadf08809869030430391628296616cf0e822bbf696fe96b06b99cb872d615` | 233.585 B |
| `figures` | `figures/fig4_stability_distribution.png` | `a41e46bc50ec2fdd6f9fdcf2b8a8b8e641045a1f37959f8eb85694f97f579077` | 174.628 B |
| `figures` | `figures/fig5_disagreement_by_distance_bin.png` | `acbc8347f29728d902fcf67aed8e8e5647240c74ab2f1970a1ab1b946efade1a` | 197.790 B |
| `figures` | `figures/fig6_h4_robust_disagreement_characterization.png` | `120133a7cf6e8bbb2c7d2a4dae8c940feaea73cc425bea15877e0270ced90c23` | 671.099 B |
| `protocol_amendment` | `docs/protocol_amendment_checkpoint_3d.md` | `22df9a1431123974509a655cb4be3b22c14abe7ff5700726513c37068dbafcb5` | 3.492 B |
| `boundary_provenance` | `data/reference/matopiba_boundary.geojson` | `716df1361fee63c453ef96e7a59c92b3317175ed98e83d1cb053b37e3b3c20c8` | 1.236.998 B |
| `boundary_provenance` | `data/reference/matopiba_municipalities.csv` | `a6adf8e6d2500be1ab788f2128b7db263260455db95bea0d9e3ca173ef3266ca` | 11.993 B |
| `boundary_provenance` | `data/reference/matopiba_states.geojson` | `68c75dcb99ca2b06a30e98324b5c9427729d9c58efb2c7ea858eb67356cf81ca` | 673.886 B |
| `processed_datasets` | `data/processed/dw_monthly.parquet` | `6254011b2c31e499f113ec47231a435831a22eb1fc9c0b75cf33fe299d80874f` | 34.847.652 B |
| `processed_datasets` | `data/processed/samples_annual.parquet` | `fb454ca04b671b5955170517a3072bf8762b59a1e491578883a6e76bcf0fc61f` | 7.958.753 B |

---

## 4. Origem dos Intervalos da Regressão e Rigor Epistemológico

### 4.1. Tabela Autorizada de Odds Ratios Redimensionados
Todos os coeficientes da regressão logística ponderada multivariada foram recalculados sobre o modelo corrigido. Os Odds Ratios escalonados e seus intervalos foram consolidados em [`tables/regression_logistic_rescaled_odds_ratios.csv`](file:///c:/Users/Altair/Documents/Dynamic%20World%20x%20MapBiomas/Dynamic-World-MapBiomas/tables/regression_logistic_rescaled_odds_ratios.csv):

| Termo | Incremento / Contraste | OR Pontual | IC 95% Analítico | IC 95% Espacial (Bootstrap 30 km) | Suporte Espacial ($1 \notin \text{IC}$) | Tabela Fonte |
|---|---|---|---|---|---|---|
| `distance_edge_min_m` | $+100\text{ m}$ | **$0,360$** | $[0,335; 0,387]$ | **$[0,319; 0,404]$** | **Sim** (fator protetor forte) | `regression_logistic_rescaled_odds_ratios.csv` |
| `entropy_annual` | $+0,10$ | **$1,421$** | $[1,278; 1,578]$ | **$[1,036; 1,988]$** | **Sim** (associação positiva) | `regression_logistic_rescaled_odds_ratios.csv` |
| `stability` | $+0,10$ | **$0,925$** | $[0,898; 0,952]$ | **$[0,861; 0,992]$** | **Sim** (fator protetor significante) | `regression_logistic_rescaled_odds_ratios.csv` |
| `jsd_temporal` | $+0,01$ | **$0,987$** | $[0,966; 1,009]$ | **$[0,914; 1,059]$** | Não ($1 \in \text{IC}$ em ambos) | `regression_logistic_rescaled_odds_ratios.csv` |
| `state_MA` | vs BA (ref.) | **$0,378$** | $[0,330; 0,434]$ | **$[0,242; 0,575]$** | **Sim** (menor chance que BA) | `regression_logistic_rescaled_odds_ratios.csv` |
| `state_TO` | vs BA (ref.) | **$0,160$** | $[0,141; 0,181]$ | **$[0,114; 0,225]$** | **Sim** (menor chance que BA) | `regression_logistic_rescaled_odds_ratios.csv` |
| `state_PI` | vs BA (ref.) | **$0,798$** | $[0,709; 0,900]$ | **$[0,507; 1,212]$** | **Não** ($1 \in \text{IC}$ no bootstrap espacial) | `regression_logistic_rescaled_odds_ratios.csv` |

### 4.2. Confirmação do Contraste Piauí versus Bahia
O contraste estadual `state_PI` apresenta $\text{OR} = 0,798$ com IC analítico $[0,709; 0,900]$ ($p < 0,001$). Contudo, sob o procedimento espacialmente honesto de *Spatial Block Bootstrap* com blocos primários de 30 km (alcance empírico de 25,62 km; 1.999 réplicas), o intervalo de confiança a 95% expande-se para **$[0,507; 1,212]$**, cobrindo o valor nulo de $1,0$.  
*Achado Metodológico:* Este é um dos principais destaques do artigo, demonstrando empiricamente que a dependência espacial infla a significância analítica clássica e que, sob inferência honesta, Piauí e Bahia não diferem significativamente na propensão de discordância condicional.

### 4.3. Linguagem Epistemológica Ajustada
1. **Hipótese H4:** Substituíram-se afirmações genéricas de "imunidade total" por descrição analítica exata:  
   *"Todos os 207 casos observados de H4 apresentaram concordância perfeita de argmax anual entre o raster canônico e a média mensal reconstruída, situando-se afastados de bordas e em zonas de maior separabilidade probabilística. Isso descreve o subconjunto sob os critérios fixados, mas não deve ser extrapolado como prova matemática absoluta de insensibilidade a qualquer outro esquema alternativo de agregação."*
2. **Hipótese H2:** Substituiu-se a alegação de causalidade por consistência descritiva:  
   *"A estabilidade numérica das estimativas pontuais de H2 ao restringir a análise aos 18.350 pontos com concordância estrita de argmax indica robustez dos efeitos observados, mas a seleção de subconjunto não constitui demonstração causal de ausência de sensibilidade a outros processamentos."*

---

## 5. Resumo das Alterações Realizadas

1. **Correção dos Limites de Intervalo no Script Diagnóstico:** Corrigiu-se `scratch/validate_full_40k_identity.py` para usar `right=False`, transferindo os 866 pontos de 250 m da categoria 100–250 m para $\ge 250\text{ m}$.
2. **Sincronização dos Intervalos de Regressão:** Reexecutou-se `src/analysis/04_weighted_regression_model.py` para integrar perfeitamente os intervalos derivados de `tables/spatial_bootstrap_logistic_model.csv`.
3. **Limpeza e Padronização do Manifesto:** Eliminou-se a auto-inclusão dos arquivos de manifesto e checksums, preservou-se o schema `category,relative_path,sha256,size_bytes,description` e validaram-se todos os 33 hashes em disco.
4. **Alinhamento Documental Completo:** Atualizaram-se `docs/final_corrected_results_validation.md`, `docs/manuscript_ready_scientific_summary.md` e `docs/manuscript_blueprint.md`.

---

## 6. Pendências Restantes

- **Nenhuma pendência técnica, matemática ou de inferência estatística restante.**
- Os dados e resultados estão congelados, verificados e criptograficamente protegidos.
- A próxima etapa autorizada é exclusivamente a redação do artigo científico.

---

## 7. Veredito Final

$$\mathbf{MANUSCRIPT\ RELEASE:\ APPROVED}$$
