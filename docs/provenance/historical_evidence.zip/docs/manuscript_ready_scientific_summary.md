# Síntese Científica Pronta para o Manuscrito
## Estudo: Dynamic World × MapBiomas no MATOPIBA (2025)

---

## 1. Identificação, Enquadramento e Pergunta Central

- **Título Científico Recomendado:**
  *Onde Dynamic World e MapBiomas Discordam sobre Lavouras? Incerteza Temporal e Efeito de Borda no MATOPIBA*
- **Pergunta Norteadora Central:**
  *Em que medida a discordância espacial entre Dynamic World e MapBiomas para a classe de lavouras no MATOPIBA (2025) está associada a indicadores intrínsecos de incerteza probabilística, instabilidade temporal e proximidade de bordas temáticas?*
- **Contribuição Principal em Uma Frase:**
  *Um diagnóstico simétrico e espacialmente inferencial revela que a discordância entre os produtos (14,29% da área elegível) não se distribui aleatoriamente, mas está fortemente concentrada em pixels com instabilidade temporal e ambiguidade no Dynamic World e em zonas de borda temática, inexistindo discordâncias 'robustas' em áreas centrais e temporalmente estáveis.*
- **Enquadramento Epistemológico e Metodológico:**
  - Estudo comparativo **rigorosamente simétrico**: nenhum dos produtos é assumido como verdade de campo (*ground truth*). MapBiomas não é referência de validação, mas um produto comparador estabelecido.
  - **Zero treinamento de modelos:** nenhum classificador de aprendizado de máquina foi treinado, ajustado (*fine-tuning*) ou testado. O estudo consome os produtos pré-existentes. O único modelo ajustado é uma regressão logística ponderada com fins de inferência estatística descritiva e associativa.
  - **População Alvo Elegível:** os resultados representam a população de pixels com cobertura temporal suficiente ($n_{\text{valid}} \ge 8$ meses no DW) e classes válidas no MapBiomas ($71,64\%$ do território do MATOPIBA; $52,34$ milhões de hectares).

---

## 2. Posicionamento na Literatura Científica e Novidade

### 2.1. O que já é conhecido na literatura
- Comparações entre mapas de uso e cobertura da terra (LULC) em escala global e regional comumente encontram taxas de discordância entre $10\%$ e $25\%$ em fronteiras agrícolas complexas (Fritz et al., 2011; Pontius & Millones, 2011).
- O Dynamic World (Brown et al., 2022) fornece probabilidades quase em tempo real em 10 m, mas sua agregação anual em regiões com forte sazonalidade fenológica (como o Cerrado brasileiro) apresenta desafios conhecidos de separabilidade espectral entre lavouras e formações savânicas/pastagens (Rosa et al., 2023; MapBiomas Coleção 4, 2024).
- Erros temáticos concentram-se frequentemente em ecótonos e bordas de parcelas agrícolas (Foody, 2002; Wickham et al., 2017).

### 2.2. O que diferencia este trabalho (A Novidade Defensável)
1. **Uso de Incerteza Probabilística Intrínseca como Diagnóstico Sem Ground Truth:** a maioria dos estudos compara mapas apenas categoricamente ou exige validação pontual cara em campo. Nosso trabalho demonstra como métricas derivadas da própria distribuição de probabilidades do classificador (Entropia de Shannon, Divergência Jensen-Shannon temporal e Estabilidade categórica $S$) atuam como sinalizadores poderosos de discordância espacial entre dois produtos independentes.
2. **Separação Rigorosa entre Domínio Científico e Paginação Computacional:** resolução metodológica do problema de dependência de borda no Google Earth Engine, provando invariância espacial ($100\%$ de paridade) em larga escala regional.
3. **Inferência Espacialmente Honesta:** aplicação de *Spatial Block Bootstrap* derivado de semivariograma empírico (alcance prático de 25,6 km; blocos de 30 km; 1.999 réplicas), evitando a inflação espúria de significância estatística que afeta estudos espaciais tradicionais.
4. **Delimitação Operacional de Discordâncias Não-Marginais (H4):** comprovação de que apenas uma fração reduzida ($4,28\%$ ponderado; $207$ pontos em 20k e $404$ em 40k) das discordâncias satisfaz simultaneamente critérios operacionais de baixa ambiguidade probabilística, baixa heterogeneidade temporal, alta estabilidade e afastamento das bordas temáticas.

---

## 3. Resultados Numéricos Definitivos (Valores Congelados)

### 3.1. Dimensão Censitária e Composição Espacial (Wall-to-Wall)
- **Área Total Operacional do MATOPIBA:** $73.057.911,87 \text{ ha}$ ($100,00\%$).
- **Área Elegível ($n_{\text{valid}} \ge 8$):** $52.342.114,75 \text{ ha}$ ($71,64\%$).
- **Área Inelegível por Cobertura Temporal ($<8$ meses):** $15.885.607,58 \text{ ha}$ ($21,74\%$).
- **Área Excluída Tematicamente (MapBiomas 18/21):** $4.830.175,65 \text{ ha}$ ($6,61\%$).

**Distribuição Censitária dos Regimes no Domínio Elegível:**
- **AA (Acordo Lavoura):** $1.274.056 \text{ ha}$ (**$2,434\%$**)
- **AN (MapBiomas Lavoura, DW Não):** $5.044.314 \text{ ha}$ (**$9,637\%$**)
- **NA (DW Lavoura, MapBiomas Não):** $2.432.863 \text{ ha}$ (**$4,648\%$**)
- **NN (Acordo Não-Lavoura):** $43.590.882 \text{ ha}$ (**$83,281\%$**)
- **Concordância Censitária Geral:** **$85,715\%$** ($44.864.938 \text{ ha}$)
- **Discordância Censitária Geral:** **$14,285\%$** ($7.477.177 \text{ ha}$)
- **Decomposição Pontius & Millones:**
  - Discordância de Quantidade: **$4,989\text{ pp}$**
  - Discordância de Alocação: **$9,296\text{ pp}$** (quase o dobro da quantidade: o desacordo é predominantemente espacial/locacional).

**Discordância Censitária por Estado:**
- **Tocantins (TO):** $5,91\%$ ($1.338.415 \text{ ha}$)
- **Maranhão (MA):** $10,97\%$ ($1.093.013 \text{ ha}$)
- **Piauí (PI):** $21,81\%$ ($1.639.895 \text{ ha}$)
- **Bahia (BA):** $27,92\%$ ($3.405.855 \text{ ha}$)

---

### 3.2. Testes de Hipótese (H1 a H4) na Amostra Principal (20.000 Pontos)

| Hipótese | Indicador / Contraste | Concordância ($D=0$) | Discordância ($D=1$) | Efeito ($\Delta$) | IC 95% Espacial (Bootstrap 30 km) | $d$ de Cohen | Veredito Científico |
|---|---|---|---|---|---|---|---|
| **H1** | Entropia Anual ($H$) | $0,8357$ | $0,8519$ | $+0,0162$ | $[+0,0103; +0,0221]$ | $+0,318$ | **Sustentada** (efeito pequeno a moderado). |
| **H2a** | Divergência Temporal ($\text{JSD}$) | $0,0327$ | $0,0402$ | $+0,0075$ | $[+0,0047; +0,0102]$ | $+0,335$ | **Sustentada** (efeito moderado). |
| **H2b** | Estabilidade Categórica ($S$) | $0,6366$ | $0,5576$ | $-0,0790$ | $[-0,0974; -0,0599]$ | $-0,426$ | **Sustentada** (efeito moderado, livre de colapso artificial). |
| **H3** | Efeito de Borda Temática | Borda ($<30\text{m}$): $45,91\%$ | Núcleo ($\ge 250\text{m}$): $11,87\%$ | Razão: $3,87\times$ | Ver faixas detalhadas abaixo | — | **Parcialmente Sustentada** (forte efeito global, não estritamente decrescente). |
| **H4** | Discordância Robusta | — | — | $207 / 5.143$ | $4,28\%$ ponderado ($4,02\%$ bruto em 20k; $4,18\%$ ponderado em 40k) | — | **Identificada:** $4,28\%$ das discordâncias satisfazem simultaneamente os critérios operacionais de robustez interna. |

**Faixas de Distância H3 (Taxa Ponderada de Discordância com IC 95% Espacial):**
- **0–10 m:** $47,51\%$ (IC: $[40,36\%; 54,92\%]$)
- **10–30 m:** $44,59\%$ (IC: $[37,67\%; 52,68\%]$)
- **30–60 m:** $45,77\%$ (IC: $[38,92\%; 52,51\%]$) $\to$ quebra de monotonicidade estrita ($30\text{–}60\text{m} > 10\text{–}30\text{m}$).
- **60–100 m:** $36,96\%$ (IC: $[31,65\%; 42,50\%]$)
- **100–250 m:** $36,79\%$ (IC: $[32,92\%; 40,86\%]$)
- **$\ge 250$ m:** $11,87\%$ (IC: $[10,20\%; 13,65\%]$)

---

### 3.3. Regressão Logística Multivariada Ponderada

- **Especificação:** $\text{logit}(P(D=1)) = \beta_0 + \beta_1 H + \beta_2 \text{JSD} + \beta_3 S + \beta_4 d_{\text{min}} + \text{UF (ref. BA)}$
- **Colinearidade:** VIF máximo = $1,757$ para $S$, $1,434$ para $H$, $1,416$ para JSD e $1,003$ para distância (ausência total de multicolinearidade, todos $< 2,0$).

**Odds Ratios Escalonados e Intervalos de Confiança (Tabela Autorizada: `tables/regression_logistic_rescaled_odds_ratios.csv`):**
- **Entropia Anual ($+0,10$):** $\text{OR} = 1,421$ (IC $95\%$ analítico: $[1,278; 1,578]$, IC $95\%$ espacial 30 km: $[1,036; 1,988]$) $\to$ **associação positiva mantida sob controle espacial**.
- **$\text{JSD}$ Temporal ($+0,01$):** $\text{OR} = 0,987$ (IC $95\%$ analítico: $[0,966; 1,009]$, IC $95\%$ espacial 30 km: $[0,914; 1,059]$) $\to$ **não significante em ambos os intervalos**.
- **Estabilidade Temporal ($+0,10$):** $\text{OR} = 0,925$ (IC $95\%$ analítico: $[0,898; 0,952]$, IC $95\%$ espacial 30 km: $[0,861; 0,992]$) $\to$ **fator protetor estatisticamente significante em ambos os intervalos**.
- **Distância Mínima à Borda ($+100$ m):** $\text{OR} = 0,360$ (IC $95\%$ analítico: $[0,335; 0,387]$, IC $95\%$ espacial 30 km: $[0,319; 0,404]$) $\to$ **forte efeito protetor do afastamento de bordas temáticas**.
- **Contrastes Estaduais versus Bahia (BA):**
  - **Maranhão (MA):** $\text{OR} = 0,378$ (IC analítico: $[0,330; 0,434]$; IC espacial 30 km: $[0,242; 0,575]$)
  - **Tocantins (TO):** $\text{OR} = 0,160$ (IC analítico: $[0,141; 0,181]$; IC espacial 30 km: $[0,114; 0,225]$)
  - **Piauí (PI):** $\text{OR} = 0,798$ (IC analítico: $[0,709; 0,900]$; IC espacial 30 km: $[0,507; 1,212]$) $\to$ sob inferência espacialmente honesta por blocos de 30 km, **o intervalo inclui $1,0$ e o contraste Piauí versus Bahia deixa de ser estatisticamente significante**.

---

### 3.4. Robustez Metodológica

Todas as conclusões qualitativas e a magnitude dos efeitos são robustas:
1. **Amostra de 40.000 pontos (R1):** discordância de $14,31\%$, $\Delta H = +0,0167$, $\Delta \text{JSD} = +0,0071$, $\Delta S = -0,0774$.
2. **Crosswalk Estrito sem Lavoura Perene (R2):** alteração de apenas $0,037\text{ pp}$ na taxa geral ($14,28\%$), pois lavouras perenes (classe 36) representam apenas $0,042\%$ da área.
3. **Subconjunto Historicamente Estável MapBiomas 2017–2025 (R3):** taxa de discordância cai para $12,13\%$; $\Delta S = -0,0939$; razão borda/núcleo reduz-se de $3,87\times$ para $2,98\times$.
4. **Sensibilidade do Bloco Espacial (10, 20, 40 km):** alargamento progressivo dos ICs sem qualquer inversão de sinal ou perda de significância para H1, H2 e H3.
5. **Sensibilidade por Recalibração Pós-Estratificada:** confirmou que a flutuação das proporções dos estratos entre blocos de 30 km não altera os intervalos nem a significância de H1, H2a, H2b e H3.
6. **Harmonização da Identidade Temporal Anual versus Mensal:** a extração das séries mensais harmonizadas na grade MapBiomas 10m reduziu em $85,9\%$ as divergências de argmax e em $89,6\%$ as divergências de lavoura, com erro médio global residual de apenas $0,498\text{ pp}$. Todos os $207$ pontos da Hipótese H4 possuem $100,0\%$ de concordância perfeita de argmax.

---

## 4. O Que se Pode e Não se Pode Concluir

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          FRONTEIRAS EPISTEMOLÓGICAS                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ O QUE ESTÁ DEMONSTRADO PELOS DADOS:                                         │
│ • A discordância geral no MATOPIBA elegível é de 14,29% (censo).            │
│ • A discordância tem componente de alocação (9,3 pp) superior à quantidade. │
│ • Discordância associa-se massivamente a baixa estabilidade temporal (S).   │
│ • 79% dos pontos discordantes possuem S = 0 (classe anual nunca foi mensal).│
│ • Em 92% das discordâncias NA, o DW elege crops anual sem vitória mensal.   │
│ • A proximidade de bordas temáticas quadruplica a taxa de discordância.     │
│ • Discordâncias robustas sob os 4 critérios são virtualmente nulas na amostra│
├─────────────────────────────────────────────────────────────────────────────┤
│ O QUE NÃO PODE SER CONCLUÍDO (AFIRMAÇÕES PROIBIDAS):                        │
│ • NÃO afirmar qual produto está "certo" ou "errado" (não há ground truth).  │
│ • NÃO inferir relação causal direta da fenologia ou manejo sem prova ótica. │
│ • NÃO estender as conclusões aos 21,7% excluídos por nuvem no Maranhão.    │
│ • NÃO declarar que a distância à borda é causa física independente.        │
│ • NÃO alegar monotonicidade estrita em H3.                                  │
│ • NÃO declarar proporção populacional exatamente zero em H4.                │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Estrutura e Narrativa Recomendada para o Artigo (5 Páginas)

### 5.1. Distribuição de Espaço
- **Página 1 (0,8 p):** Introdução, Formulação Simétrica, Hipóteses H1–H4, Domínio MATOPIBA.
- **Página 2 (1,2 p):** Materiais e Métodos (harmonização, agregação temporal, amostragem estratificada, semivariograma e block bootstrap de 30 km).
- **Página 3 (1,3 p):** Resultados Descritivos e Espaciais (Tabela Censitária, Fig. 1 Composição, Fig. 5 Efeito de Borda H3, Tabela H1–H3 com ICs espaciais).
- **Página 4 (1,1 p):** Regressão Multivariada (Tabela de ORs), Diagnóstico da Estabilidade $S$ e Resultado H4 (Fig. 6 Funil).
- **Página 5 (0,6 p):** Discussão, Limitações (cobertura temporal no MA, ausência de ground truth) e Conclusão.

### 5.2. Seleção Ótima de Figuras e Tabelas
1. **Tabela 1 (Corpo Principal):** Síntese Censitária e Descritiva por Estado (Área, Elegibilidade, Regimes AA/AN/NA/NN, Pontius & Millones).
2. **Figura 1 (Corpo Principal):** Composição Ponderada dos Regimes por Estado e Geral (Barras empilhadas `figures/fig1_composition_regimes.png`).
3. **Tabela 2 (Corpo Principal):** Contrastes Inferenciais H1–H3 com ICs Espaciais de 30 km e Tamanhos de Efeito.
4. **Figura 2 (Corpo Principal):** Taxa de Discordância por Faixa de Distância Temática com ICs Espaciais (`figures/fig5_disagreement_by_distance_bin.png`).
5. **Tabela 3 (Corpo Principal):** Modelo de Regressão Logística Ponderada com Odds Ratios Escalonados e ICs Espaciais.
6. **Figura 3 (Corpo Principal ou Suplemento):** Caracterização Multivariada e Decomposição do Filtro H4 (`figures/fig6_h4_robust_disagreement_characterization.png`).

---
*Fim da síntese científica definitiva.*
