# Blueprint do Manuscrito (~5 páginas) — Dynamic World × MapBiomas no MATOPIBA

*Plano apenas; o artigo não foi redigido. Base: relatório retrospectivo e tabelas congeladas. Evento-alvo (brief): Space Week Nordeste 2026.*

## 1. Narrativa
Não é "cronologia de código". É: **(1)** produtos de lavoura divergem; **(2)** a discordância não é aleatória: associa-se a instabilidade temporal da probabilidade do DW e a bordas; **(3)** uma fração delimitada de 4,28% ponderado (207 pontos na amostra principal de 20k e 404 na robusta de 40k) satisfaz simultaneamente critérios de baixa ambiguidade probabilística, baixa heterogeneidade temporal, alta estabilidade e afastamento de bordas temáticas; **(4)** isso é associação estatística espacial, sem ground truth.

**Pergunta central:** *Em que medida a discordância Dynamic World × MapBiomas para lavoura no MATOPIBA (2025) se associa a incerteza temporal do DW e à proximidade de bordas temáticas?*

**Contribuição (uma frase):** Um diagnóstico espacialmente inferencial, baseado em amostragem probabilística e indicadores de incerteza probabilística, mostra que a discordância (~14%) está fortemente ligada à instabilidade temporal e às bordas, com apenas 4,28% ponderado satisfazendo simultaneamente critérios operacionais de alta estabilidade, baixa ambiguidade e afastamento das bordas.

**Três títulos candidatos**
1. "Onde Dynamic World e MapBiomas discordam sobre lavouras? Incerteza temporal e bordas no MATOPIBA"
2. "Discordância entre produtos LULC de 10 m como sinal de instabilidade temporal: o caso das lavouras no MATOPIBA em 2025"
3. "Entre probabilidades e mapas temáticos: diagnóstico espacial da discordância Dynamic World × MapBiomas"

## 2. Estrutura e distribuição (≈5 páginas)
| Seção | Páginas | Conteúdo |
|---|---|---|
| Introdução | 0,6 | Problema; lacuna; RQ; H1–H4; contribuição |
| Trabalhos relacionados | 0,4 | Comparação de LULC; DW; MapBiomas; incerteza e bordas; bootstrap espacial |
| Materiais e métodos | 1,5 | Domínio; crosswalk; agregação temporal; domínio fixo; amostragem; variáveis; modelos |
| Resultados | 1,5 | Ver §3 |
| Discussão | 0,6 | Interpretação; H4; limites |
| Conclusão | 0,2 | Síntese e trabalhos futuros |
| Referências | 0,2 | — |

## 3. Seção a seção
**Introdução** — Argumentos: LULC para políticas; discordância desconhecida; DW expõe probabilidades. Indispensável: RQ, hipóteses, "sem ground truth" e "sem treinamento de modelos". Fora: história do projeto.

**Trabalhos relacionados** — Compactos; [pendente de revisão bibliográfica; `references/`].

**Materiais e métodos** — Indispensável: 337 municípios; crosswalk {19,36}; regimes AA/AN/NA/NN; pipeline dia→mês→ano; `n_valid_months ≥ 8`; domínio MATOPIBA+5 km (slices só paginação); 16 estratos, 20k/40k, π e pesos; variáveis H, JSD, S, distâncias; logística; bootstrap por blocos 30 km (alcance 25,62 km; 1.999 réplicas). Experimentos descritos: amostragem, invariância de paginação (uma frase + referência ao suplemento). Fora do corpo: lotes GEE, π nulo, invalidações → **material suplementar**.

**Resultados** (ordem recomendada)
1. Composição e discordância (14,285% censo; 14,31% amostra; por UF).
2. H1–H2 (efeitos + ICs espaciais; destaque para S).
3. H3 (faixas) com ressalva de não monotonicidade estrita (relação inversa geral).
4. H4: Caracterização de discordâncias sob baixa ambiguidade probabilística e alta estabilidade (4,28% ponderado, 207 pontos em 20k / 404 em 40k).
5. Regressão (ORs escalonados; PI×BA).
6. Robustez em uma tabela.

**Discussão** — Distinguir observado/sustentado/não demonstrado. Limites: sem ground truth; 21,7% do domínio com <8 meses; sensibilidades ≥6 meses e 30 m não executadas; dependência entre produtos; inconsistência residual matemática ($\le 0,5\text{ pp}$).

**Conclusão** — Resultados principais; H4 (subconjunto de 4,28% satisfazendo simultaneamente critérios operacionais de baixa ambiguidade e alta estabilidade temporal); futuro: ground truth, ≥6 meses, 30 m, perfil mensal.

## 4. Figuras e tabelas (melhor relação informação/espaço)
| Item | Fonte | Justificativa |
|---|---|---|
| Tabela 1: regimes e UF | descriptive_*.csv | Dimensão do problema |
| Figura A: composição por UF | fig1 | Rápida |
| Tabela 2: H1–H3 efeitos + ICs | hypothesis_*; spatial_bootstrap_contrasts | Núcleo inferencial |
| Figura B: discordância por faixa | fig5 | H3 visual |
| Figura C: caracterização H4 | fig6 | Caracterização do subconjunto operacional de H4 (4,28% ponderado) |
| Tabela 3: ORs | regression_logistic_rescaled_odds_ratios.csv | Associação multivariada |
| Tabela 4: robustez | robustness_comprehensive_summary.csv | Compacta |
| Suplemento: fig2–4, block sensitivity, lotes, π nulo | tables/ | — |

## 5. Pendências antes de escrever
- Commit/tag dos resultados (Git não rastreia).
- Corrigir `experiment.yaml` (área do domínio) e docstring do script 19 (183 slices).
- Decidir tratamento da exclusão de 21,7% do domínio (texto ou sensibilidade ≥6 meses).
- Revisão de literatura.
- Declarar desvios do brief (distância linear; blocos 10/20/40; pesos).

## 6. O que evitar no texto
"Monotônico" em H3; "MB é referência/verdade"; "treinamos/validamos modelos"; "o DW erra"; causalidade; "erros comprovados no terreno" ou "verdades terrestres" para os pontos de H4 (utilizar rigorosamente: *"Discordâncias que satisfazem simultaneamente os critérios operacionais de baixa ambiguidade probabilística, baixa heterogeneidade temporal, alta estabilidade e afastamento das bordas temáticas"*).
