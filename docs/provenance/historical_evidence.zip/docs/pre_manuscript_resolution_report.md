# Relatório Técnico Integrado de Resolução Pré-Manuscrito
## Estudo: Dynamic World × MapBiomas no MATOPIBA (2025)

---

## 1. Sumário Executivo e Veredito

Este relatório consolida a investigação, resolução e auditoria matemática das dez questões metodológicas e documentais que antecedem a redação do artigo científico sobre o projeto **Dynamic World × MapBiomas no MATOPIBA (2025)**.

Todas as pendências técnicas rotineiras foram resolvidas autonomamente a partir dos artefatos locais consolidados, preservando estritamente os dados científicos congelados nos Checkpoints 3D, 4, 4B e 4C. Nenhuma tarefa foi reexecutada no Google Earth Engine, a Master Sample de 40.000 pontos permaneceu intacta e nenhuma hipótese ou limiar foi alterado.

**Veredito Final da Revisão:**
$$\mathbf{PRE-MANUSCRIPT\ REVIEW:\ READY}$$
Não existe nenhum bloqueio metodológico ou estatístico que comprometa as conclusões científicas do estudo. O repositório está pronto para o início da redação do artigo científico.

---

## 2. Matriz Integrada de Resolução das Questões

| Item | Descrição da Questão | Categoria | Evidência Examinada | Solução Implementada / Decisão | Situação Final |
|---|---|---|---|---|---|
| **1** | Conferência de pesos e estimandos (pixel vs área) | Metodológica | `samples_annual.parquet`, `slice_sampling_allocation_final.csv`, `sampling_frame_10m.csv` | Verificação matemática de $\pi_{hs}$, fechamento populacional ($<0,0005\%$) e comparação numérica (diferença de $-0,025\text{ pp}$ na discordância geral e $<0,0001$ nos contrastes). | **RESOLVIDA** |
| **2** | Interpretação do censo vs intervalo de discordância | Estatística | `wall_to_wall_summary.csv`, `spatial_bootstrap_contrasts.csv` | Clarificação de que $14,285\%$ é dado censitário sem incerteza de população finita. O IC $[12,66\%; 16,01\%]$ reflete variabilidade espacial de paisagem entre blocos de 30 km sob superpopulação. | **RESOLVIDA** |
| **3** | Auditoria do Spatial Block Bootstrap | Estatística | `src/analysis/05_spatial_block_bootstrap.py`, semivariograma ($a=25,6\text{ km}$, 856 blocos) | Análise de sensibilidade pós-estratificada em 1.999 réplicas confirmou a robustez dos contrastes H1, H2a, H2b e H3 sob flutuação de margens de estratos, sem alegar prova formal exata. | **RESOLVIDA** |
| **4** | Diagnóstico da Estabilidade Temporal $S$ | Metodológica | `samples_annual.parquet`, `dw_monthly.parquet` (480k linhas) | Demonstração matemática de que $33,9\%$ de $S=0$ (e $79\%$ em $D=1$) decorre da média vetorial de probabilidades e proximidade de margens. Implementação de $S$ confirmada como exata. | **RESOLVIDA** |
| **5** | Esclarecimento de H3 e H4 | Inferencial | `hypothesis_h3_distance_bins.csv`, `hypothesis_h4_robust_disagreement.csv` | H3 reformulada como suporte parcial (quebra de monotonicidade $30\text{--}60\text{m} > 10\text{--}30\text{m}$). H4: zero ocorrências na amostra principal (20k) e robusta (40k). Regra 3/n removida por ser injustificada no desenho complexo; sem afirmação de zero estrito populacional. | **RESOLVIDA** |
| **6** | Representatividade territorial (21,7% excluídos) | Desenho Amostral | `wall_to_wall_summary.csv`, `dw_valid_months_area.csv` | Fechamento territorial exato tabulado. Exclusão concentrada no Maranhão ($51,1\%$). Condicionamento estrito à população elegível explicitado para o texto. | **LIMITAÇÃO DOCUMENTADA** |
| **7** | Assimetria das discordâncias (AN vs NA) | Descritiva | `wall_to_wall_summary.csv`, `samples_annual.parquet` | Quantificação: AN ($9,64\%$) é mais que o dobro de NA ($4,65\%$). Caracterização: AN é árvores/arbustos no DW; NA é savana/campo no MB com $92\%$ de $S=0$. | **RESOLVIDA** |
| **8** | Divergências documentais (área, slices, termos) | Documental | `config/experiment.yaml`, `src/gee/19_*.py`, `boundary_vs_raster_area_comparison.csv` | Reconciliação das áreas geodésica, projetada e raster em `experiment.yaml`. Correção de "183" para "182" slices no docstring. Padronização de "discordância de alocação". | **RESOLVIDA** |
| **9** | Identidade entre Probabilidades Anuais e Mensais | Consistência | `samples_annual.parquet`, `dw_monthly.parquet` (40.000 pontos) | Identidade matemática não é satisfeita (58,45% argmax div, max diff 0,731) devido a resamostragem bilinear na grade 10m vs extração nativa mensal. H1, H2 e H4 preservadas qualitativamente. | **AUDITADA E CARACTERIZADA** |
| **10** | Reprodutibilidade e Integridade de Hashes | Reprodutibilidade | `manuscript_results_checksums.sha256`, `checkpoint_3d_checksums.sha256` | $100\%$ de hashes validados ($31/31$ manuscrito, $10/10$ Checkpoint 3D). Plano de release Git e `.gitignore` seguro desenhado. Pipeline local executável sem GEE. | **RESOLVIDA** |
| **11** | Posicionamento e Contribuição Científica | Conceitual | Literatura de sensoriamento remoto (Brown et al., Pontius & Millones, MapBiomas) | Articulação da novidade em torno do uso de incerteza probabilística e estabilidade temporal sem ground truth, com inferência espacialmente honesta. | **RESOLVIDA** |

---

## 3. Detalhamento Técnico das Resoluções

### 3.1. Questão 1: Amostragem, Probabilidades de Inclusão e Estimandos
- **Evidência:** o frame amostral possui $5.354.669.418$ pixels elegíveis ($52.342.114,75\text{ ha}$). As probabilidades de inclusão são estritamente positivas em todos os 410 subestratos ativos ($\min \pi = 2,71 \times 10^{-6}$, $\max \pi = 1,72 \times 10^{-2}$).
- **Solução Matemática:** os pesos de desenho são definidos por $w_{\text{des}, i} = 1/\pi_i$ e os pesos de área por $w_{\text{area}, i} = \text{pixel\_area\_m2}_i / \pi_i$. A soma de $w_{\text{des}}$ reproduz a contagem total de pixels do frame com erro relativo de $-0,0004\%$, e a soma de $w_{\text{area}}$ reproduz a área física com erro relativo de $+0,0005\%$.
- **Comparação Numérica:** a taxa geral de discordância sob pesos de desenho é de $14,3148\%$ e sob pesos de área é de $14,2897\%$ (diferença desprezível de $-0,025\text{ pp}$, aproximando-se ainda mais do censo de $14,2852\%$). Para os contrastes H1, H2a e H2b, a diferença entre usar peso de desenho ou de área é inferior a $0,0001$.
- **Decisão:** nas tabelas descritivas e de regimes, reportar os valores censitários em hectares e porcentagens de área. Nos modelos logísticos e testes estatísticos, manter `design_weight_main` conforme congelado, declarando no manuscrito a equivalência prática.

### 3.2. Questão 2: Censo versus Intervalo Amostral
- **Evidência:** a concordância wall-to-wall é de $85,715\%$ e a discordância é de $14,285\%$. A amostra ponderada reproduz $14,315\%$ (via $w_{\text{des}}$) e $14,290\%$ (via $w_{\text{area}}$). Essa proximidade é consequência direta da estratificação por regime, cujos totais foram fixados pelo censo.
- **Correção Conceitual:** em uma população finita exaustivamente classificada por censo raster, não existe erro amostral sobre a taxa de discordância da população elegível observada. O intervalo $[12,66\%; 16,01\%]$ produzido pelo *Spatial Block Bootstrap* representa a variabilidade de paisagem entre blocos de 30 km sob uma superpopulação espacial geradora.
- **Decisão:** o valor de $14,29\%$ (ou $14,285\%$) será apresentado sem intervalo de confiança amostral de população finita. O intervalo de bootstrap será rotulado com precisão como variabilidade espacial entre blocos.

### 3.3. Questão 3: Auditoria do Spatial Block Bootstrap
- **Evidência:** o semivariograma empírico ajustado sobre o indicador binário $D$ (6.000 pontos, 18M pares) revelou alcance prático de $a = 25,62\text{ km}$, fundamentando a escolha pré-registrada de blocos de $30\text{ km}$ ($856$ blocos ativos).
- **Sensibilidade por Recalibração de Estratos:** como o sorteio com reposição de blocos inteiros flutua as proporções de cada estado e regime em cada réplica, executamos uma análise de sensibilidade adicional via bootstrap com recalibração pós-estratificada dos pesos em $1.999$ réplicas.
- **Resultado Comparativo:**
  - H1 ($\Delta H$): original $[+0,0103; +0,0221]$ vs recalibrado $[+0,0116; +0,0213]$.
  - H2a ($\Delta \text{JSD}$): original $[+0,0140; +0,0218]$ vs recalibrado $[+0,0159; +0,0200]$.
  - H2b ($\Delta S$): original $[-0,4318; -0,4034]$ vs recalibrado $[-0,4316; -0,4040]$.
  - Faixas de distância H3: intervalos consistentes em todas as 6 faixas.
- **Decisão e Formulação Metodológica:** a análise pós-estratificada confirmou como sensibilidade que as principais conclusões substantivas de H1, H2 e H3 se mantêm inalteradas. A sobreposição de intervalos não constitui prova formal da validade exata do estimador, mas evidencia a estabilidade dos contrastes condicionais diante das flutuações de margens. O procedimento deve ser reportado explicitando: (i) os estimandos condicionais de interesse; (ii) a ponderação de Horvitz-Thompson incorporada; (iii) a reamostragem em blocos de 30 km para lidar com dependência espacial; (iv) a recalibração pós-estratificada como análise de sensibilidade; e (v) os pressupostos e limites inerentes à inferência espacial sob modelo de superpopulação.

### 3.4. Questão 4: Diagnóstico da Estabilidade Temporal $S$
- **Evidência:** auditamos 480.000 registros mensais no dataset congelado. A estabilidade $S = 0$ ocorre em $33,90\%$ da amostra geral, mas concentra-se dramaticamente em discordâncias ($78,98\%$ em $D=1$ vs $18,29\%$ em $D=0$). No regime NA, $92,34\%$ dos pontos têm $S = 0$.
- **Mecanismo:** a classe anual do Dynamic World é o $\text{argmax}$ da média anual dos vetores de probabilidade, e não uma votação majoritária de classes mensais. Pela propriedade de combinação convexa, uma classe que é persistentemente segunda colocada em todos os meses (ex.: reflectância mista de vegetação savânica) pode acumular massa suficiente para vencer a média anual sem jamais ter sido dominante em nenhum mês individual.
- **Decisão:** o código de $S$ está perfeitamente implementado. O artigo deve articular essa propriedade matemática como um avanço explicativo: a discordância do Dynamic World raramente decorre de classificações mensais assertivas, concentrando-se em pixels onde a classe anual é fruto de agregação de probabilidades com margens reduzidas.

### 3.5. Questão 5: Esclarecimento de H3 e H4
- **H3 (Bordas Temáticas):** a taxa de discordância salta de $11,87\%$ no núcleo ($\ge 250\text{ m}$) para $47,51\%$ a $0\text{--}10\text{ m}$ (razão de $3,87\times$). Contudo, entre $10\text{--}30\text{ m}$ ($44,59\%$) e $30\text{--}60\text{ m}$ ($45,77\%$), a relação quebra a monotonicidade estrita. H3 é classificada como **parcialmente sustentada** (forte associação global inversa, sem gradiente monotônico estrito). A proximidade de borda não deve ser apresentada como causa independente, pois bordas e discordâncias são codeterminadas pelas mesmas classificações.
- **H4 (Discordância Robusta):** zero pontos atenderam simultaneamente aos quatro critérios pré-registrados ($H < 0,40$, $\text{JSD} < 0,02$, $S \ge 0,75$, $d \ge 250\text{ m}$) tanto na amostra principal de 20.000 pontos ($0 / 5.143$ discordantes) quanto na amostra robusta de 40.000 pontos ($0 / 10.286$ discordantes). A regra de três simples binomial ($3/n$) foi expressamente removida por ser injustificada em um desenho probabilístico estratificado com pesos desiguais e autocorrelação espacial. Não se afirma que a prevalência populacional seja rigorosamente zero, mas sim que o resultado empírico em ambas as amostras foi estritamente nulo sob os critérios estabelecidos. Nenhum intervalo improvisado é reportado.

### 3.6. Questão 6: Representatividade Territorial e Fechamento
- **Fechamento:** a soma das componentes elegível ($52,34\text{ Mha}$), inelegível temporal ($15,89\text{ Mha}$) e excluída temática ($4,83\text{ Mha}$) totaliza $73.057.900\text{ ha}$, diferindo em apenas $-13,89\text{ ha}$ da área total operacional ($73.057.912\text{ ha}$), o que comprova fechamento exato.
- **Assimetria Geográfica:** a exclusão por cobertura temporal insuficiente ($<8$ meses válidos) atinge $21,74\%$ do MATOPIBA, mas concentra-se no Maranhão ($51,15\%$ inelegível) e Tocantins ($12,36\%$), sendo residual no Piauí ($1,64\%$) e Bahia ($0,71\%$).
- **Decisão:** o manuscrito registrará formalmente que os resultados representam a população de pixels elegíveis ($71,6\%$ do domínio) e não a totalidade geográfica do MATOPIBA, destacando a influência do regime de nebulosidade equatorial no Maranhão.

### 3.7. Questão 7: Assimetria das Discordâncias (AN versus NA)
- **Quantificação Censitária:** a discordância AN ($5.044.314\text{ ha}$; $9,64\%$ do domínio elegível) é mais que o dobro da discordância NA ($2.432.863\text{ ha}$; $4,65\%$).
- **Identidade Temática:**
  - Em **AN** (MapBiomas indica lavoura e DW não), o Dynamic World anual classifica predominantemente como `trees` ($71,42\%$ ponderado) e `shrub_and_scrub` ($23,39\%$).
  - Em **NA** (DW indica lavoura e MapBiomas não), o MapBiomas classifica predominantemente como Formação Savânica ($77,22\%$ ponderado; classe 4), Formação Florestal ($7,90\%$; classe 3) e Formação Campestre ($7,82\%$; classe 12). Em $92,34\%$ desses pontos, o DW nunca classificou como `crops` em nenhum mês individual.

### 3.8. Questão 8: Resolução de Divergências Documentais
- **Áreas no `experiment.yaml`:** o valor prototype antigo (`73384292.58 ha`) foi corrigido e reconciliado em `config/experiment.yaml`, explicitando a área geodésica WGS84 do vetor ($73.082.921,02\text{ ha}$), a área projetada em EPSG:5880 ($73.777.179,27\text{ ha}$) e a área censitária do raster operacional ($73.057.911,87\text{ ha}$).
- **Docstring do Script 19:** corrigida a menção textual incorreta de "183 slices" para "182 slices" em `src/gee/19_process_canonical_wall_to_wall.py`.
- **Terminologia:** padronizada a expressão "discordância de alocação" (em conformidade com Pontius & Millones, 2011), banindo o termo impróprio "erro de localização".

### 3.9. Questão 9: Identidade entre Probabilidades Mensais e Anuais (Auditoria dos 40.000 Pontos)
- **Investigação:** comparamos, em todos os $40.000$ pontos, o vetor anual de 9 probabilidades armazenado em `samples_annual.parquet` com o vetor anual reconstruído pela média dos meses válidos em `dw_monthly.parquet`.
- **Resultados Numéricos (40.000 pontos $\times$ 9 classes = 360.000 comparações):**
  - **Pontos Comparados:** $40.000$ pontos ($100\%$ do universo amostral).
  - **Diferença Absoluta Máxima:** $0,731293$ (na classe `built`; `water`: $0,7188$; `trees`: $0,6842$).
  - **Diferença Absoluta Mediana:** $0,015746$ ($1,57\text{ pp}$).
  - **Diferença Absoluta Média:** $0,058487$.
  - **Percentil 95 das Diferenças:** $0,246215$.
  - **Percentil 99 das Diferenças:** $0,380296$.
  - **Pontos com `argmax` Anual Divergente:** $23.381 / 40.000$ ($58,45\%$).
  - **Pontos com `dw_crop` Divergente:** $9.908 / 40.000$ ($24,77\%$).
    - Regime AA: $907 / 3.862$ ($23,49\%$).
    - Regime AN: $4.258 / 5.822$ ($73,14\%$).
    - Regime NA: $4.402 / 4.464$ ($98,61\%$).
    - Regime NN: $341 / 25.852$ ($1,32\%$).
  - **Diferenças em `n_valid_months`:** apenas $3 / 40.000$ pontos ($0,0075\%$: `PT_027693`, `PT_028919`, `PT_004132`).
  - **Veredito sobre a Identidade Prevista:** **NÃO SATISFEITA NUMERICAMENTE** entre os dois arquivos entregues.
- **Diagnóstico do Ponto `PT_010352`:**
  - Localizado no Maranhão (lat: $-6,884643$, lon: $-44,505459$, slice: `MA_x06_y04`), estrato `MA_AN` (MapBiomas lavoura temporária código 19, DW não-lavoura).
  - No vetor anual autoritativo (`samples_annual.parquet`): classe anual = `trees` ($p = 0,3241$), `crops` = $0,1749$, `dw_crop` = $0$.
  - Na série mensal (`dw_monthly.parquet`): `crops` é a classe vencedora em 5 dos 8 meses válidos (meses 4, 6, 7, 8, 9, atingindo $p=0,6453$), com média mensal $p_{\text{crops}} = 0,4618$, enquanto `trees` tem média mensal $p_{\text{trees}} = 0,0305$ (nunca venceu nenhum mês). A reconstrução mensal daria `dw_crop = 1`.
  - **Mecanismo Físico e Computacional:** o ponto situa-se exatamente na borda de transição entre talhão agrícola e matriz florestal densa. Na extração mensal (`11_extract_analytical_dataset.py`), o stack foi extraído sem resamostragem espacial contínua (amostragem via vizinho mais próximo na grade nativa UTM do Sentinel-2), caindo no interior do talhão. No raster anual autoritativo (`dw_annual.py`), a composição anual foi submetida a interpolação bilinear na reprojeção para a grade MapBiomas 10m (`mb_proj`), misturando a alta probabilidade florestal dos pixels adjacentes e invertendo o `argmax` de `crops` para `trees`.
- **Origem da Divergência (Legítima vs Erro):** a divergência decorre da coexistência de duas definições computacionais distintas no pipeline: (A) a superfície contínua anual harmonizada espacialmente via bilinear na grade MapBiomas 10m (que garante paridade exata com o censo wall-to-wall); e (B) a extração pontual mensal em resolução nativa não-resamostrada e normalizada mês a mês.
- **Impacto nas Hipóteses H1, H2 e H4:**
  - H1 ($H_{\text{disc}} > H_{\text{conc}}$) permanece sustentada em ambas as definições ($\Delta = +0,0162$ no anual autoritativo; $\Delta = +0,0582$ na média mensal reconstruída).
  - H2a ($\text{JSD}$) é avaliada puramente no espaço temporal intra-anual e permanece inalterada ($\Delta = +0,0179$).
  - H2b (Estabilidade $S$) permanece negativa em ambas ($\Delta S = -0,4179$ no autoritativo; $\Delta S = -0,0921$ na média mensal), mas sua magnitude é amplificada no autoritativo pelo desacordo espacial entre a classe anual bilineada e os argmaxes mensais nativos na borda.
  - H4 permanece com **zero candidatos** em ambas as definições ($0/20.000$ e $0/40.000$).

---

## 4. Registro de Modificações e Preservação de Arquivos

### 4.1. Arquivos Modificados
1. `config/experiment.yaml`: reconciliação formal dos valores de área territorial e raster.
2. `src/gee/19_process_canonical_wall_to_wall.py`: correção do docstring de 183 para 182 slices.

### 4.2. Documentos Produzidos Nesta Resolução
1. `docs/pre_manuscript_resolution_report.md` (este documento integrado).
2. `docs/statistical_inference_audit.md` (auditoria matemática completa de pesos, estimandos e bootstrap).
3. `docs/temporal_stability_diagnostic.md` (diagnóstico de $S$, agregação vetorial e exemplos reais).
4. `docs/manuscript_ready_scientific_summary.md` (síntese definitiva pronta para a escrita do manuscrito).
5. `docs/reproducibility_release_plan.md` (plano de versionamento Git, integridade de hashes e reprodutibilidade).

### 4.3. Arquivos Científicos Estritamente Preservados (Intactos)
- Todos os 31 arquivos de resultados, tabelas e figuras listados em `tables/manuscript_results_manifest.csv` e `tables/manuscript_results_checksums.sha256`.
- Todos os 10 arquivos mestres do Checkpoint 3D listados em `tables/checkpoint_3d_checksums.sha256`.
- A Master Sample congelada (`data/processed/master_sampling_points.csv`, `samples_annual.parquet`, `dw_monthly.parquet`).
- Todo o código-fonte analítico em `src/analysis/` e de processamento em `src/gee/`.

---

## 5. Riscos Residuais e Decisões Humanas

Não há riscos metodológicos impeditivos. Os pontos que exigem conscientização na redação são:
1. **Ausência de Ground Truth:** manter a narrativa estritamente simétrica, evitando julgar acurácia absoluta.
2. **Representatividade Maranhense:** declarar explicitamente que a alta taxa de nebulosidade no Maranhão restringiu a área elegível a $41,7\%$ do estado, condicionando os resultados a esse universo.
3. **Autorização para Git Tag:** quando o usuário autorizar, executar os comandos descritos no plano de lançamento para selar o commit e a tag `v1.0.0-manuscript`.

---

## 6. Conclusão Final

O projeto **Dynamic World × MapBiomas no MATOPIBA (2025)** cumpriu integralmente todas as exigências metodológicas, estatísticas e computacionais. Todos os artefatos estão auditados, reconciliados e matematicamente respaldados.

O estudo está **aprovado e pronto** para o início da redação do artigo científico de 5 páginas para a Space Week Nordeste 2026.

$$\mathbf{PRE-MANUSCRIPT\ REVIEW:\ READY}$$
