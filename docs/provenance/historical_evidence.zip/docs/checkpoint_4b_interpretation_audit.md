# CHECKPOINT 4B — SCIENTIFIC INTERPRETATION AND REPORTING AUDIT
**Dynamic World × MapBiomas (MATOPIBA 2025) GeoAI Research Project**  
**Data:** Outubro de 2026 | **Status:** Concluído e Congelado para Revisão Humana  

---

## 1. Contexto e Diretrizes do Protocolo de Auditoria

O presente relatório cumpre a auditoria de interpretação científica e reporte estatístico (**Checkpoint 4B**) previamente à redação do manuscrito final.

### Restrições Rígidas Mantidas (Invariância Operacional):
- **Nenhuma alteração de hipóteses pré-registradas**: Critérios e formulações originais preservados.
- **Nenhuma alteração de limiares**: Quantis ponderados $Q_1(H)$, $Q_1(\text{JSD})$, $Q_3(S)$ e distância $\ge 30\text{ m}$ inalterados.
- **Nenhum re-ajuste pos-hoc (*no post-hoc tuning*)**: Modelos originais preservados; apenas redimensionamento linear de unidades para interpretabilidade substantiva.
- **Invariância do Master Sample e Censo Wall-to-Wall**: Checkpoint 3D permanece 100% congelado e validado criptograficamente (SHA-256).

---

## 2. Sumário das Correções de Interpretação Realizadas

| Item | Versão Prévia / Não Auditada | Versão Corrigida Auditada (Checkpoint 4B) | Justificativa Científica |
| :--- | :--- | :--- | :--- |
| **H3: Monotonicidade** | *"Decaimento estritamente monótono da discordância com a distância"* | *"Forte associação inversa global com discreta não-monotonicidade local entre faixas adjacentes (10–30 m vs 30–60 m)"* | 45.77% (30–60 m) > 44.59% (10–30 m). A monotonicidade estrita discreta é empiricamente falsa. H3 classificada como **PARCIALMENTE APOIADA**. |
| **H4: Interpretação Causal** | *"Discordância concentrada integralmente em flutuações fenológicas e incerteza espectral"* | *"Nenhuma observação amostrada satisfez simultaneamente baixa entropia, baixa JSD, alta estabilidade e $d \ge 30\text{ m}$ sob o critério pré-registrado"* | Fenologia e incerteza espectral não foram isoladas causalmente. Zero eventos observados reflete extrema raridade sob filtros restritivos ($S \ge Q_3$ elimina 99% das discordâncias), não prova que a população real seja zero. |
| **H1: Tamanho de Efeito** | Cohen's $d = 0.318$ descrito como *"efeito moderado"* | Cohen's $d = 0.318$ descrito como **"efeito pequeno a moderado"** | Convenção de Cohen: $0.2 \le d < 0.5$ é pequeno a moderado. |
| **H2b: Tamanho de Efeito** | Cohen's $d = -1.609$ descrito como *"efeito massivo"* | Cohen's $d = -1.609$ descrito como **"efeito muito grande"** | Linguagem científica neutra e rigorosa. |
| **H2b: Métrica de Estabilidade** | *"Alternância mensal contínua de classes"* | *"A classe mensal dominante raramente coincide com a classe anual dominante entre discordâncias"* | $S$ mede a fração de meses cujo argmax mensal coincide com o argmax anual canônico. Baixo $S$ reflete ausência de concordância modal, não necessariamente troca a cada mês. |
| **Pseudo-$R^2$ de McFadden** | *"48.8% da deviance explicada"* | **"McFadden pseudo-$R^2 = 0.488$, indicando forte ajuste relativo em relação ao modelo nulo"** | Pseudo-$R^2$ de McFadden não é percentual de variância nem de deviance explicada. |
| **Efeitos da Regressão** | Odds ratios em unidades brutas (ex: $OR = 7.14 \times 10^{12}$ para JSD, $OR = 0.9917$ por metro) | **Odds ratios redimensionados por incrementos substantivos** ($+0.10$ em $H$, $+0.01$ em JSD, $+0.10$ em $S$, $+100\text{ m}$ em distância) | Grandezas intuitivas para leitura agronômica e ecológica. |
| **Primazia Inferencial** | Inferência mista (analítica e bootstrap) | **Spatial Block Bootstrap (1.999 replicações) é a autoridade inferencial primária** | Autocorrelação espacial infla estatísticas analíticas. O contraste PI vs BA é não-significativo no bootstrap ($IC_{95\%}: [0.535, 1.275]$), embora analiticamente fosse $p=0.015$. |
| **Erros Padrão Analíticos** | Referidos implicitamente como *"erros padrão do desenho"* | Rotulados explicitamente como **"aproximação analítica ponderada"** | Fórmulas analíticas utilizam linearização ponderada sem estratificação operacional completa, sem FPC e ignorando dependência espacial. |
| **H4: Frequência Populacional** | *"Proporção populacional = 0"* | **"0 observações na Amostra Principal (20k) e 0 na Amostra Robusta (40k)"** | Evita inferir parâmetro populacional exatamente nulo a partir de contagem amostral zero sem modelo de bounds suportado. |

---

## 3. Redações Científicas Auditadas para as Hipóteses H1–H4

### Hipótese H1 (Ambiguidade Probabilística Anual) — APOIADA
- **Formulação Auditada:**
  > *"Observações discordantes ($D=1$) apresentam entropia anual normalizada de Shannon discretamente superior à das observações concordantes ($D=0$), com $\Delta \bar{H} = +0.0162$ (IC 95% espacial: $[+0.0103, +0.0221]$; aproximação analítica: $[+0.0146, +0.0179]$). O tamanho de efeito padronizado ponderado é pequeno a moderado (Cohen's $d = 0.318$). No modelo logístico multivariável ajustado por covariáveis temporais, espaciais e estaduais, cada incremento de $+0.10$ em $H_{\mathrm{anual}}$ está associado a um aumento de 37.9% na chance de discordância ($OR = 1.379$; IC 95% espacial: $[1.049, 1.891]$). A hipótese H1 é formalmente apoiada."*

### Hipótese H2 (Heterogeneidade e Instabilidade Temporal) — APOIADA
- **Formulação Auditada H2a (Divergência Temporal JSD):**
  > *"A discordância temático-estrutural exibe maior heterogeneidade temporal de Jensen-Shannon generalizada entre as distribuições de probabilidade mensais válidas ($\Delta \overline{JSD} = +0.0179$; IC 95% espacial: $[+0.0140, +0.0218]$; aproximação analítica: $[+0.0167, +0.0190]$), com tamanho de efeito moderado (Cohen's $d = 0.529$). A métrica quantifica a dispersão temporal entre os vetores mensais de probabilidade ($M = \frac{1}{T}\sum p_m$; $JSD_{\mathrm{temporal}} = H(M) - \frac{1}{T}\sum H(p_m)$), e não a divergência em relação a um modo ou argmax anual. No modelo multivariável, cada acréscimo de $+0.01$ na JSD temporal eleva a chance de discordância em 34.4% ($OR = 1.344$; IC 95% espacial: $[1.287, 1.409]$)."*
- **Formulação Auditada H2b (Estabilidade Categórica Temporal $S$):**
  > *"A estabilidade categórica temporal — definida estritamente como a proporção de meses válidos cuja classe dominante coincide com a classe dominante anual canônica — é drasticamente reduzida nas áreas discordantes ($\bar{S}_{D=1} = 0.0500$ vs $\bar{S}_{D=0} = 0.4679$; $\Delta \bar{S} = -0.4179$; IC 95% espacial: $[-0.4318, -0.4034]$). O efeito padronizado ponderado é muito grande (Cohen's $d = -1.609$). Isso indica que, entre as observações discordantes, a classe mensal dominante raramente coincide com a classe anual atribuída (apenas ~5% dos meses válidos). No modelo multivariável, cada aumento de $+0.10$ na estabilidade mensal reduz a chance de discordância em 69.1% ($OR = 0.309$; IC 95% espacial: $[0.269, 0.351]$)."*

### Hipótese H3 (Gradiente Espacial de Distância à Borda) — PARCIALMENTE APOIADA
- **Formulação Auditada:**
  > *"A análise da taxa ponderada de discordância em função da distância à borda temática mais próxima revela uma forte associação inversa global: pixels próximos à borda (< 30 m) apresentam taxa de discordância de 45.91%, comparados a apenas 11.87% no interior profundo ($\ge 250\text{ m}$), correspondendo a uma razão de risco de 3.87x. No modelo logístico contínuo, a distância mantém efeito negativo expressivo ($\beta = -0.0083\text{ m}^{-1}$; $OR = 0.437$ por $+100\text{ m}$; IC 95% espacial: $[0.375, 0.502]$). Contudo, a estratificação discreta pré-registrada não exibe decaimento estritamente monótono entre todas as faixas adjacentes, registrando-se uma pequena não-monotonicidade local entre 10–30 m (44.59%; IC 95% espacial: $[37.67\%, 52.68\%]$) e 30–60 m (45.77%; IC 95% espacial: $[38.92\%, 52.51\%]$), além de estabilização entre 60–100 m (36.96%) e 100–250 m (36.79%). Diante da quebra estrita de monotonicidade em faixas contíguas, a hipótese H3 é classificada como **PARCIALMENTE APOIADA** (ou apoiada sob ressalva de não-monotonicidade local), rejeitando-se a alegação de decaimento perfeitamente monótono."*

### Hipótese H4 (Discordâncias Internamente Robustas) — NÃO APOIADA
- **Formulação Auditada:**
  > *"Sob a definição formal pré-registrada de discordância internamente robusta ($D=1$, $H_{\mathrm{anual}} \le Q_1$, $JSD_{\mathrm{temporal}} \le Q_1$, $S \ge Q_3$ e $d_{\mathrm{min}} \ge 30\text{ m}$), registrou-se exatamente 0 observações na Amostra Principal (20.000 pontos) e 0 observações na Amostra Robusta (40.000 pontos). A decomposição marginal demonstra que a exigência de alta estabilidade temporal ($S \ge Q_3 = 0.6667$) foi o filtro mais restritivo, sendo satisfeita por apenas 45 pontos discordantes (0.875% da contagem não ponderada de $D=1$; 0.955% da área discordante ponderada), e a intersecção simultânea entre baixa ambiguidade anual ($H \le Q_1$) e alta estabilidade ($S \ge Q_3$) foi nula no espaço amostral. Conclui-se que desacordos sistemáticos entre Dynamic World e MapBiomas no MATOPIBA praticamente inexistem em condições simultâneas de estabilidade unimodal e baixa ambiguidade probabilística afastadas das bordas temáticas (no interior das regiões tematicamente homogêneas segundo os produtos). A hipótese H4 não é apoiada pelos dados amostrais sob os critérios pré-registrados. Ressalta-se que a ausência amostral indica extrema raridade empírica sob estas restrições conjuntas, e não a comprovação matemática de que a proporção na população total seja exatamente zero."*

---

## 4. Tabela Primária de Odds Ratios Redimensionados

A tabela abaixo constitui a **Tabela Primária de Regressão** do manuscrito. Todos os estimadores pontuais e intervalos foram transformados analítica e espacialmente a partir dos coeficientes do modelo logístico ponderado ajustado com pesos normalizados:
$$\text{logit}[P(D=1)] = \beta_0 + \beta_1 H_{\mathrm{anual}} + \beta_2 JSD_{\mathrm{temporal}} + \beta_3 S + \beta_4 d_{\mathrm{min}} + \gamma_{\mathrm{estado}}$$
*Ajuste global:* McFadden pseudo-$R^2 = 0.488$ (forte capacidade explicativa relativa vs. modelo nulo). Diagnóstico de colinearidade: VIF máximo = 1.069.

| Termo / Variável | Incremento Interpretativo | Coef. Bruto ($\beta$) | Coef. Redimensionado | Odds Ratio ($OR$) | IC 95% Aproximação Analítica | OR Mediano Espacial | IC 95% Spatial Bootstrap (1.999 reps) | Efeito Apoiado no Bootstrap Espacial? |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Entropia Anual ($H$)** | $+0.10$ | $+3.2101$ | $+0.3210$ | **1.379** | $[1.216, 1.562]$ | **1.393** | **$[1.049, 1.891]$** | **SIM** ($IC > 1.0$) |
| **Divergência Temporal ($JSD$)** | $+0.01$ | $+29.5969$ | $+0.2960$ | **1.344** | $[1.320, 1.370]$ | **1.348** | **$[1.287, 1.409]$** | **SIM** ($IC > 1.0$) |
| **Estabilidade Mensal ($S$)** | $+0.10$ | $-11.7548$ | $-1.1755$ | **0.309** | $[0.293, 0.325]$ | **0.307** | **$[0.269, 0.351]$** | **SIM** ($IC < 1.0$) |
| **Distância à Borda ($d_{\mathrm{min}}$)** | $+100\text{ m}$ | $-0.00828$ | $-0.8278$ | **0.437** | $[0.400, 0.478]$ | **0.435** | **$[0.375, 0.502]$** | **SIM** ($IC < 1.0$) |
| **Maranhão (MA)** | vs. Bahia (BA) | $-1.5147$ | $-1.5147$ | **0.220** | $[0.187, 0.259]$ | **0.220** | **$[0.143, 0.342]$** | **SIM** ($IC < 1.0$) |
| **Piauí (PI)** | vs. Bahia (BA) | $-0.1945$ | $-0.1945$ | **0.823** | $[0.704, 0.963]$ | **0.832** | **$[0.535, 1.275]$** | **NÃO** (**$IC$ inclui 1.0**) |
| **Tocantins (TO)** | vs. Bahia (BA) | $-2.3278$ | $-2.3278$ | **0.098** | $[0.084, 0.113]$ | **0.098** | **$[0.068, 0.144]$** | **SIM** ($IC < 1.0$) |

> **Nota Metodológica Crucial:** O contraste entre **Piauí e Bahia**, que sob a aproximação analítica parecia estatisticamente significativo ($p = 0.0152$, IC $[0.704, 0.963]$), **perde significância sob a inferência espacial primária** ($IC_{95\%}: [0.535, 1.275]$ cruza a unidade). Portanto, conclui-se formalmente que **não há diferença estatisticamente demonstrável na chance ajustada de discordância entre Piauí e Bahia** após controlar por covariáveis biofísicas e autocorrelação espacial.

---

## 5. Auditoria das Fórmulas de Variância e Erro Padrão Analítico

As fórmulas analíticas computadas nos scripts `02_weighted_descriptive_analysis.py` e `03_hypothesis_tests_h1_h4.py` foram auditadas contra a teoria clássica de amostragem:

1. **Média Ponderada e Proporções:** Utilizam o estimador de razão tipo Hájek $\bar{y}_w = \frac{\sum w_i y_i}{\sum w_i}$.
2. **Erro Padrão Analítico de Médias e Contrastes:** Utilizam a fórmula de linearização de Taylor com pesos ao quadrado:
   $$SE(\bar{y}_w) = \frac{\sqrt{\sum w_i^2 (y_i - \bar{y}_w)^2}}{\sum w_i}, \quad SE_{\mathrm{diff}} = \sqrt{SE_0^2 + SE_1^2}$$
3. **Erro Padrão Analítico de Proporções:** Utilizam a aproximação de efeito de desenho de Kish:
   $$SE(\hat{p}) = \sqrt{\hat{p}(1 - \hat{p}) \frac{\sum w_i^2}{(\sum w_i)^2}}$$

### Diagnóstico da Auditoria:
- **Ausência de Estratificação Plena:** A aproximação analítica não implementa o estimador exato de variância estratificada sem reposição nem o FPC do desenho amostral congelado (composto por 16 estratos científicos e 410 subestratos operacionais de amostragem particionados por fatias).
- **Ausência de FPC:** Não aplica o fator de correção para populações finitas $(1 - f_h)$. Embora a taxa de amostragem global seja pequena ($f \approx 20.000 / 5.35 \times 10^9 \approx 3.7 \times 10^{-6}$), o desenho formal é sem reposição.
- **Suposição de Independência Condicional:** As fórmulas analíticas assumem observações linearmente independentes sob o modelo de pesos, ignorando a **autocorrelação espacial** presente no domínio geográfico. O semivariograma empírico demonstrou dependência espacial marcante, com alcance prático estimado em **25.62 km** e tamanho primário de bloco eleito de **30 km**.

**Determinação:** Todas as estimativas de incerteza analítica são classificadas como **"aproximação analítica ponderada"**. A autoridade inferencial primária do estudo baseia-se unicamente nos **intervalos de confiança de 95% derivados do Spatial Block Bootstrap de 1.999 replicações (bloco de 30 km, EPSG:5880)**.

---

## 6. Tratamento Amostral e Populacional de Zero Eventos (H4)

- **Fato Observado:** $n = 0$ em $N_{\mathrm{amostra}} = 20.000$ (amostra principal) e $n = 0$ em $N_{\mathrm{amostra}} = 40.000$ (amostra robusta).
- **Tratamento Estatístico:**
  - A aplicação de limites superiores ingênuos como a Regra de Três clássica ($3/n = 0.015\%$) **foi expressamente rejeitada**, pois esta regra pressupõe estritamente ensaios de Bernoulli IID (independentes e identicamente distribuídos), o que viola o desenho amostral complexo estratificado, os pesos desiguais de inclusão e a autocorrelação espacial demonstrada.
  - O reporte científico limita-se rigorosamente ao fato amostral verificado: **"0 eventos observados sob a definição pré-registrada na amostra primária de 20.000 pontos e na amostra robusta de 40.000 pontos"**, sem extrapolar para $P = 0$ na população contínua.
  - A justificativa empírica é atribuída à restritividade do filtro $S \ge Q_3$ ($S \ge 0.6667$), que elimina 99.05% da área discordante ponderada (e 99.13% das observações amostradas em $D=1$).

---

## 7. Inventário dos Artefatos de Tabelas e Figuras

Todos os 21 arquivos de tabelas em `tables/` e 6 figuras em `figures/` foram validados quanto à consistência interna:
- `tables/regression_logistic_rescaled_odds_ratios.csv`: Tabela primária de inferência do manuscrito.
- `tables/hypothesis_h3_distance_bins.csv`: Tabela empírica que fundamenta a classificação de não-monotonicidade local.
- `tables/hypothesis_h4_robust_disagreement.csv`: Decomposição marginal e conjunta de H4.
- `tables/spatial_bootstrap_logistic_model.csv`: Distribuição das 1.999 replicações espaciais.
- `figures/fig1_composition_regimes.png` a `figures/fig6_h4_robust_disagreement_characterization.png`: Figuras em 300 DPI sem nenhuma menção a afirmações causais infundadas ou monotonicidade estrita.
