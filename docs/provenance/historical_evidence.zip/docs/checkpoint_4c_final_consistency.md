# CHECKPOINT 4C — FINAL CONSISTENCY FREEZE BEFORE MANUSCRIPT
**Dynamic World × MapBiomas (MATOPIBA 2025) GeoAI Research Project**  
**Data:** Outubro de 2026 | **Status:** Concluído e Congelado para Redação do Manuscrito | **Avaliação:** PASS  

---

## 1. Alcance Prático e Tamanho Primário do Bloco Espacial

A auditoria de proveniência sobre os artefatos persistidos encerra qualquer ambiguidade textual em torno do procedimento de incerteza espacial:

- **Alcance Prático Empírico ($a$):** **25.6216 km** ($\approx 25.62\text{ km}$), obtido via semivariograma empírico exponencial ajustado sobre 17.997.000 pares de distâncias na Amostra Principal (`tables/spatial_semivariogram_parameters.csv`).
- **Regra Pré-Registrada:** Arredondamento para cima ao múltiplo de 5 km mais próximo ($\lceil 25.6216 / 5 \rceil \times 5 = 30$).
- **Tamanho do Bloco Primário Eleito:** **30.0 km** (`selected_block_size_km = 30.0`).
- **Número de Blocos Espaciais Ativos:** **856 blocos**.
- **Número de Replicações:** **1.999 replicações**.
- **Semente Aleatória Raiz:** **seed = 25**.
- **Proveniência Numérica:** Todos os intervalos de confiança de 95% e medianas primárias relatados em `tables/spatial_bootstrap_contrasts.csv`, `tables/spatial_bootstrap_distance_bins.csv`, `tables/spatial_bootstrap_logistic_model.csv` e `tables/regression_logistic_rescaled_odds_ratios.csv` foram gerados estritamente com **blocos de 30 km**.
- **Resolução de Inconsistências:** Quaisquer menções residuais a "20 km" correspondiam a comentários de código preliminares e foram formalmente retificadas para **30 km** (e 25.62 km para o alcance prático). A análise de sensibilidade em `tables/spatial_bootstrap_block_sensitivity.csv` avaliou blocos de **10 km**, **20 km** e **40 km** ao redor do padrão autoritativo de 30 km.

---

## 2. Limiares Autoritativos Pré-Registrados para H4

Calculados deterministicamente sobre a população congelada da Amostra Principal (20.000 pontos com pesos Horvitz-Thompson `design_weight_main`) a partir do arquivo analítico com SHA-256 verificado:
- **Hash SHA-256 de `data/processed/samples_annual.parquet`:**  
  `66f6d846679997eca4cb3df1588a43e12ccf375ae6239548d800be588df15916` (idêntico ao congelado no Checkpoint 3D).

### Limiares Determinísticos Congelados:
1. **$Q_1(H_{\mathrm{anual}})$ (25º percentil ponderado):** $\le \mathbf{0.809031}$
2. **$Q_1(JSD_{\mathrm{temporal}})$ (25º percentil ponderado):** $\le \mathbf{0.020682}$
3. **$Q_3(\text{stability})$ (75º percentil ponderado da população geral):** $\ge \mathbf{0.666667}$ (exatamente $2/3$, ou $\mathbf{0.6667}$)
4. **Distância mínima à borda temática ($d_{\mathrm{min}}$):** $\ge \mathbf{30.0\text{ m}}$

> **Nota de Resolução:** A menção isolada a "0.75" em rascunhos anteriores decorreu de erro de cópia a partir de `tables/hypothesis_h2_results.csv`, onde 0.75 representa o 75º percentil de estabilidade restrito ao subconjunto de concordância ($D=0$). Na população geral, o 75º percentil é **0.6667**. O código de teste de hipóteses (`03_hypothesis_tests_h1_h4.py`), a tabela oficial (`tables/hypothesis_h4_robust_disagreement.csv`) e a Figura 6 já utilizavam deterministicamente `0.666667`.

---

## 3. Decomposição Marginal e Conjunta de H4: Contagens Brutas vs. Ponderadas

Conforme diretriz do protocolo, a apresentação dos filtros de sobrevivência marginal para observações discordantes ($D=1$, total $N = 5.143$ pontos) reporta separadamente as grandezas não ponderadas e ponderadas:

| Filtro / Critério | Contagem Amostral Bruta ($n$) | Proporção Amostral Não Ponderada em $D=1$ (%) | Área Ponderada em $D=1$ (%) | Área Ponderada Expandida (ha) |
| :--- | :---: | :---: | :---: | :---: |
| **1. Total de Discordâncias ($D=1$)** | **5.143** | **100.0000%** | **100.0000%** | 7.479.568,87 ha |
| **2. Baixa Ambiguidade ($H \le 0.8090$)** | 985 | 19.1522% | 21.2580% | 1.589.988,96 ha |
| **3. Baixa Dinâmica ($JSD \le 0.0207$)** | 656 | 12.7552% | 11.5415% | 863.255,27 ha |
| **4. Alta Estabilidade ($S \ge 0.6667$)** | **45** | **0.8750%** | **0.9550%** | 71.429,19 ha |
| **5. Afastado da Borda ($d_{\mathrm{min}} \ge 30\text{ m}$)** | 4.866 | 94.6140% | 94.3322% | 7.055.641,64 ha |
| **Intersecção Bivariada ($H \le Q_1 \cap JSD \le Q_1$)** | 179 | 3.4805% | 3.3283% | 248.948,01 ha |
| **Intersecção Bivariada ($H \le Q_1 \cap S \ge Q_3$)** | **0** | **0.0000%** | **0.0000%** | 0,00 ha |
| **Intersecção Bivariada ($JSD \le Q_1 \cap S \ge Q_3$)** | 10 | 0.1944% | 0.2014% | 15.064,28 ha |
| **H4 Completo (Todas as 4 condições conjuntas)** | **0** | **0.0000%** | **0.0000%** | **0,00 ha** |

*Validação Robusta (40k):* Em $10.286$ pontos discordantes na amostra robusta de 40.000 pontos, registraram-se igualmente **0 observações** atendendo às quatro restrições conjuntas.

---

## 4. Estrutura do Desenho Amostral: Estratos vs. Subestratos

A terminologia do desenho amostral fica padronizada conforme as bases matemáticas auditadas:

1. **Estratos Científicos ($H = 16$):**
   - Cruzamento das 4 Unidades Federativas com os 4 Regimes temáticos ($\{\text{MA}, \text{TO}, \text{PI}, \text{BA}\} \times \{\text{AA}, \text{AN}, \text{NA}, \text{NN}\}$).
   - Definidos em `tables/sampling_quotas.csv`. Cada estrato possui cota fixa mínima pré-registrada de $n_h \ge 400$ pontos.
2. **Subestratos Operacionais de Amostragem ($S = 410$):**
   - Unidades espaciais de alocação de amostragem por fatia geográfica com área e população estritamente positivas ($N_{hs} > 0$), definidas em `tables/slice_sampling_allocation_final.csv`.
   - Cada subestrato operacional recebeu probabilidade de seleção estritamente positiva ($\pi_{hs} > 0$, garantia de zero $\pi = 0$).
3. **Avaliação dos Erros Padrão Analíticos:**
   - A aproximação analítica ponderada **não** implementa a estratificação operacional nem o FPC do desenho sem reposição congelado, tampouco a dependência espacial do terreno. Por essa razão metodológica, o **Spatial Block Bootstrap (1.999 replicações)** permanece como a autoridade inferencial primária do estudo.

---

## 5. Definição Matemática Autoritativa de $JSD_{\mathrm{temporal}}$

Fica terminantemente vedada a caracterização da JSD temporal como "divergência em relação ao modo anual" ou "afastamento do argmax".

- **Definição Autoritativa:**
  $$\bar{p} = \frac{1}{T} \sum_{m=1}^T p_m$$
  $$H(\bar{p}) = -\frac{1}{\ln 9} \sum_{k=1}^9 \bar{p}_k \ln \bar{p}_k$$
  $$\overline{H(p_m)} = \frac{1}{T} \sum_{m=1}^T H(p_m)$$
  $$JSD_{\mathrm{temporal}} = \max\left(0, H(\bar{p}) - \overline{H(p_m)}\right)$$
- **Nomenclatura Canônica no Manuscrito:** **Heterogeneidade temporal de Jensen-Shannon generalizada entre as distribuições mensais válidas de probabilidade**.

---

## 6. Padronização Espacial e Terminológica de H4

- **Substituição Obrigatória de Termos:**
  - *Eliminado:* "no interior de talhões"
  - *Adotado:* **"afastadas das bordas temáticas"** ou **"no interior das regiões tematicamente homogêneas segundo os produtos"**.
  - *Eliminado:* "alta certeza"
  - *Adotado:* **"baixa ambiguidade probabilística"** ($H \le Q_1$).

---

## 7. Tratamento dos Erros Padrão Analíticos

- A alegação de que *"erros analíticos subestimam a variância em 2.5x a 3.5x"* foi **removida**, por constituir inferência informal a partir de larguras de intervalos de confiança não tabulada de forma reprodutiva.
- Mantém-se exclusivamente a fundamentação formal: os erros padrão analíticos ponderados tratam observações como condicionalmente independentes sob ponderação amostral simples, sem incorporar o desenho estratificado por fatias, FPC ou a estrutura espacial autorregressiva do semivariograma. Portanto, os intervalos espaciais de 95% do block bootstrap constituem o critério primário de inferência.

---

## 8. Proveniência Oficial da Delimitação do MATOPIBA

A auditoria de proveniência não-mutante comprova todos os metadados necessários para a descrição metodológica do manuscrito:

- **Contagem Oficial de Municípios:** **337 municípios**.
  - Maranhão (MA): **135 municípios**
  - Tocantins (TO): **139 municípios**
  - Piauí (PI): **33 municípios**
  - Bahia (BA): **30 municípios**
- **Fonte da Lista Oficial de Municípios:** IBGE — Estrutura Territorial MATOPIBA 2021 (`MATOPIBA_2021.xls`), geoftp oficial.
- **Fonte da Malha Municipal Cartográfica:** IBGE — Serviço de Dados, API v3 de Malhas Geográficas (`servicodados.ibge.gov.br`).
- **Ano de Referência da Malha Cartográfica:** **2025** (`data=2025`, qualidade máxima).
- **CRS Original:** EPSG:4674 (SIRGAS 2000) / GeoJSON exportado em EPSG:4326 (WGS 84).
- **Área Geodésica Vetorial:** **73.082.921,02 ha** (diferença vs. raster MapBiomas: 0,34 ha, $4,7 \times 10^{-7}\%$).
- **Área Projetada (EPSG:5880):** **73.777.179,27 ha** ($737.771,79\text{ km}^2$).
- **Hashes Criptográficos Validados:**
  - `data/reference/matopiba_municipalities.csv`: `a6adf8e6d2500be1ab788f2128b7db263260455db95bea0d9e3ca173ef3266ca`
  - `data/reference/matopiba_boundary.geojson`: `716df1361fee63c453ef96e7a59c92b3317175ed98e83d1cb053b37e3b3c20c8`
- **Frase Canônica do Manuscrito:**  
  *"A delimitação operacional do MATOPIBA foi reconstruída a partir da lista oficial de 337 municípios do IBGE e da malha municipal cartográfica do IBGE 2025."*

---

## 9. Matriz de Classificação de Consistência entre Arquivos

| Termo / Expressão | Ocorrências Identificadas | Classificação | Ação Realizada / Status |
| :--- | :--- | :--- | :--- |
| **"20 km"** | Docstrings de `05_spatial_block_bootstrap.py`; seção 5 de `checkpoint_4b_interpretation_audit.md` | `NEEDS_CORRECTION` | Corrigido para **30 km** (tamanho do bloco) e **25.62 km** (alcance prático). O valor "20 km" permanece válido apenas como cenário da análise de sensibilidade em `tables/spatial_bootstrap_block_sensitivity.csv`. |
| **"30 km"** | Parâmetro empírico em `spatial_semivariogram_parameters.csv`; variável `primary_block_km` em `05_spatial_block_bootstrap.py` | `CURRENT_VALID` | Autoridade confirmada em todos os artefatos de inferência espacial. |
| **"0.6667" / "0.666667"** | `tables/descriptive_continuous_indicators.csv`; limiar de H4 em `03_hypothesis_tests_h1_h4.py` | `CURRENT_VALID` | Limiar autoritativo de Q3(stability) na população geral confirmado. |
| **"0.75"** | Texto de `checkpoint_4b_interpretation_audit.md` como limiar de H4 | `HISTORICAL_INVALID` | Corrigido para **0.6667**. O valor 0.75 permanece válido apenas como Q3 restrito aos concordantes ($D=0$) em `hypothesis_h2_results.csv` e como `step=0.75` deg em scripts de particionamento GEE. |
| **"16 estratos"** | Quotas e estratos científicos em `PROJECT_BRIEF.md`, `sampling_quotas.csv` | `CURRENT_VALID` | Confirmado como número exato de estratos científicos ($4 \times 4$). |
| **"44 estratos"** | Rascunho de comentário no Checkpoint 4B | `HISTORICAL_INVALID` | Eliminado; substituído pela distinção precisa entre 16 estratos científicos e 410 subestratos operacionais de fatia. |
| **"decaimento estritamente monótono"** | Textos anteriores ao Checkpoint 4B | `HISTORICAL_INVALID` | Removido. H3 classificada como **PARCIALMENTE APOIADA** com não-monotonicidade local entre 10–30 m e 30–60 m. |
| **"deviance explicada"** | Antiga descrição do pseudo-$R^2$ de McFadden | `HISTORICAL_INVALID` | Substituído por **McFadden pseudo-$R^2 = 0.488$**, indicando forte ajuste relativo sem percentual de variância/deviance explicada. |
| **"interior de talhões"** | Texto preliminar de H4 | `NEEDS_CORRECTION` | Substituído por **"afastadas das bordas temáticas (no interior das regiões tematicamente homogêneas segundo os produtos)"**. |
| **"em relação ao modo anual"** | Texto preliminar de H2a | `NEEDS_CORRECTION` | Substituído por **"heterogeneidade temporal de Jensen-Shannon generalizada entre as distribuições mensais"**. |
| **"incerteza espectral" / "fenológica"** | Alegações causais prévias de H4 | `HISTORICAL_INVALID` | Eliminadas; mantida a constatação empírica de ausência amostral sob a definição pré-registrada. |

---

## 10. Manifesto e Checksums dos 31 Artefatos Congelados para o Manuscrito

Artefatos oficiais materializados:
- [`tables/manuscript_results_manifest.csv`](file:///c:/Users/Altair/Documents/Dynamic%20World%20x%20MapBiomas/Dynamic-World-MapBiomas/tables/manuscript_results_manifest.csv)
- [`tables/manuscript_results_checksums.sha256`](file:///c:/Users/Altair/Documents/Dynamic%20World%20x%20MapBiomas/Dynamic-World-MapBiomas/tables/manuscript_results_checksums.sha256)

### Tabela Resumo dos 31 Artefatos Congelados:

| Categoria | Caminho Relativo do Arquivo | SHA-256 (64 hex) |
| :--- | :--- | :--- |
| `descriptive_tables` | `tables/descriptive_regime_proportions.csv` | `6ae480a402325ae877b0bebfba463378342217cbf4061a5b4c126d4ca91880a1` |
| `descriptive_tables` | `tables/descriptive_state_proportions.csv` | `052e0085a676b92f442f494a8e2cb92fa1f750e41b9d1f33f6a6ca72a85970c7` |
| `descriptive_tables` | `tables/descriptive_continuous_indicators.csv` | `9b8fc69fa208c9035e408ec21f6a157e937d25e0be9a039750529e8c33cebaeb` |
| `descriptive_tables` | `tables/descriptive_robust_40k_comparison.csv` | `e0ba63507026df21a22b7eb1ba49c33e887f43a0d5e12f60d96d92db9f8fb173` |
| `h1_table` | `tables/hypothesis_h1_results.csv` | `295a0bc0c50dcf3f2e1a3bc862be0fe29bc181e4b308be7e1c8d523689403d52` |
| `h2_table` | `tables/hypothesis_h2_results.csv` | `26b3fa24fbeec69fec6f10fa65c71a357f00ca095fef54e1781297e68ee291fb` |
| `h3_table` | `tables/hypothesis_h3_distance_bins.csv` | `5c73d93138378bf2dbfeaa6203cfeb58223c66f91ec0b2639fb2be1c778262ea` |
| `h4_table` | `tables/hypothesis_h4_robust_disagreement.csv` | `f6a41fdfcf4bdfc919d363294377dd9f5d34a41315fcb2ebdfbbd92a0ff82806` |
| `regression_table_primary` | `tables/regression_logistic_rescaled_odds_ratios.csv` | `a906231d87e076fb4407b4d1b8c2df57451944dd6e0ce3e9702ba064e62fe0e4` |
| `regression_table_supplementary` | `tables/regression_logistic_primary_model.csv` | `5c84d65123d1306a4b16dbd783d722fc2dbe0db22822ca6d5ea2f37c3558184f` |
| `regression_table_comparison` | `tables/regression_model_comparison.csv` | `c07fce72d4cf9e31d457636e0d37e0fa0c1c4f686c4f74d0089857d42da34645` |
| `regression_table_diagnostics` | `tables/regression_collinearity_diagnostics.csv` | `233634eec3975ba5a895d52bc194602f0943eb918f6f5a34ec8d8d3f1eb5e407` |
| `spatial_bootstrap_tables` | `tables/spatial_semivariogram_parameters.csv` | `b6801837b2d294ae076046e7f226b9a89cfa6b0cfa0bfa4cc8fdfaa1ae4268e2` |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_contrasts.csv` | `37497d51ee2bc3a563d7675f9227f2f1e68ae415fa9fbe6846bf4849265f470a` |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_distance_bins.csv` | `5c37894e77519ea8149e2908f5d0263f9ebba631a299066eb253b750130616b2` |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_logistic_model.csv` | `05073e6b77c8e96bfdf27bc0f7eb618a80d52ff2e6fc85e5052960682245b08e` |
| `spatial_bootstrap_tables` | `tables/spatial_bootstrap_block_sensitivity.csv` | `dbfa1dd282365bb5ca07c427387dc816aa19d2b96057a1e2f495147ae5345704` |
| `robustness_tables` | `tables/robustness_r1_sample_size_comparison.csv` | `d72aa982cf6db8b5df8e76c12c5bfe63d7a9640984eeea5f0a071d18721c563e` |
| `robustness_tables` | `tables/robustness_r2_strict_crosswalk_comparison.csv` | `ebbe4bc6ca5f03d517c24f5a363fc4ec62b66236b3262eb1d91653ccab7b3117` |
| `robustness_tables` | `tables/robustness_r3_mapbiomas_stability_subset.csv` | `d6dfb8d8102a061405e608034a742874df1cfdb12f6a61775efc078000490b43` |
| `robustness_tables` | `tables/robustness_comprehensive_summary.csv` | `61f1ae5c79603c621bcdafa068e833441fb42ea9171f654b9d885a53e6d2bc60` |
| `figures` | `figures/fig1_composition_regimes.png` | `abf34d1bcbe35eebdf6ca2234057884ff2db4d35e1d9d9f583f7d14feea7fb62` |
| `figures` | `figures/fig2_h_annual_distribution.png` | `0910f54070a7bbcf31215bb4b712c96c4b9cfcf068595feea3cbf536ea1f86f8` |
| `figures` | `figures/fig3_jsd_temporal_distribution.png` | `b3d875a5960098f98a39c9df3a0bcfd9bceba83e7eeae09559f97973715d2a76` |
| `figures` | `figures/fig4_stability_distribution.png` | `6256f1406aa863c01bf0285be5ea3df6dcf15444ca761bebe1c43231405d436a` |
| `figures` | `figures/fig5_disagreement_by_distance_bin.png` | `f047ff9cc2624aa763ea119d691bc1c2ccf99f3630f9be3ecb0d10d9fa378d38` |
| `figures` | `figures/fig6_h4_robust_disagreement_characterization.png` | `bf8356972236d65457ef45fa95781a76f2bc8bc31f3efc55209ea9b392e212ea` |
| `protocol_amendment` | `docs/protocol_amendment_checkpoint_3d.md` | `a3e9c5661413811f5869bf00f40df83b27670732ee74b6db2b9c7e09ae2bc961` |
| `boundary_provenance` | `data/reference/matopiba_boundary.geojson` | `716df1361fee63c453ef96e7a59c92b3317175ed98e83d1cb053b37e3b3c20c8` |
| `boundary_provenance` | `data/reference/matopiba_municipalities.csv` | `a6adf8e6d2500be1ab788f2128b7db263260455db95bea0d9e3ca173ef3266ca` |
| `boundary_provenance` | `data/reference/matopiba_states.geojson` | `a3915f76f7f3cb7aa350a4d048455ca3922e9643d526fa171a819b788a8798bf` |

---

## 11. Conclusão da Auditoria do Checkpoint 4C

Todos os 8 requisitos do Checkpoint 4C foram atendidos com rigor matemático, exatidão empírica e rastreabilidade criptográfica integral. O projeto encontra-se completamente estabilizado e formalmente autorizado para a redação científica.

**RESULTADO FINAL:** **CHECKPOINT 4C: PASS**
